(() => {
  "use strict";
  const $=(s,r=document)=>r.querySelector(s),login=$("#login-view"),dash=$("#dashboard-view"),out=$("#admin-content"),note=$("#admin-notice"),err=$("#admin-error");
  let data=null,tab="deposits",busy=false;
  let transactionHistory=null;
  const scopePath=()=>{const raw=location.pathname.split("/").filter(Boolean)[0]||"";try{return decodeURIComponent(raw);}catch(_){return raw;}};
  const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const money=v=>`${Number(v||0).toLocaleString("fr-FR")} FCFA`,date=v=>v?new Date(v).toLocaleString("fr-FR"):"—";
  const api=async(url,o={})=>{const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);try{const r=await fetch(url,{credentials:"same-origin",...o,signal:controller.signal,headers:{"Content-Type":"application/json",...(o.headers||{})}}),b=await r.json().catch(()=>({}));if(!r.ok){const e=new Error(b.error||"Action impossible.");e.status=r.status;throw e;}return b;}catch(error){if(error.name==="AbortError")throw new Error("La connexion prend trop de temps. Veuillez réessayer.");throw error;}finally{clearTimeout(timer)}};
  let loadRequest=null,dataVersion=0,socialRefreshing=false;
  function updateBusy(){const loading=Boolean(loadRequest)||busy||socialRefreshing;dash.classList.toggle("admin-refreshing",loading);dash.setAttribute("aria-busy",String(loading));$("#refresh").disabled=loading;$("#refresh").setAttribute("aria-label",loading?"Actualisation en cours":"Actualiser");}
  const socialAdmin=createSocialAdmin(out,true,()=>tab==="social"&&!dash.hidden);
  function createSocialAdmin(root,cameroonOnly,isActive=()=>true){
    const base=cameroonOnly?"/api/cameroon-admin/social/posts":"/api/admin/social/posts";
    const states=["pending","approved","rejected"],labels={pending:"En attente",approved:"Approuvés",rejected:"Rejetés"};
    let status="pending",posts=[],nextCursor=null,cursors=[null],page=0,loaded=false,loading=false,mutating=false,message="",messageBad=false,requestGeneration=0;
    const escape=value=>String(value??"").replace(/[&<>"']/g,char=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
    const displayDate=value=>{if(!value)return"—";const parsed=new Date(value);return Number.isNaN(parsed.getTime())?"—":parsed.toLocaleString("fr-FR");};
    function updateFeedback(){const node=root.querySelector("[data-social-feedback]");if(!node)return;node.textContent=message;node.hidden=!message;node.className=`social-message ${messageBad?"is-error":"is-success"}`;node.setAttribute("role",messageBad?"alert":"status");}
    async function request(url,options={}){
      const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
      try{
        const response=await fetch(url,{credentials:"same-origin",...options,signal:options.signal||controller.signal,headers:{"Content-Type":"application/json",...(options.headers||{})}});
        const body=await response.json().catch(()=>({}));
        if(!response.ok)throw new Error(body.error||"Action impossible.");
        return body;
      }catch(error){if(error.name==="AbortError")throw new Error("La connexion prend trop de temps. Veuillez réessayer.");throw error;}
      finally{clearTimeout(timer);}
    }
    function render(){
      if(!isActive())return;
      if(!loaded&&!loading){root.innerHTML='<section class="admin-panel"><h2>Blogue</h2><p role="status">Chargement sécurisé…</p></section>';load();return;}
      const cards=posts.map(post=>{
        const author=post.author||{},images=Array.isArray(post.images)?post.images:[];
        const imageMarkup=images.map((image,index)=>{
          const id=String(image?.id||"");
          if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id))return "";
          return `<img src="/api/social/images/${escape(id)}" alt="Image ${index+1} du dossier" loading="lazy">`;
        }).join("");
        const review=post.status==="rejected"&&post.reviewNote?`<p class="social-review-note"><strong>Motif de refus :</strong> ${escape(post.reviewNote)}</p>`:"";
        let actions=post.status==="pending"?`<div class="social-review-actions"><form data-social-action="approve"><label>Bonus (FCFA)<input name="bonus" type="number" min="1" max="100000" step="1" inputmode="numeric" required aria-label="Bonus entier en FCFA (1 à 100 000)"></label><button type="submit" class="social-approve">Approuver et créditer le bonus</button></form><form data-social-action="reject"><label>Motif du refus<textarea name="reason" minlength="1" maxlength="1000" rows="3" required></textarea></label><button type="submit" class="social-reject">Refuser le dossier</button></form></div>`:"";
        actions+=`<div class="social-delete-actions"><button type="button" class="social-reject" data-social-delete="${escape(post.id)}">Annuler et supprimer définitivement</button><small>Supprime la publication et ses images du fil.${post.status==="approved"?" La prime déjà versée reste acquise.":""}</small></div>`;
        return `<article class="admin-list-card social-post-card" data-social-post="${escape(post.id)}"><div class="social-post-top"><div><span class="admin-status ${escape(post.status)}">${escape(labels[post.status]||post.status)}</span><h3>Dossier · ${escape(author.registrationNumber||"Inscription inconnue")}</h3></div><small>${escape(displayDate(post.createdAt))}</small></div><p class="social-post-caption">${escape(post.caption)}</p><div class="social-post-meta"><span><strong>Pays</strong>${escape(author.country||"Non renseigné")}</span><span><strong>Utilisateur</strong>#${escape(author.userId??"—")}</span><span><strong>Soumis le</strong>${escape(displayDate(post.createdAt))}</span><span><strong>Approuvé le</strong>${escape(displayDate(post.approvedAt))}</span>${post.status==="approved"?`<span><strong>Bonus versé</strong>${escape(Number(post.bonus||0).toLocaleString("fr-FR"))} FCFA</span>`:""}</div><div class="social-post-images" aria-label="${images.length} image(s)">${imageMarkup}</div>${review}${actions}</article>`;
      }).join("");
      root.innerHTML=`<section class="admin-panel social-admin-panel"><header class="social-admin-heading"><div><h2>Blogue · Cameroun</h2><p>Examinez uniquement les dossiers des comptes camerounais.</p></div></header><div class="social-status-filters" role="group" aria-label="Filtrer les dossiers">${states.map(value=>`<button type="button" data-social-status="${value}" class="${status===value?"active":""}" aria-pressed="${status===value}">${labels[value]}</button>`).join("")}</div><p class="social-message ${messageBad?"is-error":"is-success"}" data-social-feedback role="${messageBad?"alert":"status"}" ${message?"":"hidden"}>${escape(message)}</p>${loading&&!loaded?'<p role="status">Chargement des dossiers…</p>':cards?`<div class="social-post-list">${cards}</div>`:'<p class="admin-empty">Aucun dossier dans cette catégorie.</p>'}<nav class="social-pagination" aria-label="Pagination des dossiers"><button type="button" data-social-page="previous" ${page===0||mutating?"disabled":""}>Précédent</button><span>Page ${page+1}</span><button type="button" data-social-page="next" ${!nextCursor||mutating?"disabled":""}>Suivant</button></nav></section>`;
      root.querySelectorAll('[data-social-action] button,[data-social-delete]').forEach(button=>{button.disabled=mutating;});
    }
    async function deletePublication(postId){
      if(mutating||!posts.some(post=>post.id===postId))return;
      if(!window.confirm("Annuler et supprimer définitivement cette publication, ses images, ses mentions J’aime et ses vues ? Elle disparaîtra du fil. Cette action est irréversible. Les primes déjà versées restent acquises."))return;
      mutating=true;requestGeneration++;message="";messageBad=false;
      root.querySelectorAll('[data-social-action] button,[data-social-delete]').forEach(button=>button.disabled=true);
      try{
        const result=await request(`${base}/${encodeURIComponent(postId)}`,{method:"DELETE"});
        if(!result.ok||!result.deleted)throw new Error("La suppression n’a pas été confirmée par le serveur.");
        posts=posts.filter(post=>post.id!==postId);cursors=[null];page=0;nextCursor=null;render();
        const refreshed=await load();
        message=refreshed?"Publication et images supprimées définitivement.":"Publication supprimée définitivement. Actualisation impossible : "+message;messageBad=!refreshed;
      }catch(error){message=error.message;messageBad=true;}
      finally{mutating=false;root.querySelectorAll('[data-social-action] button,[data-social-delete]').forEach(button=>button.disabled=false);updateFeedback();}
    }
    async function load(){
      const generation=++requestGeneration;
      loading=true;
      const cursor=cursors[page],requestedStatus=status,query=new URLSearchParams({status:requestedStatus});
      if(cursor)query.set("cursor",cursor);
      try{
        const result=await request(`${base}?${query.toString()}`);
        if(generation!==requestGeneration)return false;
        if(!result||!Array.isArray(result.posts)||!(result.nextCursor===null||typeof result.nextCursor==="string"))throw new Error("Réponse de dossiers invalide.");
        posts=result.posts;nextCursor=result.nextCursor;loaded=true;loading=false;message="";messageBad=false;render();return true;
      }catch(error){if(generation!==requestGeneration)return false;loading=false;message=error.message;messageBad=true;if(!isActive())return false;if(!loaded){root.innerHTML=`<section class="admin-panel social-admin-panel"><h2>Blogue</h2><p class="social-message is-error" role="alert">${escape(message)}</p><button type="button" data-social-retry="1">Réessayer</button></section>`;}else{render();}return false;}
    }
    root.addEventListener("click",event=>{
      const button=event.target.closest("button");if(!button||!root.contains(button))return;
      if(mutating)return;
      if(button.dataset.socialDelete){deletePublication(button.dataset.socialDelete);return;}
      if(button.dataset.socialRetry){message="";load();return;}
      if(button.dataset.socialStatus){status=button.dataset.socialStatus;requestGeneration++;loading=false;cursors=[null];page=0;posts=[];nextCursor=null;loaded=false;message="";render();return;}
      if(button.dataset.socialPage==="previous"&&page>0){page--;message="";load();return;}
      if(button.dataset.socialPage==="next"&&nextCursor){cursors=cursors.slice(0,page+1);cursors.push(nextCursor);page++;message="";load();}
    });
    root.addEventListener("submit",async event=>{
      const form=event.target.closest("form[data-social-action]");if(!form||!root.contains(form))return;
      event.preventDefault();if(mutating)return;
      if(!form.reportValidity())return;
      const card=form.closest("[data-social-post]"),postId=card?.dataset.socialPost;
      if(!postId)return;
      const action=form.dataset.socialAction,raw=action==="approve"?form.elements.bonus.value:form.elements.reason.value;
      const amount=Number(raw),reason=String(raw).trim();
      if(action==="approve"&&(!Number.isSafeInteger(amount)||amount<1||amount>100000)){form.elements.bonus.focus();return;}
      if(action==="reject"&&(!reason||Array.from(raw).length>500)){form.elements.reason.focus();return;}
      const confirmation=action==="approve"?`Approuver et créditer le bonus de ${amount.toLocaleString("fr-FR")} FCFA ?`:"Confirmer le refus de ce dossier ?";
      if(!window.confirm(confirmation))return;
      mutating=true;message="";messageBad=false;root.querySelectorAll('[data-social-action] button').forEach(button=>button.disabled=true);
      try{
        await request(`${base}/${encodeURIComponent(postId)}/${action}`,{method:"POST",body:JSON.stringify(action==="approve"?{bonus:amount}:{reason})});
        const refreshed=await load();
        if(refreshed){message=action==="approve"?"Dossier approuvé et bonus crédité.":"Dossier refusé.";messageBad=false;}
        else{message=`Action enregistrée par le serveur. Actualisation impossible : ${message}`;messageBad=true;}
      }catch(error){message=error.message;messageBad=true;}
      finally{mutating=false;root.querySelectorAll('[data-social-action] button').forEach(button=>button.disabled=false);updateFeedback();}
    });
    return {render,refresh(){if(loading||mutating)return;message="";messageBad=false;return load();}};
  }
  const msg=(text,bad=false)=>{const active=bad?err:note,inactive=bad?note:err;inactive.hidden=true;active.textContent=text;active.hidden=!text;};
  const status=v=>`<span class="admin-status ${esc(v)}">${esc(v)}</span>`;
  const copyable=v=>`<span class="admin-copyable-value"><span>${esc(v||"—")}</span></span>`;
  function card(t){
    const withdrawal=t.type==="withdrawal";
    const adminLabel=t.adminAssisted?`<div class="admin-assistance-banner"><strong>ADMIN</strong><span>${t.hasAdminCredit&&t.hasAdminVipGrant?"Crédit et VIP admin":t.hasAdminCredit?"Crédit admin":"VIP admin"}</span></div>`:"";
    return `<article class="admin-list-card admin-transaction-card">${adminLabel}<div class="admin-transaction-details"><div class="admin-transaction-title"><strong class="${withdrawal?"admin-red-text":"admin-green-text"}">${money(t.amount)}</strong>${status(t.status)}</div><div class="admin-detail-grid"><small><b>N° d’inscription</b>${copyable(t.registrationNumber)}</small><small><b>Utilisateur</b><span>#${esc(t.userId)}</span></small><small><b>Pays</b><span>Cameroun (+237)</span></small><small><b>Opérateur</b><span>${esc(t.operatorName||"Non renseigné")}</span></small><small><b>${withdrawal?"Numéro de réception":"Compte payeur"}</b>${copyable(t.payerNumber||t.destination)}</small><small><b>Référence</b>${copyable(t.reference)}</small><small><b>Initiation</b><span>${date(t.createdAt)}</span></small>${withdrawal?`<small><b>Frais</b><span>${money(t.fee)}</span></small><small><b>Net à envoyer</b><span>${money(t.netAmount)}</span></small>`:""}</div></div><div class="admin-card-actions admin-icon-actions"><button type="button" class="approve" data-id="${esc(t.id)}" data-type="${esc(t.type)}" data-action="completed" title="Valider">✓</button><button type="button" class="reject" data-id="${esc(t.id)}" data-type="${esc(t.type)}" data-action="rejected" title="Refuser">×</button></div></article>`;
  }
  function render(){
    document.querySelectorAll("[data-tab]").forEach(button=>button.classList.toggle("active",button.dataset.tab===tab));
    if(!data)return;
    if(tab==="history"&&window.createAdminTransactionHistory){
      if(!transactionHistory)transactionHistory=window.createAdminTransactionHistory({root:out,api,scope:"cameroon",isActive:()=>Boolean(data)&&tab==="history",
        onMutation:async()=>{dataVersion++;await load({force:true,renderView:false});}});
      transactionHistory.mount();return;
    }
    transactionHistory?.invalidate();
    if(tab==="social"){socialAdmin.render();return;}
    const labels={deposits:"Dépôts en attente",normalWithdrawals:"Retraits normaux en attente",adminWithdrawals:"Retraits avec crédit admin en attente"};
    const list=data?.[tab]||[];
    out.innerHTML=`<section class="admin-stats-grid"><article class="admin-stat-card"><div><strong>${esc(data?.stats?.pendingDeposits||0)}</strong><small>Dépôts</small></div></article><article class="admin-stat-card"><div><strong>${esc(data?.stats?.pendingNormalWithdrawals||0)}</strong><small>Retraits normaux</small></div></article><article class="admin-stat-card"><div><strong>${esc(data?.stats?.pendingAdminWithdrawals||0)}</strong><small>Retraits crédit admin</small></div></article></section><section class="admin-panel"><h2>${labels[tab]}</h2><div class="admin-list">${list.map(card).join("")||'<p class="admin-empty">Aucune opération camerounaise en attente.</p>'}</div></section>`;
  }
  async function load({force=false,renderView=true}={}){
    if(loadRequest){await loadRequest;if(force)return load({force:true,renderView});return;}
    const version=dataVersion;
    if(!data)out.innerHTML='<div class="admin-panel admin-panel-loading" role="status">Chargement sécurisé…</div>';
    loadRequest=(async()=>{try{
      const result=await api("/api/cameroon-admin/pending");
      if(version!==dataVersion)return;
      data=result;login.hidden=true;dash.hidden=false;if(renderView)render();
    }catch(error){
      if(version!==dataVersion)return;
      if(error.status===401){data=null;dash.hidden=true;login.hidden=false;}
      else{msg(error.message,true);if(!data){login.hidden=true;dash.hidden=false;out.innerHTML=`<div class="admin-panel admin-panel-loading" role="alert">${esc(error.message)}<br><button type="button" data-retry-overview="1">Réessayer</button></div>`;}}
    }finally{loadRequest=null;updateBusy();}})();
    updateBusy();await loadRequest;
  }
  async function act(transaction){
    if(busy)return;
    let proofReference;
    const record=(data?.deposits||[]).find(item=>String(item.id)===String(transaction.id));
    const manual=Boolean(record)&&(record.paymentProvider??record.payment_provider??"manual")==="manual";
    if(transaction.type==="deposit"&&transaction.action==="completed"&&!manual){
      proofReference=window.prompt("Référence opérateur unique confirmant le dépôt :","")?.trim();
      if(!proofReference)return msg("La référence opérateur est obligatoire.",true);
    }
    const verb=transaction.action==="rejected"?"refuser":"valider";
    if(!window.confirm(`Confirmer : ${verb} cette opération camerounaise ?`))return;
    busy=true;dataVersion++;updateBusy();
    try{
      const endpoint=transaction.type==="withdrawal"?"withdrawals":"deposits";
      await api(`/api/cameroon-admin/${endpoint}/${transaction.id}`,{method:"PATCH",body:JSON.stringify({status:transaction.action,...(proofReference?{proofReference}:{})})});
      dataVersion++;
      const id=String(transaction.id);
      if(transaction.type==="deposit")data.deposits=(data.deposits||[]).filter(item=>String(item.id)!==id);
      else{
        data.normalWithdrawals=(data.normalWithdrawals||[]).filter(item=>String(item.id)!==id);
        data.adminWithdrawals=(data.adminWithdrawals||[]).filter(item=>String(item.id)!==id);
      }
      if(transaction.type==="deposit")data.stats.pendingDeposits=Math.max(0,Number(data.stats.pendingDeposits||0)-1);
      else if(transaction.adminAssisted)data.stats.pendingAdminWithdrawals=Math.max(0,Number(data.stats.pendingAdminWithdrawals||0)-1);
      else data.stats.pendingNormalWithdrawals=Math.max(0,Number(data.stats.pendingNormalWithdrawals||0)-1);
      render();msg("Opération retirée de la file.");await load({force:true});
    }catch(error){msg(error.message,true);}finally{busy=false;updateBusy();}
  }
  $("#admin-login").addEventListener("submit",async event=>{event.preventDefault();const button=event.currentTarget.querySelector('button[type="submit"]'),error=$("#login-error");if(button.disabled)return;button.disabled=true;button.setAttribute("aria-busy","true");error.hidden=true;try{await api("/api/cameroon-admin/login",{method:"POST",body:JSON.stringify({password:$("#admin-password").value,path:scopePath()})});$("#admin-password").value="";await load({force:true});}catch(reason){error.textContent=reason.message;error.hidden=false;}finally{button.disabled=false;button.removeAttribute("aria-busy");}});
  $(".admin-password-toggle").addEventListener("click",event=>{const field=$("#admin-password"),visible=field.type==="text";field.type=visible?"password":"text";event.currentTarget.textContent=visible?"Afficher":"Masquer";});
  $(".admin-runtime-nav").addEventListener("click",event=>{const button=event.target.closest("[data-tab]");if(button&&button.dataset.tab!==tab){tab=button.dataset.tab;render();}});
  out.addEventListener("click",event=>{if(event.target.closest("[data-retry-overview]"))return load();const button=event.target.closest("[data-action]");if(button)act(button.dataset);});
  $("#refresh").addEventListener("click",async()=>{if(busy||socialRefreshing)return;if(tab!=="social")return load();socialRefreshing=true;updateBusy();try{await socialAdmin.refresh();}finally{socialRefreshing=false;updateBusy();}});
  $("#logout").addEventListener("click",async()=>{dataVersion++;data=null;try{await api("/api/cameroon-admin/logout",{method:"POST"});}finally{dash.hidden=true;login.hidden=false;out.innerHTML="";}});
  load();
})();