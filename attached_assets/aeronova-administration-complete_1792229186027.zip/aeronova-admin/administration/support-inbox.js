(() => {
  'use strict';
  window.renderSupportInbox=({root,api,isActive})=>{
    let page=0,busy=false;
    const element=(tag,text,className)=>{
      const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(className)node.className=className;return node;
    };
    const load=async()=>{
      if(busy)return;busy=true;
      const panel=element('section',undefined,'admin-panel');
      panel.append(element('h2','Demandes Service client'),element('p','Chargement des demandes…'));
      root.replaceChildren(panel);
      try{
        const data=await api(`/api/admin/support/requests?page=${page}`);
        if(!isActive())return;
        panel.replaceChildren(element('h2','Demandes Service client'));
        if(!data.requests?.length)panel.append(element('p','Aucune demande enregistrée.'));
        for(const request of data.requests||[]){
          const card=element('article',undefined,'admin-panel');
          card.append(element('h3',request.subject),
            element('p',`Compte : ${request.phone} · ${request.country} · ${new Date(request.created_at).toLocaleString('fr-FR')}`),
            element('small',`Référence : ${request.id}`));
          const message=element('p',request.message);message.style.whiteSpace='pre-wrap';message.style.overflowWrap='anywhere';card.append(message);
          for(const attachment of request.attachments||[]){
            const link=element('a',`${attachment.name} (${Math.ceil(attachment.size/1024)} Ko)`);
            link.href=`/api/admin/support/attachments/${encodeURIComponent(attachment.id)}`;
            link.style.display='block';link.style.padding='12px 0';card.append(link);
          }
          const handled=request.status==='handled';
          card.append(element('p',handled?'Traitée':'À traiter'));
          if(!handled){
            const button=element('button','Marquer comme traitée');
            button.type='button';button.onclick=async()=>{
              button.disabled=true;
              try{
                await api(`/api/admin/support/requests/${request.id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:'handled'})});
                if(isActive()){busy=false;load();}
              }catch(error){if(isActive()){button.disabled=false;card.append(element('p',error.message));}}
            };card.append(button);
          }
          panel.append(card);
        }
        const previous=element('button','Précédent'),next=element('button','Suivant');
        previous.type=next.type='button';previous.disabled=page===0;next.disabled=!data.hasMore;
        previous.onclick=()=>{if(!busy){page--;load();}};next.onclick=()=>{if(!busy){page++;load();}};
        panel.append(previous,element('span',` Page ${page+1} `),next);
      }catch(error){
        if(isActive()){
          const retry=element('button','Réessayer');retry.type='button';retry.onclick=load;
          panel.replaceChildren(element('h2','Demandes Service client'),element('p',error.message),retry);
        }
      }finally{busy=false;}
    };
    load();
  };
})();
