import { useState } from "react";
import { PAYMENT_OPERATORS, type PaymentOperator } from "../../shared/payment-config";

export type OperatorPreset = PaymentOperator;

export const OPERATOR_PRESETS = PAYMENT_OPERATORS;

export function OperatorLogo({
  logoText,
  logoColor,
  logoUrl = "",
  size = 42,
}: {
  logoText: string;
  logoColor: string;
  logoUrl?: string;
  size?: number;
}) {
  const [failedUrl, setFailedUrl] = useState("");
  const showImage = Boolean(logoUrl) && failedUrl !== logoUrl;

  return (
    <span
      className="operator-logo"
      style={{ width: size, height: size, background: showImage ? "transparent" : logoColor }}
      aria-hidden="true"
    >
      {showImage
        ? <img src={logoUrl} alt="" onError={() => setFailedUrl(logoUrl)} />
        : <strong>{logoText.slice(0, 4).toUpperCase()}</strong>}
    </span>
  );
}import { useState } from "react";
import { PAYMENT_OPERATORS, type PaymentOperator } from "../../shared/payment-config";

export type OperatorPreset = PaymentOperator;

export const OPERATOR_PRESETS = PAYMENT_OPERATORS;

export function OperatorLogo({
  logoText,
  logoColor,
  logoUrl = "",
  size = 42,
}: {
  logoText: string;
  logoColor: string;
  logoUrl?: string;
  size?: number;
}) {
  const [failedUrl, setFailedUrl] = useState("");
  const showImage = Boolean(logoUrl) && failedUrl !== logoUrl;

  return (
    <span
      className="operator-logo"
      style={{ width: size, height: size, background: showImage ? "transparent" : logoColor }}
      aria-hidden="true"
    >
      {showImage
        ? <img src={logoUrl} alt="" onError={() => setFailedUrl(logoUrl)} />
        : <strong>{logoText.slice(0, 4).toUpperCase()}</strong>}
    </span>
  );
}import { useState } from "react";
import { PAYMENT_OPERATORS, type PaymentOperator } from "../../shared/payment-config";

export type OperatorPreset = PaymentOperator;

export const OPERATOR_PRESETS = PAYMENT_OPERATORS;

export function OperatorLogo({
  logoText,
  logoColor,
  logoUrl = "",
  size = 42,
}: {
  logoText: string;
  logoColor: string;
  logoUrl?: string;
  size?: number;
}) {
  const [failedUrl, setFailedUrl] = useState("");
  const showImage = Boolean(logoUrl) && failedUrl !== logoUrl;

  return (
    <span
      className="operator-logo"
      style={{ width: size, height: size, background: showImage ? "transparent" : logoColor }}
      aria-hidden="true"
    >
      {showImage
        ? <img src={logoUrl} alt="" onError={() => setFailedUrl(logoUrl)} />
        : <strong>{logoText.slice(0, 4).toUpperCase()}</strong>}
    </span>
  );
}import { useState } from "react";
import { PAYMENT_OPERATORS, type PaymentOperator } from "../../shared/payment-config";

export type OperatorPreset = PaymentOperator;

export const OPERATOR_PRESETS = PAYMENT_OPERATORS;

export function OperatorLogo({
  logoText,
  logoColor,
  logoUrl = "",
  size = 42,
}: {
  logoText: string;
  logoColor: string;
  logoUrl?: string;
  size?: number;
}) {
  const [failedUrl, setFailedUrl] = useState("");
  const showImage = Boolean(logoUrl) && failedUrl !== logoUrl;

  return (
    <span
      className="operator-logo"
      style={{ width: size, height: size, background: showImage ? "transparent" : logoColor }}
      aria-hidden="true"
    >
      {showImage
        ? <img src={logoUrl} alt="" onError={() => setFailedUrl(logoUrl)} />
        : <strong>{logoText.slice(0, 4).toUpperCase()}</strong>}
    </span>
  );
}