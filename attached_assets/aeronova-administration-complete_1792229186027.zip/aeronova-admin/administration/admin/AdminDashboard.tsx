import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import {
  ArrowDownToLine,
  ArrowLeft,
  ArrowUpFromLine,
  Ban,
  Check,
  Copy,
  EyeOff,
  Gift,
  LockKeyhole,
  LogOut,
  Megaphone,
  Package,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  Send,
  ShieldCheck,
  Trash2,
  Users,
  Wallet,
  X,
} from "lucide-react";
import { api, formatFcfa, request } from "../api";
import { OperatorLogo, OPERATOR_PRESETS } from "./OperatorLogos";
import { PAYMENT_COUNTRIES } from "../../shared/payment-config";
import "../styles/admin.css";

type AdminUser = {
  id: number;
  phone: string;
  referralCode: string;
  referrerId: number | null;
  createdAt: string;
  isBanned: boolean;
  isBlocked: boolean;
  withdrawalsDisabled: boolean;
};

type AdminTransaction = {
  id: number;
  userId: number;
  userPhone: string;
  reference?: string | null;
  type: string;
  amount: number;
  fee: number;
  netAmount: number;
  status: string;
  note: string;
  payerNumber: string | null;
  countryCode?: string | null;
  operatorName?: string | null;
  referralCount: number;
  adminAssisted: boolean;
  createdAt: string;
};

type AdminProduct = {
  id: number;
  name: string;
  price: number;
  dailyIncome: number;
  totalIncome: number;
  durationDays: number;
  imageClass: string;
  active: boolean;
};

type AdminOverview = {
  stats: {
    approvedDeposits: number;
    approvedWithdrawals: number;
    pendingDeposits: number;
    pendingWithdrawals: number;
    approvedDepositCount: number;
    rejectedDepositCount: number;
    approvedWithdrawalCount: number;
    rejectedWithdrawalCount: number;
    users: number;
    investments: number;
    vipPurchases: number;
    adminCredits: number;
  };
  users: AdminUser[];
  transactions: AdminTransaction[];
  orders: Array<{
    id: number;
    userId: number;
    productId: number;
    amount: number;
    status: string;
    source: string;
    createdAt: string;
    productName: string;
    userPhone: string;
  }>;
  products: AdminProduct[];
  community: { isOpen: boolean; closureMessage: string };
  withdrawOpenOverride: boolean;
};

type UserDetail = {
  user: AdminUser;
  wallet: {
    balance: number;
    totalDeposits: number;
    totalWithdrawals: number;
    totalAdminCredits: number;
    totalAdminDebits: number;
    totalCommissions: number;
    totalCheckins: number;
    totalProductIncome: number;
  };
  transactions: Array<{ id: number; type: string; amount: number; status: string; note: string; createdAt: string }>;
  orders: Array<{ id: number; productName: string; amount: number; status: string; source: string; createdAt: string }>;
  checkins: Array<{ id: number; checkinDate: string; reward: number; status: string; createdAt: string }>;
};

type GiftCode = { id: number; code: string; amount: number; createdAt: string; redemptions: number };
type AdminAnnouncement = {
  id: number;
  title: string;
  content: string;
  kind: "announcement" | "notification";
  audience: "all" | "level";
  audienceLevel: string | null;
  status: "draft" | "published";
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
};
type PaymentChannel = {
  id: number;
  operatorName: string;
  receiverNumber: string;
  receiverName: string;
  logoColor: string;
  logoText: string;
  logoUrl: string;
  country: string;
  countryCode: string;
  ussdTemplate: string;
  isActive: boolean;
  sortOrder: number;
};
type AdminMutationOptions = { method: "POST" | "PATCH" | "DELETE"; body?: unknown };
type AdminScope = "global" | "cameroon";

const date = (value: string) => new Date(value).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" });
const exactDate = (value: string) => new Date(value).toLocaleString("fr-FR", {
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
});
const pending = (status: string) => status === "pending" || status === "pending_review";
const countryName = (countryCode?: string | null) =>
  PAYMENT_COUNTRIES.find((country) => country.code === countryCode)?.name ?? countryCode ?? "Non renseigné";

export function AdminLoginScreen({ scope, onLogin, onBack }: { scope: AdminScope; onLogin: () => void; onBack: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      await api.adminLogin(password, scope);
      onLogin();
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : "Connexion impossible.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="admin-login-page">
      <button className="admin-back-link" type="button" onClick={onBack}><ArrowLeft size={18} /> Retour</button>
      <form className="admin-login-card" onSubmit={submit}>
        <span className="admin-login-mark"><ShieldCheck size={34} /></span>
        <h1>{scope === "cameroon" ? "Administration Cameroun" : "Administration générale"}</h1>
        <p>{scope === "cameroon" ? "Validation des dépôts et retraits camerounais" : "Gestion complète de la plateforme Valhalla"}</p>
        <input
          type="text"
          name="username"
          autoComplete="username"
          value={scope === "cameroon" ? "admin-cameroon" : "admin"}
          readOnly
          tabIndex={-1}
          aria-hidden="true"
          style={{ position: "absolute", width: 1, height: 1, padding: 0, margin: -1, overflow: "hidden", clip: "rect(0, 0, 0, 0)", whiteSpace: "nowrap", border: 0 }}
        />
        <label>Mot de passe<input required type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} /></label>
        {error && <div className="admin-error" role="alert">{error}</div>}
        <button className="admin-primary-button" disabled={submitting} type="submit">
          <LockKeyhole size={17} /> {submitting ? "Vérification…" : "Se connecter"}
        </button>
      </form>
    </div>
  );
}

type AdminTab = "overview" | "transactions" | "users" | "products" | "codes" | "channels" | "announcements" | "settings";
type TransactionStatusFilter = "pending" | "approved" | "rejected";
type TransactionKind = "deposit" | "withdrawal";

export function AdminDashboard({ scope, onExit, onUnauthorized }: { scope: AdminScope; onExit: () => void; onUnauthorized: () => void }) {
  const isCameroon = scope === "cameroon";
  const [overview, setOverview] = useState<AdminOverview | null>(null);
  const [tab, setTab] = useState<AdminTab>("overview");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [search, setSearch] = useState("");
  const [transactionSearch, setTransactionSearch] = useState("");
  const [transactionKind, setTransactionKind] = useState<TransactionKind>("deposit");
  const [depositStatusFilter, setDepositStatusFilter] = useState<TransactionStatusFilter>("pending");
  const [withdrawalStatusFilter, setWithdrawalStatusFilter] = useState<TransactionStatusFilter>("pending");
  const [processingTransactionIds, setProcessingTransactionIds] = useState<Set<number>>(new Set());
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [userDetail, setUserDetail] = useState<UserDetail | null>(null);

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      setOverview(await request<AdminOverview>(
        isCameroon ? "/api/admin/cameroon/overview" : "/api/admin/overview",
        { cache: "no-store" },
      ));
    } catch (loadError) {
      const message = loadError instanceof Error ? loadError.message : "Chargement impossible.";
      if (/connexion administrateur/i.test(message)) onUnauthorized();
      else setError(message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const act = async (path: string, options: AdminMutationOptions, message: string) => {
    setError("");
    setNotice("");
    try {
      await request<{ message?: string }>(path, options);
      setNotice(message);
      await load();
      if (selectedUserId) await openUser(selectedUserId);
      return true;
    } catch (actionError) {
      setError(actionError instanceof Error ? actionError.message : "Action impossible.");
      return false;
    }
  };

  const processTransaction = async (id: number, status: string, withdrawal: boolean) => {
    if (processingTransactionIds.has(id)) return;
    setProcessingTransactionIds((current) => new Set(current).add(id));
    setOverview((current) => current ? {
      ...current,
      transactions: current.transactions.map((transaction) =>
        transaction.id === id ? { ...transaction, status } : transaction,
      ),
    } : current);
    try {
      const succeeded = await act(
        `${isCameroon ? "/api/admin/cameroon" : "/api/admin"}/transactions/${id}`,
        { method: "PATCH", body: { status } },
        withdrawal ? "Retrait traité." : "Dépôt traité.",
      );
      if (!succeeded) await load();
    } finally {
      setProcessingTransactionIds((current) => {
        const next = new Set(current);
        next.delete(id);
        return next;
      });
    }
  };

  const openUser = async (userId: number) => {
    setSelectedUserId(userId);
    setUserDetail(null);
    try {
      setUserDetail(await request<UserDetail>(`/api/admin/users/${userId}`, { cache: "no-store" }));
    } catch (detailError) {
      setError(detailError instanceof Error ? detailError.message : "Fiche indisponible.");
    }
  };

  const filteredUsers = useMemo(() => {
    const value = search.trim().toLowerCase();
    return (overview?.users ?? []).filter((user) => !value || user.phone.toLowerCase().includes(value) || String(user.id).includes(value));
  }, [overview, search]);

  const filteredDeposits = useMemo(() => {
    const value = transactionSearch.trim().toLowerCase();
    const availableDeposits = (overview?.transactions ?? []).filter(
      (transaction) => transaction.type === "deposit" && transactionMatchesFilter(transaction, depositStatusFilter),
    );
    if (!value) return availableDeposits;
    return availableDeposits.filter((transaction) => {
      const reference = (transaction.reference ?? "").toLowerCase();
      const displayedReference = displayTransactionReference(transaction.reference).toLowerCase();
      return reference.includes(value) || displayedReference.includes(value);
    });
  }, [overview, transactionSearch, depositStatusFilter]);
  const filteredWithdrawals = useMemo(() => {
    const value = transactionSearch.trim().toLowerCase();
    const availableWithdrawals = (overview?.transactions ?? []).filter(
      (transaction) => transaction.type === "withdrawal" && transactionMatchesFilter(transaction, withdrawalStatusFilter),
    );
    if (!value) return availableWithdrawals;
    return availableWithdrawals.filter((transaction) => {
      const reference = (transaction.reference ?? "").toLowerCase();
      const displayedReference = displayTransactionReference(transaction.reference).toLowerCase();
      return reference.includes(value) || displayedReference.includes(value);
    });
  }, [overview, transactionSearch, withdrawalStatusFilter]);
  const selectedTransactionTotal = transactionKind === "deposit"
    ? depositStatusFilter === "pending"
      ? overview?.stats.pendingDeposits ?? 0
      : depositStatusFilter === "approved"
        ? overview?.stats.approvedDepositCount ?? 0
        : overview?.stats.rejectedDepositCount ?? 0
    : withdrawalStatusFilter === "pending"
      ? overview?.stats.pendingWithdrawals ?? 0
      : withdrawalStatusFilter === "approved"
        ? overview?.stats.approvedWithdrawalCount ?? 0
        : overview?.stats.rejectedWithdrawalCount ?? 0;

  if (loading && !overview) {
    return <div className="admin-state-page"><RefreshCw className="admin-spin" /><h1>{isCameroon ? "Administration Cameroun" : "Administration générale"}</h1><p>Chargement sécurisé…</p></div>;
  }
  if (!overview) {
    return <div className="admin-state-page"><ShieldCheck size={44} /><h1>Administration indisponible</h1><p>{error}</p><button className="admin-primary-button" onClick={() => void load()}>Réessayer</button></div>;
  }

  return (
    <div className="admin-page">
      <header className="admin-header">
        <div><strong>{isCameroon ? "Administration Cameroun" : "Administration générale"}</strong><small>{isCameroon ? "Dépôts et retraits · +237" : "Gestion complète de Valhalla"}</small></div>
        <div className="admin-header-actions">
          <button type="button" title="Actualiser" onClick={() => void load()}><RefreshCw size={18} /></button>
          <button type="button" title="Déconnexion" onClick={() => void api.adminLogout(scope).finally(onExit)}><LogOut size={18} /></button>
        </div>
      </header>
      <main className="admin-content">
        {notice && <div className="admin-notice" role="status">{notice}</div>}
        {error && <div className="admin-error" role="alert">{error}</div>}
        <section className={`admin-stats-grid${isCameroon ? " cameroon" : ""}`}>
          <Stat icon={<ArrowDownToLine />} value={formatFcfa(overview.stats.approvedDeposits)} label="Dépôts" />
          <Stat icon={<ArrowUpFromLine />} value={formatFcfa(overview.stats.approvedWithdrawals)} label="Retraits" />
          {!isCameroon && <Stat icon={<Users />} value={String(overview.stats.users)} label="Utilisateurs" />}
          {!isCameroon && <Stat icon={<Package />} value={String(overview.stats.investments)} label="VIP actifs" />}
          {!isCameroon && <Stat icon={<Wallet />} value={formatFcfa(overview.stats.adminCredits)} label="Crédits admin" />}
        </section>
        <nav className="admin-tabs" aria-label="Sections administratives">
          {((isCameroon ? [
            ["overview", "Synthèse"],
            ["transactions", "Transactions"],
          ] : [
            ["overview", "Synthèse"],
            ["transactions", "Transactions"],
            ["users", "Utilisateurs"],
            ["products", "Produits"],
            ["codes", "Codes"],
            ["channels", "Canaux"],
            ["announcements", "Annonces"],
            ["settings", "Paramètres"],
          ]) as Array<[AdminTab, string]>).map(([value, label]) => (
            <button key={value} type="button" className={tab === value ? "active" : ""} onClick={() => setTab(value)}>{label}</button>
          ))}
        </nav>

        {tab === "overview" && (
          <section className="admin-panel">
            <h2>État de la plateforme</h2>
            <div className="admin-alert-grid">
              <article><strong>{overview.stats.pendingDeposits}</strong><span>dépôt(s) en attente</span></article>
              <article><strong>{overview.stats.pendingWithdrawals}</strong><span>retrait(s) en attente</span></article>
            </div>
            {!isCameroon && <div className="admin-setting-row">
              <div><strong>Retraits hors horaire</strong><small>{overview.withdrawOpenOverride ? "Ouverts manuellement" : "Horaire normal"}</small></div>
              <button className={overview.withdrawOpenOverride ? "admin-danger-button" : "admin-primary-button"} type="button" onClick={() => void act("/api/admin/withdraw-override", { method: "PATCH", body: { enabled: !overview.withdrawOpenOverride } }, "Règle de retrait mise à jour.")}>
                {overview.withdrawOpenOverride ? "Désactiver" : "Ouvrir"}
              </button>
            </div>}
          </section>
        )}

        {tab === "transactions" && (
          <section className="admin-panel">
            <h2>Transactions</h2>
            <div className="admin-transaction-kind-tabs" role="tablist" aria-label="Type de transaction">
              <button type="button" role="tab" aria-selected={transactionKind === "deposit"} className={transactionKind === "deposit" ? "active" : ""} onClick={() => setTransactionKind("deposit")}>
                Dépôts
              </button>
              <button type="button" role="tab" aria-selected={transactionKind === "withdrawal"} className={transactionKind === "withdrawal" ? "active" : ""} onClick={() => setTransactionKind("withdrawal")}>
                Retraits
              </button>
            </div>
            <h3>{transactionKind === "deposit" ? `Dépôts (${selectedTransactionTotal})` : `Retraits (${selectedTransactionTotal})`}</h3>
            <TransactionFilters
              value={transactionKind === "deposit" ? depositStatusFilter : withdrawalStatusFilter}
              onChange={transactionKind === "deposit" ? setDepositStatusFilter : setWithdrawalStatusFilter}
            />
            <label className="admin-search transaction-search">
              <Search size={17} />
              <input
                value={transactionSearch}
                onChange={(event) => setTransactionSearch(event.target.value)}
                placeholder="Rechercher par numéro de commande"
                aria-label={`Rechercher un ${transactionKind === "deposit" ? "dépôt" : "retrait"} par numéro de commande`}
              />
            </label>
            {transactionKind === "deposit"
              ? <TransactionList values={filteredDeposits} processingIds={processingTransactionIds} onStatus={(id, status) => void processTransaction(id, status, false)} />
              : <TransactionList values={filteredWithdrawals} processingIds={processingTransactionIds} withdrawal groupByCountry={withdrawalStatusFilter === "pending"} onStatus={(id, status) => void processTransaction(id, status, true)} />}
          </section>
        )}

        {tab === "users" && (
          <section className="admin-panel">
            <h2>Utilisateurs ({filteredUsers.length})</h2>
            <label className="admin-search"><Search size={17} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Téléphone ou identifiant" /></label>
            <div className="admin-list">
              {filteredUsers.map((user) => (
                <article className="admin-list-card" key={user.id}>
                  <div><strong>{user.phone}</strong><p>ID #{user.id} · {user.referralCode}</p><small>{date(user.createdAt)}</small></div>
                  <div className="admin-badges">{user.isBanned && <span>banni</span>}{user.isBlocked && <span>bloqué</span>}{user.withdrawalsDisabled && <span>retraits fermés</span>}</div>
                  <button type="button" onClick={() => void openUser(user.id)}>Gérer</button>
                </article>
              ))}
            </div>
          </section>
        )}

        {tab === "products" && <ProductsPanel overview={overview} act={act} />}
        {tab === "codes" && <GiftCodesPanel />}
        {tab === "channels" && <ChannelsPanel />}
        {tab === "announcements" && <AnnouncementsPanel />}
        {tab === "settings" && <SettingsPanel />}
      </main>
      {!isCameroon && selectedUserId !== null && (
        <UserPanel
          detail={userDetail}
          products={overview.products}
          close={() => { setSelectedUserId(null); setUserDetail(null); }}
          act={(path, body, message) => act(path, { method: "POST", body }, message)}
        />
      )}
    </div>
  );
}

function Stat({ icon, value, label }: { icon: ReactNode; value: string; label: string }) {
  return <article className="admin-stat-card"><span>{icon}</span><div><strong>{value}</strong><small>{label}</small></div></article>;
}

const displayTransactionReference = (reference?: string | null) =>
  (reference ?? "Non disponible").replace(/^(deposit|withdrawal)-/, "");

const transactionMatchesFilter = (transaction: AdminTransaction, filter: TransactionStatusFilter) => {
  if (filter === "pending") return pending(transaction.status);
  if (filter === "approved") return transaction.status === "approved" || transaction.status === "completed";
  return transaction.status === "rejected";
};

function TransactionFilters({ value, onChange }: { value: TransactionStatusFilter; onChange: (value: TransactionStatusFilter) => void }) {
  const filters: Array<[TransactionStatusFilter, string]> = [
    ["pending", "En attente"],
    ["approved", "Validés"],
    ["rejected", "Rejetés"],
  ];
  return (
    <div className="admin-transaction-filters" role="group" aria-label="Filtrer les transactions par statut">
      {filters.map(([filter, label]) => (
        <button key={filter} type="button" className={value === filter ? "active" : ""} onClick={() => onChange(filter)}>
          {label}
        </button>
      ))}
    </div>
  );
}

function TransactionList({ values, processingIds, withdrawal = false, groupByCountry = false, onStatus }: { values: AdminTransaction[]; processingIds: Set<number>; withdrawal?: boolean; groupByCountry?: boolean; onStatus: (id: number, status: string) => void }) {
  const [selectedCountryCode, setSelectedCountryCode] = useState("");
  if (!values.length) return <p className="admin-empty">Aucune transaction.</p>;
  const renderTransactions = (transactions: AdminTransaction[]) => <div className="admin-list">{transactions.map((transaction) => (
    <article className="admin-list-card" key={transaction.id}>
      <div className="admin-transaction-details">
        <strong className={withdrawal ? "admin-red-text" : "admin-green-text"}>{formatFcfa(transaction.amount)}</strong>
        <CopyableValue label="N° d’inscription" value={transaction.userPhone} />
        <small>Identifiant utilisateur : #{transaction.userId}</small>
        <small>Pays : {countryName(transaction.countryCode)}</small>
        <small>Opérateur : {transaction.operatorName || "Non renseigné"}</small>
        {!withdrawal && transaction.payerNumber && <CopyableValue label="Portefeuille payeur" value={transaction.payerNumber} />}
        {withdrawal && transaction.payerNumber && <CopyableValue label="Numéro de réception" value={transaction.payerNumber} />}
        <CopyableValue label={withdrawal ? "N° de commande du retrait" : "N° de commande du dépôt"} value={displayTransactionReference(transaction.reference)} />
        <small>Date et heure : {exactDate(transaction.createdAt)}</small>
        {withdrawal && pending(transaction.status) && <small className="admin-total-referrals">Nombre total de filleuls : <strong>{transaction.referralCount}</strong></small>}
        {withdrawal && <small>Montant retiré : {formatFcfa(transaction.amount)}</small>}
        {withdrawal && <small>Frais : {formatFcfa(transaction.fee)} · Net à envoyer : <strong>{formatFcfa(transaction.netAmount)}</strong></small>}
      </div>
      {withdrawal && pending(transaction.status) && transaction.adminAssisted && <span className="admin-assisted-badge">Admin</span>}
      <span className={`admin-status ${transaction.status}`}>{transaction.status}</span>
      {pending(transaction.status) && <div className="admin-card-actions"><button className="approve" type="button" disabled={processingIds.has(transaction.id)} onClick={() => onStatus(transaction.id, withdrawal ? "completed" : "approved")}><Check size={16} /></button><button className="reject" type="button" disabled={processingIds.has(transaction.id)} onClick={() => onStatus(transaction.id, "rejected")}><X size={16} /></button></div>}
    </article>
  ))}</div>;
  if (!groupByCountry) return renderTransactions(values);

  const groups = Array.from(
    values.reduce((byCountry, transaction) => {
      const code = transaction.countryCode || "";
      const transactions = byCountry.get(code) ?? [];
      transactions.push(transaction);
      byCountry.set(code, transactions);
      return byCountry;
    }, new Map<string, AdminTransaction[]>()),
  ).sort(([firstCode], [secondCode]) => countryName(firstCode).localeCompare(countryName(secondCode), "fr"));
  const selectedGroup = groups.find(([code]) => code === selectedCountryCode) ?? groups[0];

  return <div className="admin-country-withdrawals">
    <div className="admin-country-tabs" role="tablist" aria-label="Filtrer les retraits en attente par pays">
      {groups.map(([code, transactions]) => (
        <button
          key={code || "unknown"}
          type="button"
          role="tab"
          aria-selected={selectedGroup[0] === code}
          className={selectedGroup[0] === code ? "active" : ""}
          onClick={() => setSelectedCountryCode(code)}
        >
          <span>{countryName(code)}</span>
          <strong>{transactions.length}</strong>
        </button>
      ))}
    </div>
    <div className="admin-selected-country-summary">
      <strong>{countryName(selectedGroup[0])}</strong>
      <span>{selectedGroup[1].length} retrait{selectedGroup[1].length > 1 ? "s" : ""} en attente</span>
    </div>
    {renderTransactions(selectedGroup[1])}
  </div>;
}

function CopyableValue({ label, value }: { label: string; value: string }) {
  return (
    <small className="admin-copyable-value">
      <span>{label} : {value}</span>
      <button type="button" title={`Copier ${label.toLowerCase()}`} aria-label={`Copier ${label.toLowerCase()}`} onClick={() => void navigator.clipboard.writeText(value)}>
        <Copy size={13} />
      </button>
    </small>
  );
}

function UserPanel({ detail, products, close, act }: { detail: UserDetail | null; products: AdminProduct[]; close: () => void; act: (path: string, body: Record<string, unknown>, message: string) => Promise<boolean> }) {
  const [credit, setCredit] = useState("");
  const [debit, setDebit] = useState("");
  const [productId, setProductId] = useState("");
  const [busy, setBusy] = useState(false);
  const operationKeys = useRef<Record<string, string>>({});
  const runFinancialAction = async (kind: "credit" | "debit" | "vip", operation: (requestId: string) => Promise<boolean>) => {
    if (busy) return;
    setBusy(true);
    try {
      const requestId = operationKeys.current[kind] ?? crypto.randomUUID();
      operationKeys.current[kind] = requestId;
      if (await operation(requestId)) delete operationKeys.current[kind];
    } finally {
      setBusy(false);
    }
  };
  const removeVip = async (order: UserDetail["orders"][number]) => {
    if (busy) return;
    const confirmed = window.confirm(
      `Supprimer ${order.productName} de cet utilisateur ? Les futurs revenus seront arrêtés, sans remboursement de l'achat ni retrait des revenus déjà versés.`,
    );
    if (!confirmed) return;
    setBusy(true);
    try {
      await act(`/api/admin/orders/${order.id}/revoke-vip`, {}, "VIP supprimé.");
    } finally {
      setBusy(false);
    }
  };
  if (!detail) return <div className="admin-overlay"><div className="admin-user-panel admin-panel-loading"><RefreshCw className="admin-spin" /></div></div>;
  const user = detail.user;
  return (
    <div className="admin-overlay">
      <section className="admin-user-panel">
        <header><div><strong>{user.phone}</strong><small>Utilisateur #{user.id}</small></div><button type="button" onClick={close}><X /></button></header>
        <div className="admin-user-body">
          <div className="admin-balance"><span>Solde disponible</span><strong>{formatFcfa(detail.wallet.balance)}</strong></div>
          <div className="admin-balance-actions">
            <input type="number" min="1" value={credit} onChange={(event) => setCredit(event.target.value)} placeholder="Montant à créditer" />
            <button type="button" disabled={busy || !credit} onClick={() => void runFinancialAction("credit", async (requestId) => { const ok = await act(`/api/admin/users/${user.id}/credit`, { amount: Number(credit), requestId }, "Solde crédité."); if (ok) setCredit(""); return ok; })}>Créditer</button>
            <input type="number" min="1" value={debit} onChange={(event) => setDebit(event.target.value)} placeholder="Montant à débiter" />
            <button className="danger" type="button" disabled={busy || !debit} onClick={() => void runFinancialAction("debit", async (requestId) => { const ok = await act(`/api/admin/users/${user.id}/debit`, { amount: Number(debit), requestId }, "Solde débité."); if (ok) setDebit(""); return ok; })}>Débiter</button>
          </div>
          <div className="admin-user-actions">
            <button type="button" onClick={() => void act(`/api/admin/users/${user.id}/${user.isBanned ? "unban" : "ban"}`, {}, user.isBanned ? "Utilisateur débanni." : "Utilisateur banni.")}><Ban size={15} /> {user.isBanned ? "Débannir" : "Bannir"}</button>
            <button type="button" onClick={() => void act(`/api/admin/users/${user.id}/${user.isBlocked ? "unblock" : "block"}`, {}, user.isBlocked ? "Compte débloqué." : "Compte bloqué.")}>{user.isBlocked ? "Débloquer" : "Bloquer"}</button>
            <button type="button" onClick={() => void act(`/api/admin/users/${user.id}/${user.withdrawalsDisabled ? "open-withdrawals" : "close-withdrawals"}`, {}, "Droits de retrait mis à jour.")}>{user.withdrawalsDisabled ? "Ouvrir retraits" : "Fermer retraits"}</button>
          </div>
          <div className="admin-grant-row">
            <select value={productId} onChange={(event) => setProductId(event.target.value)}><option value="">Octroyer un VIP…</option>{products.filter((product) => product.active).map((product) => <option value={product.id} key={product.id}>{product.name}</option>)}</select>
            <button type="button" disabled={busy || !productId} onClick={() => void runFinancialAction("vip", async (requestId) => { const ok = await act(`/api/admin/users/${user.id}/grant-vip`, { productId: Number(productId), requestId }, "VIP octroyé."); if (ok) setProductId(""); return ok; })}>Octroyer</button>
          </div>
          <div className="admin-summary-grid">
            <span>Dépôts<strong>{formatFcfa(detail.wallet.totalDeposits)}</strong></span>
            <span>Retraits<strong>{formatFcfa(detail.wallet.totalWithdrawals)}</strong></span>
            <span>Crédits admin<strong>{formatFcfa(detail.wallet.totalAdminCredits)}</strong></span>
            <span>Débits admin<strong>{formatFcfa(detail.wallet.totalAdminDebits)}</strong></span>
          </div>
          <h3>Transactions récentes ({Math.min(detail.transactions.length, 12)})</h3>
          {detail.transactions.length
            ? detail.transactions.slice(0, 12).map((transaction) => <article className="admin-mini-row" key={transaction.id}><div><strong>{transaction.type}</strong><small>{transaction.note} · {date(transaction.createdAt)}</small></div><span>{formatFcfa(transaction.amount)}</span></article>)
            : <p className="admin-empty">Aucun dépôt ou retrait enregistré.</p>}
          <h3>VIP ({detail.orders.length})</h3>
          {detail.orders.map((order) => <article className="admin-mini-row" key={order.id}><div><strong>{order.productName}</strong><small>{order.source} · {date(order.createdAt)}</small></div>{order.status !== "rejected" && <button className="danger" type="button" disabled={busy} onClick={() => void removeVip(order)}><Trash2 size={14} /> Supprimer</button>}</article>)}
        </div>
      </section>
    </div>
  );
}

function ProductsPanel({ overview, act }: { overview: AdminOverview; act: (path: string, options: AdminMutationOptions, message: string) => Promise<boolean> }) {
  const emptyForm = { name: "", price: "", dailyIncome: "", totalIncome: "", durationDays: "180", imageClass: "1-DjVpknwl_1787413021677.png" };
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<number | null>(null);
  const resetForm = () => {
    setForm(emptyForm);
    setEditingId(null);
  };
  const edit = (product: AdminProduct) => {
    setEditingId(product.id);
    setForm({
      name: product.name,
      price: String(product.price),
      dailyIncome: String(product.dailyIncome),
      totalIncome: String(product.totalIncome),
      durationDays: String(product.durationDays),
      imageClass: product.imageClass,
    });
  };
  const submit = () => {
    const body = {
      ...form,
      price: Number(form.price),
      dailyIncome: Number(form.dailyIncome),
      totalIncome: Number(form.totalIncome),
      durationDays: Number(form.durationDays),
    };
    const path = editingId ? `/api/admin/products/${editingId}` : "/api/admin/products";
    const method = editingId ? "PATCH" : "POST";
    const message = editingId ? "Produit mis à jour." : "Produit créé.";
    return act(path, { method, body }, message).then((ok) => {
      if (ok) resetForm();
    });
  };
  const complete = Boolean(form.name && form.price && form.dailyIncome && form.totalIncome && form.durationDays);

  return (
    <section className="admin-panel">
      <h2>{editingId ? "Modifier le produit" : "Produits"}</h2>
      <div className="admin-inline-form">
        {(["name", "price", "dailyIncome", "totalIncome", "durationDays"] as const).map((field) => (
          <input key={field} type={field === "name" ? "text" : "number"} value={form[field]} onChange={(event) => setForm((current) => ({ ...current, [field]: event.target.value }))} placeholder={field} />
        ))}
        <button type="button" disabled={!complete} onClick={() => void submit()}>
          {editingId ? <><Check size={15} /> Enregistrer</> : <><Plus size={15} /> Ajouter</>}
        </button>
        {editingId && <button className="admin-product-cancel" type="button" onClick={resetForm}><X size={15} /> Annuler</button>}
      </div>
      <div className="admin-list">
        {overview.products.map((product) => (
          <article className={`admin-list-card ${editingId === product.id ? "editing" : ""}`} key={product.id}>
            <div>
              <strong>{product.name}</strong>
              <p>{formatFcfa(product.price)} · {formatFcfa(product.dailyIncome)}/jour</p>
              <small>{product.durationDays} jours · {product.active ? "Actif" : "Inactif"}</small>
            </div>
            <div className="admin-product-actions">
              <button type="button" aria-label={`Modifier ${product.name}`} onClick={() => edit(product)}><Pencil size={16} /></button>
              {product.active ? (
                <button className="admin-icon-danger" type="button" aria-label={`Désactiver ${product.name}`} onClick={() => void act(`/api/admin/products/${product.id}`, { method: "DELETE" }, "Produit désactivé.")}><Trash2 size={16} /></button>
              ) : (
                <button className="admin-icon-activate" type="button" onClick={() => void act(`/api/admin/products/${product.id}/activate`, { method: "PATCH" }, "Produit réactivé.")}><RefreshCw size={16} /> Réactiver</button>
              )}
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function GiftCodesPanel() {
  const [codes, setCodes] = useState<GiftCode[]>([]);
  const [code, setCode] = useState("");
  const [amount, setAmount] = useState("");
  const [error, setError] = useState("");
  const load = () => request<{ codes: GiftCode[] }>("/api/admin/gift-codes").then((data) => setCodes(data.codes)).catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  useEffect(() => { void load(); }, []);
  const create = async () => { await request("/api/admin/gift-codes", { method: "POST", body: { code, amount: Number(amount) } }); setCode(""); setAmount(""); await load(); };
  return <section className="admin-panel"><h2><Gift size={19} /> Codes cadeaux</h2>{error && <div className="admin-error">{error}</div>}<div className="admin-inline-form"><input value={code} onChange={(event) => setCode(event.target.value.toUpperCase())} placeholder="CODE2026" /><input type="number" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="Montant" /><button type="button" disabled={!code || !amount} onClick={() => void create().catch((reason) => setError(reason instanceof Error ? reason.message : "Création impossible."))}><Plus size={15} /> Créer</button></div><div className="admin-list">{codes.map((gift) => <article className="admin-list-card" key={gift.id}><div><strong>{gift.code}</strong><p>{formatFcfa(gift.amount)}</p><small>{gift.redemptions} utilisation(s)</small></div><button className="admin-icon-danger" type="button" onClick={() => void request(`/api/admin/gift-codes/${gift.id}`, { method: "DELETE" }).then(load)}><Trash2 size={16} /></button></article>)}</div></section>;
}

const emptyAnnouncementForm = {
  title: "",
  content: "",
  kind: "announcement" as AdminAnnouncement["kind"],
  audience: "all" as AdminAnnouncement["audience"],
  audienceLevel: "Lv1",
};

function AnnouncementsPanel() {
  const [announcements, setAnnouncements] = useState<AdminAnnouncement[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState(emptyAnnouncementForm);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const load = async () => {
    const data = await request<{ announcements: AdminAnnouncement[] }>("/api/admin/announcements", { cache: "no-store" });
    setAnnouncements(data.announcements);
  };

  useEffect(() => {
    void load().catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  }, []);

  const resetForm = () => {
    setEditingId(null);
    setForm(emptyAnnouncementForm);
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    setNotice("");
    try {
      await request(editingId ? `/api/admin/announcements/${editingId}` : "/api/admin/announcements", {
        method: editingId ? "PATCH" : "POST",
        body: {
          ...form,
          audienceLevel: form.audience === "level" ? form.audienceLevel : null,
        },
      });
      setNotice(editingId ? "Annonce mise à jour." : "Brouillon créé. Il reste invisible jusqu’à sa publication.");
      resetForm();
      await load();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Enregistrement impossible.");
    } finally {
      setSubmitting(false);
    }
  };

  const edit = (announcement: AdminAnnouncement) => {
    setEditingId(announcement.id);
    setForm({
      title: announcement.title,
      content: announcement.content,
      kind: announcement.kind,
      audience: announcement.audience,
      audienceLevel: announcement.audienceLevel ?? "Lv1",
    });
    setError("");
    setNotice("");
  };

  const changePublication = async (announcement: AdminAnnouncement) => {
    setError("");
    setNotice("");
    try {
      const action = announcement.status === "published" ? "withdraw" : "publish";
      await request(`/api/admin/announcements/${announcement.id}/${action}`, { method: "POST" });
      setNotice(announcement.status === "published" ? "Annonce retirée : elle n’est plus visible des utilisateurs." : "Annonce publiée.");
      await load();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Action impossible.");
    }
  };

  return (
    <section className="admin-panel">
      <h2><Megaphone size={19} /> Annonces et notifications</h2>
      <p className="admin-panel-intro">Créez un brouillon, relisez-le, puis publiez-le pour tous les utilisateurs ou pour un niveau précis.</p>
      {notice && <div className="admin-notice" role="status">{notice}</div>}
      {error && <div className="admin-error" role="alert">{error}</div>}
      <form className="admin-announcement-form" onSubmit={submit}>
        <label>
          Titre
          <input required maxLength={160} value={form.title} onChange={(event) => setForm((current) => ({ ...current, title: event.target.value }))} placeholder="Titre affiché aux utilisateurs" />
        </label>
        <label>
          Contenu
          <textarea required maxLength={10000} rows={6} value={form.content} onChange={(event) => setForm((current) => ({ ...current, content: event.target.value }))} placeholder="Rédigez le message à diffuser…" />
        </label>
        <div className="admin-announcement-options">
          <label>
            Format
            <select value={form.kind} onChange={(event) => setForm((current) => ({ ...current, kind: event.target.value as AdminAnnouncement["kind"] }))}>
              <option value="announcement">Annonce</option>
              <option value="notification">Notification</option>
            </select>
          </label>
          <label>
            Audience
            <select value={form.audience} onChange={(event) => setForm((current) => ({ ...current, audience: event.target.value as AdminAnnouncement["audience"] }))}>
              <option value="all">Tous les utilisateurs</option>
              <option value="level">Un niveau précis</option>
            </select>
          </label>
          {form.audience === "level" && (
            <label>
              Niveau
              <select value={form.audienceLevel} onChange={(event) => setForm((current) => ({ ...current, audienceLevel: event.target.value }))}>
                {["Lv1", "Lv2", "Lv3", "Lv4"].map((level) => <option key={level} value={level}>{level}</option>)}
              </select>
            </label>
          )}
        </div>
        <div className="admin-announcement-form-actions">
          <button className="admin-primary-button" disabled={submitting} type="submit">
            {editingId ? <Pencil size={16} /> : <Plus size={16} />}
            {submitting ? "Enregistrement…" : editingId ? "Enregistrer les modifications" : "Créer le brouillon"}
          </button>
          {editingId && <button className="admin-secondary-button" type="button" onClick={resetForm}>Annuler</button>}
        </div>
      </form>
      <div className="admin-list admin-announcement-list">
        {announcements.length === 0 && <div className="admin-empty">Aucune annonce enregistrée.</div>}
        {announcements.map((announcement) => (
          <article className="admin-list-card admin-announcement-card" key={announcement.id}>
            <div>
              <div className="admin-announcement-heading">
                <strong>{announcement.title}</strong>
                <span className={`admin-status ${announcement.status}`}>{announcement.status === "published" ? "Publiée" : "Brouillon"}</span>
              </div>
              <p className="admin-announcement-copy">{announcement.content}</p>
              <small>
                {announcement.kind === "notification" ? "Notification" : "Annonce"} · {announcement.audience === "all" ? "Tous les utilisateurs" : `Niveau ${announcement.audienceLevel}`}
                {announcement.publishedAt ? ` · publiée le ${date(announcement.publishedAt)}` : ` · modifiée le ${date(announcement.updatedAt)}`}
              </small>
            </div>
            <div className="admin-card-actions">
              {announcement.status === "draft" && <button type="button" onClick={() => edit(announcement)}><Pencil size={14} /> Modifier</button>}
              <button className={announcement.status === "published" ? "reject" : "approve"} type="button" onClick={() => void changePublication(announcement)}>
                {announcement.status === "published" ? <EyeOff size={14} /> : <Send size={14} />}
                {announcement.status === "published" ? "Retirer" : "Publier"}
              </button>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function ChannelsPanel() {
  const preset = OPERATOR_PRESETS[0];
  const defaultCountry = PAYMENT_COUNTRIES[0];
  const [channels, setChannels] = useState<PaymentChannel[]>([]);
  const [error, setError] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<Omit<PaymentChannel, "id">>({ operatorName: preset.label, receiverNumber: "", receiverName: "", logoColor: preset.logoColor, logoText: preset.key, logoUrl: "", country: defaultCountry.name, countryCode: defaultCountry.code, ussdTemplate: preset.defaultUssd, isActive: true, sortOrder: 0 });
  const load = () => request<{ channels: PaymentChannel[] }>("/api/admin/payment-channels").then((data) => setChannels(data.channels)).catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  useEffect(() => { void load(); }, []);
  const resetForm = () => {
    setEditingId(null);
    setForm({ operatorName: preset.label, receiverNumber: "", receiverName: "", logoColor: preset.logoColor, logoText: preset.key, logoUrl: "", country: defaultCountry.name, countryCode: defaultCountry.code, ussdTemplate: preset.defaultUssd, isActive: true, sortOrder: 0 });
  };
  const save = async () => {
    if (editingId) {
      await request(`/api/admin/payment-channels/${editingId}`, { method: "PATCH", body: form });
    } else {
      await request("/api/admin/payment-channels", { method: "POST", body: form });
    }
    resetForm();
    await load();
  };
  const edit = (channel: PaymentChannel) => {
    setEditingId(channel.id);
    setForm({
      operatorName: channel.operatorName,
      receiverNumber: channel.receiverNumber,
      receiverName: channel.receiverName,
      logoColor: channel.logoColor,
      logoText: channel.logoText,
      logoUrl: channel.logoUrl,
      country: channel.country,
      countryCode: channel.countryCode,
      ussdTemplate: channel.ussdTemplate,
      isActive: channel.isActive,
      sortOrder: channel.sortOrder,
    });
  };
  return <section className="admin-panel"><h2>Canaux de paiement</h2>{error && <div className="admin-error">{error}</div>}<div className="admin-operator-presets">{OPERATOR_PRESETS.map((item) => <button type="button" key={item.key} className={form.logoText === item.key ? "active" : ""} onClick={() => setForm((current) => ({ ...current, operatorName: item.label, logoColor: item.logoColor, logoText: item.key, ussdTemplate: item.defaultUssd }))}><OperatorLogo logoText={item.key} logoColor={item.logoColor} size={38} /><small>{item.key}</small></button>)}</div><div className="admin-inline-form"><input value={form.operatorName} onChange={(event) => setForm((current) => ({ ...current, operatorName: event.target.value }))} placeholder="Opérateur" /><input value={form.receiverNumber} onChange={(event) => setForm((current) => ({ ...current, receiverNumber: event.target.value }))} placeholder="Numéro marchand" /><input value={form.receiverName} onChange={(event) => setForm((current) => ({ ...current, receiverName: event.target.value }))} placeholder="Nom du marchand" /><label className="admin-channel-field">Pays<select value={form.countryCode} onChange={(event) => { const selectedCountry = PAYMENT_COUNTRIES.find((country) => country.code === event.target.value); if (selectedCountry) setForm((current) => ({ ...current, country: selectedCountry.name, countryCode: selectedCountry.code })); }}><option value="" disabled>Sélectionner un pays</option>{PAYMENT_COUNTRIES.map((country) => <option value={country.code} key={country.code}>{country.name} ({country.code})</option>)}</select></label><input value={form.ussdTemplate} onChange={(event) => setForm((current) => ({ ...current, ussdTemplate: event.target.value }))} placeholder="USSD avec {account} et {amount} (facultatif)" /><input value={form.logoUrl} onChange={(event) => setForm((current) => ({ ...current, logoUrl: event.target.value }))} placeholder="URL du logo (facultatif)" /><div className="admin-logo-preview"><OperatorLogo logoText={form.logoText} logoColor={form.logoColor} logoUrl={form.logoUrl} size={38} /><span>Aperçu du logo</span></div><button type="button" disabled={!form.operatorName || !form.receiverNumber} onClick={() => void save().catch((reason) => setError(reason instanceof Error ? reason.message : "Enregistrement impossible."))}>{editingId ? <Pencil size={15} /> : <Plus size={15} />} {editingId ? "Enregistrer" : "Ajouter"}</button>{editingId && <button type="button" onClick={resetForm}>Annuler</button>}</div><div className="admin-list">{channels.map((channel) => <article className="admin-list-card" key={channel.id}><OperatorLogo logoText={channel.logoText} logoColor={channel.logoColor} logoUrl={channel.logoUrl} /><div><strong>{channel.operatorName}</strong><p>{channel.country} · {channel.countryCode} · {channel.receiverNumber} · {channel.receiverName}</p><small>{channel.isActive ? "Actif" : "Inactif"} · {channel.ussdTemplate}</small></div><div className="admin-card-actions"><button type="button" onClick={() => edit(channel)}><Pencil size={14} /> Modifier</button><button type="button" onClick={() => void request(`/api/admin/payment-channels/${channel.id}`, { method: "PATCH", body: { isActive: !channel.isActive } }).then(load)}>{channel.isActive ? "Désactiver" : "Activer"}</button><button className="reject" type="button" onClick={() => void request(`/api/admin/payment-channels/${channel.id}`, { method: "DELETE" }).then(load)}><Trash2 size={15} /></button></div></article>)}</div></section>;
}

function SettingsPanel() {
  const [config, setConfig] = useState({
    depositMin: 3500,
    withdrawalMin: 2000,
    withdrawalFeePercent: 10,
    dashboxDeposit: 300,
    dashboxWithdraw: 1000,
    signupBonus: 2000,
    checkinBonus: 200,
    maxWithdrawals: null as number | null,
  });
  const [configLoaded, setConfigLoaded] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  useEffect(() => {
    request<{ config: typeof config }>("/api/admin/popup-config")
      .then((data) => { setConfig(data.config); setConfigLoaded(true); })
      .catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  }, []);
  const labels: Record<keyof typeof config, string> = {
    depositMin: "Dépôt minimum",
    withdrawalMin: "Retrait minimum",
    withdrawalFeePercent: "Frais de retrait (%)",
    dashboxDeposit: "Montant rapide de dépôt",
    dashboxWithdraw: "Montant rapide de retrait",
    signupBonus: "Bonus d’inscription",
    checkinBonus: "Bonus de pointage",
    maxWithdrawals: "Retraits maximum par jour",
  };
  const save = async () => {
    setError("");
    setNotice("");
    if (config.maxWithdrawals !== null && (!Number.isSafeInteger(config.maxWithdrawals) || config.maxWithdrawals <= 0)) {
      setError("Le nombre maximum de retraits doit être un entier positif ou illimité.");
      return;
    }
    try {
      await request("/api/admin/popup-config", { method: "PATCH", body: config });
      setNotice("Paramètres enregistrés et appliqués aux règles backend.");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Enregistrement impossible.");
    }
  };
  return (
    <section className="admin-panel">
      <h2>Paramètres financiers</h2>
      {notice && <div className="admin-notice">{notice}</div>}
      {error && <div className="admin-error">{error}</div>}
      <div className="admin-settings-grid">
        {(Object.keys(config) as Array<keyof typeof config>).filter((field) => field !== "maxWithdrawals").map((field) => (
          <label key={field}>{labels[field]}<input type="number" min="1" value={config[field] ?? ""} onChange={(event) => setConfig((current) => ({ ...current, [field]: Number(event.target.value) }))} /></label>
        ))}
        <label>Retraits maximum par jour<select value={config.maxWithdrawals === null ? "unlimited" : "limited"} onChange={(event) => setConfig((current) => ({ ...current, maxWithdrawals: event.target.value === "unlimited" ? null : current.maxWithdrawals ?? 1 }))}><option value="limited">Nombre limité</option><option value="unlimited">Illimité</option></select><input type="number" min="1" step="1" value={config.maxWithdrawals ?? ""} disabled={config.maxWithdrawals === null} onChange={(event) => setConfig((current) => ({ ...current, maxWithdrawals: Number(event.target.value) }))} /></label>
      </div>
      <button className="admin-primary-button" type="button" disabled={!configLoaded} onClick={() => void save()}>Enregistrer</button>
    </section>
  );
}import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import {
  ArrowDownToLine,
  ArrowLeft,
  ArrowUpFromLine,
  Ban,
  Check,
  Copy,
  EyeOff,
  Gift,
  LockKeyhole,
  LogOut,
  Megaphone,
  Package,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  Send,
  ShieldCheck,
  Trash2,
  Users,
  Wallet,
  X,
} from "lucide-react";
import { api, formatFcfa, request } from "../api";
import { OperatorLogo, OPERATOR_PRESETS } from "./OperatorLogos";
import { PAYMENT_COUNTRIES } from "../../shared/payment-config";
import "../styles/admin.css";

type AdminUser = {
  id: number;
  phone: string;
  referralCode: string;
  referrerId: number | null;
  createdAt: string;
  isBanned: boolean;
  isBlocked: boolean;
  withdrawalsDisabled: boolean;
};

type AdminTransaction = {
  id: number;
  userId: number;
  userPhone: string;
  reference?: string | null;
  type: string;
  amount: number;
  fee: number;
  netAmount: number;
  status: string;
  note: string;
  payerNumber: string | null;
  countryCode?: string | null;
  operatorName?: string | null;
  referralCount: number;
  adminAssisted: boolean;
  createdAt: string;
};

type AdminProduct = {
  id: number;
  name: string;
  price: number;
  dailyIncome: number;
  totalIncome: number;
  durationDays: number;
  imageClass: string;
  active: boolean;
};

type AdminOverview = {
  stats: {
    approvedDeposits: number;
    approvedWithdrawals: number;
    pendingDeposits: number;
    pendingWithdrawals: number;
    approvedDepositCount: number;
    rejectedDepositCount: number;
    approvedWithdrawalCount: number;
    rejectedWithdrawalCount: number;
    users: number;
    investments: number;
    vipPurchases: number;
    adminCredits: number;
  };
  users: AdminUser[];
  transactions: AdminTransaction[];
  orders: Array<{
    id: number;
    userId: number;
    productId: number;
    amount: number;
    status: string;
    source: string;
    createdAt: string;
    productName: string;
    userPhone: string;
  }>;
  products: AdminProduct[];
  community: { isOpen: boolean; closureMessage: string };
  withdrawOpenOverride: boolean;
};

type UserDetail = {
  user: AdminUser;
  wallet: {
    balance: number;
    totalDeposits: number;
    totalWithdrawals: number;
    totalAdminCredits: number;
    totalAdminDebits: number;
    totalCommissions: number;
    totalCheckins: number;
    totalProductIncome: number;
  };
  transactions: Array<{ id: number; type: string; amount: number; status: string; note: string; createdAt: string }>;
  orders: Array<{ id: number; productName: string; amount: number; status: string; source: string; createdAt: string }>;
  checkins: Array<{ id: number; checkinDate: string; reward: number; status: string; createdAt: string }>;
};

type GiftCode = { id: number; code: string; amount: number; createdAt: string; redemptions: number };
type AdminAnnouncement = {
  id: number;
  title: string;
  content: string;
  kind: "announcement" | "notification";
  audience: "all" | "level";
  audienceLevel: string | null;
  status: "draft" | "published";
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
};
type PaymentChannel = {
  id: number;
  operatorName: string;
  receiverNumber: string;
  receiverName: string;
  logoColor: string;
  logoText: string;
  logoUrl: string;
  country: string;
  countryCode: string;
  ussdTemplate: string;
  isActive: boolean;
  sortOrder: number;
};
type AdminMutationOptions = { method: "POST" | "PATCH" | "DELETE"; body?: unknown };
type AdminScope = "global" | "cameroon";

const date = (value: string) => new Date(value).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" });
const exactDate = (value: string) => new Date(value).toLocaleString("fr-FR", {
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
});
const pending = (status: string) => status === "pending" || status === "pending_review";
const countryName = (countryCode?: string | null) =>
  PAYMENT_COUNTRIES.find((country) => country.code === countryCode)?.name ?? countryCode ?? "Non renseigné";

export function AdminLoginScreen({ scope, onLogin, onBack }: { scope: AdminScope; onLogin: () => void; onBack: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      await api.adminLogin(password, scope);
      onLogin();
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : "Connexion impossible.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="admin-login-page">
      <button className="admin-back-link" type="button" onClick={onBack}><ArrowLeft size={18} /> Retour</button>
      <form className="admin-login-card" onSubmit={submit}>
        <span className="admin-login-mark"><ShieldCheck size={34} /></span>
        <h1>{scope === "cameroon" ? "Administration Cameroun" : "Administration générale"}</h1>
        <p>{scope === "cameroon" ? "Validation des dépôts et retraits camerounais" : "Gestion complète de la plateforme Valhalla"}</p>
        <input
          type="text"
          name="username"
          autoComplete="username"
          value={scope === "cameroon" ? "admin-cameroon" : "admin"}
          readOnly
          tabIndex={-1}
          aria-hidden="true"
          style={{ position: "absolute", width: 1, height: 1, padding: 0, margin: -1, overflow: "hidden", clip: "rect(0, 0, 0, 0)", whiteSpace: "nowrap", border: 0 }}
        />
        <label>Mot de passe<input required type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} /></label>
        {error && <div className="admin-error" role="alert">{error}</div>}
        <button className="admin-primary-button" disabled={submitting} type="submit">
          <LockKeyhole size={17} /> {submitting ? "Vérification…" : "Se connecter"}
        </button>
      </form>
    </div>
  );
}

type AdminTab = "overview" | "transactions" | "users" | "products" | "codes" | "channels" | "announcements" | "settings";
type TransactionStatusFilter = "pending" | "approved" | "rejected";
type TransactionKind = "deposit" | "withdrawal";

export function AdminDashboard({ scope, onExit, onUnauthorized }: { scope: AdminScope; onExit: () => void; onUnauthorized: () => void }) {
  const isCameroon = scope === "cameroon";
  const [overview, setOverview] = useState<AdminOverview | null>(null);
  const [tab, setTab] = useState<AdminTab>("overview");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [search, setSearch] = useState("");
  const [transactionSearch, setTransactionSearch] = useState("");
  const [transactionKind, setTransactionKind] = useState<TransactionKind>("deposit");
  const [depositStatusFilter, setDepositStatusFilter] = useState<TransactionStatusFilter>("pending");
  const [withdrawalStatusFilter, setWithdrawalStatusFilter] = useState<TransactionStatusFilter>("pending");
  const [processingTransactionIds, setProcessingTransactionIds] = useState<Set<number>>(new Set());
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [userDetail, setUserDetail] = useState<UserDetail | null>(null);

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      setOverview(await request<AdminOverview>(
        isCameroon ? "/api/admin/cameroon/overview" : "/api/admin/overview",
        { cache: "no-store" },
      ));
    } catch (loadError) {
      const message = loadError instanceof Error ? loadError.message : "Chargement impossible.";
      if (/connexion administrateur/i.test(message)) onUnauthorized();
      else setError(message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const act = async (path: string, options: AdminMutationOptions, message: string) => {
    setError("");
    setNotice("");
    try {
      await request<{ message?: string }>(path, options);
      setNotice(message);
      await load();
      if (selectedUserId) await openUser(selectedUserId);
      return true;
    } catch (actionError) {
      setError(actionError instanceof Error ? actionError.message : "Action impossible.");
      return false;
    }
  };

  const processTransaction = async (id: number, status: string, withdrawal: boolean) => {
    if (processingTransactionIds.has(id)) return;
    setProcessingTransactionIds((current) => new Set(current).add(id));
    setOverview((current) => current ? {
      ...current,
      transactions: current.transactions.map((transaction) =>
        transaction.id === id ? { ...transaction, status } : transaction,
      ),
    } : current);
    try {
      const succeeded = await act(
        `${isCameroon ? "/api/admin/cameroon" : "/api/admin"}/transactions/${id}`,
        { method: "PATCH", body: { status } },
        withdrawal ? "Retrait traité." : "Dépôt traité.",
      );
      if (!succeeded) await load();
    } finally {
      setProcessingTransactionIds((current) => {
        const next = new Set(current);
        next.delete(id);
        return next;
      });
    }
  };

  const openUser = async (userId: number) => {
    setSelectedUserId(userId);
    setUserDetail(null);
    try {
      setUserDetail(await request<UserDetail>(`/api/admin/users/${userId}`, { cache: "no-store" }));
    } catch (detailError) {
      setError(detailError instanceof Error ? detailError.message : "Fiche indisponible.");
    }
  };

  const filteredUsers = useMemo(() => {
    const value = search.trim().toLowerCase();
    return (overview?.users ?? []).filter((user) => !value || user.phone.toLowerCase().includes(value) || String(user.id).includes(value));
  }, [overview, search]);

  const filteredDeposits = useMemo(() => {
    const value = transactionSearch.trim().toLowerCase();
    const availableDeposits = (overview?.transactions ?? []).filter(
      (transaction) => transaction.type === "deposit" && transactionMatchesFilter(transaction, depositStatusFilter),
    );
    if (!value) return availableDeposits;
    return availableDeposits.filter((transaction) => {
      const reference = (transaction.reference ?? "").toLowerCase();
      const displayedReference = displayTransactionReference(transaction.reference).toLowerCase();
      return reference.includes(value) || displayedReference.includes(value);
    });
  }, [overview, transactionSearch, depositStatusFilter]);
  const filteredWithdrawals = useMemo(() => {
    const value = transactionSearch.trim().toLowerCase();
    const availableWithdrawals = (overview?.transactions ?? []).filter(
      (transaction) => transaction.type === "withdrawal" && transactionMatchesFilter(transaction, withdrawalStatusFilter),
    );
    if (!value) return availableWithdrawals;
    return availableWithdrawals.filter((transaction) => {
      const reference = (transaction.reference ?? "").toLowerCase();
      const displayedReference = displayTransactionReference(transaction.reference).toLowerCase();
      return reference.includes(value) || displayedReference.includes(value);
    });
  }, [overview, transactionSearch, withdrawalStatusFilter]);
  const selectedTransactionTotal = transactionKind === "deposit"
    ? depositStatusFilter === "pending"
      ? overview?.stats.pendingDeposits ?? 0
      : depositStatusFilter === "approved"
        ? overview?.stats.approvedDepositCount ?? 0
        : overview?.stats.rejectedDepositCount ?? 0
    : withdrawalStatusFilter === "pending"
      ? overview?.stats.pendingWithdrawals ?? 0
      : withdrawalStatusFilter === "approved"
        ? overview?.stats.approvedWithdrawalCount ?? 0
        : overview?.stats.rejectedWithdrawalCount ?? 0;

  if (loading && !overview) {
    return <div className="admin-state-page"><RefreshCw className="admin-spin" /><h1>{isCameroon ? "Administration Cameroun" : "Administration générale"}</h1><p>Chargement sécurisé…</p></div>;
  }
  if (!overview) {
    return <div className="admin-state-page"><ShieldCheck size={44} /><h1>Administration indisponible</h1><p>{error}</p><button className="admin-primary-button" onClick={() => void load()}>Réessayer</button></div>;
  }

  return (
    <div className="admin-page">
      <header className="admin-header">
        <div><strong>{isCameroon ? "Administration Cameroun" : "Administration générale"}</strong><small>{isCameroon ? "Dépôts et retraits · +237" : "Gestion complète de Valhalla"}</small></div>
        <div className="admin-header-actions">
          <button type="button" title="Actualiser" onClick={() => void load()}><RefreshCw size={18} /></button>
          <button type="button" title="Déconnexion" onClick={() => void api.adminLogout(scope).finally(onExit)}><LogOut size={18} /></button>
        </div>
      </header>
      <main className="admin-content">
        {notice && <div className="admin-notice" role="status">{notice}</div>}
        {error && <div className="admin-error" role="alert">{error}</div>}
        <section className={`admin-stats-grid${isCameroon ? " cameroon" : ""}`}>
          <Stat icon={<ArrowDownToLine />} value={formatFcfa(overview.stats.approvedDeposits)} label="Dépôts" />
          <Stat icon={<ArrowUpFromLine />} value={formatFcfa(overview.stats.approvedWithdrawals)} label="Retraits" />
          {!isCameroon && <Stat icon={<Users />} value={String(overview.stats.users)} label="Utilisateurs" />}
          {!isCameroon && <Stat icon={<Package />} value={String(overview.stats.investments)} label="VIP actifs" />}
          {!isCameroon && <Stat icon={<Wallet />} value={formatFcfa(overview.stats.adminCredits)} label="Crédits admin" />}
        </section>
        <nav className="admin-tabs" aria-label="Sections administratives">
          {((isCameroon ? [
            ["overview", "Synthèse"],
            ["transactions", "Transactions"],
          ] : [
            ["overview", "Synthèse"],
            ["transactions", "Transactions"],
            ["users", "Utilisateurs"],
            ["products", "Produits"],
            ["codes", "Codes"],
            ["channels", "Canaux"],
            ["announcements", "Annonces"],
            ["settings", "Paramètres"],
          ]) as Array<[AdminTab, string]>).map(([value, label]) => (
            <button key={value} type="button" className={tab === value ? "active" : ""} onClick={() => setTab(value)}>{label}</button>
          ))}
        </nav>

        {tab === "overview" && (
          <section className="admin-panel">
            <h2>État de la plateforme</h2>
            <div className="admin-alert-grid">
              <article><strong>{overview.stats.pendingDeposits}</strong><span>dépôt(s) en attente</span></article>
              <article><strong>{overview.stats.pendingWithdrawals}</strong><span>retrait(s) en attente</span></article>
            </div>
            {!isCameroon && <div className="admin-setting-row">
              <div><strong>Retraits hors horaire</strong><small>{overview.withdrawOpenOverride ? "Ouverts manuellement" : "Horaire normal"}</small></div>
              <button className={overview.withdrawOpenOverride ? "admin-danger-button" : "admin-primary-button"} type="button" onClick={() => void act("/api/admin/withdraw-override", { method: "PATCH", body: { enabled: !overview.withdrawOpenOverride } }, "Règle de retrait mise à jour.")}>
                {overview.withdrawOpenOverride ? "Désactiver" : "Ouvrir"}
              </button>
            </div>}
          </section>
        )}

        {tab === "transactions" && (
          <section className="admin-panel">
            <h2>Transactions</h2>
            <div className="admin-transaction-kind-tabs" role="tablist" aria-label="Type de transaction">
              <button type="button" role="tab" aria-selected={transactionKind === "deposit"} className={transactionKind === "deposit" ? "active" : ""} onClick={() => setTransactionKind("deposit")}>
                Dépôts
              </button>
              <button type="button" role="tab" aria-selected={transactionKind === "withdrawal"} className={transactionKind === "withdrawal" ? "active" : ""} onClick={() => setTransactionKind("withdrawal")}>
                Retraits
              </button>
            </div>
            <h3>{transactionKind === "deposit" ? `Dépôts (${selectedTransactionTotal})` : `Retraits (${selectedTransactionTotal})`}</h3>
            <TransactionFilters
              value={transactionKind === "deposit" ? depositStatusFilter : withdrawalStatusFilter}
              onChange={transactionKind === "deposit" ? setDepositStatusFilter : setWithdrawalStatusFilter}
            />
            <label className="admin-search transaction-search">
              <Search size={17} />
              <input
                value={transactionSearch}
                onChange={(event) => setTransactionSearch(event.target.value)}
                placeholder="Rechercher par numéro de commande"
                aria-label={`Rechercher un ${transactionKind === "deposit" ? "dépôt" : "retrait"} par numéro de commande`}
              />
            </label>
            {transactionKind === "deposit"
              ? <TransactionList values={filteredDeposits} processingIds={processingTransactionIds} onStatus={(id, status) => void processTransaction(id, status, false)} />
              : <TransactionList values={filteredWithdrawals} processingIds={processingTransactionIds} withdrawal groupByCountry={withdrawalStatusFilter === "pending"} onStatus={(id, status) => void processTransaction(id, status, true)} />}
          </section>
        )}

        {tab === "users" && (
          <section className="admin-panel">
            <h2>Utilisateurs ({filteredUsers.length})</h2>
            <label className="admin-search"><Search size={17} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Téléphone ou identifiant" /></label>
            <div className="admin-list">
              {filteredUsers.map((user) => (
                <article className="admin-list-card" key={user.id}>
                  <div><strong>{user.phone}</strong><p>ID #{user.id} · {user.referralCode}</p><small>{date(user.createdAt)}</small></div>
                  <div className="admin-badges">{user.isBanned && <span>banni</span>}{user.isBlocked && <span>bloqué</span>}{user.withdrawalsDisabled && <span>retraits fermés</span>}</div>
                  <button type="button" onClick={() => void openUser(user.id)}>Gérer</button>
                </article>
              ))}
            </div>
          </section>
        )}

        {tab === "products" && <ProductsPanel overview={overview} act={act} />}
        {tab === "codes" && <GiftCodesPanel />}
        {tab === "channels" && <ChannelsPanel />}
        {tab === "announcements" && <AnnouncementsPanel />}
        {tab === "settings" && <SettingsPanel />}
      </main>
      {!isCameroon && selectedUserId !== null && (
        <UserPanel
          detail={userDetail}
          products={overview.products}
          close={() => { setSelectedUserId(null); setUserDetail(null); }}
          act={(path, body, message) => act(path, { method: "POST", body }, message)}
        />
      )}
    </div>
  );
}

function Stat({ icon, value, label }: { icon: ReactNode; value: string; label: string }) {
  return <article className="admin-stat-card"><span>{icon}</span><div><strong>{value}</strong><small>{label}</small></div></article>;
}

const displayTransactionReference = (reference?: string | null) =>
  (reference ?? "Non disponible").replace(/^(deposit|withdrawal)-/, "");

const transactionMatchesFilter = (transaction: AdminTransaction, filter: TransactionStatusFilter) => {
  if (filter === "pending") return pending(transaction.status);
  if (filter === "approved") return transaction.status === "approved" || transaction.status === "completed";
  return transaction.status === "rejected";
};

function TransactionFilters({ value, onChange }: { value: TransactionStatusFilter; onChange: (value: TransactionStatusFilter) => void }) {
  const filters: Array<[TransactionStatusFilter, string]> = [
    ["pending", "En attente"],
    ["approved", "Validés"],
    ["rejected", "Rejetés"],
  ];
  return (
    <div className="admin-transaction-filters" role="group" aria-label="Filtrer les transactions par statut">
      {filters.map(([filter, label]) => (
        <button key={filter} type="button" className={value === filter ? "active" : ""} onClick={() => onChange(filter)}>
          {label}
        </button>
      ))}
    </div>
  );
}

function TransactionList({ values, processingIds, withdrawal = false, groupByCountry = false, onStatus }: { values: AdminTransaction[]; processingIds: Set<number>; withdrawal?: boolean; groupByCountry?: boolean; onStatus: (id: number, status: string) => void }) {
  const [selectedCountryCode, setSelectedCountryCode] = useState("");
  if (!values.length) return <p className="admin-empty">Aucune transaction.</p>;
  const renderTransactions = (transactions: AdminTransaction[]) => <div className="admin-list">{transactions.map((transaction) => (
    <article className="admin-list-card" key={transaction.id}>
      <div className="admin-transaction-details">
        <strong className={withdrawal ? "admin-red-text" : "admin-green-text"}>{formatFcfa(transaction.amount)}</strong>
        <CopyableValue label="N° d’inscription" value={transaction.userPhone} />
        <small>Identifiant utilisateur : #{transaction.userId}</small>
        <small>Pays : {countryName(transaction.countryCode)}</small>
        <small>Opérateur : {transaction.operatorName || "Non renseigné"}</small>
        {!withdrawal && transaction.payerNumber && <CopyableValue label="Portefeuille payeur" value={transaction.payerNumber} />}
        {withdrawal && transaction.payerNumber && <CopyableValue label="Numéro de réception" value={transaction.payerNumber} />}
        <CopyableValue label={withdrawal ? "N° de commande du retrait" : "N° de commande du dépôt"} value={displayTransactionReference(transaction.reference)} />
        <small>Date et heure : {exactDate(transaction.createdAt)}</small>
        {withdrawal && pending(transaction.status) && <small className="admin-total-referrals">Nombre total de filleuls : <strong>{transaction.referralCount}</strong></small>}
        {withdrawal && <small>Montant retiré : {formatFcfa(transaction.amount)}</small>}
        {withdrawal && <small>Frais : {formatFcfa(transaction.fee)} · Net à envoyer : <strong>{formatFcfa(transaction.netAmount)}</strong></small>}
      </div>
      {withdrawal && pending(transaction.status) && transaction.adminAssisted && <span className="admin-assisted-badge">Admin</span>}
      <span className={`admin-status ${transaction.status}`}>{transaction.status}</span>
      {pending(transaction.status) && <div className="admin-card-actions"><button className="approve" type="button" disabled={processingIds.has(transaction.id)} onClick={() => onStatus(transaction.id, withdrawal ? "completed" : "approved")}><Check size={16} /></button><button className="reject" type="button" disabled={processingIds.has(transaction.id)} onClick={() => onStatus(transaction.id, "rejected")}><X size={16} /></button></div>}
    </article>
  ))}</div>;
  if (!groupByCountry) return renderTransactions(values);

  const groups = Array.from(
    values.reduce((byCountry, transaction) => {
      const code = transaction.countryCode || "";
      const transactions = byCountry.get(code) ?? [];
      transactions.push(transaction);
      byCountry.set(code, transactions);
      return byCountry;
    }, new Map<string, AdminTransaction[]>()),
  ).sort(([firstCode], [secondCode]) => countryName(firstCode).localeCompare(countryName(secondCode), "fr"));
  const selectedGroup = groups.find(([code]) => code === selectedCountryCode) ?? groups[0];

  return <div className="admin-country-withdrawals">
    <div className="admin-country-tabs" role="tablist" aria-label="Filtrer les retraits en attente par pays">
      {groups.map(([code, transactions]) => (
        <button
          key={code || "unknown"}
          type="button"
          role="tab"
          aria-selected={selectedGroup[0] === code}
          className={selectedGroup[0] === code ? "active" : ""}
          onClick={() => setSelectedCountryCode(code)}
        >
          <span>{countryName(code)}</span>
          <strong>{transactions.length}</strong>
        </button>
      ))}
    </div>
    <div className="admin-selected-country-summary">
      <strong>{countryName(selectedGroup[0])}</strong>
      <span>{selectedGroup[1].length} retrait{selectedGroup[1].length > 1 ? "s" : ""} en attente</span>
    </div>
    {renderTransactions(selectedGroup[1])}
  </div>;
}

function CopyableValue({ label, value }: { label: string; value: string }) {
  return (
    <small className="admin-copyable-value">
      <span>{label} : {value}</span>
      <button type="button" title={`Copier ${label.toLowerCase()}`} aria-label={`Copier ${label.toLowerCase()}`} onClick={() => void navigator.clipboard.writeText(value)}>
        <Copy size={13} />
      </button>
    </small>
  );
}

function UserPanel({ detail, products, close, act }: { detail: UserDetail | null; products: AdminProduct[]; close: () => void; act: (path: string, body: Record<string, unknown>, message: string) => Promise<boolean> }) {
  const [credit, setCredit] = useState("");
  const [debit, setDebit] = useState("");
  const [productId, setProductId] = useState("");
  const [busy, setBusy] = useState(false);
  const operationKeys = useRef<Record<string, string>>({});
  const runFinancialAction = async (kind: "credit" | "debit" | "vip", operation: (requestId: string) => Promise<boolean>) => {
    if (busy) return;
    setBusy(true);
    try {
      const requestId = operationKeys.current[kind] ?? crypto.randomUUID();
      operationKeys.current[kind] = requestId;
      if (await operation(requestId)) delete operationKeys.current[kind];
    } finally {
      setBusy(false);
    }
  };
  const removeVip = async (order: UserDetail["orders"][number]) => {
    if (busy) return;
    const confirmed = window.confirm(
      `Supprimer ${order.productName} de cet utilisateur ? Les futurs revenus seront arrêtés, sans remboursement de l'achat ni retrait des revenus déjà versés.`,
    );
    if (!confirmed) return;
    setBusy(true);
    try {
      await act(`/api/admin/orders/${order.id}/revoke-vip`, {}, "VIP supprimé.");
    } finally {
      setBusy(false);
    }
  };
  if (!detail) return <div className="admin-overlay"><div className="admin-user-panel admin-panel-loading"><RefreshCw className="admin-spin" /></div></div>;
  const user = detail.user;
  return (
    <div className="admin-overlay">
      <section className="admin-user-panel">
        <header><div><strong>{user.phone}</strong><small>Utilisateur #{user.id}</small></div><button type="button" onClick={close}><X /></button></header>
        <div className="admin-user-body">
          <div className="admin-balance"><span>Solde disponible</span><strong>{formatFcfa(detail.wallet.balance)}</strong></div>
          <div className="admin-balance-actions">
            <input type="number" min="1" value={credit} onChange={(event) => setCredit(event.target.value)} placeholder="Montant à créditer" />
            <button type="button" disabled={busy || !credit} onClick={() => void runFinancialAction("credit", async (requestId) => { const ok = await act(`/api/admin/users/${user.id}/credit`, { amount: Number(credit), requestId }, "Solde crédité."); if (ok) setCredit(""); return ok; })}>Créditer</button>
            <input type="number" min="1" value={debit} onChange={(event) => setDebit(event.target.value)} placeholder="Montant à débiter" />
            <button className="danger" type="button" disabled={busy || !debit} onClick={() => void runFinancialAction("debit", async (requestId) => { const ok = await act(`/api/admin/users/${user.id}/debit`, { amount: Number(debit), requestId }, "Solde débité."); if (ok) setDebit(""); return ok; })}>Débiter</button>
          </div>
          <div className="admin-user-actions">
            <button type="button" onClick={() => void act(`/api/admin/users/${user.id}/${user.isBanned ? "unban" : "ban"}`, {}, user.isBanned ? "Utilisateur débanni." : "Utilisateur banni.")}><Ban size={15} /> {user.isBanned ? "Débannir" : "Bannir"}</button>
            <button type="button" onClick={() => void act(`/api/admin/users/${user.id}/${user.isBlocked ? "unblock" : "block"}`, {}, user.isBlocked ? "Compte débloqué." : "Compte bloqué.")}>{user.isBlocked ? "Débloquer" : "Bloquer"}</button>
            <button type="button" onClick={() => void act(`/api/admin/users/${user.id}/${user.withdrawalsDisabled ? "open-withdrawals" : "close-withdrawals"}`, {}, "Droits de retrait mis à jour.")}>{user.withdrawalsDisabled ? "Ouvrir retraits" : "Fermer retraits"}</button>
          </div>
          <div className="admin-grant-row">
            <select value={productId} onChange={(event) => setProductId(event.target.value)}><option value="">Octroyer un VIP…</option>{products.filter((product) => product.active).map((product) => <option value={product.id} key={product.id}>{product.name}</option>)}</select>
            <button type="button" disabled={busy || !productId} onClick={() => void runFinancialAction("vip", async (requestId) => { const ok = await act(`/api/admin/users/${user.id}/grant-vip`, { productId: Number(productId), requestId }, "VIP octroyé."); if (ok) setProductId(""); return ok; })}>Octroyer</button>
          </div>
          <div className="admin-summary-grid">
            <span>Dépôts<strong>{formatFcfa(detail.wallet.totalDeposits)}</strong></span>
            <span>Retraits<strong>{formatFcfa(detail.wallet.totalWithdrawals)}</strong></span>
            <span>Crédits admin<strong>{formatFcfa(detail.wallet.totalAdminCredits)}</strong></span>
            <span>Débits admin<strong>{formatFcfa(detail.wallet.totalAdminDebits)}</strong></span>
          </div>
          <h3>Transactions récentes ({Math.min(detail.transactions.length, 12)})</h3>
          {detail.transactions.length
            ? detail.transactions.slice(0, 12).map((transaction) => <article className="admin-mini-row" key={transaction.id}><div><strong>{transaction.type}</strong><small>{transaction.note} · {date(transaction.createdAt)}</small></div><span>{formatFcfa(transaction.amount)}</span></article>)
            : <p className="admin-empty">Aucun dépôt ou retrait enregistré.</p>}
          <h3>VIP ({detail.orders.length})</h3>
          {detail.orders.map((order) => <article className="admin-mini-row" key={order.id}><div><strong>{order.productName}</strong><small>{order.source} · {date(order.createdAt)}</small></div>{order.status !== "rejected" && <button className="danger" type="button" disabled={busy} onClick={() => void removeVip(order)}><Trash2 size={14} /> Supprimer</button>}</article>)}
        </div>
      </section>
    </div>
  );
}

function ProductsPanel({ overview, act }: { overview: AdminOverview; act: (path: string, options: AdminMutationOptions, message: string) => Promise<boolean> }) {
  const emptyForm = { name: "", price: "", dailyIncome: "", totalIncome: "", durationDays: "180", imageClass: "1-DjVpknwl_1787413021677.png" };
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<number | null>(null);
  const resetForm = () => {
    setForm(emptyForm);
    setEditingId(null);
  };
  const edit = (product: AdminProduct) => {
    setEditingId(product.id);
    setForm({
      name: product.name,
      price: String(product.price),
      dailyIncome: String(product.dailyIncome),
      totalIncome: String(product.totalIncome),
      durationDays: String(product.durationDays),
      imageClass: product.imageClass,
    });
  };
  const submit = () => {
    const body = {
      ...form,
      price: Number(form.price),
      dailyIncome: Number(form.dailyIncome),
      totalIncome: Number(form.totalIncome),
      durationDays: Number(form.durationDays),
    };
    const path = editingId ? `/api/admin/products/${editingId}` : "/api/admin/products";
    const method = editingId ? "PATCH" : "POST";
    const message = editingId ? "Produit mis à jour." : "Produit créé.";
    return act(path, { method, body }, message).then((ok) => {
      if (ok) resetForm();
    });
  };
  const complete = Boolean(form.name && form.price && form.dailyIncome && form.totalIncome && form.durationDays);

  return (
    <section className="admin-panel">
      <h2>{editingId ? "Modifier le produit" : "Produits"}</h2>
      <div className="admin-inline-form">
        {(["name", "price", "dailyIncome", "totalIncome", "durationDays"] as const).map((field) => (
          <input key={field} type={field === "name" ? "text" : "number"} value={form[field]} onChange={(event) => setForm((current) => ({ ...current, [field]: event.target.value }))} placeholder={field} />
        ))}
        <button type="button" disabled={!complete} onClick={() => void submit()}>
          {editingId ? <><Check size={15} /> Enregistrer</> : <><Plus size={15} /> Ajouter</>}
        </button>
        {editingId && <button className="admin-product-cancel" type="button" onClick={resetForm}><X size={15} /> Annuler</button>}
      </div>
      <div className="admin-list">
        {overview.products.map((product) => (
          <article className={`admin-list-card ${editingId === product.id ? "editing" : ""}`} key={product.id}>
            <div>
              <strong>{product.name}</strong>
              <p>{formatFcfa(product.price)} · {formatFcfa(product.dailyIncome)}/jour</p>
              <small>{product.durationDays} jours · {product.active ? "Actif" : "Inactif"}</small>
            </div>
            <div className="admin-product-actions">
              <button type="button" aria-label={`Modifier ${product.name}`} onClick={() => edit(product)}><Pencil size={16} /></button>
              {product.active ? (
                <button className="admin-icon-danger" type="button" aria-label={`Désactiver ${product.name}`} onClick={() => void act(`/api/admin/products/${product.id}`, { method: "DELETE" }, "Produit désactivé.")}><Trash2 size={16} /></button>
              ) : (
                <button className="admin-icon-activate" type="button" onClick={() => void act(`/api/admin/products/${product.id}/activate`, { method: "PATCH" }, "Produit réactivé.")}><RefreshCw size={16} /> Réactiver</button>
              )}
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function GiftCodesPanel() {
  const [codes, setCodes] = useState<GiftCode[]>([]);
  const [code, setCode] = useState("");
  const [amount, setAmount] = useState("");
  const [error, setError] = useState("");
  const load = () => request<{ codes: GiftCode[] }>("/api/admin/gift-codes").then((data) => setCodes(data.codes)).catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  useEffect(() => { void load(); }, []);
  const create = async () => { await request("/api/admin/gift-codes", { method: "POST", body: { code, amount: Number(amount) } }); setCode(""); setAmount(""); await load(); };
  return <section className="admin-panel"><h2><Gift size={19} /> Codes cadeaux</h2>{error && <div className="admin-error">{error}</div>}<div className="admin-inline-form"><input value={code} onChange={(event) => setCode(event.target.value.toUpperCase())} placeholder="CODE2026" /><input type="number" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="Montant" /><button type="button" disabled={!code || !amount} onClick={() => void create().catch((reason) => setError(reason instanceof Error ? reason.message : "Création impossible."))}><Plus size={15} /> Créer</button></div><div className="admin-list">{codes.map((gift) => <article className="admin-list-card" key={gift.id}><div><strong>{gift.code}</strong><p>{formatFcfa(gift.amount)}</p><small>{gift.redemptions} utilisation(s)</small></div><button className="admin-icon-danger" type="button" onClick={() => void request(`/api/admin/gift-codes/${gift.id}`, { method: "DELETE" }).then(load)}><Trash2 size={16} /></button></article>)}</div></section>;
}

const emptyAnnouncementForm = {
  title: "",
  content: "",
  kind: "announcement" as AdminAnnouncement["kind"],
  audience: "all" as AdminAnnouncement["audience"],
  audienceLevel: "Lv1",
};

function AnnouncementsPanel() {
  const [announcements, setAnnouncements] = useState<AdminAnnouncement[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState(emptyAnnouncementForm);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const load = async () => {
    const data = await request<{ announcements: AdminAnnouncement[] }>("/api/admin/announcements", { cache: "no-store" });
    setAnnouncements(data.announcements);
  };

  useEffect(() => {
    void load().catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  }, []);

  const resetForm = () => {
    setEditingId(null);
    setForm(emptyAnnouncementForm);
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    setNotice("");
    try {
      await request(editingId ? `/api/admin/announcements/${editingId}` : "/api/admin/announcements", {
        method: editingId ? "PATCH" : "POST",
        body: {
          ...form,
          audienceLevel: form.audience === "level" ? form.audienceLevel : null,
        },
      });
      setNotice(editingId ? "Annonce mise à jour." : "Brouillon créé. Il reste invisible jusqu’à sa publication.");
      resetForm();
      await load();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Enregistrement impossible.");
    } finally {
      setSubmitting(false);
    }
  };

  const edit = (announcement: AdminAnnouncement) => {
    setEditingId(announcement.id);
    setForm({
      title: announcement.title,
      content: announcement.content,
      kind: announcement.kind,
      audience: announcement.audience,
      audienceLevel: announcement.audienceLevel ?? "Lv1",
    });
    setError("");
    setNotice("");
  };

  const changePublication = async (announcement: AdminAnnouncement) => {
    setError("");
    setNotice("");
    try {
      const action = announcement.status === "published" ? "withdraw" : "publish";
      await request(`/api/admin/announcements/${announcement.id}/${action}`, { method: "POST" });
      setNotice(announcement.status === "published" ? "Annonce retirée : elle n’est plus visible des utilisateurs." : "Annonce publiée.");
      await load();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Action impossible.");
    }
  };

  return (
    <section className="admin-panel">
      <h2><Megaphone size={19} /> Annonces et notifications</h2>
      <p className="admin-panel-intro">Créez un brouillon, relisez-le, puis publiez-le pour tous les utilisateurs ou pour un niveau précis.</p>
      {notice && <div className="admin-notice" role="status">{notice}</div>}
      {error && <div className="admin-error" role="alert">{error}</div>}
      <form className="admin-announcement-form" onSubmit={submit}>
        <label>
          Titre
          <input required maxLength={160} value={form.title} onChange={(event) => setForm((current) => ({ ...current, title: event.target.value }))} placeholder="Titre affiché aux utilisateurs" />
        </label>
        <label>
          Contenu
          <textarea required maxLength={10000} rows={6} value={form.content} onChange={(event) => setForm((current) => ({ ...current, content: event.target.value }))} placeholder="Rédigez le message à diffuser…" />
        </label>
        <div className="admin-announcement-options">
          <label>
            Format
            <select value={form.kind} onChange={(event) => setForm((current) => ({ ...current, kind: event.target.value as AdminAnnouncement["kind"] }))}>
              <option value="announcement">Annonce</option>
              <option value="notification">Notification</option>
            </select>
          </label>
          <label>
            Audience
            <select value={form.audience} onChange={(event) => setForm((current) => ({ ...current, audience: event.target.value as AdminAnnouncement["audience"] }))}>
              <option value="all">Tous les utilisateurs</option>
              <option value="level">Un niveau précis</option>
            </select>
          </label>
          {form.audience === "level" && (
            <label>
              Niveau
              <select value={form.audienceLevel} onChange={(event) => setForm((current) => ({ ...current, audienceLevel: event.target.value }))}>
                {["Lv1", "Lv2", "Lv3", "Lv4"].map((level) => <option key={level} value={level}>{level}</option>)}
              </select>
            </label>
          )}
        </div>
        <div className="admin-announcement-form-actions">
          <button className="admin-primary-button" disabled={submitting} type="submit">
            {editingId ? <Pencil size={16} /> : <Plus size={16} />}
            {submitting ? "Enregistrement…" : editingId ? "Enregistrer les modifications" : "Créer le brouillon"}
          </button>
          {editingId && <button className="admin-secondary-button" type="button" onClick={resetForm}>Annuler</button>}
        </div>
      </form>
      <div className="admin-list admin-announcement-list">
        {announcements.length === 0 && <div className="admin-empty">Aucune annonce enregistrée.</div>}
        {announcements.map((announcement) => (
          <article className="admin-list-card admin-announcement-card" key={announcement.id}>
            <div>
              <div className="admin-announcement-heading">
                <strong>{announcement.title}</strong>
                <span className={`admin-status ${announcement.status}`}>{announcement.status === "published" ? "Publiée" : "Brouillon"}</span>
              </div>
              <p className="admin-announcement-copy">{announcement.content}</p>
              <small>
                {announcement.kind === "notification" ? "Notification" : "Annonce"} · {announcement.audience === "all" ? "Tous les utilisateurs" : `Niveau ${announcement.audienceLevel}`}
                {announcement.publishedAt ? ` · publiée le ${date(announcement.publishedAt)}` : ` · modifiée le ${date(announcement.updatedAt)}`}
              </small>
            </div>
            <div className="admin-card-actions">
              {announcement.status === "draft" && <button type="button" onClick={() => edit(announcement)}><Pencil size={14} /> Modifier</button>}
              <button className={announcement.status === "published" ? "reject" : "approve"} type="button" onClick={() => void changePublication(announcement)}>
                {announcement.status === "published" ? <EyeOff size={14} /> : <Send size={14} />}
                {announcement.status === "published" ? "Retirer" : "Publier"}
              </button>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function ChannelsPanel() {
  const preset = OPERATOR_PRESETS[0];
  const defaultCountry = PAYMENT_COUNTRIES[0];
  const [channels, setChannels] = useState<PaymentChannel[]>([]);
  const [error, setError] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<Omit<PaymentChannel, "id">>({ operatorName: preset.label, receiverNumber: "", receiverName: "", logoColor: preset.logoColor, logoText: preset.key, logoUrl: "", country: defaultCountry.name, countryCode: defaultCountry.code, ussdTemplate: preset.defaultUssd, isActive: true, sortOrder: 0 });
  const load = () => request<{ channels: PaymentChannel[] }>("/api/admin/payment-channels").then((data) => setChannels(data.channels)).catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  useEffect(() => { void load(); }, []);
  const resetForm = () => {
    setEditingId(null);
    setForm({ operatorName: preset.label, receiverNumber: "", receiverName: "", logoColor: preset.logoColor, logoText: preset.key, logoUrl: "", country: defaultCountry.name, countryCode: defaultCountry.code, ussdTemplate: preset.defaultUssd, isActive: true, sortOrder: 0 });
  };
  const save = async () => {
    if (editingId) {
      await request(`/api/admin/payment-channels/${editingId}`, { method: "PATCH", body: form });
    } else {
      await request("/api/admin/payment-channels", { method: "POST", body: form });
    }
    resetForm();
    await load();
  };
  const edit = (channel: PaymentChannel) => {
    setEditingId(channel.id);
    setForm({
      operatorName: channel.operatorName,
      receiverNumber: channel.receiverNumber,
      receiverName: channel.receiverName,
      logoColor: channel.logoColor,
      logoText: channel.logoText,
      logoUrl: channel.logoUrl,
      country: channel.country,
      countryCode: channel.countryCode,
      ussdTemplate: channel.ussdTemplate,
      isActive: channel.isActive,
      sortOrder: channel.sortOrder,
    });
  };
  return <section className="admin-panel"><h2>Canaux de paiement</h2>{error && <div className="admin-error">{error}</div>}<div className="admin-operator-presets">{OPERATOR_PRESETS.map((item) => <button type="button" key={item.key} className={form.logoText === item.key ? "active" : ""} onClick={() => setForm((current) => ({ ...current, operatorName: item.label, logoColor: item.logoColor, logoText: item.key, ussdTemplate: item.defaultUssd }))}><OperatorLogo logoText={item.key} logoColor={item.logoColor} size={38} /><small>{item.key}</small></button>)}</div><div className="admin-inline-form"><input value={form.operatorName} onChange={(event) => setForm((current) => ({ ...current, operatorName: event.target.value }))} placeholder="Opérateur" /><input value={form.receiverNumber} onChange={(event) => setForm((current) => ({ ...current, receiverNumber: event.target.value }))} placeholder="Numéro marchand" /><input value={form.receiverName} onChange={(event) => setForm((current) => ({ ...current, receiverName: event.target.value }))} placeholder="Nom du marchand" /><label className="admin-channel-field">Pays<select value={form.countryCode} onChange={(event) => { const selectedCountry = PAYMENT_COUNTRIES.find((country) => country.code === event.target.value); if (selectedCountry) setForm((current) => ({ ...current, country: selectedCountry.name, countryCode: selectedCountry.code })); }}><option value="" disabled>Sélectionner un pays</option>{PAYMENT_COUNTRIES.map((country) => <option value={country.code} key={country.code}>{country.name} ({country.code})</option>)}</select></label><input value={form.ussdTemplate} onChange={(event) => setForm((current) => ({ ...current, ussdTemplate: event.target.value }))} placeholder="USSD avec {account} et {amount} (facultatif)" /><input value={form.logoUrl} onChange={(event) => setForm((current) => ({ ...current, logoUrl: event.target.value }))} placeholder="URL du logo (facultatif)" /><div className="admin-logo-preview"><OperatorLogo logoText={form.logoText} logoColor={form.logoColor} logoUrl={form.logoUrl} size={38} /><span>Aperçu du logo</span></div><button type="button" disabled={!form.operatorName || !form.receiverNumber} onClick={() => void save().catch((reason) => setError(reason instanceof Error ? reason.message : "Enregistrement impossible."))}>{editingId ? <Pencil size={15} /> : <Plus size={15} />} {editingId ? "Enregistrer" : "Ajouter"}</button>{editingId && <button type="button" onClick={resetForm}>Annuler</button>}</div><div className="admin-list">{channels.map((channel) => <article className="admin-list-card" key={channel.id}><OperatorLogo logoText={channel.logoText} logoColor={channel.logoColor} logoUrl={channel.logoUrl} /><div><strong>{channel.operatorName}</strong><p>{channel.country} · {channel.countryCode} · {channel.receiverNumber} · {channel.receiverName}</p><small>{channel.isActive ? "Actif" : "Inactif"} · {channel.ussdTemplate}</small></div><div className="admin-card-actions"><button type="button" onClick={() => edit(channel)}><Pencil size={14} /> Modifier</button><button type="button" onClick={() => void request(`/api/admin/payment-channels/${channel.id}`, { method: "PATCH", body: { isActive: !channel.isActive } }).then(load)}>{channel.isActive ? "Désactiver" : "Activer"}</button><button className="reject" type="button" onClick={() => void request(`/api/admin/payment-channels/${channel.id}`, { method: "DELETE" }).then(load)}><Trash2 size={15} /></button></div></article>)}</div></section>;
}

function SettingsPanel() {
  const [config, setConfig] = useState({
    depositMin: 3500,
    withdrawalMin: 2000,
    withdrawalFeePercent: 10,
    dashboxDeposit: 300,
    dashboxWithdraw: 1000,
    signupBonus: 2000,
    checkinBonus: 200,
    maxWithdrawals: null as number | null,
  });
  const [configLoaded, setConfigLoaded] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  useEffect(() => {
    request<{ config: typeof config }>("/api/admin/popup-config")
      .then((data) => { setConfig(data.config); setConfigLoaded(true); })
      .catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  }, []);
  const labels: Record<keyof typeof config, string> = {
    depositMin: "Dépôt minimum",
    withdrawalMin: "Retrait minimum",
    withdrawalFeePercent: "Frais de retrait (%)",
    dashboxDeposit: "Montant rapide de dépôt",
    dashboxWithdraw: "Montant rapide de retrait",
    signupBonus: "Bonus d’inscription",
    checkinBonus: "Bonus de pointage",
    maxWithdrawals: "Retraits maximum par jour",
  };
  const save = async () => {
    setError("");
    setNotice("");
    if (config.maxWithdrawals !== null && (!Number.isSafeInteger(config.maxWithdrawals) || config.maxWithdrawals <= 0)) {
      setError("Le nombre maximum de retraits doit être un entier positif ou illimité.");
      return;
    }
    try {
      await request("/api/admin/popup-config", { method: "PATCH", body: config });
      setNotice("Paramètres enregistrés et appliqués aux règles backend.");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Enregistrement impossible.");
    }
  };
  return (
    <section className="admin-panel">
      <h2>Paramètres financiers</h2>
      {notice && <div className="admin-notice">{notice}</div>}
      {error && <div className="admin-error">{error}</div>}
      <div className="admin-settings-grid">
        {(Object.keys(config) as Array<keyof typeof config>).filter((field) => field !== "maxWithdrawals").map((field) => (
          <label key={field}>{labels[field]}<input type="number" min="1" value={config[field] ?? ""} onChange={(event) => setConfig((current) => ({ ...current, [field]: Number(event.target.value) }))} /></label>
        ))}
        <label>Retraits maximum par jour<select value={config.maxWithdrawals === null ? "unlimited" : "limited"} onChange={(event) => setConfig((current) => ({ ...current, maxWithdrawals: event.target.value === "unlimited" ? null : current.maxWithdrawals ?? 1 }))}><option value="limited">Nombre limité</option><option value="unlimited">Illimité</option></select><input type="number" min="1" step="1" value={config.maxWithdrawals ?? ""} disabled={config.maxWithdrawals === null} onChange={(event) => setConfig((current) => ({ ...current, maxWithdrawals: Number(event.target.value) }))} /></label>
      </div>
      <button className="admin-primary-button" type="button" disabled={!configLoaded} onClick={() => void save()}>Enregistrer</button>
    </section>
  );
}import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import {
  ArrowDownToLine,
  ArrowLeft,
  ArrowUpFromLine,
  Ban,
  Check,
  Copy,
  EyeOff,
  Gift,
  LockKeyhole,
  LogOut,
  Megaphone,
  Package,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  Send,
  ShieldCheck,
  Trash2,
  Users,
  Wallet,
  X,
} from "lucide-react";
import { api, formatFcfa, request } from "../api";
import { OperatorLogo, OPERATOR_PRESETS } from "./OperatorLogos";
import { PAYMENT_COUNTRIES } from "../../shared/payment-config";
import "../styles/admin.css";

type AdminUser = {
  id: number;
  phone: string;
  referralCode: string;
  referrerId: number | null;
  createdAt: string;
  isBanned: boolean;
  isBlocked: boolean;
  withdrawalsDisabled: boolean;
};

type AdminTransaction = {
  id: number;
  userId: number;
  userPhone: string;
  reference?: string | null;
  type: string;
  amount: number;
  fee: number;
  netAmount: number;
  status: string;
  note: string;
  payerNumber: string | null;
  countryCode?: string | null;
  operatorName?: string | null;
  referralCount: number;
  adminAssisted: boolean;
  createdAt: string;
};

type AdminProduct = {
  id: number;
  name: string;
  price: number;
  dailyIncome: number;
  totalIncome: number;
  durationDays: number;
  imageClass: string;
  active: boolean;
};

type AdminOverview = {
  stats: {
    approvedDeposits: number;
    approvedWithdrawals: number;
    pendingDeposits: number;
    pendingWithdrawals: number;
    approvedDepositCount: number;
    rejectedDepositCount: number;
    approvedWithdrawalCount: number;
    rejectedWithdrawalCount: number;
    users: number;
    investments: number;
    vipPurchases: number;
    adminCredits: number;
  };
  users: AdminUser[];
  transactions: AdminTransaction[];
  orders: Array<{
    id: number;
    userId: number;
    productId: number;
    amount: number;
    status: string;
    source: string;
    createdAt: string;
    productName: string;
    userPhone: string;
  }>;
  products: AdminProduct[];
  community: { isOpen: boolean; closureMessage: string };
  withdrawOpenOverride: boolean;
};

type UserDetail = {
  user: AdminUser;
  wallet: {
    balance: number;
    totalDeposits: number;
    totalWithdrawals: number;
    totalAdminCredits: number;
    totalAdminDebits: number;
    totalCommissions: number;
    totalCheckins: number;
    totalProductIncome: number;
  };
  transactions: Array<{ id: number; type: string; amount: number; status: string; note: string; createdAt: string }>;
  orders: Array<{ id: number; productName: string; amount: number; status: string; source: string; createdAt: string }>;
  checkins: Array<{ id: number; checkinDate: string; reward: number; status: string; createdAt: string }>;
};

type GiftCode = { id: number; code: string; amount: number; createdAt: string; redemptions: number };
type AdminAnnouncement = {
  id: number;
  title: string;
  content: string;
  kind: "announcement" | "notification";
  audience: "all" | "level";
  audienceLevel: string | null;
  status: "draft" | "published";
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
};
type PaymentChannel = {
  id: number;
  operatorName: string;
  receiverNumber: string;
  receiverName: string;
  logoColor: string;
  logoText: string;
  logoUrl: string;
  country: string;
  countryCode: string;
  ussdTemplate: string;
  isActive: boolean;
  sortOrder: number;
};
type AdminMutationOptions = { method: "POST" | "PATCH" | "DELETE"; body?: unknown };
type AdminScope = "global" | "cameroon";

const date = (value: string) => new Date(value).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" });
const exactDate = (value: string) => new Date(value).toLocaleString("fr-FR", {
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
});
const pending = (status: string) => status === "pending" || status === "pending_review";
const countryName = (countryCode?: string | null) =>
  PAYMENT_COUNTRIES.find((country) => country.code === countryCode)?.name ?? countryCode ?? "Non renseigné";

export function AdminLoginScreen({ scope, onLogin, onBack }: { scope: AdminScope; onLogin: () => void; onBack: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      await api.adminLogin(password, scope);
      onLogin();
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : "Connexion impossible.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="admin-login-page">
      <button className="admin-back-link" type="button" onClick={onBack}><ArrowLeft size={18} /> Retour</button>
      <form className="admin-login-card" onSubmit={submit}>
        <span className="admin-login-mark"><ShieldCheck size={34} /></span>
        <h1>{scope === "cameroon" ? "Administration Cameroun" : "Administration générale"}</h1>
        <p>{scope === "cameroon" ? "Validation des dépôts et retraits camerounais" : "Gestion complète de la plateforme Valhalla"}</p>
        <input
          type="text"
          name="username"
          autoComplete="username"
          value={scope === "cameroon" ? "admin-cameroon" : "admin"}
          readOnly
          tabIndex={-1}
          aria-hidden="true"
          style={{ position: "absolute", width: 1, height: 1, padding: 0, margin: -1, overflow: "hidden", clip: "rect(0, 0, 0, 0)", whiteSpace: "nowrap", border: 0 }}
        />
        <label>Mot de passe<input required type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} /></label>
        {error && <div className="admin-error" role="alert">{error}</div>}
        <button className="admin-primary-button" disabled={submitting} type="submit">
          <LockKeyhole size={17} /> {submitting ? "Vérification…" : "Se connecter"}
        </button>
      </form>
    </div>
  );
}

type AdminTab = "overview" | "transactions" | "users" | "products" | "codes" | "channels" | "announcements" | "settings";
type TransactionStatusFilter = "pending" | "approved" | "rejected";
type TransactionKind = "deposit" | "withdrawal";

export function AdminDashboard({ scope, onExit, onUnauthorized }: { scope: AdminScope; onExit: () => void; onUnauthorized: () => void }) {
  const isCameroon = scope === "cameroon";
  const [overview, setOverview] = useState<AdminOverview | null>(null);
  const [tab, setTab] = useState<AdminTab>("overview");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [search, setSearch] = useState("");
  const [transactionSearch, setTransactionSearch] = useState("");
  const [transactionKind, setTransactionKind] = useState<TransactionKind>("deposit");
  const [depositStatusFilter, setDepositStatusFilter] = useState<TransactionStatusFilter>("pending");
  const [withdrawalStatusFilter, setWithdrawalStatusFilter] = useState<TransactionStatusFilter>("pending");
  const [processingTransactionIds, setProcessingTransactionIds] = useState<Set<number>>(new Set());
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [userDetail, setUserDetail] = useState<UserDetail | null>(null);

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      setOverview(await request<AdminOverview>(
        isCameroon ? "/api/admin/cameroon/overview" : "/api/admin/overview",
        { cache: "no-store" },
      ));
    } catch (loadError) {
      const message = loadError instanceof Error ? loadError.message : "Chargement impossible.";
      if (/connexion administrateur/i.test(message)) onUnauthorized();
      else setError(message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const act = async (path: string, options: AdminMutationOptions, message: string) => {
    setError("");
    setNotice("");
    try {
      await request<{ message?: string }>(path, options);
      setNotice(message);
      await load();
      if (selectedUserId) await openUser(selectedUserId);
      return true;
    } catch (actionError) {
      setError(actionError instanceof Error ? actionError.message : "Action impossible.");
      return false;
    }
  };

  const processTransaction = async (id: number, status: string, withdrawal: boolean) => {
    if (processingTransactionIds.has(id)) return;
    setProcessingTransactionIds((current) => new Set(current).add(id));
    setOverview((current) => current ? {
      ...current,
      transactions: current.transactions.map((transaction) =>
        transaction.id === id ? { ...transaction, status } : transaction,
      ),
    } : current);
    try {
      const succeeded = await act(
        `${isCameroon ? "/api/admin/cameroon" : "/api/admin"}/transactions/${id}`,
        { method: "PATCH", body: { status } },
        withdrawal ? "Retrait traité." : "Dépôt traité.",
      );
      if (!succeeded) await load();
    } finally {
      setProcessingTransactionIds((current) => {
        const next = new Set(current);
        next.delete(id);
        return next;
      });
    }
  };

  const openUser = async (userId: number) => {
    setSelectedUserId(userId);
    setUserDetail(null);
    try {
      setUserDetail(await request<UserDetail>(`/api/admin/users/${userId}`, { cache: "no-store" }));
    } catch (detailError) {
      setError(detailError instanceof Error ? detailError.message : "Fiche indisponible.");
    }
  };

  const filteredUsers = useMemo(() => {
    const value = search.trim().toLowerCase();
    return (overview?.users ?? []).filter((user) => !value || user.phone.toLowerCase().includes(value) || String(user.id).includes(value));
  }, [overview, search]);

  const filteredDeposits = useMemo(() => {
    const value = transactionSearch.trim().toLowerCase();
    const availableDeposits = (overview?.transactions ?? []).filter(
      (transaction) => transaction.type === "deposit" && transactionMatchesFilter(transaction, depositStatusFilter),
    );
    if (!value) return availableDeposits;
    return availableDeposits.filter((transaction) => {
      const reference = (transaction.reference ?? "").toLowerCase();
      const displayedReference = displayTransactionReference(transaction.reference).toLowerCase();
      return reference.includes(value) || displayedReference.includes(value);
    });
  }, [overview, transactionSearch, depositStatusFilter]);
  const filteredWithdrawals = useMemo(() => {
    const value = transactionSearch.trim().toLowerCase();
    const availableWithdrawals = (overview?.transactions ?? []).filter(
      (transaction) => transaction.type === "withdrawal" && transactionMatchesFilter(transaction, withdrawalStatusFilter),
    );
    if (!value) return availableWithdrawals;
    return availableWithdrawals.filter((transaction) => {
      const reference = (transaction.reference ?? "").toLowerCase();
      const displayedReference = displayTransactionReference(transaction.reference).toLowerCase();
      return reference.includes(value) || displayedReference.includes(value);
    });
  }, [overview, transactionSearch, withdrawalStatusFilter]);
  const selectedTransactionTotal = transactionKind === "deposit"
    ? depositStatusFilter === "pending"
      ? overview?.stats.pendingDeposits ?? 0
      : depositStatusFilter === "approved"
        ? overview?.stats.approvedDepositCount ?? 0
        : overview?.stats.rejectedDepositCount ?? 0
    : withdrawalStatusFilter === "pending"
      ? overview?.stats.pendingWithdrawals ?? 0
      : withdrawalStatusFilter === "approved"
        ? overview?.stats.approvedWithdrawalCount ?? 0
        : overview?.stats.rejectedWithdrawalCount ?? 0;

  if (loading && !overview) {
    return <div className="admin-state-page"><RefreshCw className="admin-spin" /><h1>{isCameroon ? "Administration Cameroun" : "Administration générale"}</h1><p>Chargement sécurisé…</p></div>;
  }
  if (!overview) {
    return <div className="admin-state-page"><ShieldCheck size={44} /><h1>Administration indisponible</h1><p>{error}</p><button className="admin-primary-button" onClick={() => void load()}>Réessayer</button></div>;
  }

  return (
    <div className="admin-page">
      <header className="admin-header">
        <div><strong>{isCameroon ? "Administration Cameroun" : "Administration générale"}</strong><small>{isCameroon ? "Dépôts et retraits · +237" : "Gestion complète de Valhalla"}</small></div>
        <div className="admin-header-actions">
          <button type="button" title="Actualiser" onClick={() => void load()}><RefreshCw size={18} /></button>
          <button type="button" title="Déconnexion" onClick={() => void api.adminLogout(scope).finally(onExit)}><LogOut size={18} /></button>
        </div>
      </header>
      <main className="admin-content">
        {notice && <div className="admin-notice" role="status">{notice}</div>}
        {error && <div className="admin-error" role="alert">{error}</div>}
        <section className={`admin-stats-grid${isCameroon ? " cameroon" : ""}`}>
          <Stat icon={<ArrowDownToLine />} value={formatFcfa(overview.stats.approvedDeposits)} label="Dépôts" />
          <Stat icon={<ArrowUpFromLine />} value={formatFcfa(overview.stats.approvedWithdrawals)} label="Retraits" />
          {!isCameroon && <Stat icon={<Users />} value={String(overview.stats.users)} label="Utilisateurs" />}
          {!isCameroon && <Stat icon={<Package />} value={String(overview.stats.investments)} label="VIP actifs" />}
          {!isCameroon && <Stat icon={<Wallet />} value={formatFcfa(overview.stats.adminCredits)} label="Crédits admin" />}
        </section>
        <nav className="admin-tabs" aria-label="Sections administratives">
          {((isCameroon ? [
            ["overview", "Synthèse"],
            ["transactions", "Transactions"],
          ] : [
            ["overview", "Synthèse"],
            ["transactions", "Transactions"],
            ["users", "Utilisateurs"],
            ["products", "Produits"],
            ["codes", "Codes"],
            ["channels", "Canaux"],
            ["announcements", "Annonces"],
            ["settings", "Paramètres"],
          ]) as Array<[AdminTab, string]>).map(([value, label]) => (
            <button key={value} type="button" className={tab === value ? "active" : ""} onClick={() => setTab(value)}>{label}</button>
          ))}
        </nav>

        {tab === "overview" && (
          <section className="admin-panel">
            <h2>État de la plateforme</h2>
            <div className="admin-alert-grid">
              <article><strong>{overview.stats.pendingDeposits}</strong><span>dépôt(s) en attente</span></article>
              <article><strong>{overview.stats.pendingWithdrawals}</strong><span>retrait(s) en attente</span></article>
            </div>
            {!isCameroon && <div className="admin-setting-row">
              <div><strong>Retraits hors horaire</strong><small>{overview.withdrawOpenOverride ? "Ouverts manuellement" : "Horaire normal"}</small></div>
              <button className={overview.withdrawOpenOverride ? "admin-danger-button" : "admin-primary-button"} type="button" onClick={() => void act("/api/admin/withdraw-override", { method: "PATCH", body: { enabled: !overview.withdrawOpenOverride } }, "Règle de retrait mise à jour.")}>
                {overview.withdrawOpenOverride ? "Désactiver" : "Ouvrir"}
              </button>
            </div>}
          </section>
        )}

        {tab === "transactions" && (
          <section className="admin-panel">
            <h2>Transactions</h2>
            <div className="admin-transaction-kind-tabs" role="tablist" aria-label="Type de transaction">
              <button type="button" role="tab" aria-selected={transactionKind === "deposit"} className={transactionKind === "deposit" ? "active" : ""} onClick={() => setTransactionKind("deposit")}>
                Dépôts
              </button>
              <button type="button" role="tab" aria-selected={transactionKind === "withdrawal"} className={transactionKind === "withdrawal" ? "active" : ""} onClick={() => setTransactionKind("withdrawal")}>
                Retraits
              </button>
            </div>
            <h3>{transactionKind === "deposit" ? `Dépôts (${selectedTransactionTotal})` : `Retraits (${selectedTransactionTotal})`}</h3>
            <TransactionFilters
              value={transactionKind === "deposit" ? depositStatusFilter : withdrawalStatusFilter}
              onChange={transactionKind === "deposit" ? setDepositStatusFilter : setWithdrawalStatusFilter}
            />
            <label className="admin-search transaction-search">
              <Search size={17} />
              <input
                value={transactionSearch}
                onChange={(event) => setTransactionSearch(event.target.value)}
                placeholder="Rechercher par numéro de commande"
                aria-label={`Rechercher un ${transactionKind === "deposit" ? "dépôt" : "retrait"} par numéro de commande`}
              />
            </label>
            {transactionKind === "deposit"
              ? <TransactionList values={filteredDeposits} processingIds={processingTransactionIds} onStatus={(id, status) => void processTransaction(id, status, false)} />
              : <TransactionList values={filteredWithdrawals} processingIds={processingTransactionIds} withdrawal groupByCountry={withdrawalStatusFilter === "pending"} onStatus={(id, status) => void processTransaction(id, status, true)} />}
          </section>
        )}

        {tab === "users" && (
          <section className="admin-panel">
            <h2>Utilisateurs ({filteredUsers.length})</h2>
            <label className="admin-search"><Search size={17} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Téléphone ou identifiant" /></label>
            <div className="admin-list">
              {filteredUsers.map((user) => (
                <article className="admin-list-card" key={user.id}>
                  <div><strong>{user.phone}</strong><p>ID #{user.id} · {user.referralCode}</p><small>{date(user.createdAt)}</small></div>
                  <div className="admin-badges">{user.isBanned && <span>banni</span>}{user.isBlocked && <span>bloqué</span>}{user.withdrawalsDisabled && <span>retraits fermés</span>}</div>
                  <button type="button" onClick={() => void openUser(user.id)}>Gérer</button>
                </article>
              ))}
            </div>
          </section>
        )}

        {tab === "products" && <ProductsPanel overview={overview} act={act} />}
        {tab === "codes" && <GiftCodesPanel />}
        {tab === "channels" && <ChannelsPanel />}
        {tab === "announcements" && <AnnouncementsPanel />}
        {tab === "settings" && <SettingsPanel />}
      </main>
      {!isCameroon && selectedUserId !== null && (
        <UserPanel
          detail={userDetail}
          products={overview.products}
          close={() => { setSelectedUserId(null); setUserDetail(null); }}
          act={(path, body, message) => act(path, { method: "POST", body }, message)}
        />
      )}
    </div>
  );
}

function Stat({ icon, value, label }: { icon: ReactNode; value: string; label: string }) {
  return <article className="admin-stat-card"><span>{icon}</span><div><strong>{value}</strong><small>{label}</small></div></article>;
}

const displayTransactionReference = (reference?: string | null) =>
  (reference ?? "Non disponible").replace(/^(deposit|withdrawal)-/, "");

const transactionMatchesFilter = (transaction: AdminTransaction, filter: TransactionStatusFilter) => {
  if (filter === "pending") return pending(transaction.status);
  if (filter === "approved") return transaction.status === "approved" || transaction.status === "completed";
  return transaction.status === "rejected";
};

function TransactionFilters({ value, onChange }: { value: TransactionStatusFilter; onChange: (value: TransactionStatusFilter) => void }) {
  const filters: Array<[TransactionStatusFilter, string]> = [
    ["pending", "En attente"],
    ["approved", "Validés"],
    ["rejected", "Rejetés"],
  ];
  return (
    <div className="admin-transaction-filters" role="group" aria-label="Filtrer les transactions par statut">
      {filters.map(([filter, label]) => (
        <button key={filter} type="button" className={value === filter ? "active" : ""} onClick={() => onChange(filter)}>
          {label}
        </button>
      ))}
    </div>
  );
}

function TransactionList({ values, processingIds, withdrawal = false, groupByCountry = false, onStatus }: { values: AdminTransaction[]; processingIds: Set<number>; withdrawal?: boolean; groupByCountry?: boolean; onStatus: (id: number, status: string) => void }) {
  const [selectedCountryCode, setSelectedCountryCode] = useState("");
  if (!values.length) return <p className="admin-empty">Aucune transaction.</p>;
  const renderTransactions = (transactions: AdminTransaction[]) => <div className="admin-list">{transactions.map((transaction) => (
    <article className="admin-list-card" key={transaction.id}>
      <div className="admin-transaction-details">
        <strong className={withdrawal ? "admin-red-text" : "admin-green-text"}>{formatFcfa(transaction.amount)}</strong>
        <CopyableValue label="N° d’inscription" value={transaction.userPhone} />
        <small>Identifiant utilisateur : #{transaction.userId}</small>
        <small>Pays : {countryName(transaction.countryCode)}</small>
        <small>Opérateur : {transaction.operatorName || "Non renseigné"}</small>
        {!withdrawal && transaction.payerNumber && <CopyableValue label="Portefeuille payeur" value={transaction.payerNumber} />}
        {withdrawal && transaction.payerNumber && <CopyableValue label="Numéro de réception" value={transaction.payerNumber} />}
        <CopyableValue label={withdrawal ? "N° de commande du retrait" : "N° de commande du dépôt"} value={displayTransactionReference(transaction.reference)} />
        <small>Date et heure : {exactDate(transaction.createdAt)}</small>
        {withdrawal && pending(transaction.status) && <small className="admin-total-referrals">Nombre total de filleuls : <strong>{transaction.referralCount}</strong></small>}
        {withdrawal && <small>Montant retiré : {formatFcfa(transaction.amount)}</small>}
        {withdrawal && <small>Frais : {formatFcfa(transaction.fee)} · Net à envoyer : <strong>{formatFcfa(transaction.netAmount)}</strong></small>}
      </div>
      {withdrawal && pending(transaction.status) && transaction.adminAssisted && <span className="admin-assisted-badge">Admin</span>}
      <span className={`admin-status ${transaction.status}`}>{transaction.status}</span>
      {pending(transaction.status) && <div className="admin-card-actions"><button className="approve" type="button" disabled={processingIds.has(transaction.id)} onClick={() => onStatus(transaction.id, withdrawal ? "completed" : "approved")}><Check size={16} /></button><button className="reject" type="button" disabled={processingIds.has(transaction.id)} onClick={() => onStatus(transaction.id, "rejected")}><X size={16} /></button></div>}
    </article>
  ))}</div>;
  if (!groupByCountry) return renderTransactions(values);

  const groups = Array.from(
    values.reduce((byCountry, transaction) => {
      const code = transaction.countryCode || "";
      const transactions = byCountry.get(code) ?? [];
      transactions.push(transaction);
      byCountry.set(code, transactions);
      return byCountry;
    }, new Map<string, AdminTransaction[]>()),
  ).sort(([firstCode], [secondCode]) => countryName(firstCode).localeCompare(countryName(secondCode), "fr"));
  const selectedGroup = groups.find(([code]) => code === selectedCountryCode) ?? groups[0];

  return <div className="admin-country-withdrawals">
    <div className="admin-country-tabs" role="tablist" aria-label="Filtrer les retraits en attente par pays">
      {groups.map(([code, transactions]) => (
        <button
          key={code || "unknown"}
          type="button"
          role="tab"
          aria-selected={selectedGroup[0] === code}
          className={selectedGroup[0] === code ? "active" : ""}
          onClick={() => setSelectedCountryCode(code)}
        >
          <span>{countryName(code)}</span>
          <strong>{transactions.length}</strong>
        </button>
      ))}
    </div>
    <div className="admin-selected-country-summary">
      <strong>{countryName(selectedGroup[0])}</strong>
      <span>{selectedGroup[1].length} retrait{selectedGroup[1].length > 1 ? "s" : ""} en attente</span>
    </div>
    {renderTransactions(selectedGroup[1])}
  </div>;
}

function CopyableValue({ label, value }: { label: string; value: string }) {
  return (
    <small className="admin-copyable-value">
      <span>{label} : {value}</span>
      <button type="button" title={`Copier ${label.toLowerCase()}`} aria-label={`Copier ${label.toLowerCase()}`} onClick={() => void navigator.clipboard.writeText(value)}>
        <Copy size={13} />
      </button>
    </small>
  );
}

function UserPanel({ detail, products, close, act }: { detail: UserDetail | null; products: AdminProduct[]; close: () => void; act: (path: string, body: Record<string, unknown>, message: string) => Promise<boolean> }) {
  const [credit, setCredit] = useState("");
  const [debit, setDebit] = useState("");
  const [productId, setProductId] = useState("");
  const [busy, setBusy] = useState(false);
  const operationKeys = useRef<Record<string, string>>({});
  const runFinancialAction = async (kind: "credit" | "debit" | "vip", operation: (requestId: string) => Promise<boolean>) => {
    if (busy) return;
    setBusy(true);
    try {
      const requestId = operationKeys.current[kind] ?? crypto.randomUUID();
      operationKeys.current[kind] = requestId;
      if (await operation(requestId)) delete operationKeys.current[kind];
    } finally {
      setBusy(false);
    }
  };
  const removeVip = async (order: UserDetail["orders"][number]) => {
    if (busy) return;
    const confirmed = window.confirm(
      `Supprimer ${order.productName} de cet utilisateur ? Les futurs revenus seront arrêtés, sans remboursement de l'achat ni retrait des revenus déjà versés.`,
    );
    if (!confirmed) return;
    setBusy(true);
    try {
      await act(`/api/admin/orders/${order.id}/revoke-vip`, {}, "VIP supprimé.");
    } finally {
      setBusy(false);
    }
  };
  if (!detail) return <div className="admin-overlay"><div className="admin-user-panel admin-panel-loading"><RefreshCw className="admin-spin" /></div></div>;
  const user = detail.user;
  return (
    <div className="admin-overlay">
      <section className="admin-user-panel">
        <header><div><strong>{user.phone}</strong><small>Utilisateur #{user.id}</small></div><button type="button" onClick={close}><X /></button></header>
        <div className="admin-user-body">
          <div className="admin-balance"><span>Solde disponible</span><strong>{formatFcfa(detail.wallet.balance)}</strong></div>
          <div className="admin-balance-actions">
            <input type="number" min="1" value={credit} onChange={(event) => setCredit(event.target.value)} placeholder="Montant à créditer" />
            <button type="button" disabled={busy || !credit} onClick={() => void runFinancialAction("credit", async (requestId) => { const ok = await act(`/api/admin/users/${user.id}/credit`, { amount: Number(credit), requestId }, "Solde crédité."); if (ok) setCredit(""); return ok; })}>Créditer</button>
            <input type="number" min="1" value={debit} onChange={(event) => setDebit(event.target.value)} placeholder="Montant à débiter" />
            <button className="danger" type="button" disabled={busy || !debit} onClick={() => void runFinancialAction("debit", async (requestId) => { const ok = await act(`/api/admin/users/${user.id}/debit`, { amount: Number(debit), requestId }, "Solde débité."); if (ok) setDebit(""); return ok; })}>Débiter</button>
          </div>
          <div className="admin-user-actions">
            <button type="button" onClick={() => void act(`/api/admin/users/${user.id}/${user.isBanned ? "unban" : "ban"}`, {}, user.isBanned ? "Utilisateur débanni." : "Utilisateur banni.")}><Ban size={15} /> {user.isBanned ? "Débannir" : "Bannir"}</button>
            <button type="button" onClick={() => void act(`/api/admin/users/${user.id}/${user.isBlocked ? "unblock" : "block"}`, {}, user.isBlocked ? "Compte débloqué." : "Compte bloqué.")}>{user.isBlocked ? "Débloquer" : "Bloquer"}</button>
            <button type="button" onClick={() => void act(`/api/admin/users/${user.id}/${user.withdrawalsDisabled ? "open-withdrawals" : "close-withdrawals"}`, {}, "Droits de retrait mis à jour.")}>{user.withdrawalsDisabled ? "Ouvrir retraits" : "Fermer retraits"}</button>
          </div>
          <div className="admin-grant-row">
            <select value={productId} onChange={(event) => setProductId(event.target.value)}><option value="">Octroyer un VIP…</option>{products.filter((product) => product.active).map((product) => <option value={product.id} key={product.id}>{product.name}</option>)}</select>
            <button type="button" disabled={busy || !productId} onClick={() => void runFinancialAction("vip", async (requestId) => { const ok = await act(`/api/admin/users/${user.id}/grant-vip`, { productId: Number(productId), requestId }, "VIP octroyé."); if (ok) setProductId(""); return ok; })}>Octroyer</button>
          </div>
          <div className="admin-summary-grid">
            <span>Dépôts<strong>{formatFcfa(detail.wallet.totalDeposits)}</strong></span>
            <span>Retraits<strong>{formatFcfa(detail.wallet.totalWithdrawals)}</strong></span>
            <span>Crédits admin<strong>{formatFcfa(detail.wallet.totalAdminCredits)}</strong></span>
            <span>Débits admin<strong>{formatFcfa(detail.wallet.totalAdminDebits)}</strong></span>
          </div>
          <h3>Transactions récentes ({Math.min(detail.transactions.length, 12)})</h3>
          {detail.transactions.length
            ? detail.transactions.slice(0, 12).map((transaction) => <article className="admin-mini-row" key={transaction.id}><div><strong>{transaction.type}</strong><small>{transaction.note} · {date(transaction.createdAt)}</small></div><span>{formatFcfa(transaction.amount)}</span></article>)
            : <p className="admin-empty">Aucun dépôt ou retrait enregistré.</p>}
          <h3>VIP ({detail.orders.length})</h3>
          {detail.orders.map((order) => <article className="admin-mini-row" key={order.id}><div><strong>{order.productName}</strong><small>{order.source} · {date(order.createdAt)}</small></div>{order.status !== "rejected" && <button className="danger" type="button" disabled={busy} onClick={() => void removeVip(order)}><Trash2 size={14} /> Supprimer</button>}</article>)}
        </div>
      </section>
    </div>
  );
}

function ProductsPanel({ overview, act }: { overview: AdminOverview; act: (path: string, options: AdminMutationOptions, message: string) => Promise<boolean> }) {
  const emptyForm = { name: "", price: "", dailyIncome: "", totalIncome: "", durationDays: "180", imageClass: "1-DjVpknwl_1787413021677.png" };
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<number | null>(null);
  const resetForm = () => {
    setForm(emptyForm);
    setEditingId(null);
  };
  const edit = (product: AdminProduct) => {
    setEditingId(product.id);
    setForm({
      name: product.name,
      price: String(product.price),
      dailyIncome: String(product.dailyIncome),
      totalIncome: String(product.totalIncome),
      durationDays: String(product.durationDays),
      imageClass: product.imageClass,
    });
  };
  const submit = () => {
    const body = {
      ...form,
      price: Number(form.price),
      dailyIncome: Number(form.dailyIncome),
      totalIncome: Number(form.totalIncome),
      durationDays: Number(form.durationDays),
    };
    const path = editingId ? `/api/admin/products/${editingId}` : "/api/admin/products";
    const method = editingId ? "PATCH" : "POST";
    const message = editingId ? "Produit mis à jour." : "Produit créé.";
    return act(path, { method, body }, message).then((ok) => {
      if (ok) resetForm();
    });
  };
  const complete = Boolean(form.name && form.price && form.dailyIncome && form.totalIncome && form.durationDays);

  return (
    <section className="admin-panel">
      <h2>{editingId ? "Modifier le produit" : "Produits"}</h2>
      <div className="admin-inline-form">
        {(["name", "price", "dailyIncome", "totalIncome", "durationDays"] as const).map((field) => (
          <input key={field} type={field === "name" ? "text" : "number"} value={form[field]} onChange={(event) => setForm((current) => ({ ...current, [field]: event.target.value }))} placeholder={field} />
        ))}
        <button type="button" disabled={!complete} onClick={() => void submit()}>
          {editingId ? <><Check size={15} /> Enregistrer</> : <><Plus size={15} /> Ajouter</>}
        </button>
        {editingId && <button className="admin-product-cancel" type="button" onClick={resetForm}><X size={15} /> Annuler</button>}
      </div>
      <div className="admin-list">
        {overview.products.map((product) => (
          <article className={`admin-list-card ${editingId === product.id ? "editing" : ""}`} key={product.id}>
            <div>
              <strong>{product.name}</strong>
              <p>{formatFcfa(product.price)} · {formatFcfa(product.dailyIncome)}/jour</p>
              <small>{product.durationDays} jours · {product.active ? "Actif" : "Inactif"}</small>
            </div>
            <div className="admin-product-actions">
              <button type="button" aria-label={`Modifier ${product.name}`} onClick={() => edit(product)}><Pencil size={16} /></button>
              {product.active ? (
                <button className="admin-icon-danger" type="button" aria-label={`Désactiver ${product.name}`} onClick={() => void act(`/api/admin/products/${product.id}`, { method: "DELETE" }, "Produit désactivé.")}><Trash2 size={16} /></button>
              ) : (
                <button className="admin-icon-activate" type="button" onClick={() => void act(`/api/admin/products/${product.id}/activate`, { method: "PATCH" }, "Produit réactivé.")}><RefreshCw size={16} /> Réactiver</button>
              )}
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function GiftCodesPanel() {
  const [codes, setCodes] = useState<GiftCode[]>([]);
  const [code, setCode] = useState("");
  const [amount, setAmount] = useState("");
  const [error, setError] = useState("");
  const load = () => request<{ codes: GiftCode[] }>("/api/admin/gift-codes").then((data) => setCodes(data.codes)).catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  useEffect(() => { void load(); }, []);
  const create = async () => { await request("/api/admin/gift-codes", { method: "POST", body: { code, amount: Number(amount) } }); setCode(""); setAmount(""); await load(); };
  return <section className="admin-panel"><h2><Gift size={19} /> Codes cadeaux</h2>{error && <div className="admin-error">{error}</div>}<div className="admin-inline-form"><input value={code} onChange={(event) => setCode(event.target.value.toUpperCase())} placeholder="CODE2026" /><input type="number" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="Montant" /><button type="button" disabled={!code || !amount} onClick={() => void create().catch((reason) => setError(reason instanceof Error ? reason.message : "Création impossible."))}><Plus size={15} /> Créer</button></div><div className="admin-list">{codes.map((gift) => <article className="admin-list-card" key={gift.id}><div><strong>{gift.code}</strong><p>{formatFcfa(gift.amount)}</p><small>{gift.redemptions} utilisation(s)</small></div><button className="admin-icon-danger" type="button" onClick={() => void request(`/api/admin/gift-codes/${gift.id}`, { method: "DELETE" }).then(load)}><Trash2 size={16} /></button></article>)}</div></section>;
}

const emptyAnnouncementForm = {
  title: "",
  content: "",
  kind: "announcement" as AdminAnnouncement["kind"],
  audience: "all" as AdminAnnouncement["audience"],
  audienceLevel: "Lv1",
};

function AnnouncementsPanel() {
  const [announcements, setAnnouncements] = useState<AdminAnnouncement[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState(emptyAnnouncementForm);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const load = async () => {
    const data = await request<{ announcements: AdminAnnouncement[] }>("/api/admin/announcements", { cache: "no-store" });
    setAnnouncements(data.announcements);
  };

  useEffect(() => {
    void load().catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  }, []);

  const resetForm = () => {
    setEditingId(null);
    setForm(emptyAnnouncementForm);
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    setNotice("");
    try {
      await request(editingId ? `/api/admin/announcements/${editingId}` : "/api/admin/announcements", {
        method: editingId ? "PATCH" : "POST",
        body: {
          ...form,
          audienceLevel: form.audience === "level" ? form.audienceLevel : null,
        },
      });
      setNotice(editingId ? "Annonce mise à jour." : "Brouillon créé. Il reste invisible jusqu’à sa publication.");
      resetForm();
      await load();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Enregistrement impossible.");
    } finally {
      setSubmitting(false);
    }
  };

  const edit = (announcement: AdminAnnouncement) => {
    setEditingId(announcement.id);
    setForm({
      title: announcement.title,
      content: announcement.content,
      kind: announcement.kind,
      audience: announcement.audience,
      audienceLevel: announcement.audienceLevel ?? "Lv1",
    });
    setError("");
    setNotice("");
  };

  const changePublication = async (announcement: AdminAnnouncement) => {
    setError("");
    setNotice("");
    try {
      const action = announcement.status === "published" ? "withdraw" : "publish";
      await request(`/api/admin/announcements/${announcement.id}/${action}`, { method: "POST" });
      setNotice(announcement.status === "published" ? "Annonce retirée : elle n’est plus visible des utilisateurs." : "Annonce publiée.");
      await load();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Action impossible.");
    }
  };

  return (
    <section className="admin-panel">
      <h2><Megaphone size={19} /> Annonces et notifications</h2>
      <p className="admin-panel-intro">Créez un brouillon, relisez-le, puis publiez-le pour tous les utilisateurs ou pour un niveau précis.</p>
      {notice && <div className="admin-notice" role="status">{notice}</div>}
      {error && <div className="admin-error" role="alert">{error}</div>}
      <form className="admin-announcement-form" onSubmit={submit}>
        <label>
          Titre
          <input required maxLength={160} value={form.title} onChange={(event) => setForm((current) => ({ ...current, title: event.target.value }))} placeholder="Titre affiché aux utilisateurs" />
        </label>
        <label>
          Contenu
          <textarea required maxLength={10000} rows={6} value={form.content} onChange={(event) => setForm((current) => ({ ...current, content: event.target.value }))} placeholder="Rédigez le message à diffuser…" />
        </label>
        <div className="admin-announcement-options">
          <label>
            Format
            <select value={form.kind} onChange={(event) => setForm((current) => ({ ...current, kind: event.target.value as AdminAnnouncement["kind"] }))}>
              <option value="announcement">Annonce</option>
              <option value="notification">Notification</option>
            </select>
          </label>
          <label>
            Audience
            <select value={form.audience} onChange={(event) => setForm((current) => ({ ...current, audience: event.target.value as AdminAnnouncement["audience"] }))}>
              <option value="all">Tous les utilisateurs</option>
              <option value="level">Un niveau précis</option>
            </select>
          </label>
          {form.audience === "level" && (
            <label>
              Niveau
              <select value={form.audienceLevel} onChange={(event) => setForm((current) => ({ ...current, audienceLevel: event.target.value }))}>
                {["Lv1", "Lv2", "Lv3", "Lv4"].map((level) => <option key={level} value={level}>{level}</option>)}
              </select>
            </label>
          )}
        </div>
        <div className="admin-announcement-form-actions">
          <button className="admin-primary-button" disabled={submitting} type="submit">
            {editingId ? <Pencil size={16} /> : <Plus size={16} />}
            {submitting ? "Enregistrement…" : editingId ? "Enregistrer les modifications" : "Créer le brouillon"}
          </button>
          {editingId && <button className="admin-secondary-button" type="button" onClick={resetForm}>Annuler</button>}
        </div>
      </form>
      <div className="admin-list admin-announcement-list">
        {announcements.length === 0 && <div className="admin-empty">Aucune annonce enregistrée.</div>}
        {announcements.map((announcement) => (
          <article className="admin-list-card admin-announcement-card" key={announcement.id}>
            <div>
              <div className="admin-announcement-heading">
                <strong>{announcement.title}</strong>
                <span className={`admin-status ${announcement.status}`}>{announcement.status === "published" ? "Publiée" : "Brouillon"}</span>
              </div>
              <p className="admin-announcement-copy">{announcement.content}</p>
              <small>
                {announcement.kind === "notification" ? "Notification" : "Annonce"} · {announcement.audience === "all" ? "Tous les utilisateurs" : `Niveau ${announcement.audienceLevel}`}
                {announcement.publishedAt ? ` · publiée le ${date(announcement.publishedAt)}` : ` · modifiée le ${date(announcement.updatedAt)}`}
              </small>
            </div>
            <div className="admin-card-actions">
              {announcement.status === "draft" && <button type="button" onClick={() => edit(announcement)}><Pencil size={14} /> Modifier</button>}
              <button className={announcement.status === "published" ? "reject" : "approve"} type="button" onClick={() => void changePublication(announcement)}>
                {announcement.status === "published" ? <EyeOff size={14} /> : <Send size={14} />}
                {announcement.status === "published" ? "Retirer" : "Publier"}
              </button>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function ChannelsPanel() {
  const preset = OPERATOR_PRESETS[0];
  const defaultCountry = PAYMENT_COUNTRIES[0];
  const [channels, setChannels] = useState<PaymentChannel[]>([]);
  const [error, setError] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<Omit<PaymentChannel, "id">>({ operatorName: preset.label, receiverNumber: "", receiverName: "", logoColor: preset.logoColor, logoText: preset.key, logoUrl: "", country: defaultCountry.name, countryCode: defaultCountry.code, ussdTemplate: preset.defaultUssd, isActive: true, sortOrder: 0 });
  const load = () => request<{ channels: PaymentChannel[] }>("/api/admin/payment-channels").then((data) => setChannels(data.channels)).catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  useEffect(() => { void load(); }, []);
  const resetForm = () => {
    setEditingId(null);
    setForm({ operatorName: preset.label, receiverNumber: "", receiverName: "", logoColor: preset.logoColor, logoText: preset.key, logoUrl: "", country: defaultCountry.name, countryCode: defaultCountry.code, ussdTemplate: preset.defaultUssd, isActive: true, sortOrder: 0 });
  };
  const save = async () => {
    if (editingId) {
      await request(`/api/admin/payment-channels/${editingId}`, { method: "PATCH", body: form });
    } else {
      await request("/api/admin/payment-channels", { method: "POST", body: form });
    }
    resetForm();
    await load();
  };
  const edit = (channel: PaymentChannel) => {
    setEditingId(channel.id);
    setForm({
      operatorName: channel.operatorName,
      receiverNumber: channel.receiverNumber,
      receiverName: channel.receiverName,
      logoColor: channel.logoColor,
      logoText: channel.logoText,
      logoUrl: channel.logoUrl,
      country: channel.country,
      countryCode: channel.countryCode,
      ussdTemplate: channel.ussdTemplate,
      isActive: channel.isActive,
      sortOrder: channel.sortOrder,
    });
  };
  return <section className="admin-panel"><h2>Canaux de paiement</h2>{error && <div className="admin-error">{error}</div>}<div className="admin-operator-presets">{OPERATOR_PRESETS.map((item) => <button type="button" key={item.key} className={form.logoText === item.key ? "active" : ""} onClick={() => setForm((current) => ({ ...current, operatorName: item.label, logoColor: item.logoColor, logoText: item.key, ussdTemplate: item.defaultUssd }))}><OperatorLogo logoText={item.key} logoColor={item.logoColor} size={38} /><small>{item.key}</small></button>)}</div><div className="admin-inline-form"><input value={form.operatorName} onChange={(event) => setForm((current) => ({ ...current, operatorName: event.target.value }))} placeholder="Opérateur" /><input value={form.receiverNumber} onChange={(event) => setForm((current) => ({ ...current, receiverNumber: event.target.value }))} placeholder="Numéro marchand" /><input value={form.receiverName} onChange={(event) => setForm((current) => ({ ...current, receiverName: event.target.value }))} placeholder="Nom du marchand" /><label className="admin-channel-field">Pays<select value={form.countryCode} onChange={(event) => { const selectedCountry = PAYMENT_COUNTRIES.find((country) => country.code === event.target.value); if (selectedCountry) setForm((current) => ({ ...current, country: selectedCountry.name, countryCode: selectedCountry.code })); }}><option value="" disabled>Sélectionner un pays</option>{PAYMENT_COUNTRIES.map((country) => <option value={country.code} key={country.code}>{country.name} ({country.code})</option>)}</select></label><input value={form.ussdTemplate} onChange={(event) => setForm((current) => ({ ...current, ussdTemplate: event.target.value }))} placeholder="USSD avec {account} et {amount} (facultatif)" /><input value={form.logoUrl} onChange={(event) => setForm((current) => ({ ...current, logoUrl: event.target.value }))} placeholder="URL du logo (facultatif)" /><div className="admin-logo-preview"><OperatorLogo logoText={form.logoText} logoColor={form.logoColor} logoUrl={form.logoUrl} size={38} /><span>Aperçu du logo</span></div><button type="button" disabled={!form.operatorName || !form.receiverNumber} onClick={() => void save().catch((reason) => setError(reason instanceof Error ? reason.message : "Enregistrement impossible."))}>{editingId ? <Pencil size={15} /> : <Plus size={15} />} {editingId ? "Enregistrer" : "Ajouter"}</button>{editingId && <button type="button" onClick={resetForm}>Annuler</button>}</div><div className="admin-list">{channels.map((channel) => <article className="admin-list-card" key={channel.id}><OperatorLogo logoText={channel.logoText} logoColor={channel.logoColor} logoUrl={channel.logoUrl} /><div><strong>{channel.operatorName}</strong><p>{channel.country} · {channel.countryCode} · {channel.receiverNumber} · {channel.receiverName}</p><small>{channel.isActive ? "Actif" : "Inactif"} · {channel.ussdTemplate}</small></div><div className="admin-card-actions"><button type="button" onClick={() => edit(channel)}><Pencil size={14} /> Modifier</button><button type="button" onClick={() => void request(`/api/admin/payment-channels/${channel.id}`, { method: "PATCH", body: { isActive: !channel.isActive } }).then(load)}>{channel.isActive ? "Désactiver" : "Activer"}</button><button className="reject" type="button" onClick={() => void request(`/api/admin/payment-channels/${channel.id}`, { method: "DELETE" }).then(load)}><Trash2 size={15} /></button></div></article>)}</div></section>;
}

function SettingsPanel() {
  const [config, setConfig] = useState({
    depositMin: 3500,
    withdrawalMin: 2000,
    withdrawalFeePercent: 10,
    dashboxDeposit: 300,
    dashboxWithdraw: 1000,
    signupBonus: 2000,
    checkinBonus: 200,
    maxWithdrawals: null as number | null,
  });
  const [configLoaded, setConfigLoaded] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  useEffect(() => {
    request<{ config: typeof config }>("/api/admin/popup-config")
      .then((data) => { setConfig(data.config); setConfigLoaded(true); })
      .catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  }, []);
  const labels: Record<keyof typeof config, string> = {
    depositMin: "Dépôt minimum",
    withdrawalMin: "Retrait minimum",
    withdrawalFeePercent: "Frais de retrait (%)",
    dashboxDeposit: "Montant rapide de dépôt",
    dashboxWithdraw: "Montant rapide de retrait",
    signupBonus: "Bonus d’inscription",
    checkinBonus: "Bonus de pointage",
    maxWithdrawals: "Retraits maximum par jour",
  };
  const save = async () => {
    setError("");
    setNotice("");
    if (config.maxWithdrawals !== null && (!Number.isSafeInteger(config.maxWithdrawals) || config.maxWithdrawals <= 0)) {
      setError("Le nombre maximum de retraits doit être un entier positif ou illimité.");
      return;
    }
    try {
      await request("/api/admin/popup-config", { method: "PATCH", body: config });
      setNotice("Paramètres enregistrés et appliqués aux règles backend.");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Enregistrement impossible.");
    }
  };
  return (
    <section className="admin-panel">
      <h2>Paramètres financiers</h2>
      {notice && <div className="admin-notice">{notice}</div>}
      {error && <div className="admin-error">{error}</div>}
      <div className="admin-settings-grid">
        {(Object.keys(config) as Array<keyof typeof config>).filter((field) => field !== "maxWithdrawals").map((field) => (
          <label key={field}>{labels[field]}<input type="number" min="1" value={config[field] ?? ""} onChange={(event) => setConfig((current) => ({ ...current, [field]: Number(event.target.value) }))} /></label>
        ))}
        <label>Retraits maximum par jour<select value={config.maxWithdrawals === null ? "unlimited" : "limited"} onChange={(event) => setConfig((current) => ({ ...current, maxWithdrawals: event.target.value === "unlimited" ? null : current.maxWithdrawals ?? 1 }))}><option value="limited">Nombre limité</option><option value="unlimited">Illimité</option></select><input type="number" min="1" step="1" value={config.maxWithdrawals ?? ""} disabled={config.maxWithdrawals === null} onChange={(event) => setConfig((current) => ({ ...current, maxWithdrawals: Number(event.target.value) }))} /></label>
      </div>
      <button className="admin-primary-button" type="button" disabled={!configLoaded} onClick={() => void save()}>Enregistrer</button>
    </section>
  );
}import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import {
  ArrowDownToLine,
  ArrowLeft,
  ArrowUpFromLine,
  Ban,
  Check,
  Copy,
  EyeOff,
  Gift,
  LockKeyhole,
  LogOut,
  Megaphone,
  Package,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  Send,
  ShieldCheck,
  Trash2,
  Users,
  Wallet,
  X,
} from "lucide-react";
import { api, formatFcfa, request } from "../api";
import { OperatorLogo, OPERATOR_PRESETS } from "./OperatorLogos";
import { PAYMENT_COUNTRIES } from "../../shared/payment-config";
import "../styles/admin.css";

type AdminUser = {
  id: number;
  phone: string;
  referralCode: string;
  referrerId: number | null;
  createdAt: string;
  isBanned: boolean;
  isBlocked: boolean;
  withdrawalsDisabled: boolean;
};

type AdminTransaction = {
  id: number;
  userId: number;
  userPhone: string;
  reference?: string | null;
  type: string;
  amount: number;
  fee: number;
  netAmount: number;
  status: string;
  note: string;
  payerNumber: string | null;
  countryCode?: string | null;
  operatorName?: string | null;
  referralCount: number;
  adminAssisted: boolean;
  createdAt: string;
};

type AdminProduct = {
  id: number;
  name: string;
  price: number;
  dailyIncome: number;
  totalIncome: number;
  durationDays: number;
  imageClass: string;
  active: boolean;
};

type AdminOverview = {
  stats: {
    approvedDeposits: number;
    approvedWithdrawals: number;
    pendingDeposits: number;
    pendingWithdrawals: number;
    approvedDepositCount: number;
    rejectedDepositCount: number;
    approvedWithdrawalCount: number;
    rejectedWithdrawalCount: number;
    users: number;
    investments: number;
    vipPurchases: number;
    adminCredits: number;
  };
  users: AdminUser[];
  transactions: AdminTransaction[];
  orders: Array<{
    id: number;
    userId: number;
    productId: number;
    amount: number;
    status: string;
    source: string;
    createdAt: string;
    productName: string;
    userPhone: string;
  }>;
  products: AdminProduct[];
  community: { isOpen: boolean; closureMessage: string };
  withdrawOpenOverride: boolean;
};

type UserDetail = {
  user: AdminUser;
  wallet: {
    balance: number;
    totalDeposits: number;
    totalWithdrawals: number;
    totalAdminCredits: number;
    totalAdminDebits: number;
    totalCommissions: number;
    totalCheckins: number;
    totalProductIncome: number;
  };
  transactions: Array<{ id: number; type: string; amount: number; status: string; note: string; createdAt: string }>;
  orders: Array<{ id: number; productName: string; amount: number; status: string; source: string; createdAt: string }>;
  checkins: Array<{ id: number; checkinDate: string; reward: number; status: string; createdAt: string }>;
};

type GiftCode = { id: number; code: string; amount: number; createdAt: string; redemptions: number };
type AdminAnnouncement = {
  id: number;
  title: string;
  content: string;
  kind: "announcement" | "notification";
  audience: "all" | "level";
  audienceLevel: string | null;
  status: "draft" | "published";
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
};
type PaymentChannel = {
  id: number;
  operatorName: string;
  receiverNumber: string;
  receiverName: string;
  logoColor: string;
  logoText: string;
  logoUrl: string;
  country: string;
  countryCode: string;
  ussdTemplate: string;
  isActive: boolean;
  sortOrder: number;
};
type AdminMutationOptions = { method: "POST" | "PATCH" | "DELETE"; body?: unknown };
type AdminScope = "global" | "cameroon";

const date = (value: string) => new Date(value).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" });
const exactDate = (value: string) => new Date(value).toLocaleString("fr-FR", {
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
});
const pending = (status: string) => status === "pending" || status === "pending_review";
const countryName = (countryCode?: string | null) =>
  PAYMENT_COUNTRIES.find((country) => country.code === countryCode)?.name ?? countryCode ?? "Non renseigné";

export function AdminLoginScreen({ scope, onLogin, onBack }: { scope: AdminScope; onLogin: () => void; onBack: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      await api.adminLogin(password, scope);
      onLogin();
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : "Connexion impossible.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="admin-login-page">
      <button className="admin-back-link" type="button" onClick={onBack}><ArrowLeft size={18} /> Retour</button>
      <form className="admin-login-card" onSubmit={submit}>
        <span className="admin-login-mark"><ShieldCheck size={34} /></span>
        <h1>{scope === "cameroon" ? "Administration Cameroun" : "Administration générale"}</h1>
        <p>{scope === "cameroon" ? "Validation des dépôts et retraits camerounais" : "Gestion complète de la plateforme Valhalla"}</p>
        <input
          type="text"
          name="username"
          autoComplete="username"
          value={scope === "cameroon" ? "admin-cameroon" : "admin"}
          readOnly
          tabIndex={-1}
          aria-hidden="true"
          style={{ position: "absolute", width: 1, height: 1, padding: 0, margin: -1, overflow: "hidden", clip: "rect(0, 0, 0, 0)", whiteSpace: "nowrap", border: 0 }}
        />
        <label>Mot de passe<input required type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} /></label>
        {error && <div className="admin-error" role="alert">{error}</div>}
        <button className="admin-primary-button" disabled={submitting} type="submit">
          <LockKeyhole size={17} /> {submitting ? "Vérification…" : "Se connecter"}
        </button>
      </form>
    </div>
  );
}

type AdminTab = "overview" | "transactions" | "users" | "products" | "codes" | "channels" | "announcements" | "settings";
type TransactionStatusFilter = "pending" | "approved" | "rejected";
type TransactionKind = "deposit" | "withdrawal";

export function AdminDashboard({ scope, onExit, onUnauthorized }: { scope: AdminScope; onExit: () => void; onUnauthorized: () => void }) {
  const isCameroon = scope === "cameroon";
  const [overview, setOverview] = useState<AdminOverview | null>(null);
  const [tab, setTab] = useState<AdminTab>("overview");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [search, setSearch] = useState("");
  const [transactionSearch, setTransactionSearch] = useState("");
  const [transactionKind, setTransactionKind] = useState<TransactionKind>("deposit");
  const [depositStatusFilter, setDepositStatusFilter] = useState<TransactionStatusFilter>("pending");
  const [withdrawalStatusFilter, setWithdrawalStatusFilter] = useState<TransactionStatusFilter>("pending");
  const [processingTransactionIds, setProcessingTransactionIds] = useState<Set<number>>(new Set());
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [userDetail, setUserDetail] = useState<UserDetail | null>(null);

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      setOverview(await request<AdminOverview>(
        isCameroon ? "/api/admin/cameroon/overview" : "/api/admin/overview",
        { cache: "no-store" },
      ));
    } catch (loadError) {
      const message = loadError instanceof Error ? loadError.message : "Chargement impossible.";
      if (/connexion administrateur/i.test(message)) onUnauthorized();
      else setError(message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const act = async (path: string, options: AdminMutationOptions, message: string) => {
    setError("");
    setNotice("");
    try {
      await request<{ message?: string }>(path, options);
      setNotice(message);
      await load();
      if (selectedUserId) await openUser(selectedUserId);
      return true;
    } catch (actionError) {
      setError(actionError instanceof Error ? actionError.message : "Action impossible.");
      return false;
    }
  };

  const processTransaction = async (id: number, status: string, withdrawal: boolean) => {
    if (processingTransactionIds.has(id)) return;
    setProcessingTransactionIds((current) => new Set(current).add(id));
    setOverview((current) => current ? {
      ...current,
      transactions: current.transactions.map((transaction) =>
        transaction.id === id ? { ...transaction, status } : transaction,
      ),
    } : current);
    try {
      const succeeded = await act(
        `${isCameroon ? "/api/admin/cameroon" : "/api/admin"}/transactions/${id}`,
        { method: "PATCH", body: { status } },
        withdrawal ? "Retrait traité." : "Dépôt traité.",
      );
      if (!succeeded) await load();
    } finally {
      setProcessingTransactionIds((current) => {
        const next = new Set(current);
        next.delete(id);
        return next;
      });
    }
  };

  const openUser = async (userId: number) => {
    setSelectedUserId(userId);
    setUserDetail(null);
    try {
      setUserDetail(await request<UserDetail>(`/api/admin/users/${userId}`, { cache: "no-store" }));
    } catch (detailError) {
      setError(detailError instanceof Error ? detailError.message : "Fiche indisponible.");
    }
  };

  const filteredUsers = useMemo(() => {
    const value = search.trim().toLowerCase();
    return (overview?.users ?? []).filter((user) => !value || user.phone.toLowerCase().includes(value) || String(user.id).includes(value));
  }, [overview, search]);

  const filteredDeposits = useMemo(() => {
    const value = transactionSearch.trim().toLowerCase();
    const availableDeposits = (overview?.transactions ?? []).filter(
      (transaction) => transaction.type === "deposit" && transactionMatchesFilter(transaction, depositStatusFilter),
    );
    if (!value) return availableDeposits;
    return availableDeposits.filter((transaction) => {
      const reference = (transaction.reference ?? "").toLowerCase();
      const displayedReference = displayTransactionReference(transaction.reference).toLowerCase();
      return reference.includes(value) || displayedReference.includes(value);
    });
  }, [overview, transactionSearch, depositStatusFilter]);
  const filteredWithdrawals = useMemo(() => {
    const value = transactionSearch.trim().toLowerCase();
    const availableWithdrawals = (overview?.transactions ?? []).filter(
      (transaction) => transaction.type === "withdrawal" && transactionMatchesFilter(transaction, withdrawalStatusFilter),
    );
    if (!value) return availableWithdrawals;
    return availableWithdrawals.filter((transaction) => {
      const reference = (transaction.reference ?? "").toLowerCase();
      const displayedReference = displayTransactionReference(transaction.reference).toLowerCase();
      return reference.includes(value) || displayedReference.includes(value);
    });
  }, [overview, transactionSearch, withdrawalStatusFilter]);
  const selectedTransactionTotal = transactionKind === "deposit"
    ? depositStatusFilter === "pending"
      ? overview?.stats.pendingDeposits ?? 0
      : depositStatusFilter === "approved"
        ? overview?.stats.approvedDepositCount ?? 0
        : overview?.stats.rejectedDepositCount ?? 0
    : withdrawalStatusFilter === "pending"
      ? overview?.stats.pendingWithdrawals ?? 0
      : withdrawalStatusFilter === "approved"
        ? overview?.stats.approvedWithdrawalCount ?? 0
        : overview?.stats.rejectedWithdrawalCount ?? 0;

  if (loading && !overview) {
    return <div className="admin-state-page"><RefreshCw className="admin-spin" /><h1>{isCameroon ? "Administration Cameroun" : "Administration générale"}</h1><p>Chargement sécurisé…</p></div>;
  }
  if (!overview) {
    return <div className="admin-state-page"><ShieldCheck size={44} /><h1>Administration indisponible</h1><p>{error}</p><button className="admin-primary-button" onClick={() => void load()}>Réessayer</button></div>;
  }

  return (
    <div className="admin-page">
      <header className="admin-header">
        <div><strong>{isCameroon ? "Administration Cameroun" : "Administration générale"}</strong><small>{isCameroon ? "Dépôts et retraits · +237" : "Gestion complète de Valhalla"}</small></div>
        <div className="admin-header-actions">
          <button type="button" title="Actualiser" onClick={() => void load()}><RefreshCw size={18} /></button>
          <button type="button" title="Déconnexion" onClick={() => void api.adminLogout(scope).finally(onExit)}><LogOut size={18} /></button>
        </div>
      </header>
      <main className="admin-content">
        {notice && <div className="admin-notice" role="status">{notice}</div>}
        {error && <div className="admin-error" role="alert">{error}</div>}
        <section className={`admin-stats-grid${isCameroon ? " cameroon" : ""}`}>
          <Stat icon={<ArrowDownToLine />} value={formatFcfa(overview.stats.approvedDeposits)} label="Dépôts" />
          <Stat icon={<ArrowUpFromLine />} value={formatFcfa(overview.stats.approvedWithdrawals)} label="Retraits" />
          {!isCameroon && <Stat icon={<Users />} value={String(overview.stats.users)} label="Utilisateurs" />}
          {!isCameroon && <Stat icon={<Package />} value={String(overview.stats.investments)} label="VIP actifs" />}
          {!isCameroon && <Stat icon={<Wallet />} value={formatFcfa(overview.stats.adminCredits)} label="Crédits admin" />}
        </section>
        <nav className="admin-tabs" aria-label="Sections administratives">
          {((isCameroon ? [
            ["overview", "Synthèse"],
            ["transactions", "Transactions"],
          ] : [
            ["overview", "Synthèse"],
            ["transactions", "Transactions"],
            ["users", "Utilisateurs"],
            ["products", "Produits"],
            ["codes", "Codes"],
            ["channels", "Canaux"],
            ["announcements", "Annonces"],
            ["settings", "Paramètres"],
          ]) as Array<[AdminTab, string]>).map(([value, label]) => (
            <button key={value} type="button" className={tab === value ? "active" : ""} onClick={() => setTab(value)}>{label}</button>
          ))}
        </nav>

        {tab === "overview" && (
          <section className="admin-panel">
            <h2>État de la plateforme</h2>
            <div className="admin-alert-grid">
              <article><strong>{overview.stats.pendingDeposits}</strong><span>dépôt(s) en attente</span></article>
              <article><strong>{overview.stats.pendingWithdrawals}</strong><span>retrait(s) en attente</span></article>
            </div>
            {!isCameroon && <div className="admin-setting-row">
              <div><strong>Retraits hors horaire</strong><small>{overview.withdrawOpenOverride ? "Ouverts manuellement" : "Horaire normal"}</small></div>
              <button className={overview.withdrawOpenOverride ? "admin-danger-button" : "admin-primary-button"} type="button" onClick={() => void act("/api/admin/withdraw-override", { method: "PATCH", body: { enabled: !overview.withdrawOpenOverride } }, "Règle de retrait mise à jour.")}>
                {overview.withdrawOpenOverride ? "Désactiver" : "Ouvrir"}
              </button>
            </div>}
          </section>
        )}

        {tab === "transactions" && (
          <section className="admin-panel">
            <h2>Transactions</h2>
            <div className="admin-transaction-kind-tabs" role="tablist" aria-label="Type de transaction">
              <button type="button" role="tab" aria-selected={transactionKind === "deposit"} className={transactionKind === "deposit" ? "active" : ""} onClick={() => setTransactionKind("deposit")}>
                Dépôts
              </button>
              <button type="button" role="tab" aria-selected={transactionKind === "withdrawal"} className={transactionKind === "withdrawal" ? "active" : ""} onClick={() => setTransactionKind("withdrawal")}>
                Retraits
              </button>
            </div>
            <h3>{transactionKind === "deposit" ? `Dépôts (${selectedTransactionTotal})` : `Retraits (${selectedTransactionTotal})`}</h3>
            <TransactionFilters
              value={transactionKind === "deposit" ? depositStatusFilter : withdrawalStatusFilter}
              onChange={transactionKind === "deposit" ? setDepositStatusFilter : setWithdrawalStatusFilter}
            />
            <label className="admin-search transaction-search">
              <Search size={17} />
              <input
                value={transactionSearch}
                onChange={(event) => setTransactionSearch(event.target.value)}
                placeholder="Rechercher par numéro de commande"
                aria-label={`Rechercher un ${transactionKind === "deposit" ? "dépôt" : "retrait"} par numéro de commande`}
              />
            </label>
            {transactionKind === "deposit"
              ? <TransactionList values={filteredDeposits} processingIds={processingTransactionIds} onStatus={(id, status) => void processTransaction(id, status, false)} />
              : <TransactionList values={filteredWithdrawals} processingIds={processingTransactionIds} withdrawal groupByCountry={withdrawalStatusFilter === "pending"} onStatus={(id, status) => void processTransaction(id, status, true)} />}
          </section>
        )}

        {tab === "users" && (
          <section className="admin-panel">
            <h2>Utilisateurs ({filteredUsers.length})</h2>
            <label className="admin-search"><Search size={17} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Téléphone ou identifiant" /></label>
            <div className="admin-list">
              {filteredUsers.map((user) => (
                <article className="admin-list-card" key={user.id}>
                  <div><strong>{user.phone}</strong><p>ID #{user.id} · {user.referralCode}</p><small>{date(user.createdAt)}</small></div>
                  <div className="admin-badges">{user.isBanned && <span>banni</span>}{user.isBlocked && <span>bloqué</span>}{user.withdrawalsDisabled && <span>retraits fermés</span>}</div>
                  <button type="button" onClick={() => void openUser(user.id)}>Gérer</button>
                </article>
              ))}
            </div>
          </section>
        )}

        {tab === "products" && <ProductsPanel overview={overview} act={act} />}
        {tab === "codes" && <GiftCodesPanel />}
        {tab === "channels" && <ChannelsPanel />}
        {tab === "announcements" && <AnnouncementsPanel />}
        {tab === "settings" && <SettingsPanel />}
      </main>
      {!isCameroon && selectedUserId !== null && (
        <UserPanel
          detail={userDetail}
          products={overview.products}
          close={() => { setSelectedUserId(null); setUserDetail(null); }}
          act={(path, body, message) => act(path, { method: "POST", body }, message)}
        />
      )}
    </div>
  );
}

function Stat({ icon, value, label }: { icon: ReactNode; value: string; label: string }) {
  return <article className="admin-stat-card"><span>{icon}</span><div><strong>{value}</strong><small>{label}</small></div></article>;
}

const displayTransactionReference = (reference?: string | null) =>
  (reference ?? "Non disponible").replace(/^(deposit|withdrawal)-/, "");

const transactionMatchesFilter = (transaction: AdminTransaction, filter: TransactionStatusFilter) => {
  if (filter === "pending") return pending(transaction.status);
  if (filter === "approved") return transaction.status === "approved" || transaction.status === "completed";
  return transaction.status === "rejected";
};

function TransactionFilters({ value, onChange }: { value: TransactionStatusFilter; onChange: (value: TransactionStatusFilter) => void }) {
  const filters: Array<[TransactionStatusFilter, string]> = [
    ["pending", "En attente"],
    ["approved", "Validés"],
    ["rejected", "Rejetés"],
  ];
  return (
    <div className="admin-transaction-filters" role="group" aria-label="Filtrer les transactions par statut">
      {filters.map(([filter, label]) => (
        <button key={filter} type="button" className={value === filter ? "active" : ""} onClick={() => onChange(filter)}>
          {label}
        </button>
      ))}
    </div>
  );
}

function TransactionList({ values, processingIds, withdrawal = false, groupByCountry = false, onStatus }: { values: AdminTransaction[]; processingIds: Set<number>; withdrawal?: boolean; groupByCountry?: boolean; onStatus: (id: number, status: string) => void }) {
  const [selectedCountryCode, setSelectedCountryCode] = useState("");
  if (!values.length) return <p className="admin-empty">Aucune transaction.</p>;
  const renderTransactions = (transactions: AdminTransaction[]) => <div className="admin-list">{transactions.map((transaction) => (
    <article className="admin-list-card" key={transaction.id}>
      <div className="admin-transaction-details">
        <strong className={withdrawal ? "admin-red-text" : "admin-green-text"}>{formatFcfa(transaction.amount)}</strong>
        <CopyableValue label="N° d’inscription" value={transaction.userPhone} />
        <small>Identifiant utilisateur : #{transaction.userId}</small>
        <small>Pays : {countryName(transaction.countryCode)}</small>
        <small>Opérateur : {transaction.operatorName || "Non renseigné"}</small>
        {!withdrawal && transaction.payerNumber && <CopyableValue label="Portefeuille payeur" value={transaction.payerNumber} />}
        {withdrawal && transaction.payerNumber && <CopyableValue label="Numéro de réception" value={transaction.payerNumber} />}
        <CopyableValue label={withdrawal ? "N° de commande du retrait" : "N° de commande du dépôt"} value={displayTransactionReference(transaction.reference)} />
        <small>Date et heure : {exactDate(transaction.createdAt)}</small>
        {withdrawal && pending(transaction.status) && <small className="admin-total-referrals">Nombre total de filleuls : <strong>{transaction.referralCount}</strong></small>}
        {withdrawal && <small>Montant retiré : {formatFcfa(transaction.amount)}</small>}
        {withdrawal && <small>Frais : {formatFcfa(transaction.fee)} · Net à envoyer : <strong>{formatFcfa(transaction.netAmount)}</strong></small>}
      </div>
      {withdrawal && pending(transaction.status) && transaction.adminAssisted && <span className="admin-assisted-badge">Admin</span>}
      <span className={`admin-status ${transaction.status}`}>{transaction.status}</span>
      {pending(transaction.status) && <div className="admin-card-actions"><button className="approve" type="button" disabled={processingIds.has(transaction.id)} onClick={() => onStatus(transaction.id, withdrawal ? "completed" : "approved")}><Check size={16} /></button><button className="reject" type="button" disabled={processingIds.has(transaction.id)} onClick={() => onStatus(transaction.id, "rejected")}><X size={16} /></button></div>}
    </article>
  ))}</div>;
  if (!groupByCountry) return renderTransactions(values);

  const groups = Array.from(
    values.reduce((byCountry, transaction) => {
      const code = transaction.countryCode || "";
      const transactions = byCountry.get(code) ?? [];
      transactions.push(transaction);
      byCountry.set(code, transactions);
      return byCountry;
    }, new Map<string, AdminTransaction[]>()),
  ).sort(([firstCode], [secondCode]) => countryName(firstCode).localeCompare(countryName(secondCode), "fr"));
  const selectedGroup = groups.find(([code]) => code === selectedCountryCode) ?? groups[0];

  return <div className="admin-country-withdrawals">
    <div className="admin-country-tabs" role="tablist" aria-label="Filtrer les retraits en attente par pays">
      {groups.map(([code, transactions]) => (
        <button
          key={code || "unknown"}
          type="button"
          role="tab"
          aria-selected={selectedGroup[0] === code}
          className={selectedGroup[0] === code ? "active" : ""}
          onClick={() => setSelectedCountryCode(code)}
        >
          <span>{countryName(code)}</span>
          <strong>{transactions.length}</strong>
        </button>
      ))}
    </div>
    <div className="admin-selected-country-summary">
      <strong>{countryName(selectedGroup[0])}</strong>
      <span>{selectedGroup[1].length} retrait{selectedGroup[1].length > 1 ? "s" : ""} en attente</span>
    </div>
    {renderTransactions(selectedGroup[1])}
  </div>;
}

function CopyableValue({ label, value }: { label: string; value: string }) {
  return (
    <small className="admin-copyable-value">
      <span>{label} : {value}</span>
      <button type="button" title={`Copier ${label.toLowerCase()}`} aria-label={`Copier ${label.toLowerCase()}`} onClick={() => void navigator.clipboard.writeText(value)}>
        <Copy size={13} />
      </button>
    </small>
  );
}

function UserPanel({ detail, products, close, act }: { detail: UserDetail | null; products: AdminProduct[]; close: () => void; act: (path: string, body: Record<string, unknown>, message: string) => Promise<boolean> }) {
  const [credit, setCredit] = useState("");
  const [debit, setDebit] = useState("");
  const [productId, setProductId] = useState("");
  const [busy, setBusy] = useState(false);
  const operationKeys = useRef<Record<string, string>>({});
  const runFinancialAction = async (kind: "credit" | "debit" | "vip", operation: (requestId: string) => Promise<boolean>) => {
    if (busy) return;
    setBusy(true);
    try {
      const requestId = operationKeys.current[kind] ?? crypto.randomUUID();
      operationKeys.current[kind] = requestId;
      if (await operation(requestId)) delete operationKeys.current[kind];
    } finally {
      setBusy(false);
    }
  };
  const removeVip = async (order: UserDetail["orders"][number]) => {
    if (busy) return;
    const confirmed = window.confirm(
      `Supprimer ${order.productName} de cet utilisateur ? Les futurs revenus seront arrêtés, sans remboursement de l'achat ni retrait des revenus déjà versés.`,
    );
    if (!confirmed) return;
    setBusy(true);
    try {
      await act(`/api/admin/orders/${order.id}/revoke-vip`, {}, "VIP supprimé.");
    } finally {
      setBusy(false);
    }
  };
  if (!detail) return <div className="admin-overlay"><div className="admin-user-panel admin-panel-loading"><RefreshCw className="admin-spin" /></div></div>;
  const user = detail.user;
  return (
    <div className="admin-overlay">
      <section className="admin-user-panel">
        <header><div><strong>{user.phone}</strong><small>Utilisateur #{user.id}</small></div><button type="button" onClick={close}><X /></button></header>
        <div className="admin-user-body">
          <div className="admin-balance"><span>Solde disponible</span><strong>{formatFcfa(detail.wallet.balance)}</strong></div>
          <div className="admin-balance-actions">
            <input type="number" min="1" value={credit} onChange={(event) => setCredit(event.target.value)} placeholder="Montant à créditer" />
            <button type="button" disabled={busy || !credit} onClick={() => void runFinancialAction("credit", async (requestId) => { const ok = await act(`/api/admin/users/${user.id}/credit`, { amount: Number(credit), requestId }, "Solde crédité."); if (ok) setCredit(""); return ok; })}>Créditer</button>
            <input type="number" min="1" value={debit} onChange={(event) => setDebit(event.target.value)} placeholder="Montant à débiter" />
            <button className="danger" type="button" disabled={busy || !debit} onClick={() => void runFinancialAction("debit", async (requestId) => { const ok = await act(`/api/admin/users/${user.id}/debit`, { amount: Number(debit), requestId }, "Solde débité."); if (ok) setDebit(""); return ok; })}>Débiter</button>
          </div>
          <div className="admin-user-actions">
            <button type="button" onClick={() => void act(`/api/admin/users/${user.id}/${user.isBanned ? "unban" : "ban"}`, {}, user.isBanned ? "Utilisateur débanni." : "Utilisateur banni.")}><Ban size={15} /> {user.isBanned ? "Débannir" : "Bannir"}</button>
            <button type="button" onClick={() => void act(`/api/admin/users/${user.id}/${user.isBlocked ? "unblock" : "block"}`, {}, user.isBlocked ? "Compte débloqué." : "Compte bloqué.")}>{user.isBlocked ? "Débloquer" : "Bloquer"}</button>
            <button type="button" onClick={() => void act(`/api/admin/users/${user.id}/${user.withdrawalsDisabled ? "open-withdrawals" : "close-withdrawals"}`, {}, "Droits de retrait mis à jour.")}>{user.withdrawalsDisabled ? "Ouvrir retraits" : "Fermer retraits"}</button>
          </div>
          <div className="admin-grant-row">
            <select value={productId} onChange={(event) => setProductId(event.target.value)}><option value="">Octroyer un VIP…</option>{products.filter((product) => product.active).map((product) => <option value={product.id} key={product.id}>{product.name}</option>)}</select>
            <button type="button" disabled={busy || !productId} onClick={() => void runFinancialAction("vip", async (requestId) => { const ok = await act(`/api/admin/users/${user.id}/grant-vip`, { productId: Number(productId), requestId }, "VIP octroyé."); if (ok) setProductId(""); return ok; })}>Octroyer</button>
          </div>
          <div className="admin-summary-grid">
            <span>Dépôts<strong>{formatFcfa(detail.wallet.totalDeposits)}</strong></span>
            <span>Retraits<strong>{formatFcfa(detail.wallet.totalWithdrawals)}</strong></span>
            <span>Crédits admin<strong>{formatFcfa(detail.wallet.totalAdminCredits)}</strong></span>
            <span>Débits admin<strong>{formatFcfa(detail.wallet.totalAdminDebits)}</strong></span>
          </div>
          <h3>Transactions récentes ({Math.min(detail.transactions.length, 12)})</h3>
          {detail.transactions.length
            ? detail.transactions.slice(0, 12).map((transaction) => <article className="admin-mini-row" key={transaction.id}><div><strong>{transaction.type}</strong><small>{transaction.note} · {date(transaction.createdAt)}</small></div><span>{formatFcfa(transaction.amount)}</span></article>)
            : <p className="admin-empty">Aucun dépôt ou retrait enregistré.</p>}
          <h3>VIP ({detail.orders.length})</h3>
          {detail.orders.map((order) => <article className="admin-mini-row" key={order.id}><div><strong>{order.productName}</strong><small>{order.source} · {date(order.createdAt)}</small></div>{order.status !== "rejected" && <button className="danger" type="button" disabled={busy} onClick={() => void removeVip(order)}><Trash2 size={14} /> Supprimer</button>}</article>)}
        </div>
      </section>
    </div>
  );
}

function ProductsPanel({ overview, act }: { overview: AdminOverview; act: (path: string, options: AdminMutationOptions, message: string) => Promise<boolean> }) {
  const emptyForm = { name: "", price: "", dailyIncome: "", totalIncome: "", durationDays: "180", imageClass: "1-DjVpknwl_1787413021677.png" };
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<number | null>(null);
  const resetForm = () => {
    setForm(emptyForm);
    setEditingId(null);
  };
  const edit = (product: AdminProduct) => {
    setEditingId(product.id);
    setForm({
      name: product.name,
      price: String(product.price),
      dailyIncome: String(product.dailyIncome),
      totalIncome: String(product.totalIncome),
      durationDays: String(product.durationDays),
      imageClass: product.imageClass,
    });
  };
  const submit = () => {
    const body = {
      ...form,
      price: Number(form.price),
      dailyIncome: Number(form.dailyIncome),
      totalIncome: Number(form.totalIncome),
      durationDays: Number(form.durationDays),
    };
    const path = editingId ? `/api/admin/products/${editingId}` : "/api/admin/products";
    const method = editingId ? "PATCH" : "POST";
    const message = editingId ? "Produit mis à jour." : "Produit créé.";
    return act(path, { method, body }, message).then((ok) => {
      if (ok) resetForm();
    });
  };
  const complete = Boolean(form.name && form.price && form.dailyIncome && form.totalIncome && form.durationDays);

  return (
    <section className="admin-panel">
      <h2>{editingId ? "Modifier le produit" : "Produits"}</h2>
      <div className="admin-inline-form">
        {(["name", "price", "dailyIncome", "totalIncome", "durationDays"] as const).map((field) => (
          <input key={field} type={field === "name" ? "text" : "number"} value={form[field]} onChange={(event) => setForm((current) => ({ ...current, [field]: event.target.value }))} placeholder={field} />
        ))}
        <button type="button" disabled={!complete} onClick={() => void submit()}>
          {editingId ? <><Check size={15} /> Enregistrer</> : <><Plus size={15} /> Ajouter</>}
        </button>
        {editingId && <button className="admin-product-cancel" type="button" onClick={resetForm}><X size={15} /> Annuler</button>}
      </div>
      <div className="admin-list">
        {overview.products.map((product) => (
          <article className={`admin-list-card ${editingId === product.id ? "editing" : ""}`} key={product.id}>
            <div>
              <strong>{product.name}</strong>
              <p>{formatFcfa(product.price)} · {formatFcfa(product.dailyIncome)}/jour</p>
              <small>{product.durationDays} jours · {product.active ? "Actif" : "Inactif"}</small>
            </div>
            <div className="admin-product-actions">
              <button type="button" aria-label={`Modifier ${product.name}`} onClick={() => edit(product)}><Pencil size={16} /></button>
              {product.active ? (
                <button className="admin-icon-danger" type="button" aria-label={`Désactiver ${product.name}`} onClick={() => void act(`/api/admin/products/${product.id}`, { method: "DELETE" }, "Produit désactivé.")}><Trash2 size={16} /></button>
              ) : (
                <button className="admin-icon-activate" type="button" onClick={() => void act(`/api/admin/products/${product.id}/activate`, { method: "PATCH" }, "Produit réactivé.")}><RefreshCw size={16} /> Réactiver</button>
              )}
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function GiftCodesPanel() {
  const [codes, setCodes] = useState<GiftCode[]>([]);
  const [code, setCode] = useState("");
  const [amount, setAmount] = useState("");
  const [error, setError] = useState("");
  const load = () => request<{ codes: GiftCode[] }>("/api/admin/gift-codes").then((data) => setCodes(data.codes)).catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  useEffect(() => { void load(); }, []);
  const create = async () => { await request("/api/admin/gift-codes", { method: "POST", body: { code, amount: Number(amount) } }); setCode(""); setAmount(""); await load(); };
  return <section className="admin-panel"><h2><Gift size={19} /> Codes cadeaux</h2>{error && <div className="admin-error">{error}</div>}<div className="admin-inline-form"><input value={code} onChange={(event) => setCode(event.target.value.toUpperCase())} placeholder="CODE2026" /><input type="number" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="Montant" /><button type="button" disabled={!code || !amount} onClick={() => void create().catch((reason) => setError(reason instanceof Error ? reason.message : "Création impossible."))}><Plus size={15} /> Créer</button></div><div className="admin-list">{codes.map((gift) => <article className="admin-list-card" key={gift.id}><div><strong>{gift.code}</strong><p>{formatFcfa(gift.amount)}</p><small>{gift.redemptions} utilisation(s)</small></div><button className="admin-icon-danger" type="button" onClick={() => void request(`/api/admin/gift-codes/${gift.id}`, { method: "DELETE" }).then(load)}><Trash2 size={16} /></button></article>)}</div></section>;
}

const emptyAnnouncementForm = {
  title: "",
  content: "",
  kind: "announcement" as AdminAnnouncement["kind"],
  audience: "all" as AdminAnnouncement["audience"],
  audienceLevel: "Lv1",
};

function AnnouncementsPanel() {
  const [announcements, setAnnouncements] = useState<AdminAnnouncement[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState(emptyAnnouncementForm);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const load = async () => {
    const data = await request<{ announcements: AdminAnnouncement[] }>("/api/admin/announcements", { cache: "no-store" });
    setAnnouncements(data.announcements);
  };

  useEffect(() => {
    void load().catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  }, []);

  const resetForm = () => {
    setEditingId(null);
    setForm(emptyAnnouncementForm);
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    setNotice("");
    try {
      await request(editingId ? `/api/admin/announcements/${editingId}` : "/api/admin/announcements", {
        method: editingId ? "PATCH" : "POST",
        body: {
          ...form,
          audienceLevel: form.audience === "level" ? form.audienceLevel : null,
        },
      });
      setNotice(editingId ? "Annonce mise à jour." : "Brouillon créé. Il reste invisible jusqu’à sa publication.");
      resetForm();
      await load();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Enregistrement impossible.");
    } finally {
      setSubmitting(false);
    }
  };

  const edit = (announcement: AdminAnnouncement) => {
    setEditingId(announcement.id);
    setForm({
      title: announcement.title,
      content: announcement.content,
      kind: announcement.kind,
      audience: announcement.audience,
      audienceLevel: announcement.audienceLevel ?? "Lv1",
    });
    setError("");
    setNotice("");
  };

  const changePublication = async (announcement: AdminAnnouncement) => {
    setError("");
    setNotice("");
    try {
      const action = announcement.status === "published" ? "withdraw" : "publish";
      await request(`/api/admin/announcements/${announcement.id}/${action}`, { method: "POST" });
      setNotice(announcement.status === "published" ? "Annonce retirée : elle n’est plus visible des utilisateurs." : "Annonce publiée.");
      await load();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Action impossible.");
    }
  };

  return (
    <section className="admin-panel">
      <h2><Megaphone size={19} /> Annonces et notifications</h2>
      <p className="admin-panel-intro">Créez un brouillon, relisez-le, puis publiez-le pour tous les utilisateurs ou pour un niveau précis.</p>
      {notice && <div className="admin-notice" role="status">{notice}</div>}
      {error && <div className="admin-error" role="alert">{error}</div>}
      <form className="admin-announcement-form" onSubmit={submit}>
        <label>
          Titre
          <input required maxLength={160} value={form.title} onChange={(event) => setForm((current) => ({ ...current, title: event.target.value }))} placeholder="Titre affiché aux utilisateurs" />
        </label>
        <label>
          Contenu
          <textarea required maxLength={10000} rows={6} value={form.content} onChange={(event) => setForm((current) => ({ ...current, content: event.target.value }))} placeholder="Rédigez le message à diffuser…" />
        </label>
        <div className="admin-announcement-options">
          <label>
            Format
            <select value={form.kind} onChange={(event) => setForm((current) => ({ ...current, kind: event.target.value as AdminAnnouncement["kind"] }))}>
              <option value="announcement">Annonce</option>
              <option value="notification">Notification</option>
            </select>
          </label>
          <label>
            Audience
            <select value={form.audience} onChange={(event) => setForm((current) => ({ ...current, audience: event.target.value as AdminAnnouncement["audience"] }))}>
              <option value="all">Tous les utilisateurs</option>
              <option value="level">Un niveau précis</option>
            </select>
          </label>
          {form.audience === "level" && (
            <label>
              Niveau
              <select value={form.audienceLevel} onChange={(event) => setForm((current) => ({ ...current, audienceLevel: event.target.value }))}>
                {["Lv1", "Lv2", "Lv3", "Lv4"].map((level) => <option key={level} value={level}>{level}</option>)}
              </select>
            </label>
          )}
        </div>
        <div className="admin-announcement-form-actions">
          <button className="admin-primary-button" disabled={submitting} type="submit">
            {editingId ? <Pencil size={16} /> : <Plus size={16} />}
            {submitting ? "Enregistrement…" : editingId ? "Enregistrer les modifications" : "Créer le brouillon"}
          </button>
          {editingId && <button className="admin-secondary-button" type="button" onClick={resetForm}>Annuler</button>}
        </div>
      </form>
      <div className="admin-list admin-announcement-list">
        {announcements.length === 0 && <div className="admin-empty">Aucune annonce enregistrée.</div>}
        {announcements.map((announcement) => (
          <article className="admin-list-card admin-announcement-card" key={announcement.id}>
            <div>
              <div className="admin-announcement-heading">
                <strong>{announcement.title}</strong>
                <span className={`admin-status ${announcement.status}`}>{announcement.status === "published" ? "Publiée" : "Brouillon"}</span>
              </div>
              <p className="admin-announcement-copy">{announcement.content}</p>
              <small>
                {announcement.kind === "notification" ? "Notification" : "Annonce"} · {announcement.audience === "all" ? "Tous les utilisateurs" : `Niveau ${announcement.audienceLevel}`}
                {announcement.publishedAt ? ` · publiée le ${date(announcement.publishedAt)}` : ` · modifiée le ${date(announcement.updatedAt)}`}
              </small>
            </div>
            <div className="admin-card-actions">
              {announcement.status === "draft" && <button type="button" onClick={() => edit(announcement)}><Pencil size={14} /> Modifier</button>}
              <button className={announcement.status === "published" ? "reject" : "approve"} type="button" onClick={() => void changePublication(announcement)}>
                {announcement.status === "published" ? <EyeOff size={14} /> : <Send size={14} />}
                {announcement.status === "published" ? "Retirer" : "Publier"}
              </button>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function ChannelsPanel() {
  const preset = OPERATOR_PRESETS[0];
  const defaultCountry = PAYMENT_COUNTRIES[0];
  const [channels, setChannels] = useState<PaymentChannel[]>([]);
  const [error, setError] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<Omit<PaymentChannel, "id">>({ operatorName: preset.label, receiverNumber: "", receiverName: "", logoColor: preset.logoColor, logoText: preset.key, logoUrl: "", country: defaultCountry.name, countryCode: defaultCountry.code, ussdTemplate: preset.defaultUssd, isActive: true, sortOrder: 0 });
  const load = () => request<{ channels: PaymentChannel[] }>("/api/admin/payment-channels").then((data) => setChannels(data.channels)).catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  useEffect(() => { void load(); }, []);
  const resetForm = () => {
    setEditingId(null);
    setForm({ operatorName: preset.label, receiverNumber: "", receiverName: "", logoColor: preset.logoColor, logoText: preset.key, logoUrl: "", country: defaultCountry.name, countryCode: defaultCountry.code, ussdTemplate: preset.defaultUssd, isActive: true, sortOrder: 0 });
  };
  const save = async () => {
    if (editingId) {
      await request(`/api/admin/payment-channels/${editingId}`, { method: "PATCH", body: form });
    } else {
      await request("/api/admin/payment-channels", { method: "POST", body: form });
    }
    resetForm();
    await load();
  };
  const edit = (channel: PaymentChannel) => {
    setEditingId(channel.id);
    setForm({
      operatorName: channel.operatorName,
      receiverNumber: channel.receiverNumber,
      receiverName: channel.receiverName,
      logoColor: channel.logoColor,
      logoText: channel.logoText,
      logoUrl: channel.logoUrl,
      country: channel.country,
      countryCode: channel.countryCode,
      ussdTemplate: channel.ussdTemplate,
      isActive: channel.isActive,
      sortOrder: channel.sortOrder,
    });
  };
  return <section className="admin-panel"><h2>Canaux de paiement</h2>{error && <div className="admin-error">{error}</div>}<div className="admin-operator-presets">{OPERATOR_PRESETS.map((item) => <button type="button" key={item.key} className={form.logoText === item.key ? "active" : ""} onClick={() => setForm((current) => ({ ...current, operatorName: item.label, logoColor: item.logoColor, logoText: item.key, ussdTemplate: item.defaultUssd }))}><OperatorLogo logoText={item.key} logoColor={item.logoColor} size={38} /><small>{item.key}</small></button>)}</div><div className="admin-inline-form"><input value={form.operatorName} onChange={(event) => setForm((current) => ({ ...current, operatorName: event.target.value }))} placeholder="Opérateur" /><input value={form.receiverNumber} onChange={(event) => setForm((current) => ({ ...current, receiverNumber: event.target.value }))} placeholder="Numéro marchand" /><input value={form.receiverName} onChange={(event) => setForm((current) => ({ ...current, receiverName: event.target.value }))} placeholder="Nom du marchand" /><label className="admin-channel-field">Pays<select value={form.countryCode} onChange={(event) => { const selectedCountry = PAYMENT_COUNTRIES.find((country) => country.code === event.target.value); if (selectedCountry) setForm((current) => ({ ...current, country: selectedCountry.name, countryCode: selectedCountry.code })); }}><option value="" disabled>Sélectionner un pays</option>{PAYMENT_COUNTRIES.map((country) => <option value={country.code} key={country.code}>{country.name} ({country.code})</option>)}</select></label><input value={form.ussdTemplate} onChange={(event) => setForm((current) => ({ ...current, ussdTemplate: event.target.value }))} placeholder="USSD avec {account} et {amount} (facultatif)" /><input value={form.logoUrl} onChange={(event) => setForm((current) => ({ ...current, logoUrl: event.target.value }))} placeholder="URL du logo (facultatif)" /><div className="admin-logo-preview"><OperatorLogo logoText={form.logoText} logoColor={form.logoColor} logoUrl={form.logoUrl} size={38} /><span>Aperçu du logo</span></div><button type="button" disabled={!form.operatorName || !form.receiverNumber} onClick={() => void save().catch((reason) => setError(reason instanceof Error ? reason.message : "Enregistrement impossible."))}>{editingId ? <Pencil size={15} /> : <Plus size={15} />} {editingId ? "Enregistrer" : "Ajouter"}</button>{editingId && <button type="button" onClick={resetForm}>Annuler</button>}</div><div className="admin-list">{channels.map((channel) => <article className="admin-list-card" key={channel.id}><OperatorLogo logoText={channel.logoText} logoColor={channel.logoColor} logoUrl={channel.logoUrl} /><div><strong>{channel.operatorName}</strong><p>{channel.country} · {channel.countryCode} · {channel.receiverNumber} · {channel.receiverName}</p><small>{channel.isActive ? "Actif" : "Inactif"} · {channel.ussdTemplate}</small></div><div className="admin-card-actions"><button type="button" onClick={() => edit(channel)}><Pencil size={14} /> Modifier</button><button type="button" onClick={() => void request(`/api/admin/payment-channels/${channel.id}`, { method: "PATCH", body: { isActive: !channel.isActive } }).then(load)}>{channel.isActive ? "Désactiver" : "Activer"}</button><button className="reject" type="button" onClick={() => void request(`/api/admin/payment-channels/${channel.id}`, { method: "DELETE" }).then(load)}><Trash2 size={15} /></button></div></article>)}</div></section>;
}

function SettingsPanel() {
  const [config, setConfig] = useState({
    depositMin: 3500,
    withdrawalMin: 2000,
    withdrawalFeePercent: 10,
    dashboxDeposit: 300,
    dashboxWithdraw: 1000,
    signupBonus: 2000,
    checkinBonus: 200,
    maxWithdrawals: null as number | null,
  });
  const [configLoaded, setConfigLoaded] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  useEffect(() => {
    request<{ config: typeof config }>("/api/admin/popup-config")
      .then((data) => { setConfig(data.config); setConfigLoaded(true); })
      .catch((reason) => setError(reason instanceof Error ? reason.message : "Chargement impossible."));
  }, []);
  const labels: Record<keyof typeof config, string> = {
    depositMin: "Dépôt minimum",
    withdrawalMin: "Retrait minimum",
    withdrawalFeePercent: "Frais de retrait (%)",
    dashboxDeposit: "Montant rapide de dépôt",
    dashboxWithdraw: "Montant rapide de retrait",
    signupBonus: "Bonus d’inscription",
    checkinBonus: "Bonus de pointage",
    maxWithdrawals: "Retraits maximum par jour",
  };
  const save = async () => {
    setError("");
    setNotice("");
    if (config.maxWithdrawals !== null && (!Number.isSafeInteger(config.maxWithdrawals) || config.maxWithdrawals <= 0)) {
      setError("Le nombre maximum de retraits doit être un entier positif ou illimité.");
      return;
    }
    try {
      await request("/api/admin/popup-config", { method: "PATCH", body: config });
      setNotice("Paramètres enregistrés et appliqués aux règles backend.");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Enregistrement impossible.");
    }
  };
  return (
    <section className="admin-panel">
      <h2>Paramètres financiers</h2>
      {notice && <div className="admin-notice">{notice}</div>}
      {error && <div className="admin-error">{error}</div>}
      <div className="admin-settings-grid">
        {(Object.keys(config) as Array<keyof typeof config>).filter((field) => field !== "maxWithdrawals").map((field) => (
          <label key={field}>{labels[field]}<input type="number" min="1" value={config[field] ?? ""} onChange={(event) => setConfig((current) => ({ ...current, [field]: Number(event.target.value) }))} /></label>
        ))}
        <label>Retraits maximum par jour<select value={config.maxWithdrawals === null ? "unlimited" : "limited"} onChange={(event) => setConfig((current) => ({ ...current, maxWithdrawals: event.target.value === "unlimited" ? null : current.maxWithdrawals ?? 1 }))}><option value="limited">Nombre limité</option><option value="unlimited">Illimité</option></select><input type="number" min="1" step="1" value={config.maxWithdrawals ?? ""} disabled={config.maxWithdrawals === null} onChange={(event) => setConfig((current) => ({ ...current, maxWithdrawals: Number(event.target.value) }))} /></label>
      </div>
      <button className="admin-primary-button" type="button" disabled={!configLoaded} onClick={() => void save()}>Enregistrer</button>
    </section>
  );
}