// Presentation only: keep legacy class names, IDs, routes and script hooks intact.
// These are not product branding and renaming them would break existing screens.
function withAeronovaBranding(html) {
  return html.replace(
    /<script\b[^>]*>[\s\S]*?<\/script\s*>|<style\b[^>]*>[\s\S]*?<\/style\s*>|<[^>]*>|[^<]+/gi,
    chunk => {
      if (/^<(?:script|style)\b/i.test(chunk)) return chunk;
      if (!chunk.startsWith('<')) return chunk.replace(/andship/gi, 'AERONOVA');
      return chunk
        .replace(/\b(alt|aria-label|title|placeholder|content|data-brand)\s*=\s*(["'])(.*?)\2/gi,
          (attribute, name, quote, value) => {
            const branded = value.replace(/andship/gi, name.toLowerCase() === 'data-brand' ? 'aeronova' : 'AERONOVA');
            return `${name}=${quote}${branded}${quote}`;
          })
        .replace(/(?:andship-auth-logo|andship-drone-wordmark|finance-reference-logo)\.svg(?:\?[^"' >]*)?/gi,
          'aeronova-wordmark.svg?v=1');
    }
  );
}

module.exports = { withAeronovaBranding };
