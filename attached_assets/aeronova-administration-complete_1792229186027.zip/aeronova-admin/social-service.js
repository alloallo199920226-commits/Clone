'use strict';

const crypto = require('crypto');

const MAX_PAGE_SIZE = 40;
const DEFAULT_PAGE_SIZE = 20;
const MAX_IMAGE_INPUT_BYTES = Math.floor(1.5 * 1024 * 1024);
const MAX_IMAGE_INPUT_TOTAL_BYTES = 9 * 1024 * 1024;
const MAX_IMAGE_OUTPUT_BYTES = 4 * 1024 * 1024;
const MAX_POST_OUTPUT_BYTES = 9 * 1024 * 1024;
const MAX_PIXELS = 16_000_000;
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const CAMEROON_COUNTRIES = new Set(['CM', 'CAMEROUN', '+237', '237']);
const COUNTRY_PREFIXES = new Map([
  ['BJ', '229'], ['BENIN', '229'], ['BÉNIN', '229'],
  ['CM', '237'], ['CAMEROUN', '237'], ['+237', '237'], ['237', '237'],
  ['BF', '226'], ['BURKINA FASO', '226'],
  ['CI', '225'], ["CÔTE D'IVOIRE", '225'], ["COTE D'IVOIRE", '225'],
  ['TG', '228'], ['TOGO', '228'],
  ['NE', '227'], ['NIGER', '227'],
  ['TD', '235'], ['TCHAD', '235'],
  ['SN', '221'], ['SÉNÉGAL', '221'], ['SENEGAL', '221']
]);

class SocialError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.name = 'SocialError';
    this.status = status;
  }
}

function canonicalCountryPrefix(country) {
  return COUNTRY_PREFIXES.get(String(country || '').trim().toLocaleUpperCase('fr')) || '';
}

function canonicalRegistrationNumber(phone, country) {
  const digits = String(phone || '').replace(/\D/g, '');
  if (!digits) return '';
  const prefix = canonicalCountryPrefix(country);
  return `+${prefix && !digits.startsWith(prefix) ? prefix + digits : digits}`;
}

function maskRegistrationNumber(phone, country) {
  const registration = canonicalRegistrationNumber(phone, country);
  const digits = registration.replace(/\D/g, '');
  if (!digits) return '';
  const visibleCount = Math.floor(digits.length / 2);
  const prefix = canonicalCountryPrefix(country);
  const visiblePrefixCount = Math.min(prefix && digits.startsWith(prefix) ? prefix.length : Math.ceil(visibleCount / 2), visibleCount);
  const visibleSuffixCount = visibleCount - visiblePrefixCount;
  const hiddenCount = digits.length - visibleCount;
  const start = digits.slice(0, visiblePrefixCount);
  const end = visibleSuffixCount ? digits.slice(-visibleSuffixCount) : '';
  return `${registration.startsWith('+') ? '+' : ''}${start}${'•'.repeat(hiddenCount)}${end}`;
}

function isCameroonCountry(country) {
  return CAMEROON_COUNTRIES.has(String(country || '').trim().toLocaleUpperCase('fr'));
}

function parsePageOptions(query = {}) {
  const rawLimit = query.limit;
  let limit = DEFAULT_PAGE_SIZE;
  if (rawLimit !== undefined) {
    if (!/^(?:[1-9]\d{0,2})$/.test(String(rawLimit))) throw new SocialError('Limite de pagination invalide.');
    limit = Number(rawLimit);
    if (limit < 1 || limit > MAX_PAGE_SIZE) throw new SocialError('La limite maximale est de 40 éléments.');
  }
  let cursor = null;
  if (query.cursor !== undefined) {
    if (typeof query.cursor !== 'string' || !UUID_PATTERN.test(query.cursor)) throw new SocialError('Curseur de pagination invalide.');
    cursor = query.cursor.toLowerCase();
  }
  return { limit, cursor };
}

function validateCaptionAndImages(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw new SocialError('Corps de requête invalide.');
  const keys = Object.keys(body);
  if (keys.some(key => !['caption', 'images'].includes(key))) throw new SocialError('Champs de requête inattendus.');
  if (typeof body.caption !== 'string' || body.caption.trim().length < 1 || Array.from(body.caption).length > 1000) {
    throw new SocialError('La légende doit contenir entre 1 et 1 000 caractères.');
  }
  if (!Array.isArray(body.images) || body.images.length < 2 || body.images.length > 6) {
    throw new SocialError('Un dossier doit contenir entre 2 et 6 images.');
  }
  let aggregateBytes = 0;
  for (const image of body.images) {
    if (typeof image !== 'string') throw new SocialError('Format d’image invalide.', 415);
    const size = Buffer.byteLength(image, 'utf8');
    if (size > MAX_IMAGE_INPUT_BYTES) throw new SocialError('Chaque image doit peser au maximum 1,5 Mo.', 413);
    aggregateBytes += size;
    if (aggregateBytes > MAX_IMAGE_INPUT_TOTAL_BYTES) throw new SocialError('La taille totale des images dépasse 9 Mo.', 413);
  }
  return { caption: body.caption.trim(), images: body.images };
}

function decodeImageDataUrl(value) {
  const match = /^data:(image\/(?:jpeg|jpg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/.exec(value);
  if (!match || match[2].length % 4 !== 0) throw new SocialError('Seules les images JPEG, PNG et WebP encodées en base64 sont acceptées.', 415);
  const bytes = Buffer.from(match[2], 'base64');
  if (!bytes.length || bytes.toString('base64') !== match[2]) throw new SocialError('Données d’image base64 invalides.', 415);
  const mime = match[1];
  const signatureMatches = mime === 'image/jpeg' || mime === 'image/jpg'
    ? bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff
    : mime === 'image/png'
      ? bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))
      : bytes.length >= 12 && bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP';
  if (!signatureMatches) throw new SocialError('Le contenu ne correspond pas au format d’image déclaré.', 415);
  return { bytes, mime };
}

function toIso(value) {
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString();
}

function imageDto(image) {
  return {
    id: image.id,
    url: `/api/social/images/${image.id}`,
    width: Number(image.width),
    height: Number(image.height)
  };
}

function engagementDto(row) {
  const likesCount = Number(row.likes_count);
  const viewsCount = Number(row.views_count);
  if (row.likes_count === null || row.views_count === null ||
      !Number.isSafeInteger(likesCount) || likesCount < 0 ||
      !Number.isSafeInteger(viewsCount) || viewsCount < 0 ||
      typeof row.liked_by_me !== 'boolean') {
    throw new SocialError('Les compteurs de cette publication sont indisponibles.', 500);
  }
  return { id: row.id, likesCount, viewsCount, likedByMe: row.liked_by_me };
}

function mapPost(row, images = []) {
  return {
    id: row.id,
    caption: row.caption,
    status: row.status,
    createdAt: toIso(row.created_at),
    approvedAt: row.approved_at ? toIso(row.approved_at) : null,
    bonus: Number(row.bonus),
    reviewNote: row.review_note || '',
    images: images.map(imageDto)
  };
}

function createSocialService({ pool, sharp, internationalPhone = canonicalRegistrationNumber }) {
  if (!pool) throw new TypeError('Social service requires a PostgreSQL pool.');

  async function processImage(dataUrl) {
    const { bytes, mime } = decodeImageDataUrl(dataUrl);
    const imageProcessor = sharp || require('sharp');
    let output;
    try {
      const source = imageProcessor(bytes, { limitInputPixels: MAX_PIXELS, failOn: 'error' });
      const metadata = await source.metadata();
      if (!metadata.width || !metadata.height || metadata.width * metadata.height > MAX_PIXELS) {
        throw new SocialError('Les dimensions maximales autorisées sont de 16 mégapixels.', 413);
      }
      const expectedFormat = mime === 'image/jpeg' || mime === 'image/jpg' ? 'jpeg' : mime === 'image/png' ? 'png' : 'webp';
      if (metadata.format !== expectedFormat) throw new SocialError('Le contenu ne correspond pas au format d’image déclaré.', 415);
      const result = await imageProcessor(bytes, { limitInputPixels: MAX_PIXELS, failOn: 'error' })
        .rotate()
        .resize({ width: 1600, height: 1600, fit: 'inside', withoutEnlargement: true })
        .jpeg({ quality: 94, chromaSubsampling: '4:4:4', mozjpeg: true })
        .toBuffer({ resolveWithObject: true });
      output = result;
    } catch (error) {
      if (error instanceof SocialError) throw error;
      if (error && /pixel|image exceeds|dimensions/i.test(String(error.message))) {
        throw new SocialError('Les dimensions maximales autorisées sont de 16 mégapixels.', 413);
      }
      throw new SocialError('Impossible de décoder cette image.', 415);
    }
    if (!output.data.length || output.data.length > MAX_IMAGE_OUTPUT_BYTES) {
      throw new SocialError('L’image traitée dépasse la taille autorisée.', 413);
    }
    return { bytes: output.data, width: output.info.width, height: output.info.height };
  }

  async function insertPost(userId, body) {
    const input = validateCaptionAndImages(body);
    const processed = [];
    let totalOutputBytes = 0;
    for (const dataUrl of input.images) {
      const image = await processImage(dataUrl);
      totalOutputBytes += image.bytes.length;
      if (totalOutputBytes > MAX_POST_OUTPUT_BYTES) throw new SocialError('La taille totale des images traitées dépasse 9 Mo.', 413);
      processed.push(image);
    }

    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const user = (await client.query('SELECT id FROM users WHERE id=$1 FOR UPDATE', [userId])).rows[0];
      if (!user) throw new SocialError('Compte introuvable.', 404);
      const quotas = (await client.query(
        `SELECT count(*) FILTER (WHERE status='pending')::int AS pending,
                count(*) FILTER (WHERE created_at >= now()-interval '1 day')::int AS daily
         FROM social_posts WHERE user_id=$1`,
        [userId]
      )).rows[0];
      if (Number(quotas.pending) >= 3) throw new SocialError('Vous avez déjà 3 dossiers en attente de vérification.', 429);
      if (Number(quotas.daily) >= 10) throw new SocialError('La limite de 10 dossiers par jour est atteinte.', 429);
      const post = (await client.query(
        `INSERT INTO social_posts(id,user_id,caption) VALUES($1,$2,$3)
         RETURNING id,caption,status,created_at,approved_at,bonus,review_note`,
        [crypto.randomUUID(), userId, input.caption]
      )).rows[0];
      const imageRows = [];
      for (let ordinal = 0; ordinal < processed.length; ordinal += 1) {
        const image = processed[ordinal];
        const inserted = await client.query(
          `INSERT INTO social_post_images(id,post_id,ordinal,mime_type,width,height,content)
           VALUES($1,$2,$3,'image/jpeg',$4,$5,$6)
           RETURNING id,width,height`,
          [crypto.randomUUID(), post.id, ordinal, image.width, image.height, image.bytes]
        );
        imageRows.push(inserted.rows[0]);
      }
      await client.query('COMMIT');
      return mapPost(post, imageRows);
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async function getImages(postIds) {
    if (!postIds.length) return new Map();
    const result = await pool.query(
      `SELECT id,post_id,width,height FROM social_post_images
       WHERE post_id=ANY($1::uuid[]) ORDER BY post_id,ordinal`,
      [postIds]
    );
    const images = new Map();
    for (const image of result.rows) {
      if (!images.has(image.post_id)) images.set(image.post_id, []);
      images.get(image.post_id).push(image);
    }
    return images;
  }

  async function findCursor(cursor, condition, params) {
    if (!cursor) return null;
    const row = (await pool.query(
      `SELECT 1 AS found FROM social_posts p WHERE p.id=$1 AND ${condition}`,
      [cursor, ...params]
    )).rows[0];
    if (!row) throw new SocialError('Curseur de pagination introuvable ou hors périmètre.');
    return row;
  }

  async function listPublic(query = {}, viewerId = null) {
    const { limit, cursor } = parsePageOptions(query);
    await findCursor(cursor, "p.status='approved' AND p.bonus>0", []);
    const cursorClause = cursor
      ? `AND (p.created_at,p.id) < (
           SELECT c.created_at,c.id FROM social_posts c
           WHERE c.id=$1::uuid AND c.status='approved' AND c.bonus>0
         )`
      : '';
    const values = cursor ? [cursor, limit + 1] : [limit + 1];
    const limitParam = cursor ? '$2' : '$1';
    values.push(viewerId);
    const viewerParam = `$${values.length}`;
    const rows = (await pool.query(
      `SELECT p.id,p.caption,p.created_at,p.approved_at,p.bonus,u.phone,u.country,
         (SELECT count(*) FROM social_post_likes l WHERE l.post_id=p.id) AS likes_count,
         (SELECT count(*) FROM social_post_views v WHERE v.post_id=p.id) AS views_count,
         EXISTS(SELECT 1 FROM social_post_likes l WHERE l.post_id=p.id AND l.user_id=${viewerParam}::bigint) AS liked_by_me
       FROM social_posts p JOIN users u ON u.id=p.user_id
       WHERE p.status='approved' AND p.bonus>0 ${cursorClause}
       ORDER BY p.created_at DESC,p.id DESC LIMIT ${limitParam}`,
      values
    )).rows;
    const hasMore = rows.length > limit;
    const page = rows.slice(0, limit);
    const images = await getImages(page.map(row => row.id));
    return {
      posts: page.map(row => ({
        ...engagementDto(row),
        caption: row.caption,
        createdAt: toIso(row.created_at),
        approvedAt: toIso(row.approved_at),
        bonus: Number(row.bonus),
        registrationNumberMasked: maskRegistrationNumber(row.phone, row.country),
        images: (images.get(row.id) || []).map(imageDto)
      })),
      nextCursor: hasMore ? page[page.length - 1].id : null
    };
  }

  async function readEngagement(client, postId, userId) {
    const row = (await client.query(
      `SELECT $1::uuid AS id,
         (SELECT count(*) FROM social_post_likes WHERE post_id=$1) AS likes_count,
         (SELECT count(*) FROM social_post_views WHERE post_id=$1) AS views_count,
         EXISTS(SELECT 1 FROM social_post_likes WHERE post_id=$1 AND user_id=$2) AS liked_by_me`,
      [postId, userId]
    )).rows[0];
    return engagementDto(row);
  }

  async function changeEngagement(postId, userId, kind, liked) {
    if (typeof postId !== 'string' || !UUID_PATTERN.test(postId)) {
      throw new SocialError('Publication introuvable.', 404);
    }
    if (!/^[1-9]\d{0,18}$/.test(String(userId))) throw new SocialError('Compte invalide.');
    const id = postId.toLowerCase();
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const post = (await client.query(
        `SELECT id FROM social_posts WHERE id=$1 AND status='approved' AND bonus>0 FOR UPDATE`,
        [id]
      )).rows[0];
      if (!post) throw new SocialError('Publication introuvable.', 404);
      if (kind === 'view') {
        await client.query(
          `INSERT INTO social_post_views(post_id,user_id) VALUES($1,$2) ON CONFLICT(post_id,user_id) DO NOTHING`,
          [id, userId]
        );
      } else if (liked) {
        await client.query(
          `INSERT INTO social_post_likes(post_id,user_id) VALUES($1,$2) ON CONFLICT(post_id,user_id) DO NOTHING`,
          [id, userId]
        );
      } else {
        await client.query('DELETE FROM social_post_likes WHERE post_id=$1 AND user_id=$2', [id, userId]);
      }
      const result = await readEngagement(client, id, userId);
      await client.query('COMMIT');
      return result;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async function setLike(postId, userId, body) {
    if (!body || typeof body !== 'object' || Array.isArray(body) ||
        Object.keys(body).length !== 1 || typeof body.liked !== 'boolean') {
      throw new SocialError('Indiquez uniquement si vous aimez cette publication.');
    }
    return changeEngagement(postId, userId, 'like', body.liked);
  }

  async function recordView(postId, userId) {
    return changeEngagement(postId, userId, 'view');
  }

  async function listMine(userId, query = {}) {
    const { limit, cursor } = parsePageOptions(query);
    await findCursor(cursor, 'p.user_id=$2', [userId]);
    const cursorClause = cursor
      ? `AND (p.created_at,p.id) < (
           SELECT c.created_at,c.id FROM social_posts c
           WHERE c.id=$2::uuid AND c.user_id=$1
         )`
      : '';
    const values = cursor ? [userId, cursor, limit + 1] : [userId, limit + 1];
    const limitParam = cursor ? '$3' : '$2';
    const rows = (await pool.query(
      `SELECT p.id,p.caption,p.status,p.created_at,p.approved_at,p.bonus,p.review_note
       FROM social_posts p WHERE p.user_id=$1 ${cursorClause}
       ORDER BY p.created_at DESC,p.id DESC LIMIT ${limitParam}`,
      values
    )).rows;
    const hasMore = rows.length > limit;
    const page = rows.slice(0, limit);
    const images = await getImages(page.map(row => row.id));
    return { posts: page.map(row => mapPost(row, images.get(row.id) || [])), nextCursor: hasMore ? page[page.length - 1].id : null };
  }

  async function availablePosts(query = {}) {
    if (typeof query.ids !== 'string' || Object.keys(query).some(key => key !== 'ids')) throw new SocialError('Liste de publications invalide.');
    const ids = query.ids.split(',');
    if (!ids.length || ids.length > MAX_PAGE_SIZE || ids.some(id => !UUID_PATTERN.test(id))) throw new SocialError('La liste doit contenir entre 1 et 40 identifiants valides.');
    const rows = (await pool.query(
      "SELECT id FROM social_posts WHERE id=ANY($1::uuid[]) AND status='approved' AND bonus>0",
      [[...new Set(ids.map(id => id.toLowerCase()))]]
    )).rows;
    return { ids: rows.map(row => row.id) };
  }

  async function deletePost(postId, options = {}) {
    if (!UUID_PATTERN.test(String(postId || ''))) throw new SocialError('Identifiant de dossier invalide.');
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      // Use the same locks as reviewPost so approval and deletion cannot race.
      const post = (await client.query(
        `SELECT p.id,u.country FROM social_posts p JOIN users u ON u.id=p.user_id
         WHERE p.id=$1 FOR UPDATE OF p,u`,
        [postId]
      )).rows[0];
      if (!post || (options.cameroonOnly && !isCameroonCountry(post.country))) throw new SocialError('Dossier introuvable.', 404);
      // Images, likes and views cascade. Already-paid financial ledger entries remain intact.
      await client.query('DELETE FROM social_posts WHERE id=$1', [post.id]);
      await client.query('COMMIT');
      return { ok: true, deleted: true, id: post.id };
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async function listAdmin(query = {}, cameroonOnly = false) {
    const { limit, cursor } = parsePageOptions(query);
    const status = query.status;
    if (!['pending', 'approved', 'rejected'].includes(status)) throw new SocialError('Statut de dossier invalide.');
    const countryClause = cameroonOnly ? "AND upper(trim(u.country)) IN ('CAMEROUN','CM','+237','237')" : '';
    const baseParams = [status];
    const cursorCondition = `p.status=$2${cameroonOnly ? " AND upper(trim((SELECT cu.country FROM users cu WHERE cu.id=p.user_id))) IN ('CAMEROUN','CM','+237','237')" : ''}`;
    await findCursor(cursor, cursorCondition, baseParams);
    const cursorCountryCondition = cameroonOnly
      ? " AND upper(trim((SELECT cu.country FROM users cu WHERE cu.id=c.user_id))) IN ('CAMEROUN','CM','+237','237')"
      : '';
    const cursorClause = cursor
      ? `AND (p.created_at,p.id) < (
           SELECT c.created_at,c.id FROM social_posts c
           WHERE c.id=$2::uuid AND c.status=$1${cursorCountryCondition}
         )`
      : '';
    const values = cursor ? [status, cursor, limit + 1] : [status, limit + 1];
    const limitParam = cursor ? '$3' : '$2';
    const rows = (await pool.query(
      `SELECT p.id,p.caption,p.status,p.created_at,p.approved_at,p.bonus,p.review_note,
              u.id AS author_id,u.phone AS author_phone,u.country AS author_country
       FROM social_posts p JOIN users u ON u.id=p.user_id
       WHERE p.status=$1 ${countryClause} ${cursorClause}
       ORDER BY p.created_at DESC,p.id DESC LIMIT ${limitParam}`,
      values
    )).rows;
    const hasMore = rows.length > limit;
    const page = rows.slice(0, limit);
    const images = await getImages(page.map(row => row.id));
    return {
      posts: page.map(row => ({
        ...mapPost(row, images.get(row.id) || []),
        author: {
          userId: row.author_id,
          registrationNumber: internationalPhone(row.author_phone, row.author_country),
          country: row.author_country
        }
      })),
      nextCursor: hasMore ? page[page.length - 1].id : null
    };
  }

  async function reviewPost(postId, action, options = {}) {
    if (!UUID_PATTERN.test(String(postId || ''))) throw new SocialError('Identifiant de dossier invalide.');
    const cameroonOnly = Boolean(options.cameroonOnly);
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const post = (await client.query(
        `SELECT p.id,p.user_id,p.status,p.bonus,p.caption,p.created_at,p.approved_at,p.review_note,
                u.country,u.is_banned,u.is_blocked
         FROM social_posts p JOIN users u ON u.id=p.user_id
         WHERE p.id=$1 FOR UPDATE OF p,u`,
        [postId]
      )).rows[0];
      if (!post || (cameroonOnly && !isCameroonCountry(post.country))) throw new SocialError('Dossier introuvable.', 404);
      if (action === 'approve') {
        const bonus = options.bonus;
        if (!Number.isInteger(bonus) || bonus < 1 || bonus > 100000) throw new SocialError('La prime doit être un entier compris entre 1 et 100 000.');
        if (post.status === 'approved') {
          await client.query('COMMIT');
          return { ok: true, replayed: true, bonus: Number(post.bonus), post: mapPost(post) };
        }
        if (post.status !== 'pending') throw new SocialError('Seuls les dossiers en attente peuvent être approuvés.', 409);
        if (post.is_banned || post.is_blocked) throw new SocialError('Le compte est indisponible pour recevoir une prime.', 409);
        const account = (await client.query('SELECT balance,cumulative_earnings FROM accounts WHERE user_id=$1 FOR UPDATE', [post.user_id])).rows[0];
        if (!account) throw new SocialError('Compte financier introuvable.', 409);
        const balance = Number(account.balance);
        const cumulativeEarnings = Number(account.cumulative_earnings);
        if (!Number.isSafeInteger(balance) || balance < 0 || !Number.isSafeInteger(balance + bonus) ||
            !Number.isSafeInteger(cumulativeEarnings) || cumulativeEarnings < 0 || !Number.isSafeInteger(cumulativeEarnings + bonus)) {
          throw new SocialError('Le solde ne peut pas recevoir cette prime.', 409);
        }
        await client.query(
          'UPDATE accounts SET balance=balance+$2,cumulative_earnings=cumulative_earnings+$2,updated_at=now() WHERE user_id=$1',
          [post.user_id, bonus]
        );
        await client.query(
          `INSERT INTO transactions(user_id,type,amount,direction,reference,metadata)
           VALUES($1,'social_bonus',$2,'credit',$3,$4)`,
          // Preserve the full UUID identity while fitting the ledger's varchar(40).
          [post.user_id, bonus, `SOCIAL-${post.id.replace(/-/g, '')}`, JSON.stringify({ postId: post.id, socialPostId: post.id })]
        );
        const updated = (await client.query(
          `UPDATE social_posts SET status='approved',bonus=$2,approved_at=now(),review_note=NULL
           WHERE id=$1 RETURNING id,caption,status,created_at,approved_at,bonus,review_note`,
          [post.id, bonus]
        )).rows[0];
        await client.query('COMMIT');
        return { ok: true, replayed: false, bonus, post: mapPost(updated) };
      }
      if (action === 'reject') {
        const reason = options.reason;
        if (typeof reason !== 'string' || reason.trim().length < 1 || Array.from(reason).length > 500) throw new SocialError('Le motif de refus doit contenir entre 1 et 500 caractères.');
        if (post.status !== 'pending') throw new SocialError('Seuls les dossiers en attente peuvent être refusés.', 409);
        const updated = (await client.query(
          `UPDATE social_posts SET status='rejected',review_note=$2 WHERE id=$1
           RETURNING id,caption,status,created_at,approved_at,bonus,review_note`,
          [post.id, reason.trim()]
        )).rows[0];
        await client.query('COMMIT');
        return { ok: true, post: mapPost(updated) };
      }
      throw new SocialError('Action administrative invalide.');
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async function readImage(imageId, viewer) {
    if (!UUID_PATTERN.test(String(imageId || ''))) throw new SocialError('Identifiant d’image invalide.');
    const row = (await pool.query(
      `SELECT i.id,i.mime_type,i.content,p.status,p.bonus,p.user_id,u.country
       FROM social_post_images i JOIN social_posts p ON p.id=i.post_id
       JOIN users u ON u.id=p.user_id WHERE i.id=$1`,
      [imageId]
    )).rows[0];
    if (!row) throw new SocialError('Image introuvable.', 404);
    const isOwner = viewer.kind === 'customer' && String(viewer.userId) === String(row.user_id);
    const hasGeneralAccess = viewer.kind === 'generalAdmin';
    const hasCameroonAccess = viewer.kind === 'cameroonAdmin' && isCameroonCountry(row.country);
    const isApproved = row.status === 'approved' && Number(row.bonus) > 0;
    if ((!isApproved && !isOwner && !hasGeneralAccess && !hasCameroonAccess) ||
        (viewer.kind === 'cameroonAdmin' && !hasCameroonAccess)) {
      throw new SocialError('Accès à cette image refusé.', 403);
    }
    return { bytes: row.content, mimeType: row.mime_type };
  }

  return { insertPost, listPublic, listMine, listAdmin, reviewPost, deletePost, availablePosts, readImage, processImage, setLike, recordView };
}

module.exports = {
  SocialError,
  createSocialService,
  canonicalRegistrationNumber,
  maskRegistrationNumber,
  isCameroonCountry,
  parsePageOptions,
  validateCaptionAndImages,
  decodeImageDataUrl,
  UUID_PATTERN,
  MAX_IMAGE_INPUT_BYTES,
  MAX_IMAGE_INPUT_TOTAL_BYTES,
  MAX_PIXELS
};