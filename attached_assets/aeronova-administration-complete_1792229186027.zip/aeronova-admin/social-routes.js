'use strict';

const { createSocialService, SocialError } = require('./social-service');
const { createDbRateLimiter } = require('./security');

function asyncRoute(handler) {
  return (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);
}

function registerSocialRoutes(app, dependencies) {
  const {
    pool,
    auth,
    financialRate,
    socialEngagementRate = createDbRateLimiter({
      pool, windowMs: 60 * 1000, max: 180, key: req => `social-engagement:${req.user.id}`
    }),
    adminAuth,
    cameroonAdminAuth,
    express,
    getAdminScope = () => null,
    sharp
  } = dependencies;
  const service = createSocialService({ pool, sharp });
  const uploadJson = express.json({
    limit: '10mb',
    type: 'application/json'
  });
  const requireJson = (req, res, next) => req.is('application/json')
    ? next()
    : res.status(415).json({ error: 'Le contenu doit être au format JSON.' });

  app.get('/api/social/posts', auth, asyncRoute(async (req, res) => {
    res.json(await service.listPublic(req.query, req.user.id));
  }));
  app.get('/api/social/mine', auth, asyncRoute(async (req, res) => {
    res.json(await service.listMine(req.user.id, req.query));
  }));
  app.get('/api/social/posts/availability', auth, socialEngagementRate, asyncRoute(async (req, res) => {
    res.json(await service.availablePosts(req.query));
  }));
  // This parser is deliberately mounted after auth and the financial rate limit.
  app.post('/api/social/posts', auth, financialRate, requireJson, uploadJson, asyncRoute(async (req, res) => {
    const post = await service.insertPost(req.user.id, req.body);
    res.status(201).json({ post });
  }));
  app.put('/api/social/posts/:id/like', auth, socialEngagementRate, requireJson, asyncRoute(async (req, res) => {
    res.json(await service.setLike(req.params.id, req.user.id, req.body));
  }));
  app.post('/api/social/posts/:id/view', auth, socialEngagementRate, asyncRoute(async (req, res) => {
    if (req.body !== undefined && req.body !== null &&
        (typeof req.body !== 'object' || Array.isArray(req.body) || Object.keys(req.body).length)) {
      throw new SocialError('Une vue ne nécessite aucune donnée supplémentaire.');
    }
    res.json(await service.recordView(req.params.id, req.user.id));
  }));

  const imageAuth = (req, res, next) => {
    const scope = getAdminScope(req);
    const middleware = scope === 'cameroon'
      ? cameroonAdminAuth
      : scope === 'general' ? adminAuth : auth;
    middleware(req, res, error => {
      if (error) return next(error);
      if (res.headersSent) return undefined;
      req.socialViewer = scope === 'cameroon'
        ? { kind: 'cameroonAdmin' }
        : scope === 'general'
          ? { kind: 'generalAdmin' }
          : { kind: 'customer', userId: req.user.id };
      next();
      return undefined;
    });
  };
  app.get('/api/social/images/:imageId', imageAuth, asyncRoute(async (req, res) => {
    const image = await service.readImage(req.params.imageId, req.socialViewer);
    res.setHeader('Content-Type', image.mimeType);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'private, no-store');
    res.send(image.bytes);
  }));

  app.get('/api/admin/social/posts', adminAuth, asyncRoute(async (req, res) => {
    res.json(await service.listAdmin(req.query, false));
  }));
  app.get('/api/cameroon-admin/social/posts', cameroonAdminAuth, asyncRoute(async (req, res) => {
    res.json(await service.listAdmin(req.query, true));
  }));

  for (const [basePath, middleware, cameroonOnly] of [
    ['/api/admin/social/posts', adminAuth, false],
    ['/api/cameroon-admin/social/posts', cameroonAdminAuth, true]
  ]) {
    app.delete(`${basePath}/:id`, middleware, financialRate, asyncRoute(async (req, res) => {
      if (req.body !== undefined && req.body !== null &&
          (typeof req.body !== 'object' || Array.isArray(req.body) || Object.keys(req.body).length)) {
        throw new SocialError('La suppression ne nécessite aucune donnée supplémentaire.');
      }
      res.json(await service.deletePost(req.params.id, { cameroonOnly }));
    }));
    app.post(`${basePath}/:id/approve`, middleware, financialRate, asyncRoute(async (req, res) => {
      if (!req.body || Array.isArray(req.body) || Object.keys(req.body).some(key => key !== 'bonus')) {
        throw new SocialError('Corps de requête invalide.');
      }
      const result = await service.reviewPost(req.params.id, 'approve', {
        bonus: req.body.bonus,
        cameroonOnly
      });
      res.json(result);
    }));
    app.post(`${basePath}/:id/reject`, middleware, financialRate, asyncRoute(async (req, res) => {
      if (!req.body || Array.isArray(req.body) || Object.keys(req.body).some(key => key !== 'reason')) {
        throw new SocialError('Corps de requête invalide.');
      }
      const result = await service.reviewPost(req.params.id, 'reject', {
        reason: req.body.reason,
        cameroonOnly
      });
      res.json(result);
    }));
  }
  return service;
}

module.exports = { registerSocialRoutes };