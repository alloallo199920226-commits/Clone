const fs = require('node:fs');
const path = require('node:path');
const { withAeronovaBranding } = require('./site-branding');

// Home is the single source of the notification's content and live config hooks.
function popupRange(html) {
  const opening = /<div\b[^>]*\bid=["']campaignPopup["'][^>]*>/i.exec(html);
  if (!opening) return null;
  const tags = /<\/?div\b[^>]*>/gi;
  tags.lastIndex = opening.index;
  let depth = 0, match;
  while ((match = tags.exec(html))) {
    depth += /^<\/div/i.test(match[0]) ? -1 : 1;
    if (depth === 0) return { start: opening.index, end: tags.lastIndex };
  }
  throw new Error('Notification dialog has unbalanced markup');
}

function notificationMarkup() {
  const home = fs.readFileSync(path.join(__dirname, 'accueil_produits_coca_cola/code.html'), 'utf8');
  const range = popupRange(home);
  if (!range) throw new Error('Home notification dialog is missing');
  return withAeronovaBranding(home.slice(range.start, range.end))
    .replace('id="campaignPopup"', 'id="campaignPopup" data-shared-notification="home"');
}

function withSharedNotifications(html) {
  // No notification is added to a page that does not have a notification bell.
  if (!/\bnotice-trigger\b/.test(html)) return html;
  const range = popupRange(html);
  const cleaned = (range ? html.slice(0, range.start) + html.slice(range.end) : html)
    .replace(/<link\b[^>]*\bhref=["'][^"']*notification-popup\.css(?:\?[^"']*)?["'][^>]*>/gi, '')
    .replace(/<script\b[^>]*\bsrc=["'][^"']*notification-modal\.js(?:\?[^"']*)?["'][^>]*>\s*<\/script>/gi, '');
  return cleaned
    .replace('</head>', '<link rel="stylesheet" href="/accueil_produits_coca_cola/notification-popup.css?v=5"></head>')
    .replace('</body>', `${notificationMarkup()}<script src="/accueil_produits_coca_cola/notification-modal.js?v=4" defer></script></body>`);
}

module.exports = { withSharedNotifications, notificationMarkup };
