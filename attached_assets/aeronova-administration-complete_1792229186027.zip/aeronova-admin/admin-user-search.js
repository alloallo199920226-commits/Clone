'use strict';

const PAGE_SIZE = 50;
const USER_MATCH = `($1='' OR strpos(lower(u.phone),$1)>0
  OR ($2<>'' AND strpos(regexp_replace(u.phone,'[^0-9]','','g'),$2)>0)
  OR u.id::text=$1)`;

function searchParameters(query = {}) {
  if (query.search !== undefined && typeof query.search !== 'string') {
    throw Object.assign(new Error('Recherche invalide.'), { status: 400 });
  }
  const search = (query.search || '').trim().toLowerCase();
  if (search.length > 100) throw Object.assign(new Error('Recherche trop longue.'), { status: 400 });
  const cursor = query.cursor ?? null;
  if (cursor !== null && (typeof cursor !== 'string' || !/^[1-9]\d{0,18}$/.test(cursor) || BigInt(cursor) > 9223372036854775807n)) {
    throw Object.assign(new Error('Page invalide.'), { status: 400 });
  }
  return { search, digits: search.replace(/\D/g, '').replace(/^00/, ''), cursor };
}

function registerAdminUserSearch(app, { pool, adminAuth }) {
  app.get('/api/admin/users/search', adminAuth, async (req, res, next) => {
    try {
      const { search, digits, cursor } = searchParameters(req.query);
      const [count, page] = await Promise.all([
        pool.query(`SELECT count(*)::text AS total FROM users u WHERE ${USER_MATCH}`, [search, digits]),
        pool.query(`SELECT u.id,u.phone,u.country,u.referral_code AS "referralCode",
          u.created_at AS "createdAt",u.is_banned AS "isBanned",
          u.is_blocked AS "isBlocked",u.withdrawals_disabled AS "withdrawalsDisabled"
          FROM users u WHERE ${USER_MATCH} AND ($3::bigint IS NULL OR u.id<$3::bigint)
          ORDER BY u.id DESC LIMIT $4`, [search, digits, cursor, PAGE_SIZE + 1])
      ]);
      const users = page.rows.slice(0, PAGE_SIZE);
      res.json({
        users, total: count.rows[0].total,
        nextCursor: page.rows.length > PAGE_SIZE ? String(users.at(-1).id) : null
      });
    } catch (error) { next(error); }
  });
}

module.exports = { registerAdminUserSearch, searchParameters };