const express = require('express');
const { Pool } = require('pg');
const { BANNED_MESSAGE, EXPIRED_COOKIE, createAccountSessionControl } = require('./account-session-control');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs/promises');
const { withCustomerNavigation } = require('./customer-navigation');
const { withPlatformProductTheme } = require('./platform-product-theme');
const { registerVipIncomeSeries } = require('./vip-income-series');
const { promisify } = require('util');
const { exactBody, westpayEventMatches, createDbRateLimiter } = require('./security');
const { applyFinancialPolicy, applyDepositMinimumPolicy, applyWithdrawalWindowPolicy, applyWithdrawalMinimumPolicy, applySignupBonusPolicy, applyWithdrawalFrequencyPolicy, applyReferralWithdrawalRatesPolicy } = require('./financial-policy');
const {
  registerPaymentRoutes,
  isCoteDIvoireWaveChannel,
  isTogoManualChannel,
  isNigerRechargeOperator
} = require('./payments/routes');
const { paymentCountry, normalizePaymentPhone } = require('./payments/countries');
const { registerSaspayRoutes } = require('./payments/saspay-routes');
const { registerSonaraWebhook } = require('./payments/sonarapay-webhook');
const { createProviderControls, registerProviderControls } = require('./payments/provider-controls');
const { registerSonaraRoutes } = require('./payments/sonarapay-routes');
const { registerSocialRoutes } = require('./social-routes');
const { registerSupportRoutes } = require('./support-routes');
const { ADMIN_SESSION_DURATION, createAdminLoginProtection } = require('./admin-auth-policy');
const { isPublicAsset } = require('./public-assets');
const { registerUserMaintenance } = require('./admin-user-maintenance');
const { registerTransactionHistory } = require('./admin-transaction-history');
const { registerAdminUserSearch } = require('./admin-user-search');
const { registerCameroonTotals } = require('./admin-cameroon-totals');
const { createVipIncomeScheduler } = require('./vip-income');
const { createRestrictedAdminAuth, registerRestrictedAdmin, restrictedAdminHtml, restrictedConfigurationError } = require('./restricted-admin');

const scrypt = promisify(crypto.scrypt);
const app = express();
app.set('trust proxy', 1);
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const accountSessions = createAccountSessionControl(pool);
pool.on('error', () => console.error('Connexion à la base interrompue.'));
const vipIncomeScheduler = createVipIncomeScheduler({pool,onError:error=>{
  console.error('Versement automatique des revenus VIP différé.', {
    code:/^[0-9A-Z]{5}$/.test(String(error?.code||''))?error.code:'unknown'
  });
}});
const PORT = Number(process.env.PORT || 5000);
const DAY = 86400000;
const adminPath = String(process.env.ADMIN_PATH || '').trim().replace(/^\/+|\/+$/g, '');
const cameroonAdminPath = String(process.env.CAMEROON_ADMIN_PATH || '').trim().replace(/^\/+|\/+$/g, '');
const restrictedAdminPath = String(process.env.RESTRICTED_ADMIN_PATH || '').trim().replace(/^\/+|\/+$/g, '');

app.disable('x-powered-by');
// Ashtech signatures cover the original bytes; parse only after verification.
app.use('/api/payments/webhook', express.raw({
  type: 'application/json',
  limit: '32kb',
  verify: (req, _res, buffer) => { req.rawBody = buffer; }
}));
app.use(express.json({
  limit: '32kb',
  type: req => !(req.method === 'POST' && /^\/api\/(?:social\/posts|support\/requests)\/?$/.test(req.path)) && Boolean(req.is('application/json')),
  verify: (req, _res, buffer) => {
    if (req.originalUrl.startsWith('/api/webhooks/westpay') || req.originalUrl.startsWith('/api/saspay/webhook')) req.rawBody = Buffer.from(buffer);
  }
}));
app.use((req, res, next) => {
  res.setHeader('Cache-Control', req.path.startsWith('/api/') ? 'no-store' : 'no-cache');
  res.setHeader('Content-Security-Policy', "default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; connect-src 'self'; img-src 'self' data: blob: https:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' data: https://fonts.gstatic.com; script-src 'self' 'unsafe-inline'");
  res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});

const brandHtml = html => {
  const brand = 'AERONOVA';
  const metadata = [
    '<meta name="theme-color" content="#e5e7e8">',
    '<link rel="icon" href="/favicon.svg?v=aeronova-2" type="image/svg+xml">',
    '<link rel="alternate icon" href="/favicon.ico?v=aeronova-2" sizes="16x16 32x32 48x48 64x64">',
    '<link rel="apple-touch-icon" href="/favicon-180.png?v=aeronova-2" sizes="180x180">',
    '<meta name="application-name" content="Sprite">',
    '<meta name="apple-mobile-web-app-title" content="Sprite">',
    '<meta name="description" content="Sprite">',
    '<meta property="og:site_name" content="Sprite">',
    '<meta property="og:title" content="Sprite">',
    '<meta property="og:description" content="Sprite">',
    '<meta property="og:type" content="website">',
    '<meta name="twitter:card" content="summary">',
    '<meta name="twitter:title" content="Sprite">',
    '<meta name="twitter:description" content="Sprite">'
  ].join('').replaceAll('Sprite', brand);
  return withPlatformProductTheme(html)
    .replace('</head>', '<script src="/sprite-assets/account-session.js" defer></script></head>')
    .replace(/<link\b(?=[^>]*\brel\s*=\s*["'][^"']*\b(?:icon|apple-touch-icon|mask-icon)\b[^"']*["'])[^>]*>\s*/gi, '')
    .replace(/<meta\b(?=[^>]*\bname\s*=\s*["']theme-color["'])[^>]*>\s*/gi, '')
    .replace(/<title>[\s\S]*?<\/title>/i, `<title>${brand}</title>`)
    .replace('<head>', `<head>${metadata}${html.includes('stripe-pay-brand.js?v=2') ? '' : '<link rel="stylesheet" href="/sprite-assets/stripe-pay-brand.css?v=1"><script src="/sprite-assets/stripe-pay-brand.js?v=2" defer></script>'}`);
};
// Signed server-to-server notifications do not use browser sessions/origins.
// Register only this receiver before the browser-origin guard.
registerSonaraWebhook(app, {
  pool,
  automaticCredits: async () => providerControls.sonaraEnabled(),
  onRejected: reason => console.warn('Notification SonaraPay refusée.', { reason }),
  onError: error => console.error('Réception SonaraPay différée.', {
    code: /^[0-9A-Z]{5}$/.test(String(error?.code || '')) ? error.code : 'unknown'
  })
});
app.use((req, res, next) => {
  if (!req.path.startsWith('/api/') || ['GET', 'HEAD', 'OPTIONS'].includes(req.method) || req.path === '/api/webhooks/westpay' || (req.method === 'POST' && req.path === '/api/payments/webhook')) return next();
  const origin = String(req.get('origin') || '');
  if (!origin) return next();
  const expected = `${req.protocol}://${req.get('host')}`;
  if (origin !== expected) {
    auditSecurity(req, 'origin_rejected', null, { path: req.path, method: req.method });
    return res.status(403).json({ error: 'Origine de requête refusée.' });
  }
  next();
});

const DEFAULT_CONFIG = { signupBonus: 2000, dailyCheckInReward: 200, minimumDeposit: 3000, minimumWithdrawal: 2000, withdrawalFeePercent: 15, maxWithdrawals: 2, dashboxDeposit: 200, dashboxWithdraw: 2000, referralCommissionRates: [30, 2, 1], referralCommissionCondition: 'first_completed_deposit', withdrawalRequiresActiveVip: true };
async function financialConfig(queryable = pool) {
  const row = (await queryable.query('SELECT value FROM admin_settings WHERE key=$1', ['financial_config'])).rows[0];
  const stored = row?.value || {};
  return {
    ...DEFAULT_CONFIG,
    ...stored,
    signupBonus: stored.signupBonus ?? DEFAULT_CONFIG.signupBonus,
    dailyCheckInReward: stored.dailyCheckInReward ?? stored.checkinBonus ?? DEFAULT_CONFIG.dailyCheckInReward,
    minimumDeposit: Math.max(3000, stored.minimumDeposit ?? stored.depositMin ?? DEFAULT_CONFIG.minimumDeposit),
    minimumWithdrawal: stored.minimumWithdrawal ?? stored.withdrawalMin ?? DEFAULT_CONFIG.minimumWithdrawal,
    dashboxDeposit: stored.dashboxDeposit ?? DEFAULT_CONFIG.dashboxDeposit,
    dashboxWithdraw: stored.dashboxWithdraw ?? DEFAULT_CONFIG.dashboxWithdraw
  };
}
app.get('/api/config/public', async (_req, res, next) => {
  try { const c = await financialConfig(); res.json({ ...c, depositMin: c.minimumDeposit, withdrawalMin: c.minimumWithdrawal, checkinBonus: c.dailyCheckInReward }); } catch (e) { next(e); }
});

const cookies = req => Object.fromEntries((req.headers.cookie || '').split(';').filter(Boolean).map(v => {
  const i = v.indexOf('=');
  return [v.slice(0, i).trim(), decodeURIComponent(v.slice(i + 1))];
}));
const hashToken = token => crypto.createHash('sha256').update(token).digest('hex');
const reference = prefix => `${prefix}-${Date.now()}-${crypto.randomBytes(5).toString('hex')}`;
const cleanPhone = value => String(value || '').replace(/\D/g, '');
const strictBody = allowed => (req, res, next) => exactBody(req.body, allowed) ? next() : res.status(400).json({ error: 'Champs de requête inattendus.' });
const requestIp = req => String(req.ip || req.socket?.remoteAddress || 'unknown');
const loginRate = createDbRateLimiter({ pool, windowMs: 15 * 60 * 1000, max: 10, key: req => `login:${requestIp(req)}:${cleanPhone(req.body?.phone)}` });
const adminLoginRate = createAdminLoginProtection({
  pool, requestIp,
  validCredentials: req => req.path.startsWith('/api/restricted-admin/')
    ? Boolean(restrictedAdminPath && process.env.RESTRICTED_ADMIN_PASSWORD && secureEqual(req.body?.path, restrictedAdminPath) && secureEqual(req.body?.password, process.env.RESTRICTED_ADMIN_PASSWORD))
    : req.path.startsWith('/api/cameroon-admin/')
    ? Boolean(cameroonAdminPath && process.env.CAMEROON_ADMIN_PASSWORD && secureEqual(req.body?.path, cameroonAdminPath) && secureEqual(req.body?.password, process.env.CAMEROON_ADMIN_PASSWORD))
    : Boolean(adminPath && process.env.ADMIN_PASSWORD && secureEqual(req.body?.path, adminPath) && secureEqual(req.body?.password, process.env.ADMIN_PASSWORD))
});
const cameroonAdminLoginRate = adminLoginRate;
const financialRate = createDbRateLimiter({ pool, windowMs: 10 * 60 * 1000, max: 20, key: req => `financial:${requestIp(req)}:${req.user?.id || 'anonymous'}:${req.path}` });
const socialEngagementRate = createDbRateLimiter({ pool, windowMs: 60 * 1000, max: 180, key: req => `social-engagement:${req.user.id}` });
const giftRate = createDbRateLimiter({ pool, windowMs: 15 * 60 * 1000, max: 5, key: req => `gift:${requestIp(req)}:${req.user?.id || 'anonymous'}` });
const auditSecurity = (req, eventType, userId = null, details = {}) => {
  const ipHash = hashToken(requestIp(req));
  pool.query('INSERT INTO security_events(event_type,user_id,ip_hash,details) VALUES($1,$2,$3,$4)', [eventType, userId, ipHash, JSON.stringify(details)])
    .catch(() => console.error('Journal de sécurité indisponible.'));
};
const internationalPhone = (phone, country) => {
  const digits = cleanPhone(phone);
  const prefixes = {
    BJ: '229', 'Bénin': '229', Benin: '229',
    CM: '237', Cameroun: '237',
    BF: '226', 'Burkina Faso': '226',
    CI: '225', "Côte d'Ivoire": '225', "Cote d'Ivoire": '225',
    TG: '228', Togo: '228',
    NE: '227', Niger: '227',
    TD: '235', Tchad: '235',
    SN: '221', Sénégal: '221', Senegal: '221'
  };
  const prefix = prefixes[String(country || '').trim()] || '';
  return `+${prefix && !digits.startsWith(prefix) ? prefix + digits : digits}`;
};
const localPhone = (phone, country) => {
  const digits = cleanPhone(phone);
  const prefixes = {
    BJ: '229', 'Bénin': '229', Benin: '229',
    CM: '237', Cameroun: '237',
    BF: '226', 'Burkina Faso': '226',
    CI: '225', "Côte d'Ivoire": '225', "Cote d'Ivoire": '225',
    TG: '228', Togo: '228',
    NE: '227', Niger: '227',
    TD: '235', Tchad: '235',
    SN: '221', Sénégal: '221', Senegal: '221'
  };
  const prefix = prefixes[String(country || '').trim()] || '';
  return prefix && digits.startsWith(prefix) ? digits.slice(prefix.length) : digits;
};
const paymentCountryName = country => {
  const value = String(country || '').trim();
  const aliases = {
    BJ: 'Bénin', Benin: 'Bénin',
    BF: 'Burkina Faso',
    CI: "Côte d'Ivoire", "Cote d'Ivoire": "Côte d'Ivoire",
    TG: 'Togo'
  };
  return aliases[value] || value;
};
const paymentCountryKey = country => {
  const canonical = paymentCountry(country);
  if (canonical) return `code:${canonical.code}`;
  return `name:${paymentCountryName(country).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('fr')}`;
};
const paymentCountryFilterValues = country => {
  const canonical = paymentCountry(country);
  const values = [
    country,
    paymentCountryName(country),
    ...(canonical ? [canonical.code, canonical.name, ...canonical.aliases] : [])
  ];
  return [...new Set(values.map(value => String(value || '').trim().toLocaleLowerCase('fr')).filter(Boolean))];
};
const eligiblePaymentCountries = new Map([
  ['Bénin', '+229'],
  ['Togo', '+228'],
  ['Niger', '+227'],
  ['Tchad', '+235'],
  ['Cameroun', '+237'],
  ['Sénégal', '+221'],
  ['Burkina Faso', '+226'],
  ["Côte d'Ivoire", '+225']
]);

async function passwordHash(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = await scrypt(password, salt, 64);
  return `${salt}:${derived.toString('hex')}`;
}
async function passwordMatches(password, stored) {
  const [salt, expected] = String(stored).split(':');
  if (!salt || !expected) return false;
  const actual = (await scrypt(password, salt, 64)).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(actual, 'hex'), Buffer.from(expected, 'hex'));
}
async function auth(req, res, next) {
  try {
    const token = cookies(req).coca_session;
    if (!token) return res.status(401).json({ error: 'Authentification requise.' });
    const { rows } = await pool.query(
       `SELECT u.id,u.phone,u.country,u.referral_code,u.referred_by,u.is_banned,u.is_blocked,u.withdrawals_disabled
       FROM sessions s JOIN users u ON u.id=s.user_id
       WHERE s.token_hash=$1 AND s.expires_at>now()`, [hashToken(token)]
    );
    if (!rows[0]) {
      res.setHeader('Set-Cookie', EXPIRED_COOKIE);
      return res.status(401).json({ error: 'Session expirée.' });
    }
    req.user = rows[0];
    if (rows[0].is_banned || rows[0].is_blocked) {
      res.setHeader('Set-Cookie', EXPIRED_COOKIE);
      return res.status(403).json({ error: rows[0].is_banned ? BANNED_MESSAGE : 'Compte bloqué.', code: rows[0].is_banned ? 'ACCOUNT_BANNED' : 'ACCOUNT_BLOCKED' });
    }
    next();
  } catch (error) { next(error); }
}
async function persistSession(userId, remember, queryable = pool) {
  const token = crypto.randomBytes(32).toString('hex');
  const duration = remember ? 30 * DAY : DAY;
  const inserted = await queryable.query(
    `INSERT INTO sessions(token_hash,user_id,expires_at)
     SELECT $1,id,$3 FROM users WHERE id=$2 AND is_banned=false AND is_blocked=false
     FOR UPDATE RETURNING user_id`,
    [hashToken(token), userId, new Date(Date.now() + duration)]);
  if (inserted.rowCount === 0) {
    const member = (await queryable.query('SELECT is_banned FROM users WHERE id=$1', [userId])).rows[0];
    throw Object.assign(new Error(member?.is_banned ? BANNED_MESSAGE : 'Compte bloqué.'), { status: 403 });
  }
  return `coca_session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${Math.floor(duration / 1000)}`;
}
async function createSession(res, userId, remember) {
  res.setHeader('Set-Cookie', await persistSession(userId, remember));
}
const money = value => Number.isSafeInteger(Number(value)) ? Number(value) : NaN;
const WESTPAY_CHECKOUT = 'https://checkout1.westpay.cfd/pay';
const westpayEnabled = () => Boolean(process.env.WESTPAY_MERCHANT_SLUG && process.env.WESTPAY_WEBHOOK_SECRET);
const westpayCountries = new Set();
const westpayCountryParam = country => country === 'Bénin' ? 'Benin' : country;
function verifyWestpaySignature(req, secret) {
  const rawSignature = String(
    req.get('x-robotpay-signature') ||
    req.get('x-webhook-signature') ||
    req.get('x-signature') ||
    ''
  ).trim();
  if (!rawSignature) return { ok: false, reason: 'missing_header' };
  const signature = rawSignature
    .replace(/^Bearer\s+/i, '')
    .replace(/^(?:sha256|v1)=/i, '')
    .trim();
  const expected = crypto.createHmac('sha256', secret).update(req.rawBody).digest();
  let provided;
  if (/^[a-f0-9]{64}$/i.test(signature)) {
    provided = Buffer.from(signature, 'hex');
  } else if (/^[A-Za-z0-9+/]{43}=$/.test(signature) || /^[A-Za-z0-9_-]{43}=?$/.test(signature)) {
    try {
      const normalized = signature.replace(/-/g, '+').replace(/_/g, '/');
      provided = Buffer.from(normalized, 'base64');
    } catch {
      return { ok: false, reason: 'unsupported_format' };
    }
  } else {
    return { ok: false, reason: 'unsupported_format' };
  }
  if (provided.length !== expected.length || !crypto.timingSafeEqual(provided, expected)) {
    return { ok: false, reason: 'secret_mismatch' };
  }
  return { ok: true };
}

async function completeWestpayDeposit(client, deposit, event) {
  if (deposit.status !== 'pending' && !(['ashtechpay', 'saspay', 'sonarapay'].includes(deposit.payment_provider) && deposit.status === 'pending_review') &&
      !(deposit.payment_provider === 'sonarapay' && deposit.status === 'rejected')) return false;
  await client.query('SELECT id FROM users WHERE id=$1 FOR UPDATE', [deposit.user_id]);
  const prior = await client.query(`SELECT 1 FROM deposits WHERE user_id=$1 AND status='completed' AND id<>$2 LIMIT 1`, [deposit.user_id, deposit.id]);
  await client.query(`UPDATE deposits SET status='completed',provider_confirmed_at=now() WHERE id=$1`, [deposit.id]);
  await client.query('UPDATE accounts SET balance=balance+$2,cumulative_earnings=cumulative_earnings+$2,updated_at=now() WHERE user_id=$1', [deposit.user_id, deposit.amount]);
  await client.query(`INSERT INTO transactions(user_id,type,amount,direction,status,reference,metadata)
    VALUES($1,'deposit',$2,'credit','completed',$3,$4)`,
    [deposit.user_id, deposit.amount, deposit.reference, JSON.stringify({ depositId: deposit.id, confirmedBy: event.confirmedBy || 'westpay_webhook', providerTxId: event.txId })]);
  if (!prior.rowCount) {
    const rates = (await financialConfig(client)).referralCommissionRates;
    let sourceUserId = deposit.user_id;
    for (let level = 1; level <= 3; level += 1) {
      const sponsor = (await client.query('SELECT referred_by FROM users WHERE id=$1', [sourceUserId])).rows[0]?.referred_by;
      if (!sponsor) break;
      const commission = Math.floor(Number(deposit.amount) * rates[level - 1] / 100);
      const inserted = await client.query(
        `INSERT INTO referral_commissions(beneficiary_id,source_user_id,deposit_id,level,rate,amount)
         VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT DO NOTHING RETURNING id`,
        [sponsor, deposit.user_id, deposit.id, level, rates[level - 1], commission]);
      if (inserted.rowCount) {
        await client.query('UPDATE accounts SET balance=balance+$2,cumulative_earnings=cumulative_earnings+$2,updated_at=now() WHERE user_id=$1', [sponsor, commission]);
        await client.query(`INSERT INTO transactions(user_id,type,amount,direction,reference,metadata)
          VALUES($1,'referral_commission',$2,'credit',$3,$4)`,
          [sponsor, commission, reference('REF'), JSON.stringify({ depositId: deposit.id, sourceUserId: deposit.user_id, level, rate: rates[level - 1] })]);
      }
      sourceUserId = sponsor;
    }
  }
  return true;
}

const secureEqual = (left, right) => {
  const leftHash = crypto.createHash('sha256').update(String(left)).digest();
  const rightHash = crypto.createHash('sha256').update(String(right)).digest();
  return crypto.timingSafeEqual(leftHash, rightHash);
};
const adminClientKey = req => hashToken(requestIp(req));
const restrictedAdminAuth = createRestrictedAdminAuth({ pool, cookies, hashToken });
async function adminAuth(req, res, next) {
  try {
    const requestCookies = cookies(req);
    if (requestCookies.coca_cameroon_admin) return res.status(403).json({ error: 'Cette session est limitée à l’administration Cameroun.' });
    if (requestCookies.coca_restricted_admin) return restrictedAdminAuth(req, res, next);
    const token = requestCookies.coca_admin;
    if (!token) return res.status(401).json({ error: 'Connexion administrateur requise.' });
    const session = await pool.query(`SELECT 1 FROM admin_sessions WHERE token_hash=$1 AND scope='general' AND expires_at>now()`, [hashToken(token)]);
    if (!session.rowCount) return res.status(401).json({ error: 'Session administrateur expirée.' });
    req.adminScope = 'general';
    next();
  } catch (error) { next(error); }
}
async function cameroonAdminAuth(req, res, next) {
  try {
    const token = cookies(req).coca_cameroon_admin;
    if (!token) return res.status(401).json({ error: 'Connexion administrateur Cameroun requise.' });
    const session = await pool.query(`SELECT 1 FROM admin_sessions WHERE token_hash=$1 AND scope='cameroon' AND expires_at>now()`, [hashToken(token)]);
    if (!session.rowCount) return res.status(401).json({ error: 'Session administrateur Cameroun expirée.' });
    next();
  } catch (error) { next(error); }
}
async function createAdminSession(res, scope = 'general') {
  const token = crypto.randomBytes(32).toString('hex');
  await pool.query('DELETE FROM admin_sessions WHERE expires_at<=now()');
  await pool.query('INSERT INTO admin_sessions(token_hash,expires_at,scope) VALUES($1,$2,$3)',
    [hashToken(token), new Date(Date.now() + ADMIN_SESSION_DURATION), scope]);
  const cookieName = scope === 'cameroon' ? 'coca_cameroon_admin' : scope === 'restricted' ? 'coca_restricted_admin' : 'coca_admin';
  const sessionCookie = `${cookieName}=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${ADMIN_SESSION_DURATION / 1000}; Expires=${new Date(Date.now() + ADMIN_SESSION_DURATION).toUTCString()}`;
  res.setHeader('Set-Cookie', scope === 'restricted'
    ? [sessionCookie, 'coca_admin=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0', 'coca_cameroon_admin=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0']
    : scope === 'cameroon'
      ? [sessionCookie, 'coca_admin=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0', 'coca_restricted_admin=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0']
      : sessionCookie);
}

registerSupportRoutes(app, {pool,auth,adminAuth,financialRate,express,sharp:require('sharp')});
registerSocialRoutes(app, {
  pool,
  auth,
  financialRate,
  socialEngagementRate,
  adminAuth,
  cameroonAdminAuth,
  express,
  getAdminScope: req => {
    const requestCookies = cookies(req);
    if (requestCookies.coca_cameroon_admin) return 'cameroon';
    if (requestCookies.coca_restricted_admin) return 'general';
    if (requestCookies.coca_admin) return 'general';
    return null;
  }
});

app.post('/api/admin/login', adminLoginRate, strictBody(['path', 'password']), async (req, res, next) => {
  try {
    if (cookies(req).coca_cameroon_admin) return res.status(403).json({ error: 'Déconnectez-vous de l’administration Cameroun avant toute autre connexion.' });
    if (cookies(req).coca_restricted_admin) return res.status(403).json({ error: 'Déconnectez-vous de l’administration séparée avant toute autre connexion.' });
    const clientKey = adminClientKey(req);
    const attempt = (await pool.query('SELECT failures,locked_until FROM admin_login_attempts WHERE client_hash=$1', [clientKey])).rows[0];
    if (attempt?.locked_until && new Date(attempt.locked_until) > new Date()) {
      return res.status(429).json({ error: 'Trop de tentatives. Réessayez dans quelques minutes.' });
    }
    if (!adminPath || !process.env.ADMIN_PASSWORD || !secureEqual(req.body.path, adminPath)) {
      auditSecurity(req, 'admin_login_path_rejected');
      return res.status(404).json({ error: 'Administration indisponible.' });
    }
    if (!secureEqual(req.body.password, process.env.ADMIN_PASSWORD)) {
      await pool.query(
        `INSERT INTO admin_login_attempts(client_hash,failures,locked_until)
         VALUES($1,1,NULL)
         ON CONFLICT(client_hash) DO UPDATE SET
           failures=CASE WHEN admin_login_attempts.updated_at < now()-interval '30 minutes' THEN 1 ELSE admin_login_attempts.failures+1 END,
           locked_until=CASE
             WHEN (CASE WHEN admin_login_attempts.updated_at < now()-interval '30 minutes' THEN 1 ELSE admin_login_attempts.failures+1 END)>=5
             THEN now()+interval '15 minutes' ELSE NULL END,
           updated_at=now()`,
        [clientKey]
      );
      await new Promise(resolve => setTimeout(resolve, 650));
      auditSecurity(req, 'admin_login_failed');
      return res.status(401).json({ error: 'Mot de passe administrateur incorrect.' });
    }
    await pool.query('DELETE FROM admin_login_attempts WHERE client_hash=$1', [clientKey]);
    await createAdminSession(res);
    auditSecurity(req, 'admin_login_succeeded');
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.post('/api/cameroon-admin/login', cameroonAdminLoginRate, strictBody(['path', 'password']), async (req, res, next) => {
  try {
    const clientKey = hashToken(`cameroon:${requestIp(req)}`);
    const attempt = (await pool.query('SELECT failures,locked_until FROM admin_login_attempts WHERE client_hash=$1', [clientKey])).rows[0];
    if (attempt?.locked_until && new Date(attempt.locked_until) > new Date()) return res.status(429).json({ error: 'Trop de tentatives. Réessayez dans quelques minutes.' });
    const pathValid = cameroonAdminPath && secureEqual(req.body.path, cameroonAdminPath);
    const passwordValid = process.env.CAMEROON_ADMIN_PASSWORD && secureEqual(req.body.password, process.env.CAMEROON_ADMIN_PASSWORD);
    if (!pathValid) {
      auditSecurity(req, 'cameroon_admin_login_path_rejected');
      return res.status(404).json({ error: 'Administration indisponible.' });
    }
    if (!passwordValid) {
      await pool.query(`INSERT INTO admin_login_attempts(client_hash,failures,locked_until) VALUES($1,1,NULL)
        ON CONFLICT(client_hash) DO UPDATE SET
          failures=CASE WHEN admin_login_attempts.updated_at < now()-interval '30 minutes' THEN 1 ELSE admin_login_attempts.failures+1 END,
          locked_until=CASE WHEN (CASE WHEN admin_login_attempts.updated_at < now()-interval '30 minutes' THEN 1 ELSE admin_login_attempts.failures+1 END)>=5 THEN now()+interval '15 minutes' ELSE NULL END,
          updated_at=now()`, [clientKey]);
      await new Promise(resolve => setTimeout(resolve, 650));
      auditSecurity(req, 'cameroon_admin_login_failed');
      return res.status(401).json({ error: 'Mot de passe administrateur incorrect.' });
    }
    await pool.query('DELETE FROM admin_login_attempts WHERE client_hash=$1', [clientKey]);
    await createAdminSession(res, 'cameroon');
    auditSecurity(req, 'cameroon_admin_login_succeeded');
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.post('/api/cameroon-admin/logout', cameroonAdminAuth, async (req, res, next) => {
  try {
    const token = cookies(req).coca_cameroon_admin;
    if (token) await pool.query(`DELETE FROM admin_sessions WHERE token_hash=$1 AND scope='cameroon'`, [hashToken(token)]);
    res.setHeader('Set-Cookie', 'coca_cameroon_admin=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0');
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.post('/api/admin/logout', adminAuth, async (req, res, next) => {
  try {
    const token = cookies(req).coca_admin;
    if (token) await pool.query('DELETE FROM admin_sessions WHERE token_hash=$1', [hashToken(token)]);
    res.setHeader('Set-Cookie', 'coca_admin=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0');
    res.json({ ok: true });
  } catch (error) { next(error); }
});

registerRestrictedAdmin(app, {
  pool, cookies, hashToken, secureEqual, strictBody, loginRate: adminLoginRate,
  createAdminSession, adminAuth: restrictedAdminAuth, requestIp, auditSecurity,
  privatePath: restrictedAdminPath, getPassword: () => process.env.RESTRICTED_ADMIN_PASSWORD,
  getConfigurationError: () => restrictedAdminConfigurationError
});

registerUserMaintenance(app, { pool, adminAuth, strictBody, secureEqual,
  rate: createDbRateLimiter({ pool, windowMs: 15 * 60 * 1000, max: 3, key: req => `user-purge:${requestIp(req)}` }),
  getPassword: req => req.adminScope === 'restricted' ? process.env.RESTRICTED_ADMIN_PASSWORD : process.env.ADMIN_PASSWORD, getSecret: () => process.env.SESSION_SECRET });
registerTransactionHistory(app, { pool, adminAuth, cameroonAdminAuth, internationalPhone });
registerAdminUserSearch(app, { pool, adminAuth });
registerCameroonTotals(app, { pool, adminAuth });

app.get('/api/admin/overview', adminAuth, async (_req, res, next) => {
  try {
    const [users, deposits, withdrawals, totals] = await Promise.all([
       pool.query(`SELECT u.id,u.phone,u.country,u.referral_code AS "referralCode",u.referred_by AS "referrerId",u.created_at AS "createdAt",u.is_banned AS "isBanned",u.is_blocked AS "isBlocked",u.withdrawals_disabled AS "withdrawalsDisabled",a.balance
        FROM users u JOIN accounts a ON a.user_id=u.id ORDER BY u.created_at DESC LIMIT 500`),
      _req.query?.summary === 'true' ? Promise.resolve({ rows: [] }) : pool.query(`SELECT d.id,d.user_id AS "userId",u.phone AS "userPhone",u.country AS "countryCode",d.amount,d.status,d.reference,d.created_at AS "createdAt",d.amount AS "netAmount",0 AS fee,COALESCE(d.payer_number,u.phone) AS "payerNumber",d.receiver_number AS destination,COALESCE(d.operator_name,'Compte principal') AS "operatorName",d.receiver_name AS "receiverName",COALESCE(d.payment_provider,'manual') AS "paymentProvider",d.provider_tx_id AS "providerTxId",d.provider_confirmed_at AS "providerConfirmedAt",d.provider_return_status AS "providerReturnStatus",0::int AS "referralCount",false AS "adminAssisted",'deposit' AS type
        FROM deposits d JOIN users u ON u.id=d.user_id ORDER BY d.created_at DESC`),
       _req.query?.summary === 'true' ? Promise.resolve({ rows: [] }) : pool.query(`SELECT w.id,w.user_id AS "userId",u.phone AS "userPhone",COALESCE(NULLIF(w.wallet_country,''),u.country) AS "countryCode",w.amount,w.fee,w.net_amount AS "netAmount",w.destination,COALESCE(w.wallet_account_number,w.destination) AS "payerNumber",w.wallet_operator AS "operatorName",w.wallet_holder_name AS "walletHolderName",w.wallet_id AS "walletId",w.status,w.reference,w.created_at AS "createdAt",(SELECT count(*)::int FROM users r WHERE r.referred_by=w.user_id) AS "referralCount",
         (SELECT COALESCE(sum(rc.amount),0)::bigint FROM referral_commissions rc WHERE rc.beneficiary_id=w.user_id) AS "referralCommissionAmount",
         EXISTS(SELECT 1 FROM transactions t WHERE t.user_id=w.user_id AND t.type='admin_credit') AS "hasAdminCredit",
         EXISTS(SELECT 1 FROM admin_operations ao WHERE ao.user_id=w.user_id AND ao.operation_type='grant_vip') AS "hasAdminVipGrant",
         (EXISTS(SELECT 1 FROM transactions t WHERE t.user_id=w.user_id AND t.type='admin_credit')
          OR EXISTS(SELECT 1 FROM admin_operations ao WHERE ao.user_id=w.user_id AND ao.operation_type='grant_vip')) AS "adminAssisted",
         'withdrawal' AS type
         FROM withdrawals w JOIN users u ON u.id=w.user_id ORDER BY w.created_at DESC`),
      pool.query(`SELECT
         (SELECT count(*) FROM users)::int users,
          (SELECT count(*) FROM user_vips WHERE status='active' AND expires_at>now())::int investments,
         (SELECT count(*) FROM user_vips)::int vip_purchases,
          (SELECT COALESCE(sum(amount),0) FROM transactions WHERE type='admin_credit')::bigint "adminCredits",
         (SELECT COALESCE(sum(amount),0) FROM deposits WHERE status='completed')::bigint "approvedDeposits",
         (SELECT COALESCE(sum(amount),0) FROM withdrawals WHERE status='completed')::bigint "approvedWithdrawals",
         (SELECT count(*) FROM deposits WHERE status='completed')::int "approvedDepositCount",
         (SELECT count(*) FROM deposits WHERE status='rejected')::int "rejectedDepositCount",
         (SELECT count(*) FROM withdrawals WHERE status='completed')::int "approvedWithdrawalCount",
         (SELECT count(*) FROM withdrawals WHERE status='rejected')::int "rejectedWithdrawalCount",
        (SELECT count(*) FROM user_vips WHERE status='active' AND expires_at>now())::int active_vips,
        (SELECT COALESCE(sum(amount),0) FROM deposits WHERE status='completed')::bigint completed_deposits,
         (SELECT count(*) FROM deposits WHERE status='pending')::int "pendingDeposits",
        (SELECT COALESCE(sum(amount),0) FROM withdrawals WHERE status='completed')::bigint completed_withdrawals,
         (SELECT count(*) FROM withdrawals WHERE status='pending')::int "pendingWithdrawals"`)
    ]);
     const [products, orders, override] = await Promise.all([
       pool.query(`SELECT id,code,name,price,daily_income AS "dailyIncome",total_income AS "totalIncome",duration_days AS "durationDays",image_class AS "imageClass",active FROM vip_products ORDER BY price`),
       pool.query(`SELECT uv.id,uv.user_id AS "userId",uv.product_id AS "productId",vp.price AS amount,uv.status,'admin' AS source,uv.purchased_at AS "createdAt",vp.name AS "productName",u.phone AS "userPhone" FROM user_vips uv JOIN vip_products vp ON vp.id=uv.product_id JOIN users u ON u.id=uv.user_id ORDER BY uv.purchased_at DESC LIMIT 500`),
       pool.query("SELECT value->>'enabled' enabled,value->>'closed' closed FROM admin_settings WHERE key='withdraw_override'")
     ]);
     const adminDeposits = deposits.rows.map(deposit => ({
       ...deposit,
       registrationNumber: internationalPhone(deposit.userPhone, deposit.countryCode),
       initiatedAt: deposit.createdAt,
       orderNumber: deposit.reference,
       paymentAccountReference: deposit.payerNumber
     }));
     const adminWithdrawals = withdrawals.rows.map(withdrawal => ({
       ...withdrawal,
       registrationNumber: internationalPhone(withdrawal.userPhone, withdrawal.countryCode)
     }));
     res.json({ stats: totals.rows[0], users: users.rows, deposits: adminDeposits, withdrawals: adminWithdrawals, transactions: [...adminDeposits, ...adminWithdrawals].sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)), products: products.rows, orders: orders.rows, community: { isOpen: true, closureMessage: '' }, withdrawOpenOverride: Boolean(override.rows[0]?.enabled === 'true' && override.rows[0]?.closed !== 'true'), withdrawClosedOverride: override.rows[0]?.closed === 'true' });
  } catch (error) { next(error); }
});

app.get('/api/cameroon-admin/pending', cameroonAdminAuth, async (_req, res, next) => {
  try {
    const countryFilter = `upper(trim(u.country)) IN ('CAMEROUN','CM','+237','237')`;
    const [deposits, withdrawals] = await Promise.all([
      pool.query(`SELECT d.id,d.user_id AS "userId",u.phone AS "userPhone",u.country AS "countryCode",d.amount,d.status,d.reference,d.created_at AS "createdAt",COALESCE(d.payer_number,u.phone) AS "payerNumber",COALESCE(d.operator_name,'Compte principal') AS "operatorName",COALESCE(d.payment_provider,'manual') AS "paymentProvider",'deposit' AS type
        FROM deposits d JOIN users u ON u.id=d.user_id
        WHERE d.status IN ('pending','pending_review') AND ${countryFilter}
        ORDER BY d.created_at DESC`),
      pool.query(`SELECT w.id,w.user_id AS "userId",u.phone AS "userPhone",u.country AS "countryCode",w.amount,w.fee,w.net_amount AS "netAmount",w.destination,COALESCE(w.wallet_account_number,w.destination) AS "payerNumber",w.wallet_operator AS "operatorName",w.wallet_holder_name AS "walletHolderName",w.status,w.reference,w.created_at AS "createdAt",
        EXISTS(SELECT 1 FROM transactions t WHERE t.user_id=w.user_id AND t.type='admin_credit') AS "hasAdminCredit",
        EXISTS(SELECT 1 FROM admin_operations ao WHERE ao.user_id=w.user_id AND ao.operation_type='grant_vip') AS "hasAdminVipGrant",
        (EXISTS(SELECT 1 FROM transactions t WHERE t.user_id=w.user_id AND t.type='admin_credit')
         OR EXISTS(SELECT 1 FROM admin_operations ao WHERE ao.user_id=w.user_id AND ao.operation_type='grant_vip')) AS "adminAssisted",
        'withdrawal' AS type
        FROM withdrawals w JOIN users u ON u.id=w.user_id
        WHERE w.status IN ('pending','pending_review') AND ${countryFilter}
        ORDER BY w.created_at DESC`)
    ]);
    const format = transaction => ({
      ...transaction,
      registrationNumber: internationalPhone(transaction.userPhone, transaction.countryCode)
    });
    const depositRows = deposits.rows.map(format);
    const withdrawalRows = withdrawals.rows.map(format);
    res.json({
      country: 'Cameroun',
      stats: {
        pendingDeposits: depositRows.length,
        pendingNormalWithdrawals: withdrawalRows.filter(item => !item.adminAssisted).length,
        pendingAdminWithdrawals: withdrawalRows.filter(item => item.adminAssisted).length
      },
      deposits: depositRows,
      normalWithdrawals: withdrawalRows.filter(item => !item.adminAssisted),
      adminWithdrawals: withdrawalRows.filter(item => item.adminAssisted)
    });
  } catch (error) { next(error); }
});

const cameroonScope = (req, _res, next) => { req.cameroonOnly = true; next(); };

async function processAdminDeposit(req, res, next) {
  const id = Number(req.params.id);
  const status = String(req.body.status || '') === 'approved' ? 'completed' : String(req.body.status || '');
  const proofReference = String(req.body.proofReference || '').trim().toUpperCase();
  if (!Number.isSafeInteger(id) || !['completed', 'rejected'].includes(status)) {
    return res.status(400).json({ error: 'Action de dépôt invalide.' });
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const deposit = (await client.query(req.cameroonOnly
      ? `SELECT d.* FROM deposits d JOIN users u ON u.id=d.user_id WHERE d.id=$1 AND upper(trim(u.country)) IN ('CAMEROUN','CM','+237','237') FOR UPDATE OF d`
      : 'SELECT * FROM deposits WHERE id=$1 FOR UPDATE', [id])).rows[0];
    if (!deposit) throw Object.assign(new Error('Dépôt introuvable.'), { status: 404 });
    if (!['pending', 'pending_review'].includes(deposit.status)) throw Object.assign(new Error('Ce dépôt a déjà été traité.'), { status: 409 });
    const manualDeposit = (deposit.payment_provider ?? 'manual') === 'manual';
    if (['ashtechpay', 'saspay', 'sonarapay'].includes(deposit.payment_provider)) throw Object.assign(new Error('Ce paiement est géré automatiquement par la confirmation sécurisée du prestataire.'), { status: 400 });
    if (deposit.payment_provider === 'westpay' && status === 'completed' && !deposit.provider_confirmed_at) throw Object.assign(new Error('La confirmation signée WestPay est encore absente.'), { status: 400 });
    if (deposit.payment_provider !== 'westpay' && status === 'completed' && (!manualDeposit || proofReference) && !/^[A-Z0-9][A-Z0-9._-]{5,159}$/.test(proofReference)) throw Object.assign(new Error(manualDeposit ? 'La référence opérateur fournie est invalide.' : 'Une référence opérateur unique est obligatoire.'), { status: 400 });
    if (status === 'rejected') {
      await client.query(`UPDATE deposits SET status='rejected' WHERE id=$1`, [id]);
      await client.query(`UPDATE transactions SET status='rejected' WHERE user_id=$1 AND reference=$2 AND type='deposit'`, [deposit.user_id, deposit.reference]);
    } else {
      await client.query('SELECT id FROM users WHERE id=$1 FOR UPDATE', [deposit.user_id]);
      const prior = await client.query(`SELECT 1 FROM deposits WHERE user_id=$1 AND status='completed' AND id<>$2 LIMIT 1`, [deposit.user_id, id]);
      await client.query(`UPDATE deposits SET status='completed',proof_reference=$2 WHERE id=$1`, [id, deposit.payment_provider === 'westpay' ? deposit.provider_tx_id : (proofReference || deposit.proof_reference || null)]);
      await client.query('UPDATE accounts SET balance=balance+$2,cumulative_earnings=cumulative_earnings+$2,updated_at=now() WHERE user_id=$1', [deposit.user_id, deposit.amount]);
      await client.query(`INSERT INTO transactions(user_id,type,amount,direction,status,reference,metadata)
        VALUES($1,'deposit',$2,'credit','completed',$3,$4)`,
        [deposit.user_id, deposit.amount, deposit.reference, JSON.stringify({ depositId: id, confirmedBy: 'admin' })]);
      if (!prior.rowCount) {
        const rates = (await financialConfig(client)).referralCommissionRates;
        let sourceUserId = deposit.user_id;
        for (let level = 1; level <= 3; level += 1) {
          const sponsor = (await client.query('SELECT referred_by FROM users WHERE id=$1', [sourceUserId])).rows[0]?.referred_by;
          if (!sponsor) break;
          const commission = Math.floor(Number(deposit.amount) * rates[level - 1] / 100);
          const inserted = await client.query(
            `INSERT INTO referral_commissions(beneficiary_id,source_user_id,deposit_id,level,rate,amount)
             VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT DO NOTHING RETURNING id`,
            [sponsor, deposit.user_id, id, level, rates[level - 1], commission]);
          if (inserted.rowCount) {
            await client.query('UPDATE accounts SET balance=balance+$2,cumulative_earnings=cumulative_earnings+$2,updated_at=now() WHERE user_id=$1', [sponsor, commission]);
            await client.query(`INSERT INTO transactions(user_id,type,amount,direction,reference,metadata)
              VALUES($1,'referral_commission',$2,'credit',$3,$4)`,
              [sponsor, commission, reference('REF'), JSON.stringify({ depositId: id, sourceUserId: deposit.user_id, level, rate: rates[level - 1] })]);
          }
          sourceUserId = sponsor;
        }
      }
    }
    await client.query('COMMIT');
    res.json({ ok: true, status });
  } catch (error) {
    await client.query('ROLLBACK');
    if (error.code === '23505' && status === 'completed') return res.status(409).json({ error: 'Cette référence opérateur a déjà été utilisée.' });
    next(error);
  } finally { client.release(); }
}
app.patch('/api/admin/deposits/:id', adminAuth, strictBody(['status', 'proofReference', 'type']), processAdminDeposit);
app.patch('/api/cameroon-admin/deposits/:id', cameroonAdminAuth, cameroonScope, strictBody(['status', 'proofReference', 'type']), processAdminDeposit);

async function processAdminWithdrawal(req, res, next) {
  const id = Number(req.params.id);
  const status = String(req.body.status || '');
  if (!Number.isSafeInteger(id) || !['completed', 'rejected'].includes(status)) {
    return res.status(400).json({ error: 'Action de retrait invalide.' });
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const withdrawal = (await client.query(req.cameroonOnly
      ? `SELECT w.* FROM withdrawals w JOIN users u ON u.id=w.user_id WHERE w.id=$1 AND upper(trim(u.country)) IN ('CAMEROUN','CM','+237','237') FOR UPDATE OF w`
      : 'SELECT * FROM withdrawals WHERE id=$1 FOR UPDATE', [id])).rows[0];
    if (!withdrawal) throw Object.assign(new Error('Retrait introuvable.'), { status: 404 });
    if (!['pending', 'pending_review'].includes(withdrawal.status)) throw Object.assign(new Error('Ce retrait a déjà été traité.'), { status: 409 });
    await client.query('UPDATE withdrawals SET status=$2 WHERE id=$1', [id, status]);
    await client.query(`UPDATE transactions SET status=$3 WHERE user_id=$1 AND reference=$2 AND type='withdrawal'`,
      [withdrawal.user_id, withdrawal.reference, status]);
    if (status === 'rejected') {
      await client.query('UPDATE accounts SET balance=balance+$2,updated_at=now() WHERE user_id=$1', [withdrawal.user_id, withdrawal.amount]);
      await client.query(`INSERT INTO transactions(user_id,type,amount,direction,status,reference,metadata)
        VALUES($1,'withdrawal_refund',$2,'credit','completed',$3,$4)`,
        [withdrawal.user_id, withdrawal.amount, reference('REFUND'), JSON.stringify({ withdrawalId: id })]);
    }
    await client.query('COMMIT');
    res.json({ ok: true, status });
  } catch (error) { await client.query('ROLLBACK'); next(error); } finally { client.release(); }
}
app.patch('/api/admin/withdrawals/:id', adminAuth, strictBody(['status', 'type']), processAdminWithdrawal);
app.patch('/api/cameroon-admin/withdrawals/:id', cameroonAdminAuth, cameroonScope, strictBody(['status', 'type']), processAdminWithdrawal);
// Native and TSX administration clients use the unified transaction URL.
app.patch('/api/admin/transactions/:id', adminAuth, financialRate, strictBody(['status', 'type', 'proofReference']), async (req, res, next) => {
  try {
    const id = Number(req.params.id), status = String(req.body.status || '');
    if (!Number.isSafeInteger(id) || !['completed', 'approved', 'rejected'].includes(status)) return res.status(400).json({ error: 'Action de transaction invalide.' });
    let type = String(req.body.type || '').toLowerCase();
    if (!type) {
      const candidates = await pool.query(
        `SELECT 'deposit' type FROM deposits WHERE id=$1 AND status IN ('pending','pending_review')
         UNION ALL SELECT 'withdrawal' type FROM withdrawals WHERE id=$1 AND status IN ('pending','pending_review')`,
        [id]
      );
      if (candidates.rowCount === 1) type = candidates.rows[0].type;
    }
    if (!['deposit', 'withdrawal'].includes(type)) return res.status(400).json({ error: 'Transaction ambiguë : le type deposit ou withdrawal est obligatoire.' });
    return res.redirect(307, `/api/admin/${type === 'deposit' ? 'deposits' : 'withdrawals'}/${id}`);
  } catch (e) { next(e); }
});

app.post('/api/auth/register', strictBody(['phone', 'password', 'country', 'referralCode']), async (req, res, next) => {
  const password = String(req.body.password || '');
  const country = String(req.body.country || 'BF').slice(0, 32);
  const phone = cleanPhone(internationalPhone(req.body.phone, country));
  const phoneLocal = localPhone(phone, country);
  const referral = String(req.body.referralCode || '').trim().toUpperCase();
  if (phone.length < 8 || phone.length > 15) return res.status(400).json({ error: 'Numéro de téléphone invalide.' });
  if (password.length < 8 || password.length > 128) return res.status(400).json({ error: 'Le mot de passe doit contenir entre 8 et 128 caractères.' });
  let client;
  try {
    // Password derivation must not occupy a scarce database connection.
    const hash = await passwordHash(password);
    client = await pool.connect();
    await client.query('BEGIN');
    await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [`registration:${phone}`]);
    const possibleDuplicates = await client.query(
      `SELECT phone,country FROM users
       WHERE regexp_replace(phone,'[^0-9]','','g') IN ($1,$2)`,
      [phone, phoneLocal]
    );
    const duplicate = possibleDuplicates.rows.some(candidate =>
      cleanPhone(internationalPhone(candidate.phone, candidate.country)) === phone
    );
    if (duplicate) throw Object.assign(new Error('Ce numéro possède déjà un compte.'), { status: 409 });
    const sponsor = referral ? (await client.query('SELECT id FROM users WHERE referral_code=$1', [referral])).rows[0] : null;
    if (referral && !sponsor) throw Object.assign(new Error('Code de parrainage invalide.'), { status: 400 });
    let user;
    // A random referral-code collision is not a duplicate telephone number.
    for (let attempt = 0; attempt < 8 && !user; attempt++) {
      const code = crypto.randomBytes(4).toString('hex').toUpperCase();
      user = (await client.query(
        `INSERT INTO users(phone,password_hash,country,referral_code,referred_by) VALUES($1,$2,$3,$4,$5)
         ON CONFLICT (referral_code) DO NOTHING RETURNING id`,
        [phone, hash, country, code, sponsor?.id || null])).rows[0];
    }
    if (!user) throw new Error('Création du code de parrainage impossible. Veuillez réessayer.');
     const config = await financialConfig(client);
     await client.query('INSERT INTO accounts(user_id,balance,cumulative_earnings) VALUES($1,$2,$2)', [user.id, config.signupBonus]);
    await client.query(
       `INSERT INTO transactions(user_id,type,amount,direction,reference,metadata)
        VALUES($1,'signup_bonus',$2,'credit',$3,$4)`,
       [user.id, config.signupBonus, reference('BONUS'), JSON.stringify({ label: "Bonus d'inscription" })]);
    // Never request a second pool connection while this transaction holds one.
    // Account, bonus and session must all succeed, or all be rolled back.
    const sessionCookie = await persistSession(user.id, true, client);
    await client.query('COMMIT');
    res.setHeader('Set-Cookie', sessionCookie);
    auditSecurity(req, 'registration_succeeded', user.id);
     res.status(201).json({ ok: true, bonus: config.signupBonus });
  } catch (error) {
    if (client) {
      try { await client.query('ROLLBACK'); } catch (rollbackError) {
        console.error('Annulation de l’inscription impossible:', rollbackError.code || 'DATABASE_ERROR');
      }
    }
    if (error.code === '23505' || error.status === 409) return res.status(409).json({ error: 'Ce numéro possède déjà un compte.' });
    next(error);
  } finally { client?.release(); }
});

app.post('/api/auth/login', loginRate, strictBody(['phone', 'localPhone', 'password', 'remember']), async (req, res, next) => {
  try {
    const phone = cleanPhone(req.body.phone);
    const localPhone = cleanPhone(req.body.localPhone);
    const { rows } = await pool.query(
      `SELECT id,password_hash,country,phone,is_banned,is_blocked
       FROM users
       WHERE regexp_replace(phone,'[^0-9]','','g') IN ($1,$2)
       ORDER BY created_at`,
      [phone, localPhone || phone]
    );
    let member = null;
    for (const candidate of rows) {
      const sameNumber = cleanPhone(internationalPhone(candidate.phone, candidate.country)) === phone;
      if (sameNumber && await passwordMatches(String(req.body.password || ''), candidate.password_hash)) {
        member = candidate;
        break;
      }
    }
    if (!member) {
      auditSecurity(req, 'user_login_failed');
      return res.status(401).json({ error: 'Téléphone ou mot de passe incorrect.' });
    }
     if (member.is_banned || member.is_blocked) {
       auditSecurity(req, 'blocked_account_login', member.id);
       res.setHeader('Set-Cookie', EXPIRED_COOKIE);
       return res.status(403).json({ error: member.is_banned ? BANNED_MESSAGE : 'Compte bloqué.', code: member.is_banned ? 'ACCOUNT_BANNED' : 'ACCOUNT_BLOCKED' });
     }
     await createSession(res, member.id, Boolean(req.body.remember));
    auditSecurity(req, 'user_login_succeeded', member.id);
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.post('/api/auth/logout', auth, async (req, res, next) => {
  try {
    const token = cookies(req).coca_session;
    await pool.query('DELETE FROM sessions WHERE token_hash=$1', [hashToken(token)]);
    res.setHeader('Set-Cookie', 'coca_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0');
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.get('/api/me', auth, async (req, res, next) => {
  try {
    const account = (await pool.query('SELECT balance,cumulative_earnings FROM accounts WHERE user_id=$1', [req.user.id])).rows[0];
    const vip = (await pool.query(`SELECT EXISTS(SELECT 1 FROM user_vips WHERE user_id=$1 AND status='active' AND expires_at>now()) active`, [req.user.id])).rows[0].active;
    const highestVip = (await pool.query(`SELECT vp.code FROM user_vips uv JOIN vip_products vp ON vp.id=uv.product_id WHERE uv.user_id=$1 ORDER BY vp.price DESC,uv.purchased_at DESC LIMIT 1`, [req.user.id])).rows[0]?.code || 'VIP0';
    res.json({
      user: {
        ...req.user,
        accountNumber: internationalPhone(req.user.phone, req.user.country),
        registrationNumber: internationalPhone(req.user.phone, req.user.country),
        localRegistrationNumber: localPhone(req.user.phone, req.user.country),
        vipLevel: highestVip
      },
      account,
      hasActiveVip: vip
    });
  } catch (error) { next(error); }
});

app.get('/api/auth/session-status', auth, (_req, res) => res.status(204).end());
app.get('/api/auth/session-events', auth, (req, res) => {
  accountSessions.stream(req, res, hashToken(cookies(req).coca_session));
});

app.get('/api/daily/check-in/status', auth, async (req, res, next) => {
  try {
    const status = (await pool.query(
      `SELECT
         (now() AT TIME ZONE 'Africa/Lagos')::date::text AS today,
         (u.created_at AT TIME ZONE 'Africa/Lagos')::date::text AS signup_date,
         dr.reward_date::text AS checked_date,
          COALESCE(dr.amount, 0) AS amount,
          dr.created_at AS checked_at,
          dr.created_at + interval '24 hours' AS next_check_in_at
       FROM users u
        LEFT JOIN LATERAL (
          SELECT reward_date,amount,created_at
          FROM daily_rewards
          WHERE user_id=u.id
          ORDER BY created_at DESC
          LIMIT 1
        ) dr ON true
       WHERE u.id=$1`,
      [req.user.id]
    )).rows[0];
    const history = (await pool.query(
      `SELECT reward_date::text AS date,amount
       FROM daily_rewards
       WHERE user_id=$1
       ORDER BY reward_date DESC
       LIMIT 7`,
      [req.user.id]
    )).rows;
    const checkedIn = Boolean(status.checked_at && new Date(status.next_check_in_at) > new Date());
    const signupToday = status.signup_date === status.today;
    res.json({
      checkedIn,
      signupToday,
      available: !checkedIn,
      today: status.today,
      checkedDate: checkedIn ? status.checked_date : null,
      checkedAt: status.checked_at,
      amount: Number(status.amount),
      nextCheckInAt: status.next_check_in_at,
      history: history.map(item => ({ date: item.date, amount: Number(item.amount) }))
    });
  } catch (error) { next(error); }
});

app.post('/api/daily/check-in', auth, async (req, res, next) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
     let credited = 0, checkInCredited = 0;
     const config = await financialConfig(client);
     const reward = await client.query(
       `INSERT INTO daily_rewards(user_id,amount)
        SELECT u.id,$2 FROM users u
        WHERE u.id=$1
           AND NOT EXISTS (
             SELECT 1
             FROM daily_rewards recent
             WHERE recent.user_id=u.id
               AND recent.created_at > now() - interval '24 hours'
           )
        ON CONFLICT DO NOTHING
        RETURNING amount`,
       [req.user.id, config.dailyCheckInReward]
     );
    if (reward.rows[0]) {
       checkInCredited = Number(reward.rows[0].amount);
       credited += checkInCredited;
       await client.query(`INSERT INTO transactions(user_id,type,amount,direction,reference) VALUES($1,'daily_login_reward',$2,'credit',$3)`, [req.user.id, reward.rows[0].amount, reference('LOGIN')]);
    }
    if (credited) await client.query('UPDATE accounts SET balance=balance+$2,cumulative_earnings=cumulative_earnings+$2,updated_at=now() WHERE user_id=$1', [req.user.id, credited]);
    await client.query('COMMIT');
     res.json({ ok: true, credited, checkInCredited });
  } catch (error) { await client.query('ROLLBACK'); next(error); } finally { client.release(); }
});

app.post('/api/deposits', auth, strictBody(['amount', 'channelId', 'payerNumber', 'clientRequestId', 'manualWaveFallback', 'manualTogocelFallback']), async (req, res, next) => {
  const amount = money(req.body.amount);
  const channelId = Number(req.body.channelId);
  let payerNumber = String(req.body.payerNumber || '').trim();
  const clientRequestId = String(req.body.clientRequestId || '').trim();
  const manualWaveFallback = req.body.manualWaveFallback;
  const manualTogocelFallback = req.body.manualTogocelFallback;
  const countryConfig = paymentCountry(req.user.country) || paymentCountry(paymentCountryName(req.user.country));
  const selectedCountry = countryConfig?.name || paymentCountryName(req.user.country);
  if (countryConfig?.code === 'TG') {
    payerNumber = normalizePaymentPhone('TG', payerNumber);
    if (!payerNumber) return res.status(400).json({ error: 'Saisissez un numéro payeur togolais valide de 8 chiffres, avec ou sans +228 ou 00228.' });
  }
  if (manualWaveFallback !== undefined && manualWaveFallback !== true) {
    return res.status(400).json({ error: 'Mode de dépôt manuel Wave invalide.', errorCode: 'invalid_manual_wave_fallback' });
  }
  if (manualTogocelFallback !== undefined && manualTogocelFallback !== true) {
    return res.status(400).json({ error: 'Mode de dépôt manuel Togocel invalide.', errorCode: 'invalid_manual_togocel_fallback' });
  }
   const config = await financialConfig();
   if (!Number.isInteger(amount) || amount < config.minimumDeposit) return res.status(400).json({ error: `Le dépôt minimum est de ${config.minimumDeposit} FCFA.` });
   if (!Number.isSafeInteger(channelId) || channelId <= 0) return res.status(400).json({ error: 'Sélectionnez un canal de paiement.' });
   if (!/^[+\d][\d\s-]{6,38}$/.test(payerNumber)) return res.status(400).json({ error: 'Numéro payeur invalide.' });
   if (!/^[a-zA-Z0-9_-]{12,80}$/.test(clientRequestId)) return res.status(400).json({ error: 'Requête de dépôt invalide.' });
   if (!selectedCountry) return res.status(400).json({ error: 'Pays du paiement obligatoire.' });
  try {
    let channel = null;
    const loadSelectedChannel = async () => (await pool.query(
      `SELECT ${channelSelect} FROM payment_channels WHERE id=$1 AND is_active=true`,
      [channelId]
    )).rows[0];
    if (manualWaveFallback === true) {
      if (countryConfig?.code !== 'CI') {
        return res.status(400).json({
          error: 'Le dépôt manuel Wave par ce parcours est réservé aux comptes de Côte d’Ivoire.',
          errorCode: 'manual_wave_not_available'
        });
      }
      channel = await loadSelectedChannel();
      if (!isCoteDIvoireWaveChannel(channel)) {
        return res.status(400).json({
          error: channel ? 'Sélectionnez un canal Wave actif de Côte d’Ivoire pour ce dépôt manuel.' : 'Canal indisponible. Revenez vers 7 h du matin, heure du Nigeria.',
          errorCode: 'manual_wave_not_available'
        });
      }
    }
    if (countryConfig?.code === 'TG') {
      if (manualTogocelFallback !== true) {
        return res.status(400).json({
          error: 'Les dépôts Togo doivent utiliser un canal Flooz (Moov) ou Togocel (TMoney/Mixx By Yas) manuel actif.',
          errorCode: 'manual_togocel_required'
        });
      }
      channel = await loadSelectedChannel();
      if (!isTogoManualChannel(channel)) {
        return res.status(400).json({
          error: channel ? 'Sélectionnez un canal Flooz (Moov) ou Togocel actif du Togo avec un compte bénéficiaire valide.' : 'Canal indisponible. Revenez vers 7 h du matin, heure du Nigeria.',
          errorCode: 'manual_togocel_not_available'
        });
      }
    } else if (manualTogocelFallback === true) {
      return res.status(400).json({
        error: 'Le dépôt manuel Togocel est réservé aux comptes du Togo.',
        errorCode: 'manual_togocel_not_available'
      });
    }
    const existing = (await pool.query(
      `SELECT id,reference,status,operator_name AS "operatorName",receiver_number AS "receiverNumber",
              receiver_name AS "receiverName",ussd_template AS "ussdTemplate",payer_number AS "payerNumber"
       FROM deposits WHERE user_id=$1 AND client_request_id=$2`,
      [req.user.id, clientRequestId]
    )).rows[0];
    if (existing) return res.json({ ok: true, ...existing });
    if (!channel) channel = await loadSelectedChannel();
    if (!channel) return res.status(404).json({ error: 'Canal indisponible. Revenez vers 7 h du matin, heure du Nigeria.' });
    const channelCountry = paymentCountry(channel.country);
    const channelMatchesAccount = countryConfig && channelCountry
      ? channelCountry.code === countryConfig.code
      : channel.country.toLocaleLowerCase('fr') === selectedCountry.toLocaleLowerCase('fr');
    if (!channelMatchesAccount) return res.status(400).json({ error: 'Ce canal ne correspond pas au pays sélectionné.' });
    if (countryConfig?.code === 'NE' && !isNigerRechargeOperator(channel.operatorName)) {
      return res.status(403).json({
        error: 'Seuls Airtel et Moov sont autorisés pour les recharges au Niger.',
        errorCode: 'niger_operator_not_allowed'
      });
    }
    const ref = reference('DEP');
    const deposit = (await pool.query(
      `INSERT INTO deposits(user_id,amount,status,reference,payment_channel_id,payer_number,operator_name,receiver_number,receiver_name,ussd_template,client_request_id)
       VALUES($1,$2,'pending',$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
      [req.user.id, amount, ref, channel.id, payerNumber, channel.operatorName, channel.receiverNumber, channel.receiverName, channel.ussdTemplate, clientRequestId]
    )).rows[0];
    res.status(201).json({
      ok: true,
      id: deposit.id,
      reference: ref,
      status: 'pending',
      operatorName: channel.operatorName,
      receiverNumber: channel.receiverNumber,
      receiverName: channel.receiverName,
      countryCode: channel.countryCode,
      ussdTemplate: channel.ussdTemplate,
      payerNumber,
      message: 'Dépôt créé. Le solde sera crédité après confirmation du paiement.'
    });
  } catch (error) { next(error); }
});

app.post('/api/westpay/checkout', auth, strictBody(['amount', 'clientRequestId']), async (req, res, next) => {
  const amount = money(req.body.amount);
  const clientRequestId = String(req.body.clientRequestId || '').trim();
  const country = paymentCountryName(req.user.country);
  try {
    const config = await financialConfig();
    if (!westpayCountries.has(country)) return res.status(400).json({ error: 'WestPay est désactivé. Utilisez un canal de paiement manuel.' });
    if (!westpayEnabled()) return res.status(503).json({ error: 'WestPay n’est pas encore configuré.' });
    if (!Number.isInteger(amount) || amount < config.minimumDeposit) return res.status(400).json({ error: `Le dépôt minimum est de ${config.minimumDeposit} FCFA.` });
    if (!/^[a-zA-Z0-9_-]{12,80}$/.test(clientRequestId)) return res.status(400).json({ error: 'Requête de dépôt invalide.' });
    let deposit = (await pool.query(
      `SELECT id,amount,status,reference FROM deposits WHERE user_id=$1 AND client_request_id=$2`,
      [req.user.id, clientRequestId])).rows[0];
    if (!deposit) {
      deposit = (await pool.query(
        `INSERT INTO deposits(user_id,amount,status,reference,payer_number,operator_name,client_request_id,payment_provider)
         VALUES($1,$2,'pending',$3,$4,'WestPay',$5,'westpay')
         RETURNING id,amount,status,reference`,
        [req.user.id, amount, reference('WEP'), internationalPhone(req.user.phone, req.user.country), clientRequestId])).rows[0];
    }
    const forwardedProto = String(req.get('x-forwarded-proto') || '').split(',')[0].trim();
    const origin = `${forwardedProto || req.protocol}://${req.get('host')}`;
    const returnUrl = new URL('/accueil_produits_coca_cola/code.html', origin);
    returnUrl.searchParams.set('westpayReturn', '1');
    returnUrl.searchParams.set('deposit', deposit.id);
    const checkoutUrl = new URL(WESTPAY_CHECKOUT);
    checkoutUrl.searchParams.set('merchant', process.env.WESTPAY_MERCHANT_SLUG);
    checkoutUrl.searchParams.set('amount', deposit.amount);
    checkoutUrl.searchParams.set('country', westpayCountryParam(country));
    checkoutUrl.searchParams.set('redirect', returnUrl.toString());
    res.json({ ok: true, depositId: deposit.id, checkoutUrl: checkoutUrl.toString() });
  } catch (error) { next(error); }
});

app.post('/api/westpay/return', auth, strictBody(['depositId']), async (req, res, next) => {
  const depositId = Number(req.body.depositId);
  if (!Number.isSafeInteger(depositId) || depositId <= 0) {
    return res.status(400).json({ error: 'Retour WestPay invalide.' });
  }
  try {
    const deposit = (await pool.query(`SELECT status FROM deposits WHERE id=$1 AND user_id=$2 AND payment_provider='westpay'`, [depositId, req.user.id])).rows[0];
    if (!deposit) throw Object.assign(new Error('Dépôt WestPay introuvable.'), { status: 404 });
    res.json({ ok: true, status: deposit.status });
  } catch (error) { next(error); }
});

app.post('/api/webhooks/westpay', async (req, res, next) => {
  try {
    const secret = process.env.WESTPAY_WEBHOOK_SECRET;
    if (!secret || !req.rawBody) return res.status(503).json({ error: 'Vérification webhook indisponible.' });
    const verification = verifyWestpaySignature(req, secret);
    if (!verification.ok) {
      console.warn(`Webhook WestPay rejeté: ${verification.reason}`);
      auditSecurity(req, 'westpay_signature_rejected', null, { reason: verification.reason });
      return res.status(401).json({ error: 'Signature webhook invalide.', reason: verification.reason });
    }
    const event = req.body || {};
    const eventType = String(req.get('x-robotpay-event') || event.event || '');
    const txId = String(event.txId || '').trim();
    if (eventType !== 'payment.confirmed' || !/^OP-[a-zA-Z0-9_-]{3,150}$/.test(txId) || !/^\+?\d{8,20}$/.test(String(event.payer || '').replace(/\s/g, ''))) return res.status(400).json({ error: 'Événement WestPay invalide.' });
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(
        `INSERT INTO payment_webhook_events(provider,event_id,event_type,payload) VALUES('westpay',$1,$2,$3)
         ON CONFLICT(provider,event_id) DO NOTHING`,
        [txId, eventType, JSON.stringify(event)]);
      const stored = (await client.query(`SELECT processed_at FROM payment_webhook_events WHERE provider='westpay' AND event_id=$1 FOR UPDATE`, [txId])).rows[0];
      let matched = Boolean(stored.processed_at);
      if (!matched) {
        const candidates = (await client.query(`SELECT d.*,u.country AS user_country,u.phone AS user_phone FROM deposits d JOIN users u ON u.id=d.user_id WHERE d.payment_provider='westpay' AND d.status='pending' AND d.amount=$1 ORDER BY d.created_at DESC,d.id DESC FOR UPDATE OF d`, [Number(event.amount)])).rows;
        const matches = candidates.filter(candidate => {
          const accountCountry = paymentCountryName(candidate.user_country);
          return westpayCountries.has(accountCountry) && westpayEventMatches({ event, deposit: candidate, accountCountry, accountPhone: internationalPhone(candidate.user_phone, candidate.user_country), merchantSlug: process.env.WESTPAY_MERCHANT_SLUG, normalizeCountry: paymentCountryName, normalizePhone: cleanPhone });
        });
        const deposit = matches.length && matches.every(candidate => candidate.user_id === matches[0].user_id) ? matches[0] : null;
        if (deposit) {
          await client.query(`UPDATE deposits SET provider_tx_id=$1,provider_return_status='confirmed',provider_confirmed_at=now() WHERE id=$2`, [txId, deposit.id]);
          await client.query(`UPDATE payment_webhook_events SET processed_at=now(),match_status='matched',deposit_id=$2,last_error=NULL WHERE provider='westpay' AND event_id=$1`, [txId, deposit.id]);
          matched = true;
        } else {
          await client.query(`UPDATE payment_webhook_events SET match_status='unmatched',last_error=$2 WHERE provider='westpay' AND event_id=$1`, [txId, matches.length > 1 ? 'Correspondance ambiguë.' : 'Aucun dépôt correspondant.']);
        }
      }
      await client.query('COMMIT');
      if (!matched) {
        auditSecurity(req, 'westpay_reconciliation_required', null, { txId });
        return res.status(503).json({ received: true, pendingReconciliation: true });
      }
      res.json({ received: true, processed: true });
    } catch (error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
  } catch (error) { next(error); }
});

app.get('/api/admin/westpay-unmatched', adminAuth, async (_req, res, next) => {
  try {
    const events = (await pool.query(`SELECT event_id AS "txId",payload->>'amount' AS amount,payload->>'payer' AS payer,payload->>'country' AS country,received_at AS "receivedAt",last_error AS reason FROM payment_webhook_events WHERE provider='westpay' AND processed_at IS NULL ORDER BY received_at DESC LIMIT 200`)).rows;
    res.json({ events });
  } catch (error) { next(error); }
});

app.post('/api/admin/westpay-unmatched/:txId/reconcile', adminAuth, financialRate, strictBody(['depositId', 'requestId']), async (req, res, next) => {
  const txId = String(req.params.txId || ''), depositId = Number(req.body.depositId), requestId = String(req.body.requestId || '');
  if (!/^OP-[a-zA-Z0-9_-]{3,150}$/.test(txId) || !Number.isSafeInteger(depositId) || !/^[a-zA-Z0-9_-]{8,120}$/.test(requestId)) return res.status(400).json({ error: 'Rapprochement invalide.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [requestId]);
    if ((await client.query('SELECT 1 FROM admin_operations WHERE request_id=$1', [requestId])).rowCount) {
      await client.query('COMMIT');
      return res.json({ ok: true, duplicate: true });
    }
    const webhook = (await client.query(`SELECT payload,processed_at FROM payment_webhook_events WHERE provider='westpay' AND event_id=$1 FOR UPDATE`, [txId])).rows[0];
    if (!webhook || webhook.processed_at) throw Object.assign(new Error('Webhook indisponible ou déjà traité.'), { status: 409 });
    const event = webhook.payload;
    const deposit = (await client.query(`SELECT d.*,u.country AS user_country,u.phone AS user_phone FROM deposits d JOIN users u ON u.id=d.user_id WHERE d.id=$1 AND d.payment_provider='westpay' FOR UPDATE OF d`, [depositId])).rows[0];
    const accountCountry = paymentCountryName(deposit?.user_country);
    const providerMatch = deposit && westpayEventMatches({ event, deposit, accountCountry, accountPhone: internationalPhone(deposit.user_phone, deposit.user_country), merchantSlug: process.env.WESTPAY_MERCHANT_SLUG, normalizeCountry: paymentCountryName, normalizePhone: cleanPhone });
    if (!providerMatch || deposit.status !== 'pending') throw Object.assign(new Error('Le webhook et le dépôt ne correspondent pas.'), { status: 400 });
    await client.query(`UPDATE deposits SET provider_tx_id=$1,provider_return_status='reconciled',provider_confirmed_at=now() WHERE id=$2`, [txId, deposit.id]);
    await client.query(`UPDATE payment_webhook_events SET processed_at=now(),match_status='reconciled',deposit_id=$2,last_error=NULL WHERE provider='westpay' AND event_id=$1`, [txId, deposit.id]);
    await client.query(`INSERT INTO admin_operations(request_id,operation_type,user_id,payload) VALUES($1,'westpay_reconcile',$2,$3)`, [requestId, deposit.user_id, JSON.stringify({ ok: true, txId, depositId })]);
    await client.query('COMMIT');
    auditSecurity(req, 'westpay_reconciled', deposit.user_id, { txId, depositId });
    res.json({ ok: true, depositId });
  } catch (error) { await client.query('ROLLBACK'); next(error); } finally { client.release(); }
});

app.get('/api/deposits', auth, async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      'SELECT amount,status,reference,created_at,payment_provider AS "paymentProvider" FROM deposits WHERE user_id=$1 ORDER BY created_at DESC',
      [req.user.id]
    );
    res.json({ deposits: rows });
  } catch (error) { next(error); }
});

app.get('/api/deposits/:id/status', auth, async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id <= 0) return res.status(400).json({ error: 'Dépôt invalide.' });
    const deposit = (await pool.query(
      'SELECT id,status,amount,reference FROM deposits WHERE id=$1 AND user_id=$2',
      [id, req.user.id]
    )).rows[0];
    if (!deposit) return res.status(404).json({ error: 'Dépôt introuvable.' });
    res.json(deposit);
  } catch (error) { next(error); }
});

app.get('/api/products', async (_req, res, next) => {
  try { res.json({ products: (await pool.query('SELECT code,name,price,daily_income,total_income,duration_days,image_class FROM vip_products WHERE active=true ORDER BY price')).rows }); }
  catch (error) { next(error); }
});

app.post('/api/vips/purchase', auth, async (req, res, next) => {
  const code = String(req.body.code || '').toUpperCase();
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const product = (await client.query('SELECT * FROM vip_products WHERE code=$1 AND active=true', [code])).rows[0];
    if (!product) throw Object.assign(new Error('Produit VIP introuvable.'), { status: 404 });
    if (Number(product.price) >= 80000) throw Object.assign(new Error('Ce produit est épuisé et ne peut plus être acheté.'), { status: 409 });
    const account = (await client.query('SELECT balance FROM accounts WHERE user_id=$1 FOR UPDATE', [req.user.id])).rows[0];
    if (Number(account.balance) < Number(product.price)) throw Object.assign(new Error('Solde insuffisant pour cet achat.'), { status: 400 });
    const purchase = (await client.query(
      `INSERT INTO user_vips(user_id,product_id,expires_at,status) VALUES($1,$2,now()+($3||' days')::interval,'active') RETURNING id`,
      [req.user.id, product.id, product.duration_days])).rows[0];
    await client.query('UPDATE accounts SET balance=balance-$2,updated_at=now() WHERE user_id=$1', [req.user.id, product.price]);
    await client.query(`INSERT INTO transactions(user_id,type,amount,direction,reference,metadata) VALUES($1,'vip_purchase',$2,'debit',$3,$4)`,
      [req.user.id, product.price, reference('VIP'), JSON.stringify({ code, userVipId: purchase.id })]);
    await client.query('COMMIT');
    res.status(201).json({ ok: true, purchaseId: purchase.id });
  } catch (error) { await client.query('ROLLBACK'); next(error); } finally { client.release(); }
});

app.get('/api/vips/mine', auth, async (req, res, next) => {
  try {
    const { rows } = await pool.query(`SELECT uv.id,vp.code,vp.name,vp.price,vp.daily_income,vp.image_class,uv.purchased_at,uv.expires_at,uv.status
      FROM user_vips uv JOIN vip_products vp ON vp.id=uv.product_id WHERE uv.user_id=$1 ORDER BY uv.purchased_at DESC`, [req.user.id]);
    res.json({ purchases: rows });
  } catch (error) { next(error); }
});
registerVipIncomeSeries({ app, auth, pool });

const WITHDRAWAL_OPERATORS = new Set(['Moov', 'MTN', 'Airtel', 'Orange', 'Wave', 'TMoney']);
const walletSelect = `id,operator,holder_name AS "holderName",account_number AS "accountNumber",country,is_default AS "isDefault",created_at AS "createdAt"`;
app.get('/api/withdrawal-wallets', auth, async (req, res, next) => {
  try {
    const wallets = await pool.query(`SELECT ${walletSelect} FROM withdrawal_wallets WHERE user_id=$1 AND active=true ORDER BY is_default DESC,created_at DESC`, [req.user.id]);
    res.json({ wallets: wallets.rows });
  } catch (error) { next(error); }
});
app.post('/api/withdrawal-wallets', auth, async (req, res, next) => {
  const operator = String(req.body.operator || '').trim();
  const holderName = String(req.body.holderName || '').trim();
  const accountNumber = String(req.body.accountNumber || '').replace(/[^\d+]/g, '');
  if (!WITHDRAWAL_OPERATORS.has(operator)) return res.status(400).json({ error: 'Opérateur de retrait invalide.' });
  if (holderName.length < 2 || holderName.length > 160) return res.status(400).json({ error: 'Nom du titulaire invalide.' });
  if (!/^\+?\d{6,20}$/.test(accountNumber)) return res.status(400).json({ error: 'Numéro de retrait invalide.' });
  try {
    const created = await pool.query(
      `INSERT INTO withdrawal_wallets(user_id,operator,holder_name,account_number,country,is_default)
       VALUES($1,$2,$3,$4,$5,NOT EXISTS(SELECT 1 FROM withdrawal_wallets WHERE user_id=$1 AND active=true))
       ON CONFLICT(user_id,operator,account_number) DO UPDATE SET holder_name=excluded.holder_name,country=excluded.country,active=true,updated_at=now()
       RETURNING ${walletSelect}`,
      [req.user.id, operator, holderName, accountNumber, req.user.country || '']
    );
    res.status(201).json({ ok: true, wallet: created.rows[0] });
  } catch (error) { next(error); }
});
app.patch('/api/withdrawal-wallets/:id', auth, async (req, res, next) => {
  const id = Number(req.params.id), operator = String(req.body.operator || '').trim(), holderName = String(req.body.holderName || '').trim(), accountNumber = String(req.body.accountNumber || '').replace(/[^\d+]/g, '');
  if (!Number.isSafeInteger(id) || !WITHDRAWAL_OPERATORS.has(operator) || holderName.length < 2 || !/^\+?\d{6,20}$/.test(accountNumber)) return res.status(400).json({ error: 'Informations du portefeuille invalides.' });
  try {
    const updated = await pool.query(`UPDATE withdrawal_wallets SET operator=$3,holder_name=$4,account_number=$5,updated_at=now() WHERE id=$1 AND user_id=$2 AND active=true RETURNING ${walletSelect}`, [id, req.user.id, operator, holderName, accountNumber]);
    if (!updated.rowCount) return res.status(404).json({ error: 'Portefeuille introuvable.' });
    res.json({ ok: true, wallet: updated.rows[0] });
  } catch (error) { next(error); }
});
app.delete('/api/withdrawal-wallets/:id', auth, async (req, res, next) => {
  try {
    const deleted = await pool.query('UPDATE withdrawal_wallets SET active=false,is_default=false,updated_at=now() WHERE id=$1 AND user_id=$2 AND active=true RETURNING id', [Number(req.params.id), req.user.id]);
    if (!deleted.rowCount) return res.status(404).json({ error: 'Portefeuille introuvable.' });
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.post('/api/withdrawals', auth, strictBody(['amount', 'walletId']), async (req, res, next) => {
  const amount = money(req.body.amount);
  const walletId = Number(req.body.walletId);
   const config = await financialConfig();
   if (!Number.isInteger(amount) || amount < config.minimumWithdrawal) return res.status(400).json({ error: `Le retrait minimum est de ${config.minimumWithdrawal} FCFA.` });
   if (!Number.isSafeInteger(walletId)) return res.status(400).json({ error: 'Ajoutez ou sélectionnez d’abord un portefeuille de retrait.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
     const wallet = (await client.query('SELECT * FROM withdrawal_wallets WHERE id=$1 AND user_id=$2 AND active=true FOR UPDATE', [walletId, req.user.id])).rows[0];
     if (!wallet) throw Object.assign(new Error('Portefeuille de retrait introuvable. Ajoutez-en un avant de continuer.'), { status: 400 });
     const flags = (await client.query('SELECT withdrawals_disabled FROM users WHERE id=$1 FOR UPDATE', [req.user.id])).rows[0];
     if (flags?.withdrawals_disabled) throw Object.assign(new Error('Les retraits sont désactivés pour ce compte.'), { status: 403 });
     // Keep the setting locked until the financial transaction finishes: once a
     // manual closure has been saved, no in-flight reader can debit afterward.
     const override = (await client.query("SELECT COALESCE((value->>'enabled')::boolean,false) enabled,COALESCE((value->>'closed')::boolean,false) closed FROM admin_settings WHERE key='withdraw_override' FOR SHARE")).rows[0];
     if (override?.closed) {
       throw Object.assign(new Error('Les retraits sont temporairement fermés par l’administration. Veuillez réessayer après leur réouverture.'), { status: 403 });
     }
     const localTime = (await client.query("SELECT extract(hour FROM now() AT TIME ZONE 'Africa/Algiers')::int AS local_hour")).rows[0];
     if (!override?.enabled && (localTime.local_hour < 10 || localTime.local_hour >= 24)) {
       throw Object.assign(new Error('Les retraits sont ouverts tous les jours de 10 h à 00 h (minuit), heure de l’Algérie.'), { status: 403 });
     }
     // The locked user row serializes requests even when different wallets are used.
     const pending = await client.query("SELECT 1 FROM withdrawals WHERE user_id=$1 AND status IN ('pending','pending_review','pending_verification') LIMIT 1", [req.user.id]);
     if (pending.rowCount) {
       throw Object.assign(new Error('Vous avez déjà un retrait en attente. Attendez son traitement avant de demander un nouveau retrait.'), { status: 409 });
     }
     if (config.maxWithdrawals !== null) {
       const todayCount = Number((await client.query("SELECT count(*) FROM withdrawals WHERE user_id=$1 AND created_at >= (date_trunc('day', now() AT TIME ZONE 'Africa/Algiers') AT TIME ZONE 'Africa/Algiers')", [req.user.id])).rows[0].count);
       if (todayCount >= Number(config.maxWithdrawals)) {
         throw Object.assign(new Error(`Limite quotidienne de ${config.maxWithdrawals} retrait(s) atteinte.`), { status: 429 });
       }
     }
     const vip = await client.query(`SELECT 1 FROM user_vips WHERE user_id=$1 AND status='active' AND expires_at>now() LIMIT 1`, [req.user.id]);
     if (config.withdrawalRequiresActiveVip && !vip.rowCount) throw Object.assign(new Error('Achetez d’abord un produit VIP pour pouvoir retirer.'), { status: 403 });
    const account = (await client.query('SELECT balance FROM accounts WHERE user_id=$1 FOR UPDATE', [req.user.id])).rows[0];
    if (Number(account.balance) < amount) throw Object.assign(new Error('Solde insuffisant.'), { status: 400 });
     const fee = Math.floor(amount * Number(config.withdrawalFeePercent) / 100);
    const ref = reference('WDR');
     const destination = `${wallet.operator} · ${wallet.holder_name} · ${wallet.account_number}`;
     await client.query(`INSERT INTO withdrawals(user_id,amount,fee,net_amount,destination,reference,wallet_id,wallet_operator,wallet_holder_name,wallet_account_number,wallet_country)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
       [req.user.id, amount, fee, amount - fee, destination, ref, wallet.id, wallet.operator, wallet.holder_name, wallet.account_number, wallet.country]);
    await client.query('UPDATE accounts SET balance=balance-$2,updated_at=now() WHERE user_id=$1', [req.user.id, amount]);
    await client.query(`INSERT INTO transactions(user_id,type,amount,direction,status,reference,metadata) VALUES($1,'withdrawal',$2,'debit','pending',$3,$4)`,
       [req.user.id, amount, ref, JSON.stringify({ fee, netAmount: amount - fee, walletId: wallet.id, operator: wallet.operator })]);
    await client.query('COMMIT');
    res.status(201).json({ ok: true, reference: ref, netAmount: amount - fee, status: 'pending' });
  } catch (error) { await client.query('ROLLBACK'); next(error); } finally { client.release(); }
});

app.get('/api/withdrawals', auth, async (req, res, next) => {
  try { res.json({ withdrawals: (await pool.query('SELECT amount,fee,net_amount,status,reference,created_at,wallet_operator,wallet_holder_name,wallet_account_number,wallet_country FROM withdrawals WHERE user_id=$1 ORDER BY created_at DESC', [req.user.id])).rows }); }
  catch (error) { next(error); }
});

app.get('/api/transactions/recent-site', auth, async (_req, res, next) => {
  try {
    const trustedLedgerTypes = new Set([
      'signup_bonus',
      'referral_commission',
      'daily_login_reward',
      'vip_daily_income',
      'vip_purchase',
      'mission_reward',
      'admin_credit',
      'admin_debit',
      'withdrawal_refund',
      'gift_code'
    ]);
    const confirmedStatuses = new Set(['completed', 'approved', 'success', 'paid']);
    const { rows } = await pool.query(
      `SELECT recent.id,recent.type,recent.amount,recent.direction,recent.status,recent.created_at,u.phone FROM (
       SELECT id,user_id,type,amount,direction,status,created_at,source FROM (
         SELECT d.id,d.user_id,'deposit'::text type,d.amount,'credit'::text direction,d.status::text status,d.created_at,'deposit'::text source
         FROM deposits d
         WHERE lower(coalesce(d.status::text,''))='completed'
           AND d.amount::text ~ '^[0-9]+([.][0-9]+)?$'
           AND d.amount::numeric > 0
           AND d.amount::numeric <= 9007199254740991::numeric
         UNION ALL
         SELECT w.id,w.user_id,'withdrawal'::text type,w.amount,'debit'::text direction,w.status::text status,w.created_at,'withdrawal'::text source
         FROM withdrawals w
         WHERE lower(coalesce(w.status::text,''))='completed'
           AND w.amount::text ~ '^[0-9]+([.][0-9]+)?$'
           AND w.amount::numeric > 0
           AND w.amount::numeric <= 9007199254740991::numeric
         UNION ALL
         SELECT t.id,t.user_id,t.type,t.amount,t.direction,t.status::text status,t.created_at,'ledger'::text source
         FROM transactions t
         WHERE t.type IN ('signup_bonus','referral_commission','daily_login_reward','vip_daily_income','vip_purchase','mission_reward','admin_credit','admin_debit','withdrawal_refund','gift_code')
           AND (lower(coalesce(t.status::text,'')) IN ('completed','approved','success','paid') OR t.status IS NULL)
           AND t.amount::text ~ '^[0-9]+([.][0-9]+)?$'
           AND t.amount::numeric > 0
           AND t.amount::numeric <= 9007199254740991::numeric
           AND t.direction IN ('credit','debit')
       ) recent
       ORDER BY created_at DESC,id DESC,source ASC
       LIMIT 100
       ) recent
       LEFT JOIN users u ON u.id=recent.user_id
       ORDER BY recent.created_at DESC,recent.id DESC,recent.source ASC`
    );
    const transactions = rows
      .filter(row => {
        const ledgerNullStatusIsCommitted = row.status == null && trustedLedgerTypes.has(row.type);
        return (confirmedStatuses.has(String(row.status || '').toLowerCase()) || ledgerNullStatusIsCommitted) &&
          (row.type === 'deposit' || row.type === 'withdrawal' || trustedLedgerTypes.has(row.type)) &&
          (row.direction === 'credit' || row.direction === 'debit') &&
          Number.isFinite(Number(row.amount)) && Number(row.amount) > 0 &&
          Number(row.amount) <= Number.MAX_SAFE_INTEGER;
      })
      .slice(0, 100)
      .map(row => {
        const digits = String(row.phone || '').replace(/\D/g, '');
        const visible = Math.floor(digits.length / 2);
        const maskedPhone = digits.length >= 7 && digits.length <= 15
          ? `${String(row.phone).startsWith('+') ? '+' : ''}${digits.slice(0, visible)}${'*'.repeat(digits.length - visible)}`
          : null;
        return {
          type: row.type,
          amount: Number(row.amount),
          direction: row.direction,
          status: 'completed',
          maskedPhone
        };
      });
    res.json({ transactions });
  } catch (error) { next(error); }
});

app.get('/api/transactions', auth, async (req, res, next) => {
  try {
    const state = req.query.state === undefined ? 'all' : req.query.state;
    const hasLimit = req.query.limit !== undefined;
    const limit = hasLimit ? Number(req.query.limit) : 250;
    const offset = req.query.offset === undefined ? 0 : Number(req.query.offset);
    const isIntegerQueryValue = value => typeof value === 'string' && /^\d+$/.test(value);
    if (!['all', 'success', 'pending', 'failed'].includes(state)) {
      return res.status(400).json({ error: 'Filtre de transaction invalide.' });
    }
    if ((hasLimit && (!isIntegerQueryValue(req.query.limit) || !Number.isSafeInteger(limit) || limit < 1 || limit > 100)) ||
        (req.query.offset !== undefined && (!isIntegerQueryValue(req.query.offset) || !Number.isSafeInteger(offset) || offset < 0 || offset > 2147483647))) {
      return res.status(400).json({ error: 'Pagination invalide.' });
    }

    const { rows } = await pool.query(
      `SELECT type,amount,direction,status,reference,metadata,created_at FROM (
         SELECT 'deposit'::text type,d.amount,'credit'::text direction,d.status,d.reference,
                jsonb_build_object('operator',d.operator_name,'provider',d.payment_provider) metadata,d.created_at
         FROM deposits d WHERE d.user_id=$1
         UNION ALL
         SELECT 'withdrawal'::text,w.amount,'debit'::text,w.status,w.reference,
                jsonb_build_object('fee',w.fee,'netAmount',w.net_amount,'operator',w.wallet_operator) metadata,w.created_at
         FROM withdrawals w WHERE w.user_id=$1
         UNION ALL
         SELECT t.type,t.amount,t.direction,t.status,t.reference,t.metadata,t.created_at
         FROM transactions t WHERE t.user_id=$1 AND t.type NOT IN ('deposit','withdrawal')
        ) history
        WHERE $2 = 'all' OR CASE
          WHEN lower(coalesce(status::text, '')) IN ('completed','approved','success','paid') THEN 'success'
          WHEN lower(coalesce(status::text, '')) IN ('failed','rejected','cancelled') THEN 'failed'
          ELSE 'pending'
        END = $2
        ORDER BY created_at DESC, type ASC, reference ASC
        LIMIT $3 OFFSET $4`,
      [req.user.id, state, limit + 1, offset]
    );
    const hasMore = rows.length > limit;
    res.json({ transactions: rows.slice(0, limit), hasMore });
  }
  catch (error) { next(error); }
});

app.get('/api/referrals', auth, async (req, res, next) => {
  try {
    const team = await pool.query(
      `WITH RECURSIVE referral_tree AS (
         SELECT id,phone,created_at,1 AS level FROM users WHERE referred_by=$1
         UNION ALL
         SELECT u.id,u.phone,u.created_at,rt.level+1
         FROM users u JOIN referral_tree rt ON u.referred_by=rt.id
         WHERE rt.level<3
       )
       SELECT rt.id,rt.phone,rt.created_at,rt.level,
              COALESCE(sum(d.amount) FILTER (WHERE d.status='completed'),0)::bigint AS completed_deposits
       FROM referral_tree rt
       LEFT JOIN deposits d ON d.user_id=rt.id
       GROUP BY rt.id,rt.phone,rt.created_at,rt.level
       ORDER BY rt.level,rt.created_at DESC`, [req.user.id]);
    const earnings = await pool.query('SELECT COALESCE(sum(amount),0)::bigint total FROM referral_commissions WHERE beneficiary_id=$1', [req.user.id]);
    const commissions = await pool.query(
      `SELECT level,COALESCE(sum(amount),0)::bigint total
       FROM referral_commissions WHERE beneficiary_id=$1 GROUP BY level`, [req.user.id]);
    const commissionByLevel = Object.fromEntries(commissions.rows.map(row => [row.level, Number(row.total)]));
    const members = team.rows.map(row => ({
      level: row.level,
      account: `${row.phone.slice(0, 2)}*****${row.phone.slice(-2)}`,
      joinedAt: row.created_at,
      completedDeposits: Number(row.completed_deposits)
    }));
    const configuredRates = (await financialConfig()).referralCommissionRates;
    const levels = [1, 2, 3].map(level => ({
      level,
      rate: configuredRates[level - 1],
      members: members.filter(member => member.level === level),
      memberCount: members.filter(member => member.level === level).length,
      completedDeposits: members.filter(member => member.level === level).reduce((sum, member) => sum + member.completedDeposits, 0),
      commission: commissionByLevel[level] || 0
    }));
    res.json({
      referralCode: req.user.referral_code,
      directReferrals: levels[0].memberCount,
      totalTeamSize: members.length,
      totalCommission: Number(earnings.rows[0].total),
      levels
    });
  } catch (error) { next(error); }
});

app.get('/api/missions', auth, async (req, res, next) => {
  try {
    const direct = Number((await pool.query('SELECT count(*) FROM users WHERE referred_by=$1', [req.user.id])).rows[0].count);
    const teamDeposits = Number((await pool.query(`SELECT COALESCE(sum(d.amount),0) total FROM deposits d JOIN users u ON u.id=d.user_id WHERE u.referred_by=$1 AND d.status='completed'`, [req.user.id])).rows[0].total);
    const vip3 = (await pool.query(`SELECT EXISTS(SELECT 1 FROM user_vips uv JOIN vip_products vp ON vp.id=uv.product_id WHERE uv.user_id=$1 AND vp.code='VIP3') done`, [req.user.id])).rows[0].done;
    const claims = new Set((await pool.query('SELECT mission_id FROM mission_claims WHERE user_id=$1', [req.user.id])).rows.map(r => String(r.mission_id)));
    const missions = (await pool.query('SELECT * FROM missions WHERE active=true ORDER BY id')).rows.map(m => {
      const current = m.target_type === 'referrals' ? direct : m.target_type === 'team_deposits' ? teamDeposits : vip3 ? Number(m.target_value) : 0;
      return { ...m, current, completed: current >= Number(m.target_value), claimed: claims.has(String(m.id)) };
    });
    res.json({ missions });
  } catch (error) { next(error); }
});

const DIRECT_VIP_MISSIONS = Object.freeze({
  1: { goal: 5, reward: 1500 },
  2: { goal: 15, reward: 3000 },
  3: { goal: 35, reward: 5000 },
  4: { goal: 70, reward: 10000 }
});

async function directActiveVipCount(client, userId) {
  const result = await client.query(
    `SELECT count(DISTINCT invited.id)::int AS count
     FROM users invited
     WHERE invited.referred_by=$1
       AND EXISTS (
         SELECT 1
         FROM user_vips uv
         WHERE uv.user_id=invited.id
           AND uv.status='active'
           AND uv.expires_at>now()
       )`,
    [userId]
  );
  return Number(result.rows[0].count);
}

app.get('/api/direct-vip-missions', auth, async (req, res, next) => {
  try {
    const activeVipReferrals = await directActiveVipCount(pool, req.user.id);
    const claimedRows = (await pool.query(
      `SELECT (metadata->>'level')::int AS level,amount
       FROM transactions
       WHERE user_id=$1
         AND type='mission_reward'
         AND metadata->>'kind'='direct_active_vip'`,
      [req.user.id]
    )).rows;
    const claimed = new Set(claimedRows.map(row => Number(row.level)));
    res.json({
      activeVipReferrals,
      cumulativeRewards: claimedRows.reduce((sum, row) => sum + Number(row.amount), 0),
      levels: Object.entries(DIRECT_VIP_MISSIONS).map(([level, mission]) => ({
        level: Number(level),
        ...mission,
        current: activeVipReferrals,
        completed: activeVipReferrals >= mission.goal,
        claimed: claimed.has(Number(level))
      }))
    });
  } catch (error) { next(error); }
});

app.post('/api/direct-vip-missions/:level/claim', auth, async (req, res, next) => {
  const level = Number(req.params.level);
  const mission = DIRECT_VIP_MISSIONS[level];
  if (!mission) return res.status(404).json({ error: 'Mission introuvable.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('SELECT user_id FROM accounts WHERE user_id=$1 FOR UPDATE', [req.user.id]);
    const alreadyClaimed = await client.query(
      `SELECT 1 FROM transactions
       WHERE user_id=$1
         AND type='mission_reward'
         AND metadata->>'kind'='direct_active_vip'
         AND metadata->>'level'=$2
       LIMIT 1`,
      [req.user.id, String(level)]
    );
    if (alreadyClaimed.rowCount) throw Object.assign(new Error('Récompense déjà réclamée.'), { status: 409 });
    const current = await directActiveVipCount(client, req.user.id);
    if (current < mission.goal) throw Object.assign(new Error(`Il faut ${mission.goal} filleuls directs avec un VIP actif.`), { status: 400 });
    await client.query(
      'UPDATE accounts SET balance=balance+$2,cumulative_earnings=cumulative_earnings+$2,updated_at=now() WHERE user_id=$1',
      [req.user.id, mission.reward]
    );
    await client.query(
      `INSERT INTO transactions(user_id,type,amount,direction,status,reference,metadata)
       VALUES($1,'mission_reward',$2,'credit','completed',$3,$4)`,
      [req.user.id, mission.reward, reference('MISSION'), JSON.stringify({ kind: 'direct_active_vip', level, goal: mission.goal })]
    );
    await client.query('COMMIT');
    res.json({ ok: true, reward: mission.reward, current });
  } catch (error) {
    await client.query('ROLLBACK');
    next(error);
  } finally { client.release(); }
});

app.post('/api/missions/:id/claim', auth, async (req, res, next) => {
  const id = Number(req.params.id);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const mission = (await client.query('SELECT * FROM missions WHERE id=$1 AND active=true', [id])).rows[0];
    if (!mission) throw Object.assign(new Error('Mission introuvable.'), { status: 404 });
    const direct = Number((await client.query('SELECT count(*) FROM users WHERE referred_by=$1', [req.user.id])).rows[0].count);
    const team = Number((await client.query(`SELECT COALESCE(sum(d.amount),0) total FROM deposits d JOIN users u ON u.id=d.user_id WHERE u.referred_by=$1 AND d.status='completed'`, [req.user.id])).rows[0].total);
    const vip3 = (await client.query(`SELECT EXISTS(SELECT 1 FROM user_vips uv JOIN vip_products vp ON vp.id=uv.product_id WHERE uv.user_id=$1 AND vp.code='VIP3') done`, [req.user.id])).rows[0].done;
    const current = mission.target_type === 'referrals' ? direct : mission.target_type === 'team_deposits' ? team : vip3 ? Number(mission.target_value) : 0;
    if (current < Number(mission.target_value)) throw Object.assign(new Error('Cette mission n’est pas encore terminée.'), { status: 400 });
    const claimed = await client.query('INSERT INTO mission_claims(user_id,mission_id) VALUES($1,$2) ON CONFLICT DO NOTHING RETURNING mission_id', [req.user.id, id]);
    if (!claimed.rowCount) throw Object.assign(new Error('Récompense déjà réclamée.'), { status: 409 });
    await client.query('UPDATE accounts SET balance=balance+$2,cumulative_earnings=cumulative_earnings+$2,updated_at=now() WHERE user_id=$1', [req.user.id, mission.reward]);
    await client.query(`INSERT INTO transactions(user_id,type,amount,direction,reference,metadata) VALUES($1,'mission_reward',$2,'credit',$3,$4)`,
      [req.user.id, mission.reward, reference('MISSION'), JSON.stringify({ missionId: id })]);
    await client.query('COMMIT');
    res.json({ ok: true, reward: Number(mission.reward) });
  } catch (error) { await client.query('ROLLBACK'); next(error); } finally { client.release(); }
});

// Administrative controls. All balance-changing operations lock the account and
// use admin_operations as an idempotency ledger.
const adminUserAction = (field, value) => async (req, res, next) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id)) return res.status(400).json({ error: 'Identifiant invalide.' });
  try {
    const result = value && ['is_banned', 'is_blocked'].includes(field)
      ? await accountSessions.revoke(id, field)
      : await pool.query(`UPDATE users SET ${field}=$1 WHERE id=$2 RETURNING id`, [value, id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Utilisateur introuvable.' });
    res.json({ ok: true });
  } catch (e) { next(e); }
};
for (const [name, field, value] of [['ban','is_banned',true],['unban','is_banned',false],['block','is_blocked',true],['unblock','is_blocked',false],['close-withdrawals','withdrawals_disabled',true],['open-withdrawals','withdrawals_disabled',false]]) app.post(`/api/admin/users/:id/${name}`, adminAuth, adminUserAction(field, value));

app.get('/api/admin/users/:id', adminAuth, async (req, res, next) => {
  try {
    const id = Number(req.params.id); const user = (await pool.query(`SELECT id,phone,country,referral_code AS "referralCode",referred_by AS "referrerId",created_at AS "createdAt",is_banned AS "isBanned",is_blocked AS "isBlocked",withdrawals_disabled AS "withdrawalsDisabled" FROM users WHERE id=$1`, [id])).rows[0];
    if (!user) return res.status(404).json({ error: 'Utilisateur introuvable.' });
    const tx = await pool.query(`SELECT id,type,amount,status,COALESCE(metadata->>'note','') note,created_at AS "createdAt" FROM transactions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100`, [id]);
    const orders = await pool.query(`SELECT uv.id,vp.name AS "productName",vp.price amount,uv.status,'purchase' source,uv.purchased_at AS "createdAt" FROM user_vips uv JOIN vip_products vp ON vp.id=uv.product_id WHERE uv.user_id=$1 ORDER BY uv.purchased_at DESC`, [id]);
    const totals = (await pool.query(`SELECT a.balance,(SELECT COALESCE(sum(amount),0) FROM deposits WHERE user_id=$1 AND status='completed') total_deposits,(SELECT COALESCE(sum(amount),0) FROM withdrawals WHERE user_id=$1 AND status='completed') total_withdrawals,(SELECT COALESCE(sum(amount),0) FROM transactions WHERE user_id=$1 AND type='admin_credit') total_admin_credits,(SELECT COALESCE(sum(amount),0) FROM transactions WHERE user_id=$1 AND type='admin_debit') total_admin_debits,(SELECT COALESCE(sum(amount),0) FROM referral_commissions WHERE beneficiary_id=$1) total_commissions,(SELECT COALESCE(sum(amount),0) FROM daily_rewards WHERE user_id=$1) total_checkins,(SELECT COALESCE(sum(amount),0) FROM transactions WHERE user_id=$1 AND type='vip_daily_income') total_product_income FROM accounts a WHERE a.user_id=$1`, [id])).rows[0];
    res.json({ user, wallet: { balance:Number(totals?.balance||0), totalDeposits:Number(totals?.total_deposits||0), totalWithdrawals:Number(totals?.total_withdrawals||0), totalAdminCredits:Number(totals?.total_admin_credits||0), totalAdminDebits:Number(totals?.total_admin_debits||0), totalCommissions:Number(totals?.total_commissions||0), totalCheckins:Number(totals?.total_checkins||0), totalProductIncome:Number(totals?.total_product_income||0) }, transactions: tx.rows, orders: orders.rows, checkins: [] });
  } catch (e) { next(e); }
});
async function adminMoney(req, res, next) {
  const userId=Number(req.params.id), amount=money(req.body.amount), requestId=String(req.body.requestId||'').trim();
  if (!Number.isSafeInteger(userId)||!Number.isSafeInteger(amount)||amount<=0||requestId.length<8||requestId.length>120) return res.status(400).json({error:'Montant ou requestId invalide.'});
  const debit=req.path.endsWith('/debit'), client=await pool.connect();
  try { await client.query('BEGIN'); await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',[requestId]); const prior=await client.query('SELECT payload FROM admin_operations WHERE request_id=$1 FOR UPDATE',[requestId]); if(prior.rowCount){await client.query('COMMIT');return res.json(prior.rows[0].payload);}
    const a=(await client.query('SELECT balance FROM accounts WHERE user_id=$1 FOR UPDATE',[userId])).rows[0]; if(!a) throw Object.assign(new Error('Compte introuvable.'),{status:404}); if(debit&&Number(a.balance)<amount)throw Object.assign(new Error('Solde insuffisant.'),{status:400});
    await client.query('UPDATE accounts SET balance=balance+$2*CASE WHEN $3 THEN -1 ELSE 1 END,updated_at=now() WHERE user_id=$1',[userId,amount,debit]);
    const type=debit?'admin_debit':'admin_credit', payload={ok:true,amount,type}; await client.query(`INSERT INTO transactions(user_id,type,amount,direction,reference,metadata) VALUES($1,$2,$3,$4,$5,$6)`,[userId,type,amount,debit?'debit':'credit',reference('ADMIN'),JSON.stringify({requestId})]);
    await client.query('INSERT INTO admin_operations(request_id,operation_type,user_id,payload) VALUES($1,$2,$3,$4)',[requestId,type,userId,JSON.stringify(payload)]); await client.query('COMMIT'); res.json(payload);
  } catch(e){await client.query('ROLLBACK');next(e)}finally{client.release()}
}
app.post('/api/admin/users/:id/credit',adminAuth,financialRate,strictBody(['amount','requestId']),adminMoney); app.post('/api/admin/users/:id/debit',adminAuth,financialRate,strictBody(['amount','requestId']),adminMoney);
app.post('/api/admin/users/:id/grant-vip', adminAuth, financialRate, strictBody(['productId','requestId']), async (req, res, next) => {
  const userId = Number(req.params.id);
  const productId = Number(req.body.productId);
  const requestId = String(req.body.requestId || '').trim();
  if (!Number.isSafeInteger(userId) || !Number.isSafeInteger(productId) || requestId.length < 8 || requestId.length > 120) {
    return res.status(400).json({ error: 'Utilisateur, produit ou requestId invalide.' });
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [requestId]);
    const prior = await client.query('SELECT payload FROM admin_operations WHERE request_id=$1 FOR UPDATE', [requestId]);
    if (prior.rowCount) {
      await client.query('COMMIT');
      return res.json(prior.rows[0].payload);
    }
    const user = await client.query('SELECT 1 FROM users WHERE id=$1 FOR UPDATE', [userId]);
    if (!user.rowCount) throw Object.assign(new Error('Utilisateur introuvable.'), { status: 404 });
    const product = (await client.query('SELECT * FROM vip_products WHERE id=$1 AND active=true', [productId])).rows[0];
    if (!product) throw Object.assign(new Error('Produit introuvable.'), { status: 404 });
    const vip = (await client.query(
      "INSERT INTO user_vips(user_id,product_id,expires_at) VALUES($1,$2,now()+($3 || ' days')::interval) RETURNING id",
      [userId, productId, product.duration_days]
    )).rows[0];
    const payload = { ok: true, purchaseId: vip.id };
    await client.query('INSERT INTO admin_operations(request_id,operation_type,user_id,payload) VALUES($1,$2,$3,$4)', [requestId, 'grant_vip', userId, JSON.stringify(payload)]);
    await client.query('COMMIT');
    res.json(payload);
  } catch (error) {
    await client.query('ROLLBACK');
    next(error);
  } finally {
    client.release();
  }
});
app.post('/api/admin/orders/:id/revoke-vip',adminAuth,async(req,res,next)=>{try{const r=await pool.query("UPDATE user_vips SET status='revoked' WHERE id=$1 AND status='active' RETURNING id", [Number(req.params.id)]);if(!r.rowCount)return res.status(404).json({error:'Commande introuvable.'});res.json({ok:true})}catch(e){next(e)}});
app.post('/api/admin/products',adminAuth,async(req,res,next)=>{try{const b=req.body,code=String(b.code||`VIP${Date.now()}`).trim().toUpperCase(),name=String(b.name||'').trim(),price=money(b.price),dailyIncome=money(b.dailyIncome),totalIncome=money(b.totalIncome),durationDays=Number(b.durationDays);if(!/^[A-Z0-9_-]{2,32}$/.test(code)||!name||name.length>160||!Number.isSafeInteger(price)||price<=0||!Number.isSafeInteger(dailyIncome)||dailyIncome<=0||!Number.isSafeInteger(totalIncome)||totalIncome<=0||!Number.isSafeInteger(durationDays)||durationDays<=0)return res.status(400).json({error:'Produit invalide.'});const p=await pool.query('INSERT INTO vip_products(code,name,price,daily_income,total_income,duration_days,image_class) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id',[code,name,price,dailyIncome,totalIncome,durationDays,String(b.imageClass||'')]);res.status(201).json({ok:true,product:p.rows[0]})}catch(e){next(e)}});
app.patch('/api/admin/products/:id',adminAuth,async(req,res,next)=>{try{const b=req.body,r=await pool.query('UPDATE vip_products SET name=COALESCE($1,name),price=COALESCE($2,price),daily_income=COALESCE($3,daily_income),total_income=COALESCE($4,total_income),duration_days=COALESCE($5,duration_days),image_class=COALESCE($6,image_class) WHERE id=$7 RETURNING id',[b.name?.trim(),money(b.price),money(b.dailyIncome),money(b.totalIncome),Number(b.durationDays),b.imageClass,Number(req.params.id)]);if(!r.rowCount)return res.status(404).json({error:'Produit introuvable.'});res.json({ok:true})}catch(e){next(e)}});
app.delete('/api/admin/products/:id',adminAuth,async(req,res,next)=>{try{const r=await pool.query('UPDATE vip_products SET active=false WHERE id=$1 RETURNING id',[Number(req.params.id)]);if(!r.rowCount)return res.status(404).json({error:'Produit introuvable.'});res.json({ok:true})}catch(e){next(e)}});app.patch('/api/admin/products/:id/activate',adminAuth,async(req,res,next)=>{try{const r=await pool.query('UPDATE vip_products SET active=true WHERE id=$1 RETURNING id',[Number(req.params.id)]);if(!r.rowCount)return res.status(404).json({error:'Produit introuvable.'});res.json({ok:true})}catch(e){next(e)}});
app.delete('/api/admin/products/:id/permanent',adminAuth,async(req,res,next)=>{try{const id=Number(req.params.id);if(!Number.isSafeInteger(id)||id<=0)return res.status(400).json({error:'Produit invalide.'});const used=(await pool.query('SELECT EXISTS(SELECT 1 FROM user_vips WHERE product_id=$1) AS used',[id])).rows[0]?.used;if(used)return res.status(409).json({error:'Ce produit possède déjà des achats. Désactivez-le pour préserver les historiques financiers.'});const r=await pool.query('DELETE FROM vip_products WHERE id=$1 RETURNING id',[id]);if(!r.rowCount)return res.status(404).json({error:'Produit introuvable.'});res.json({ok:true})}catch(e){next(e)}});
app.get('/api/admin/gift-codes',adminAuth,async(_req,res,next)=>{try{res.json({codes:(await pool.query('SELECT id,code,amount,max_redemptions AS "maxRedemptions",redemption_count AS redemptions,expires_at AS "expiresAt",created_at AS "createdAt" FROM gift_codes ORDER BY created_at DESC')).rows})}catch(e){next(e)}});
app.post('/api/admin/gift-codes',adminAuth,financialRate,strictBody(['code','amount','maxRedemptions','expiresInDays']),async(req,res,next)=>{try{const supplied=String(req.body.code||'').trim().toUpperCase(),code=supplied||crypto.randomBytes(16).toString('hex').toUpperCase(),amount=money(req.body.amount),maxRedemptions=Number(req.body.maxRedemptions||1),expiresInDays=Number(req.body.expiresInDays||30);if(!/^[A-Z0-9_-]{16,64}$/.test(code)||!Number.isSafeInteger(amount)||amount<=0||amount>100000000||!Number.isSafeInteger(maxRedemptions)||maxRedemptions<1||maxRedemptions>10000||!Number.isSafeInteger(expiresInDays)||expiresInDays<1||expiresInDays>365)return res.status(400).json({error:'Code cadeau invalide.'});const r=await pool.query(`INSERT INTO gift_codes(code,amount,max_redemptions,expires_at) VALUES($1,$2,$3,now()+($4 || ' days')::interval) RETURNING id,code,amount,max_redemptions AS "maxRedemptions",expires_at AS "expiresAt"`,[code,amount,maxRedemptions,expiresInDays]);res.status(201).json({ok:true,code:r.rows[0]})}catch(e){next(e)}});app.delete('/api/admin/gift-codes/:id',adminAuth,async(req,res,next)=>{try{await pool.query('UPDATE gift_codes SET active=false WHERE id=$1',[Number(req.params.id)]);res.json({ok:true})}catch(e){next(e)}});
app.post('/api/gift-codes/redeem',auth,giftRate,strictBody(['code']),async(req,res,next)=>{const code=String(req.body.code||'').trim().toUpperCase();if(!/^[A-Z0-9_-]{16,64}$/.test(code))return res.status(400).json({error:'Code cadeau invalide.'});const c=await pool.connect();try{await c.query('BEGIN');const g=(await c.query('SELECT * FROM gift_codes WHERE code=$1 AND active=true AND (expires_at IS NULL OR expires_at>now()) FOR UPDATE',[code])).rows[0];if(!g||Number(g.redemption_count)>=Number(g.max_redemptions))throw Object.assign(new Error('Code cadeau invalide ou épuisé.'),{status:400});const x=await c.query('INSERT INTO gift_code_redemptions(gift_code_id,user_id,amount) VALUES($1,$2,$3) ON CONFLICT DO NOTHING RETURNING amount',[g.id,req.user.id,g.amount]);if(!x.rowCount)throw Object.assign(new Error('Code déjà utilisé.'),{status:409});const updated=await c.query('UPDATE gift_codes SET redemption_count=redemption_count+1 WHERE id=$1 AND redemption_count<max_redemptions RETURNING id',[g.id]);if(!updated.rowCount)throw Object.assign(new Error('Code cadeau épuisé.'),{status:409});await c.query('UPDATE accounts SET balance=balance+$2,cumulative_earnings=cumulative_earnings+$2 WHERE user_id=$1',[req.user.id,g.amount]);await c.query("INSERT INTO transactions(user_id,type,amount,direction,status,reference,metadata) VALUES($1,'gift_code',$2,'credit','completed',$3,$4)",[req.user.id,g.amount,reference('GIFT'),JSON.stringify({giftCodeId:g.id})]);await c.query('COMMIT');res.json({ok:true,amount:g.amount})}catch(e){await c.query('ROLLBACK');next(e)}finally{c.release()}});
const channelSelect=`id,operator_name AS "operatorName",receiver_number AS "receiverNumber",receiver_name AS "receiverName",logo_color AS "logoColor",logo_text AS "logoText",logo_url AS "logoUrl",country,country_code AS "countryCode",ussd_template AS "ussdTemplate",is_active AS "isActive",sort_order AS "sortOrder"`;
app.get('/api/payment-countries',async(_req,res,next)=>{try{res.json({countries:(await pool.query(`SELECT country,MIN(country_code) AS "countryCode",count(*)::int AS "channelCount" FROM payment_channels WHERE is_active=true AND trim(country)<>'' GROUP BY country ORDER BY country`)).rows})}catch(e){next(e)}});
app.get('/api/payment-channels/me', auth, async (req, res, next) => {
  try {
    const canonicalCountry = paymentCountry(req.user.country);
    const country = canonicalCountry?.name || paymentCountryName(req.user.country);
    if (!country) return res.status(400).json({ error: 'Aucun pays n’est associé à votre compte.' });
    const rows = (await pool.query(
      `SELECT ${channelSelect} FROM payment_channels
        WHERE is_active=true AND lower(country)=ANY($1::text[])
        ORDER BY sort_order,id`,
      [paymentCountryFilterValues(req.user.country)]
    )).rows;
    const accountCountryKey = paymentCountryKey(req.user.country);
    const channels = rows.filter(channel =>
      paymentCountryKey(channel.country) === accountCountryKey &&
      (accountCountryKey !== 'code:TG' || isTogoManualChannel(channel)) &&
      (accountCountryKey !== 'code:NE' || isNigerRechargeOperator(channel.operatorName))
    );
    res.json({ country, channels });
  } catch (e) { next(e); }
});
app.get('/api/payment-channels',async(req,res,next)=>{try{const country=String(req.query.country||'').trim();if(!country)return res.status(400).json({error:'Sélectionnez un pays.'});const rows=(await pool.query(`SELECT ${channelSelect} FROM payment_channels WHERE is_active=true AND lower(country)=lower($1) ORDER BY sort_order,id`,[country])).rows;res.json({channels:rows.filter(channel=>paymentCountry(country)?.code!=='NE'||isNigerRechargeOperator(channel.operatorName))})}catch(e){next(e)}});
app.get('/api/admin/payment-channels',adminAuth,async(_req,res,next)=>{try{res.json({channels:(await pool.query(`SELECT ${channelSelect} FROM payment_channels ORDER BY sort_order,id`)).rows})}catch(e){next(e)}});
app.post('/api/admin/payment-channels',adminAuth,async(req,res,next)=>{try{const b=req.body,url=String(b.logoUrl||''),country=String(b.country||'').trim(),countryCode=String(b.countryCode||'').trim();if(!String(b.operatorName||'').trim()||!String(b.receiverNumber||'').trim()||!eligiblePaymentCountries.has(country)||eligiblePaymentCountries.get(country)!==countryCode||!/^#[0-9a-f]{6}$/i.test(String(b.logoColor||'#e51b23'))||url&& !/^https?:\/\//i.test(url))return res.status(400).json({error:'Opérateur, compte marchand et pays éligible sont obligatoires.'});const result=await pool.query(`INSERT INTO payment_channels(operator_name,receiver_number,receiver_name,logo_color,logo_text,logo_url,country,country_code,ussd_template,is_active,sort_order) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING ${channelSelect}`,[String(b.operatorName).trim(),String(b.receiverNumber).trim(),b.receiverName||'',b.logoColor||'#e51b23',b.logoText||'PAY',url,country,countryCode,b.ussdTemplate||'',b.isActive!==false,Number(b.sortOrder)||0]);res.status(201).json({ok:true,channel:result.rows[0]})}catch(e){next(e)}});
app.patch('/api/admin/payment-channels/:id',adminAuth,async(req,res,next)=>{try{const b=req.body;if(b.country!==undefined||b.countryCode!==undefined){const country=String(b.country||'').trim(),countryCode=String(b.countryCode||'').trim();if(!eligiblePaymentCountries.has(country)||eligiblePaymentCountries.get(country)!==countryCode)return res.status(400).json({error:'Sélectionnez un pays éligible avec son indicatif automatique.'});}await pool.query('UPDATE payment_channels SET operator_name=COALESCE($1,operator_name),receiver_number=COALESCE($2,receiver_number),receiver_name=COALESCE($3,receiver_name),logo_color=COALESCE($4,logo_color),logo_text=COALESCE($5,logo_text),logo_url=COALESCE($6,logo_url),country=COALESCE($7,country),country_code=COALESCE($8,country_code),ussd_template=COALESCE($9,ussd_template),is_active=COALESCE($10,is_active),sort_order=COALESCE($11,sort_order),updated_at=now() WHERE id=$12',[b.operatorName,b.receiverNumber,b.receiverName,b.logoColor,b.logoText,b.logoUrl,b.country,b.countryCode,b.ussdTemplate,b.isActive,b.sortOrder,Number(req.params.id)]);res.json({ok:true})}catch(e){next(e)}});app.delete('/api/admin/payment-channels/:id',adminAuth,async(req,res,next)=>{try{await pool.query('DELETE FROM payment_channels WHERE id=$1',[Number(req.params.id)]);res.json({ok:true})}catch(e){next(e)}});

const announcementSelect=`id,title,content,kind,audience,audience_level AS "audienceLevel",status,published_at AS "publishedAt",created_at AS "createdAt",updated_at AS "updatedAt"`;
app.get('/api/announcements',auth,async(req,res,next)=>{try{res.json({announcements:(await pool.query(`SELECT ${announcementSelect} FROM admin_announcements a WHERE a.status='published' AND (a.audience='all' OR EXISTS (SELECT 1 FROM user_vips uv JOIN vip_products vp ON vp.id=uv.product_id WHERE uv.user_id=$1 AND uv.status='active' AND (vp.code=a.audience_level OR vp.name=a.audience_level))) ORDER BY a.published_at DESC`,[req.user.id])).rows})}catch(e){next(e)}});
app.get('/api/admin/announcements',adminAuth,async(_req,res,next)=>{try{res.json({announcements:(await pool.query(`SELECT ${announcementSelect} FROM admin_announcements ORDER BY created_at DESC`)).rows})}catch(e){next(e)}});
app.post('/api/admin/announcements',adminAuth,async(req,res,next)=>{try{const b=req.body;const result=await pool.query(`INSERT INTO admin_announcements(title,content,kind,audience,audience_level) VALUES($1,$2,$3,$4,$5) RETURNING ${announcementSelect}`,[String(b.title||'').trim(),String(b.content||'').trim(),b.kind||'announcement',b.audience||'all',b.audienceLevel||null]);res.status(201).json({ok:true,announcement:result.rows[0]})}catch(e){next(e)}});
app.patch('/api/admin/announcements/:id',adminAuth,async(req,res,next)=>{try{const b=req.body;await pool.query("UPDATE admin_announcements SET title=$1,content=$2,kind=$3,audience=$4,audience_level=$5,updated_at=now() WHERE id=$6 AND status='draft'",[String(b.title||'').trim(),String(b.content||'').trim(),b.kind,b.audience,b.audienceLevel||null,Number(req.params.id)]);res.json({ok:true})}catch(e){next(e)}});
app.delete('/api/admin/announcements/:id',adminAuth,async(req,res,next)=>{try{const result=await pool.query('DELETE FROM admin_announcements WHERE id=$1',[Number(req.params.id)]);if(!result.rowCount)return res.status(404).json({error:'Annonce introuvable.'});res.json({ok:true})}catch(e){next(e)}});
app.post('/api/admin/announcements/:id/:action',adminAuth,async(req,res,next)=>{try{const publish=req.params.action==='publish';if(!publish&&req.params.action!=='withdraw')return res.status(400).json({error:'Action invalide.'});await pool.query(`UPDATE admin_announcements SET status=$1,published_at=${publish?'now()':'NULL'},updated_at=now() WHERE id=$2`,[publish?'published':'draft',Number(req.params.id)]);res.json({ok:true})}catch(e){next(e)}});
app.get('/api/admin/popup-config',adminAuth,async(_req,res,next)=>{try{const c=await financialConfig();res.json({config:{depositMin:c.minimumDeposit,withdrawalMin:c.minimumWithdrawal,withdrawalFeePercent:c.withdrawalFeePercent,dashboxDeposit:c.dashboxDeposit,dashboxWithdraw:c.dashboxWithdraw,signupBonus:c.signupBonus,checkinBonus:c.dailyCheckInReward,maxWithdrawals:c.maxWithdrawals}})}catch(e){next(e)}});
app.patch('/api/admin/popup-config',adminAuth,async(req,res,next)=>{
  try {
    const b=req.body,previous=await financialConfig();
    const c={...DEFAULT_CONFIG,...previous,
      signupBonus:money(b.signupBonus),dailyCheckInReward:money(b.checkinBonus),
      minimumDeposit:money(b.depositMin),minimumWithdrawal:money(b.withdrawalMin),
      withdrawalFeePercent:Number(b.withdrawalFeePercent),
      maxWithdrawals:b.maxWithdrawals===null?null:Number(b.maxWithdrawals),
      dashboxDeposit:money(b.dashboxDeposit),dashboxWithdraw:money(b.dashboxWithdraw)};
    const invalidAmounts=[c.signupBonus,c.dailyCheckInReward,c.minimumDeposit,c.minimumWithdrawal,c.dashboxDeposit,c.dashboxWithdraw].some(v=>!Number.isSafeInteger(v)||v<=0);
    const invalidLimit=c.maxWithdrawals!==null&&(!Number.isSafeInteger(c.maxWithdrawals)||c.maxWithdrawals<=0);
    if(invalidAmounts||c.minimumDeposit<3000||!Number.isFinite(c.withdrawalFeePercent)||c.withdrawalFeePercent<0||c.withdrawalFeePercent>100||invalidLimit)
      return res.status(400).json({error:'Configuration invalide.'});
    await pool.query('INSERT INTO admin_settings(key,value) VALUES($1,$2) ON CONFLICT(key) DO UPDATE SET value=$2,updated_at=now()',['financial_config',JSON.stringify(c)]);
    res.json({ok:true,config:c});
  }catch(e){next(e)}
});
app.patch('/api/admin/withdraw-override',adminAuth,strictBody(['mode','enabled']),async(req,res,next)=>{
  try {
    // Legacy boolean callers retain their existing open/scheduled semantics.
    // A global closure is explicit, not confused with disabling forced opening.
    const { mode: requestedMode, enabled: legacyEnabled } = req.body;
    const mode = requestedMode !== undefined ? requestedMode : (typeof legacyEnabled === 'boolean' ? (legacyEnabled ? 'open' : 'scheduled') : null);
    if (!['open','closed','scheduled'].includes(mode) ||
        (legacyEnabled !== undefined && (typeof legacyEnabled !== 'boolean' || legacyEnabled !== (mode === 'open')))) {
      return res.status(400).json({error:'Choisissez ouvrir, fermer ou horaire normal pour les retraits.'});
    }
    const enabled = mode === 'open', closed = mode === 'closed';
    await pool.query('INSERT INTO admin_settings(key,value) VALUES($1,$2) ON CONFLICT(key) DO UPDATE SET value=$2,updated_at=now()',
      ['withdraw_override',JSON.stringify({enabled,closed})]);
    res.json({ok:true,mode,enabled,closed});
  } catch(e) { next(e); }
});

const adminRoute = adminPath.length >= 3 && adminPath.length <= 100 && !/[/?#\\]/.test(adminPath) ? `/${adminPath}` : '';
const cameroonAdminRoute = cameroonAdminPath.length >= 8 && cameroonAdminPath.length <= 100 && /^[a-zA-Z0-9_-]+$/.test(cameroonAdminPath) && cameroonAdminPath !== adminPath ? `/${cameroonAdminPath}` : '';
const restrictedAdminRoute = restrictedAdminPath.length >= 8 && restrictedAdminPath.length <= 100 && /^[a-zA-Z0-9_-]+$/.test(restrictedAdminPath) && ![adminPath, cameroonAdminPath, 'admin-ui', 'api', 'checkout', 'administration'].includes(restrictedAdminPath) ? `/${restrictedAdminPath}` : '';
const restrictedAdminConfigurationError = restrictedConfigurationError({
  privatePath: restrictedAdminPath, password: process.env.RESTRICTED_ADMIN_PASSWORD,
  generalPath: adminPath, cameroonPath: cameroonAdminPath,
  generalPassword: process.env.ADMIN_PASSWORD, cameroonPassword: process.env.CAMEROON_ADMIN_PASSWORD
});
app.get('/admin-ui/styles.css', (_req, res) => res.type('css').sendFile(path.join(__dirname, 'administration', 'styles', 'admin.css')));
app.get('/admin-ui/runtime.css', (_req, res) => res.type('css').sendFile(path.join(__dirname, 'administration', 'styles', 'runtime.css')));
app.get('/admin-ui/admin-credit.css', (_req, res) => res.type('css').sendFile(path.join(__dirname, 'administration', 'styles', 'admin-credit.css')));
app.get('/admin-ui/general.js', (_req, res) => res.type('application/javascript').sendFile(path.join(__dirname, 'administration', 'admin.js')));
app.get('/admin-ui/support-inbox.js', (_req, res) => res.type('application/javascript').sendFile(path.join(__dirname, 'administration', 'support-inbox.js')));
app.get('/admin-ui/user-search.js', (_req, res) => res.type('application/javascript').sendFile(path.join(__dirname, 'administration', 'user-search.js')));
app.get('/admin-ui/cameroun.js', (_req, res) => res.type('application/javascript').sendFile(path.join(__dirname, 'administration', 'cameroun.js')));
app.get('/admin-ui/history.css', (_req, res) => res.type('css').sendFile(path.join(__dirname, 'administration', 'styles', 'history.css')));
app.get('/admin-ui/transaction-history.js', (_req, res) => res.type('application/javascript').sendFile(path.join(__dirname, 'administration', 'transaction-history.js')));
app.get('/admin-ui/user-maintenance.js', (_req, res) => res.type('application/javascript').sendFile(path.join(__dirname, 'administration', 'user-maintenance.js')));
app.use((req, res, next) => {
  if (req.method !== 'GET') return next();
  let requestedPath;
  try { requestedPath = decodeURIComponent(req.path); } catch { return res.status(400).end(); }
  if (adminRoute) {
    if ((requestedPath === adminRoute || requestedPath.startsWith(`${adminRoute}/`)) && (cookies(req).coca_cameroon_admin || cookies(req).coca_restricted_admin)) return res.status(404).end();
    if (requestedPath === adminRoute) return res.redirect(308, `${adminRoute}/`);
    if (requestedPath === `${adminRoute}/`) return res.sendFile(path.join(__dirname, 'administration', 'index.html'));
    if (requestedPath === `${adminRoute}/admin.js`) return res.type('application/javascript').sendFile(path.join(__dirname, 'administration', 'admin.js'));
    if (requestedPath === `${adminRoute}/styles.css`) return res.type('css').sendFile(path.join(__dirname, 'administration', 'styles', 'admin.css'));
    if (requestedPath === `${adminRoute}/runtime.css`) return res.type('css').sendFile(path.join(__dirname, 'administration', 'styles', 'runtime.css'));
    if (requestedPath === `${adminRoute}/admin-credit.css`) return res.type('css').sendFile(path.join(__dirname, 'administration', 'styles', 'admin-credit.css'));
  }
  if (cameroonAdminRoute) {
    if (requestedPath === cameroonAdminRoute) return res.redirect(308, `${cameroonAdminRoute}/`);
    if (requestedPath === `${cameroonAdminRoute}/`) return res.sendFile(path.join(__dirname, 'administration', 'cameroun.html'));
    if (requestedPath === `${cameroonAdminRoute}/cameroun.js`) return res.type('application/javascript').sendFile(path.join(__dirname, 'administration', 'cameroun.js'));
    if (requestedPath === `${cameroonAdminRoute}/styles.css`) return res.type('css').sendFile(path.join(__dirname, 'administration', 'styles', 'admin.css'));
    if (requestedPath === `${cameroonAdminRoute}/runtime.css`) return res.type('css').sendFile(path.join(__dirname, 'administration', 'styles', 'runtime.css'));
    if (requestedPath === `${cameroonAdminRoute}/admin-credit.css`) return res.type('css').sendFile(path.join(__dirname, 'administration', 'styles', 'admin-credit.css'));
  }
  if (restrictedAdminRoute) {
    if (requestedPath === restrictedAdminRoute) return res.redirect(308, `${restrictedAdminRoute}/`);
    if (requestedPath === `${restrictedAdminRoute}/`) {
      fs.readFile(path.join(__dirname, 'administration', 'index.html'), 'utf8')
        .then(html => res.type('html').send(restrictedAdminHtml(html))).catch(next);
      return;
    }
  }
  next();
});

app.use((req, res, next) => {
  if (/^\/(?:administration\/|server\.js|package(?:-lock)?\.json|node_modules\/|\.git\/|\.agents\/|\.local\/)/.test(req.path)) {
    return res.status(404).end();
  }
  next();
});
const paymentWebhookReconciliation = registerPaymentRoutes(app, {
  pool, auth, strictBody, financialConfig, reference, paymentCountryName, financialRate,
  automaticDepositsEnabled: false,
  completeProviderDeposit: completeWestpayDeposit
});
const providerControls = createProviderControls(pool, {
  sonaraConfigured: () => Boolean(process.env.SONARAPAY_SDK_KEY && process.env.SONARAPAY_WEBHOOK_SECRET)
});
registerProviderControls(app, { controls: providerControls, adminAuth, strictBody });
app.get('/api/payments/deposit-provider',auth,async(_req,res,next)=>{
  try {
    const controls=await providerControls.read();
    res.json({provider:controls.saspayEnabled?'saspay':controls.sonarapayAutomaticEnabled?'sonarapay':'manual'});
  }catch(error){next(error);}
});
const sonaraReconciliation = registerSonaraRoutes(app, {
  pool,auth,strictBody,financialRate,financialConfig,
  automaticPaymentsEnabled:providerControls.sonaraEnabled,
  completeProviderDeposit:completeWestpayDeposit
});
const saspayReconciliation = registerSaspayRoutes(app, {
  pool, auth, strictBody, financialRate, financialConfig,
  automaticPaymentsEnabled: providerControls.saspayEnabled,
  completeProviderDeposit: completeWestpayDeposit
});

app.get(['/checkout', '/checkout/'], async (_req, res, next) => {
  try {
    const html = await fs.readFile(path.join(__dirname, 'checkout', 'index.html'), 'utf8');
    res.type('html').send(withCustomerNavigation(brandHtml(html.replace('<head>', '<head><base href="/checkout/">')), '/checkout'));
  } catch (error) { next(error); }
});

app.get('/register', async (_req, res, next) => {
  try {
    const file = path.join(__dirname, 'inscription_s_lection_pays', 'code.html');
    let html = await fs.readFile(file, 'utf8');
    html = html
      .replace('<head>', '<head><base href="/inscription_s_lection_pays/"><script src="/network-runtime.js"></script>')
      .replace('value="88VRPA"', 'value="" placeholder="Facultatif"')
      .replace('</body>', '<script src="/app.js"></script></body>');
    res.type('html').send(brandHtml(html));
  } catch (error) {
    next(error);
  }
});
app.get(/\.html$/, async (req, res, next) => {
  if (!isPublicAsset(req.path)) return res.status(404).end();
  try {
    const file = path.resolve(__dirname, `.${req.path}`);
    if (!file.startsWith(`${__dirname}${path.sep}`)) return res.status(404).end();
    let html = await fs.readFile(file, 'utf8');
    if (!html.includes('src="/network-runtime.js"')) {
      html = html.replace('<head>', '<head><script src="/network-runtime.js"></script>');
    }
    if (!html.includes('src="../app.js"') && !html.includes('src="/app.js"')) {
      html = html.replace('</body>', '<script src="../app.js"></script></body>');
    }
    if (req.path.includes('/inscription_s_lection_pays/')) {
      html = html.replace('value="88VRPA"', 'value="" placeholder="Facultatif"');
    }
    if (req.path.includes('/recharge_paiement_gopay/')) {
      html = html
        .replace('.history-link{height:43px;margin:8px 0 2px;border:1px solid #efb8be;border-radius:22px;color:#b4000c;background:#fff;display:flex;align-items:center;justify-content:center;gap:8px;text-decoration:none;font-size:13px;font-weight:800}.history-link svg{width:18px}', '.history-link{width:44px;height:44px;margin:8px 0 2px auto;border:1px solid #cde8d0;border-radius:50%;color:#075b35;background:#fff;display:grid;place-items:center;text-decoration:none;box-shadow:0 4px 12px #075b3516}.history-link svg{width:22px}')
        .replace(/<a class="history-link" href="\.\.\/historique_des_depots\/code\.html">[\s\S]*?<\/a>/, '<a class="history-link" href="../historique_des_depots/code.html" aria-label="Historique des dépôts" title="Historique des dépôts"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 4v5h5"/><path d="M6.5 8.5A7 7 0 1 1 5 13"/><path d="M12 8v5l3 2"/><path d="M12 3v3m-2-1 2 2 2-2"/></svg></a>');
    }
    if (req.path.includes('/retrait_d_argent/')) {
      html = html.replaceAll('min="1200"', 'min="2000"')
        .replaceAll('minimum de 1 200 FCFA', 'minimum de 2 000 FCFA')
        .replace('</style>', '.history-link{position:absolute;z-index:4;right:18px;top:20px;width:42px;height:42px;border:1px solid #ffffff70;border-radius:50%;color:#fff;background:#064d37c9;display:grid;place-items:center;text-decoration:none}.history-link svg{width:21px;height:21px}</style>')
        .replace('<header class="hero">', '<header class="hero"><a class="history-link" href="../historique_des_retraits/code.html" aria-label="Historique des retraits" title="Historique des retraits"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 4v5h5"/><path d="M6.5 8.5A7 7 0 1 1 5 13"/><path d="M12 8v5l3 2"/></svg></a>');
    }
    res.type('html').send(withCustomerNavigation(brandHtml(html), req.path));
  } catch (error) {
    if (error.code === 'ENOENT') return next();
    next(error);
  }
});
app.get('/favicon.svg', (_req, res) => res.type('image/svg+xml').sendFile(path.join(__dirname, 'favicon.svg')));
app.get('/favicon.ico', (_req, res) => res.type('image/x-icon').sendFile(path.join(__dirname, 'favicon.ico')));
app.get('/favicon-180.png', (_req, res) => res.type('image/png').sendFile(path.join(__dirname, 'favicon-180.png')));
// Provider implementation is server-only, never a browser asset.
app.use('/payments', (_req, res) => res.status(404).end());
// Only explicitly public assets are served: no backups, exports or server sources.
app.use((req, res, next) => {
  if (req.path === '/') return next();
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Route introuvable.' });
  if (!isPublicAsset(req.path)) return res.status(404).end();
  next();
});
app.use(express.static(path.join(__dirname), { index: false, dotfiles: 'deny' }));
app.get('/', async (_req, res, next) => {
  try {
    res.type('html').send(brandHtml(await fs.readFile(path.join(__dirname, 'index.html'), 'utf8')));
  } catch (error) {
    next(error);
  }
});
app.use((error, req, res, _next) => {
  const socialRequest = req.path.startsWith('/api/social/') || req.path.startsWith('/api/admin/social/') || req.path.startsWith('/api/cameroon-admin/social/');
  if (socialRequest && (error.status || 500) >= 500) {
    // SQLSTATE only: never log captions, images, phone numbers, SQL, or row details.
    console.error('Erreur interne publication sociale.', {
      code: /^[0-9A-Z]{5}$/.test(String(error?.code || '')) ? error.code : 'unknown'
    });
  } else if (!socialRequest && error?.name !== 'SocialError' && !['entity.too.large', 'entity.parse.failed'].includes(error?.type)) console.error('Erreur serveur', { code: /^[0-9A-Z]{5}$/.test(String(error?.code || '')) ? error.code : 'unknown' });
  const message = error.type === 'entity.parse.failed' ? 'Requête JSON invalide.'
    : error.type === 'entity.too.large' ? 'Requête trop volumineuse.'
    : error.status ? error.message : 'Erreur interne du serveur.';
  res.status(error.status || 500).json({ error: message });
});
async function start() {
  if ((restrictedAdminPath || process.env.RESTRICTED_ADMIN_PASSWORD) && restrictedAdminConfigurationError)
    console.warn('Administration séparée non activée.', restrictedAdminConfigurationError);
  if (!cameroonAdminRoute || String(process.env.CAMEROON_ADMIN_PASSWORD || '').length < 12 || secureEqual(process.env.CAMEROON_ADMIN_PASSWORD || '', process.env.ADMIN_PASSWORD || '')) {
    throw new Error('Configuration sécurisée de l’administration Cameroun invalide.');
  }
  const securityMigration = await fs.readFile(path.join(__dirname, 'migrations', '008_security_hardening.sql'), 'utf8');
  await pool.query(securityMigration);
  const socialMigration = await fs.readFile(path.join(__dirname, 'migrations', '015_social_posts.sql'), 'utf8');
  await pool.query(socialMigration);
  const saspayMigration = await fs.readFile(path.join(__dirname, 'migrations', '026_saspay_direct_payments.sql'), 'utf8');
  await pool.query(saspayMigration);
  const sonaraMigration = await fs.readFile(path.join(__dirname,'migrations','027_sonarapay_direct_payments.sql'),'utf8');
  await pool.query(sonaraMigration);
  await applyFinancialPolicy(pool, DEFAULT_CONFIG);
  await applyDepositMinimumPolicy(pool, DEFAULT_CONFIG);
  await applyWithdrawalWindowPolicy(pool);
  await applyWithdrawalMinimumPolicy(pool, DEFAULT_CONFIG);
  await applySignupBonusPolicy(pool, DEFAULT_CONFIG);
  await applyWithdrawalFrequencyPolicy(pool, DEFAULT_CONFIG);
  await applyReferralWithdrawalRatesPolicy(pool, DEFAULT_CONFIG);
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Application et API sur le port ${PORT}`);
    paymentWebhookReconciliation.start();
    saspayReconciliation.start();
    sonaraReconciliation.start();
    vipIncomeScheduler.start();
  });
}
start().catch(error => {
  console.error('Démarrage sécurisé impossible.', { code: /^[0-9A-Z]{5}$/.test(String(error?.code || '')) ? error.code : 'unknown' });
  process.exit(1);
});