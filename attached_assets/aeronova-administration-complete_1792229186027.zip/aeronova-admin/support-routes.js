'use strict';
const crypto = require('node:crypto');
const MAX_BYTES = 10 * 1024 * 1024;
const SUBJECTS = ['Question sur mon compte','Problème de recharge','Problème de retrait','Autre demande'];
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
class SupportError extends Error { constructor(message,status=400){super(message);this.status=status;} }

async function validateSupportPayload(body, sharp) {
  if(!body || typeof body!=='object' || Array.isArray(body) ||
      Object.keys(body).some(key=>!['subject','message','requestKey','attachments'].includes(key)))
    throw new SupportError('Demande invalide.');
  if(!SUBJECTS.includes(body.subject))throw new SupportError('Choisissez un sujet valide.');
  if(typeof body.message!=='string'||!body.message.trim()||body.message.length>500)
    throw new SupportError('Votre message doit contenir entre 1 et 500 caractères.');
  if(!UUID.test(String(body.requestKey||'')))throw new SupportError('Identifiant de demande invalide.');
  const input=body.attachments===undefined?[]:body.attachments;
  if(!Array.isArray(input)||input.length>3)throw new SupportError('Vous pouvez joindre au maximum trois fichiers.');
  let total=0,storedTotal=0;
  const attachments=[];
  const hash=crypto.createHash('sha256').update(JSON.stringify([body.subject,body.message.trim()]));
  for(const file of input){
    if(!file||typeof file!=='object'||Object.keys(file).some(key=>!['name','type','data'].includes(key))||
        typeof file.name!=='string'||!file.name.trim()||typeof file.data!=='string'||
        file.data.length>Math.ceil(MAX_BYTES/3)*4||!/^[A-Za-z0-9+/]+={0,2}$/.test(file.data))
      throw new SupportError('Pièce jointe invalide.');
    let bytes=Buffer.from(file.data,'base64');
    if(!bytes.length||bytes.toString('base64')!==file.data)throw new SupportError('Fichier illisible.');
    total+=bytes.length;
    if(total>MAX_BYTES)throw new SupportError('Les pièces jointes dépassent 10 Mo.');
    let mime='';
    if(bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))mime='image/png';
    else if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255)mime='image/jpeg';
    else if(bytes.subarray(0,4).toString()==='RIFF'&&bytes.subarray(8,12).toString()==='WEBP')mime='image/webp';
    else if(bytes.subarray(0,5).toString()==='%PDF-')mime='application/pdf';
    else if(bytes.length>=16&&bytes.subarray(4,8).toString()==='ftyp')mime='video/mp4';
    if(!mime||mime!==file.type)throw new SupportError('Formats acceptés : PNG, JPEG, WebP, PDF et MP4.');
    const name=file.name.replace(/[/\\\u0000-\u001f\u007f]/g,'_').slice(0,100);
    hash.update(JSON.stringify([name,mime,crypto.createHash('sha256').update(bytes).digest('hex')]));
    if(mime.startsWith('image/')){
      try{
        const image=sharp(bytes,{limitInputPixels:25000000,animated:false});
        const metadata=await image.metadata();
        if(!metadata.width||!metadata.height||metadata.pages>1)throw new Error('image');
        bytes=await image.rotate().toFormat(mime.split('/')[1],{quality:88}).toBuffer();
      }catch{throw new SupportError('Cette image ne peut pas être traitée.');}
    }
    storedTotal+=bytes.length;
    if(storedTotal>MAX_BYTES)throw new SupportError('Les fichiers traités dépassent 10 Mo.');
    attachments.push({name,mime,bytes});
  }
  return {subject:body.subject,message:body.message.trim(),requestKey:body.requestKey,
    fingerprint:hash.digest('hex'),attachments};
}

async function saveSupportRequest(pool,userId,payload){
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    const inserted=await client.query(
      `INSERT INTO support_requests(id,user_id,request_key,fingerprint,subject,message)
       VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(user_id,request_key) DO NOTHING RETURNING id,status,created_at`,
      [crypto.randomUUID(),userId,payload.requestKey,payload.fingerprint,payload.subject,payload.message]);
    let record=inserted.rows[0];
    if(!record){
      record=(await client.query('SELECT id,status,created_at,fingerprint FROM support_requests WHERE user_id=$1 AND request_key=$2',[userId,payload.requestKey])).rows[0];
      if(!record||record.fingerprint!==payload.fingerprint)
        throw new SupportError('Cette demande a changé. Actualisez-la avant de la renvoyer.',409);
    }else{
      for(const file of payload.attachments)
        await client.query('INSERT INTO support_attachments(id,request_id,name,mime,size,data) VALUES($1,$2,$3,$4,$5,$6)',
          [crypto.randomUUID(),record.id,file.name,file.mime,file.bytes.length,file.bytes]);
    }
    await client.query('COMMIT');
    return {id:record.id,status:record.status,createdAt:record.created_at};
  }catch(error){await client.query('ROLLBACK').catch(()=>{});throw error;}
  finally{client.release();}
}

function registerSupportRoutes(app,{pool,auth,adminAuth,financialRate,express,sharp}){
  const route=handler=>(req,res,next)=>Promise.resolve(handler(req,res)).catch(error=>{
    if(error instanceof SupportError)return res.status(error.status).json({error:error.message});
    if(error.code==='42P01')return res.status(503).json({error:'Le service de demandes est temporairement indisponible. Utilisez les contacts officiels.'});
    next(error);
  });
  app.post('/api/support/requests',auth,financialRate,
    (req,res,next)=>req.is('application/json')?next():res.status(415).json({error:'Format de demande non pris en charge.'}),
    express.json({limit:'15mb'}),route(async(req,res)=>{
      const payload=await validateSupportPayload(req.body,sharp);
      const request=await saveSupportRequest(pool,req.user.id,payload);
      res.status(201).json({ok:true,request});
    }));
  app.get('/api/admin/support/requests',adminAuth,route(async(req,res)=>{
    const page=Number(req.query.page||0);
    if(!Number.isSafeInteger(page)||page<0||page>100000)throw new SupportError('Page invalide.');
    const result=await pool.query(
      `SELECT r.id,r.subject,r.message,r.status,r.created_at,r.handled_at,u.phone,u.country,
       COALESCE((SELECT json_agg(json_build_object('id',a.id,'name',a.name,'size',a.size))
       FROM support_attachments a WHERE a.request_id=r.id),'[]'::json) attachments
       FROM support_requests r JOIN users u ON u.id=r.user_id ORDER BY r.created_at DESC,r.id DESC LIMIT 26 OFFSET $1`,[page*25]);
    res.json({requests:result.rows.slice(0,25),hasMore:result.rows.length>25,page});
  }));
  app.patch('/api/admin/support/requests/:id',adminAuth,route(async(req,res)=>{
    if(!UUID.test(req.params.id)||!req.body||Object.keys(req.body).length!==1||req.body.status!=='handled')
      throw new SupportError('Modification invalide.');
    const result=await pool.query("UPDATE support_requests SET status='handled',handled_at=COALESCE(handled_at,now()) WHERE id=$1 RETURNING id",[req.params.id]);
    if(!result.rowCount)throw new SupportError('Demande introuvable.',404);
    res.json({ok:true});
  }));
  app.get('/api/admin/support/attachments/:id',adminAuth,route(async(req,res)=>{
    if(!UUID.test(req.params.id))throw new SupportError('Fichier introuvable.',404);
    const file=(await pool.query('SELECT name,data FROM support_attachments WHERE id=$1',[req.params.id])).rows[0];
    if(!file)throw new SupportError('Fichier introuvable.',404);
    const ascii=file.name.replace(/[^\x20-\x7e]|["\\]/g,'_');
    res.set({'Content-Type':'application/octet-stream','Content-Disposition':`attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(file.name)}`,
      'Cache-Control':'private, no-store','Content-Security-Policy':"default-src 'none'",'X-Content-Type-Options':'nosniff'});
    res.send(file.data);
  }));
}
module.exports={registerSupportRoutes,validateSupportPayload,saveSupportRequest,SupportError,MAX_BYTES,SUBJECTS};
