'use strict';
const { createRateLimiter, createDbRateLimiter } = require('./security');

const ADMIN_SESSION_DURATION = 24 * 60 * 60 * 1000;

function createAdminLoginProtection({ pool, requestIp, validCredentials }) {
  const burst = createRateLimiter({
    windowMs: 60 * 1000, max: 10, key: req => `admin-burst:${requestIp(req)}`
  });
  const address = createDbRateLimiter({
    pool, windowMs: 15 * 60 * 1000, max: 5,
    key: req => `admin-login-shared:${requestIp(req)}`
  });
  const distributedFailures = createDbRateLimiter({
    pool, windowMs: 15 * 60 * 1000, max: 25,
    key: req => req.path.startsWith('/api/cameroon-admin/') ? 'admin-failures:cameroon' : 'admin-failures:general'
  });
  return [burst, address, (req, res, next) => {
    // Distributed wrong guesses cannot lock out a correctly authenticated operator.
    if (validCredentials(req)) return next();
    return distributedFailures(req, res, next);
  }];
}

module.exports = { ADMIN_SESSION_DURATION, createAdminLoginProtection };