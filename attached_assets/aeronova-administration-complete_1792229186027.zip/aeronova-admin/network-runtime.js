(() => {
  if (window.__cocaFetchTimeoutInstalled) return;
  window.__cocaFetchTimeoutInstalled = true;
  const nativeFetch = window.fetch.bind(window);
  window.fetch = (input, init = {}) => {
    if (init.signal) return nativeFetch(input, init);
    const controller = new AbortController();
    const requestUrl = input?.url || String(input);
    let pathname = requestUrl.split(/[?#]/, 1)[0];
    try {
      pathname = new URL(requestUrl, window.document?.baseURI || window.location.href).pathname;
    } catch {
      // about:srcdoc has no hierarchical URL base. Keep root-relative detection;
      // nativeFetch below still validates the actual input, just as before.
    }
    const isRegistration = pathname === '/api/auth/register'
      && String(init.method || input?.method || 'GET').toUpperCase() === 'POST';
    // Let a legitimate signup burst queue without aborting after only 15 seconds.
    // Do not retry this write automatically: its result may already be committed.
    const timeout = setTimeout(() => controller.abort(), isRegistration ? 120000 : 15000);
    return nativeFetch(input, { ...init, signal: controller.signal })
      .catch(error => {
        if (error?.name === 'AbortError') throw new Error(isRegistration
          ? 'L’inscription prend plus de temps que prévu. Vérifiez si vous pouvez déjà vous connecter avec votre numéro et votre mot de passe.'
          : 'La connexion prend trop de temps. Veuillez réessayer.');
        throw error;
      })
      .finally(() => clearTimeout(timeout));
  };
})();