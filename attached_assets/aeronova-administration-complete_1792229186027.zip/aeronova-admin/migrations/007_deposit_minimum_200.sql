ALTER TABLE deposits
  DROP CONSTRAINT IF EXISTS deposits_amount_check;

ALTER TABLE deposits
  ADD CONSTRAINT deposits_amount_check CHECK (amount >= 200);