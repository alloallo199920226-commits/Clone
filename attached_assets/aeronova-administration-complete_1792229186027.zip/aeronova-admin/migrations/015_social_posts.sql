BEGIN;

CREATE TABLE IF NOT EXISTS social_posts (
  id uuid PRIMARY KEY,
  user_id bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  caption varchar(1000) NOT NULL CHECK (caption ~ '[^[:space:]]' AND length(caption) BETWEEN 1 AND 1000),
  status varchar(16) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  bonus integer NOT NULL DEFAULT 0,
  review_note varchar(500),
  created_at timestamptz NOT NULL DEFAULT now(),
  approved_at timestamptz,
  CONSTRAINT social_posts_review_state_check CHECK (
    (status='approved' AND bonus BETWEEN 1 AND 100000 AND approved_at IS NOT NULL)
    OR (status IN ('pending','rejected') AND bonus=0 AND approved_at IS NULL)
  )
);

CREATE INDEX IF NOT EXISTS social_posts_public_page_idx
  ON social_posts(created_at DESC,id DESC)
  WHERE status='approved' AND bonus>0;
CREATE INDEX IF NOT EXISTS social_posts_user_page_idx
  ON social_posts(user_id,created_at DESC,id DESC);
CREATE INDEX IF NOT EXISTS social_posts_review_page_idx
  ON social_posts(status,created_at DESC,id DESC);

CREATE TABLE IF NOT EXISTS social_post_images (
  id uuid PRIMARY KEY,
  post_id uuid NOT NULL REFERENCES social_posts(id) ON DELETE CASCADE,
  ordinal smallint NOT NULL CHECK (ordinal BETWEEN 0 AND 5),
  mime_type varchar(24) NOT NULL CHECK (mime_type='image/jpeg'),
  width integer NOT NULL CHECK (width BETWEEN 1 AND 1600),
  height integer NOT NULL CHECK (height BETWEEN 1 AND 1600),
  content bytea NOT NULL CHECK (octet_length(content) BETWEEN 1 AND 4194304),
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT social_post_images_ordinal_unique UNIQUE(post_id,ordinal)
);
CREATE INDEX IF NOT EXISTS social_post_images_post_idx ON social_post_images(post_id,ordinal);

CREATE OR REPLACE FUNCTION enforce_social_post_image_count() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE
  target_post uuid;
  image_total integer;
BEGIN
  IF TG_TABLE_NAME='social_posts' THEN
    target_post := COALESCE(NEW.id,OLD.id);
  ELSIF TG_OP='DELETE' THEN
    target_post := OLD.post_id;
  ELSE
    target_post := NEW.post_id;
  END IF;
  IF EXISTS (SELECT 1 FROM social_posts WHERE id=target_post) THEN
    SELECT count(*) INTO image_total FROM social_post_images WHERE post_id=target_post;
    IF image_total < 2 OR image_total > 6 THEN
      RAISE EXCEPTION 'Social posts must have between 2 and 6 images'
        USING ERRCODE='23514';
    END IF;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS social_posts_image_count_check ON social_posts;
CREATE CONSTRAINT TRIGGER social_posts_image_count_check
  AFTER INSERT OR UPDATE ON social_posts
  DEFERRABLE INITIALLY DEFERRED
  FOR EACH ROW EXECUTE FUNCTION enforce_social_post_image_count();
DROP TRIGGER IF EXISTS social_post_images_image_count_check ON social_post_images;
CREATE CONSTRAINT TRIGGER social_post_images_image_count_check
  AFTER INSERT OR UPDATE OR DELETE ON social_post_images
  DEFERRABLE INITIALLY DEFERRED
  FOR EACH ROW EXECUTE FUNCTION enforce_social_post_image_count();

CREATE UNIQUE INDEX IF NOT EXISTS transactions_social_bonus_post_unique
  ON transactions((metadata->>'postId'))
  WHERE type='social_bonus';

COMMIT;