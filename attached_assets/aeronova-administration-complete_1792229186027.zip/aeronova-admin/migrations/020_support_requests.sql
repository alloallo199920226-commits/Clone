BEGIN;
CREATE TABLE IF NOT EXISTS support_requests (
  id uuid PRIMARY KEY,
  user_id bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  request_key uuid NOT NULL,
  fingerprint char(64) NOT NULL,
  subject text NOT NULL CHECK (subject IN ('Question sur mon compte','Problème de recharge','Problème de retrait','Autre demande')),
  message text NOT NULL CHECK (char_length(message) BETWEEN 1 AND 500),
  status text NOT NULL DEFAULT 'received' CHECK (status IN ('received','handled')),
  created_at timestamptz NOT NULL DEFAULT now(),
  handled_at timestamptz,
  UNIQUE(user_id,request_key)
);
CREATE INDEX IF NOT EXISTS support_requests_created_idx ON support_requests(created_at DESC,id);
CREATE TABLE IF NOT EXISTS support_attachments (
  id uuid PRIMARY KEY,
  request_id uuid NOT NULL REFERENCES support_requests(id) ON DELETE CASCADE,
  name text NOT NULL,
  mime text NOT NULL CHECK (mime IN ('image/png','image/jpeg','image/webp','application/pdf','video/mp4')),
  size integer NOT NULL CHECK (size BETWEEN 1 AND 10485760),
  data bytea NOT NULL,
  CHECK (octet_length(data)=size)
);
CREATE INDEX IF NOT EXISTS support_attachments_request_idx ON support_attachments(request_id);
COMMIT;
