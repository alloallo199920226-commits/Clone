BEGIN;

ALTER TABLE gift_codes
  ADD COLUMN IF NOT EXISTS max_redemptions integer NOT NULL DEFAULT 1 CHECK (max_redemptions > 0),
  ADD COLUMN IF NOT EXISTS redemption_count integer NOT NULL DEFAULT 0 CHECK (redemption_count >= 0),
  ADD COLUMN IF NOT EXISTS expires_at timestamptz;

UPDATE gift_codes g
SET redemption_count = counts.total
FROM (
  SELECT gift_code_id, count(*)::integer total
  FROM gift_code_redemptions
  GROUP BY gift_code_id
) counts
WHERE counts.gift_code_id = g.id
  AND g.redemption_count < counts.total;

ALTER TABLE deposits
  ADD COLUMN IF NOT EXISTS proof_reference varchar(160);

CREATE UNIQUE INDEX IF NOT EXISTS deposits_manual_proof_unique
  ON deposits(proof_reference)
  WHERE proof_reference IS NOT NULL;

DROP INDEX IF EXISTS deposits_westpay_pending_user_amount_unique;

CREATE TABLE IF NOT EXISTS security_rate_limits (
  key_hash varchar(64) PRIMARY KEY,
  attempt_count integer NOT NULL DEFAULT 0,
  reset_at timestamptz NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS security_rate_limits_reset_idx ON security_rate_limits(reset_at);
DELETE FROM security_rate_limits WHERE reset_at < now() - interval '1 day';

ALTER TABLE payment_webhook_events
  ADD COLUMN IF NOT EXISTS match_status varchar(24) NOT NULL DEFAULT 'received',
  ADD COLUMN IF NOT EXISTS deposit_id bigint REFERENCES deposits(id),
  ADD COLUMN IF NOT EXISTS last_error text;

CREATE INDEX IF NOT EXISTS payment_webhook_unmatched_idx
  ON payment_webhook_events(received_at)
  WHERE provider = 'westpay' AND processed_at IS NULL;

CREATE TABLE IF NOT EXISTS security_events (
  id bigserial PRIMARY KEY,
  event_type varchar(64) NOT NULL,
  user_id bigint REFERENCES users(id) ON DELETE SET NULL,
  ip_hash varchar(64),
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS security_events_type_time_idx ON security_events(event_type, created_at DESC);

ALTER TABLE admin_sessions
  ADD COLUMN IF NOT EXISTS scope varchar(24) NOT NULL DEFAULT 'general';

COMMIT;