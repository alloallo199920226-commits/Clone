CREATE TABLE IF NOT EXISTS sonarapay_payments (
  id bigserial PRIMARY KEY,
  user_id bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  deposit_id bigint NOT NULL UNIQUE REFERENCES deposits(id) ON DELETE CASCADE,
  reference varchar(191) NOT NULL UNIQUE,
  client_request_id varchar(80) NOT NULL,
  amount bigint NOT NULL CHECK(amount > 0),
  currency varchar(3) NOT NULL,
  country_code varchar(2) NOT NULL,
  operator varchar(120) NOT NULL,
  operator_name varchar(160) NOT NULL,
  phone varchar(24) NOT NULL,
  request_payload jsonb NOT NULL,
  provider_reference varchar(191) UNIQUE,
  provider_tx_id varchar(191) UNIQUE,
  state varchar(24) NOT NULL DEFAULT 'sending'
    CHECK(state IN ('sending','pending','pending_review','succeeded','failed','manual_required')),
  lease_token uuid,
  lease_until timestamptz,
  first_sent_at timestamptz NOT NULL DEFAULT now(),
  last_checked_at timestamptz,
  last_error varchar(80),
  last_diagnostic jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id,client_request_id),
  CHECK((country_code='CM' AND currency='XAF') OR
        (country_code IN ('TG','BJ','NE','SN') AND currency='XOF'))
);
CREATE INDEX IF NOT EXISTS sonarapay_pending_check_idx ON sonarapay_payments(last_checked_at ASC NULLS FIRST)
  WHERE provider_reference IS NOT NULL AND state <> 'succeeded';
CREATE TABLE IF NOT EXISTS sonarapay_manual_networks (
  country_code varchar(2) NOT NULL,
  operator varchar(120) NOT NULL,
  reason varchar(80) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(country_code,operator)
);
