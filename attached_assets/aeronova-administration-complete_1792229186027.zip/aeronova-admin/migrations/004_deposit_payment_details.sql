ALTER TABLE deposits
  ADD COLUMN IF NOT EXISTS payment_channel_id bigint REFERENCES payment_channels(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS payer_number varchar(40),
  ADD COLUMN IF NOT EXISTS operator_name varchar(120),
  ADD COLUMN IF NOT EXISTS receiver_number varchar(120),
  ADD COLUMN IF NOT EXISTS receiver_name varchar(160),
  ADD COLUMN IF NOT EXISTS ussd_template text,
  ADD COLUMN IF NOT EXISTS client_request_id varchar(80);

CREATE UNIQUE INDEX IF NOT EXISTS deposits_user_client_request_unique
  ON deposits(user_id, client_request_id)
  WHERE client_request_id IS NOT NULL;