BEGIN;

ALTER TABLE payment_orders
  DROP CONSTRAINT IF EXISTS payment_orders_country_currency_check;

ALTER TABLE payment_orders
  ADD CONSTRAINT payment_orders_country_currency_check
  CHECK ((country_code = 'BJ' AND currency = 'XOF') OR
         (country_code = 'CM' AND currency = 'XAF') OR
         (country_code = 'CI' AND currency = 'XOF') OR
         (country_code = 'TG' AND currency = 'XOF'));

COMMIT;