BEGIN;

CREATE TABLE IF NOT EXISTS withdrawal_wallets (
  id bigserial PRIMARY KEY,
  user_id bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  operator varchar(40) NOT NULL,
  holder_name varchar(160) NOT NULL,
  account_number varchar(80) NOT NULL,
  country varchar(120) NOT NULL DEFAULT '',
  is_default boolean NOT NULL DEFAULT false,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, operator, account_number)
);

CREATE INDEX IF NOT EXISTS withdrawal_wallets_user_idx
  ON withdrawal_wallets(user_id, active, created_at DESC);

ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS wallet_id bigint REFERENCES withdrawal_wallets(id) ON DELETE SET NULL;
ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS wallet_operator varchar(40);
ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS wallet_holder_name varchar(160);
ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS wallet_account_number varchar(80);
ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS wallet_country varchar(120);

COMMIT;