BEGIN;

ALTER TABLE payment_orders
  DROP CONSTRAINT IF EXISTS payment_orders_currency_check,
  DROP CONSTRAINT IF EXISTS payment_orders_country_code_check,
  DROP CONSTRAINT IF EXISTS payment_orders_country_currency_check;

ALTER TABLE payment_orders
  ADD CONSTRAINT payment_orders_country_currency_check
  CHECK ((country_code = 'BJ' AND currency = 'XOF') OR
         (country_code = 'CM' AND currency = 'XAF'));

COMMIT;