BEGIN;

ALTER TABLE payment_orders
  ADD COLUMN IF NOT EXISTS verification_processing_token varchar(80),
  ADD COLUMN IF NOT EXISTS verification_processing_until timestamptz,
  ADD COLUMN IF NOT EXISTS verification_last_attempt_at timestamptz;

CREATE INDEX IF NOT EXISTS ashtech_order_verification_queue_idx
  ON payment_orders(
    provider,
    (COALESCE(verification_last_attempt_at, created_at)) ASC,
    created_at ASC,
    verification_processing_until ASC
  )
  WHERE provider = 'ashtechpay'
    AND provider_tx_id IS NOT NULL
    AND webhook_seen = false
    AND status NOT IN ('succeeded', 'failed', 'requires_redirect');

COMMIT;