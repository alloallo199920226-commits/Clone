BEGIN;

ALTER TABLE users ADD COLUMN IF NOT EXISTS is_banned boolean NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_blocked boolean NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS withdrawals_disabled boolean NOT NULL DEFAULT false;
ALTER TABLE vip_products ADD COLUMN IF NOT EXISTS image_class text NOT NULL DEFAULT '';
ALTER TABLE vip_products ADD COLUMN IF NOT EXISTS total_income bigint;
UPDATE vip_products SET total_income=daily_income*duration_days WHERE total_income IS NULL;
ALTER TABLE vip_products ALTER COLUMN total_income SET NOT NULL;

CREATE TABLE IF NOT EXISTS admin_settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS admin_operations (
  request_id text PRIMARY KEY,
  operation_type text NOT NULL,
  user_id bigint REFERENCES users(id) ON DELETE CASCADE,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS admin_login_attempts (
  client_hash text PRIMARY KEY,
  failures integer NOT NULL DEFAULT 0,
  locked_until timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS gift_codes (
  id bigserial PRIMARY KEY,
  code varchar(64) NOT NULL UNIQUE,
  amount bigint NOT NULL CHECK (amount > 0),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS gift_code_redemptions (
  gift_code_id bigint NOT NULL REFERENCES gift_codes(id) ON DELETE CASCADE,
  user_id bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount bigint NOT NULL,
  redeemed_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (gift_code_id, user_id)
);

CREATE TABLE IF NOT EXISTS payment_channels (
  id bigserial PRIMARY KEY,
  operator_name varchar(120) NOT NULL,
  receiver_number varchar(80) NOT NULL,
  receiver_name varchar(160) NOT NULL DEFAULT '',
  logo_color varchar(32) NOT NULL DEFAULT '#e51b23',
  logo_text varchar(16) NOT NULL DEFAULT 'PAY',
  logo_url text NOT NULL DEFAULT '',
  country varchar(120) NOT NULL,
  country_code varchar(8) NOT NULL,
  ussd_template text NOT NULL DEFAULT '',
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS admin_announcements (
  id bigserial PRIMARY KEY,
  title varchar(160) NOT NULL,
  content text NOT NULL,
  kind varchar(24) NOT NULL CHECK (kind IN ('announcement','notification')),
  audience varchar(16) NOT NULL CHECK (audience IN ('all','level')),
  audience_level varchar(16),
  status varchar(16) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published')),
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO admin_settings(key,value) VALUES
  ('financial_config', '{"minimumDeposit":3000,"minimumWithdrawal":1600,"withdrawalFeePercent":10,"dashboxDeposit":200,"dashboxWithdraw":2000,"signupBonus":1600,"dailyCheckInReward":300,"maxWithdrawals":2}'::jsonb),
  ('withdraw_override', '{"enabled":false}'::jsonb)
ON CONFLICT (key) DO NOTHING;

COMMIT;