BEGIN;

WITH same_day_rewards AS (
  SELECT dr.user_id, sum(dr.amount)::bigint AS amount
  FROM daily_rewards dr
  JOIN users u ON u.id=dr.user_id
  WHERE (dr.reward_date AT TIME ZONE 'Africa/Lagos')::date
        = (u.created_at AT TIME ZONE 'Africa/Lagos')::date
  GROUP BY dr.user_id
)
UPDATE accounts a
SET balance=GREATEST(0,a.balance-r.amount),
    cumulative_earnings=GREATEST(0,a.cumulative_earnings-r.amount),
    updated_at=now()
FROM same_day_rewards r
WHERE a.user_id=r.user_id;

DELETE FROM transactions t
USING users u
WHERE t.user_id=u.id
  AND t.type='daily_login_reward'
  AND (t.created_at AT TIME ZONE 'Africa/Lagos')::date
      = (u.created_at AT TIME ZONE 'Africa/Lagos')::date;

DELETE FROM daily_rewards dr
USING users u
WHERE dr.user_id=u.id
  AND (dr.reward_date AT TIME ZONE 'Africa/Lagos')::date
      = (u.created_at AT TIME ZONE 'Africa/Lagos')::date;

COMMIT;