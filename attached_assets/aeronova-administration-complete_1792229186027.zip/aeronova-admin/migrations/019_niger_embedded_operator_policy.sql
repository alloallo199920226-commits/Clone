BEGIN;
ALTER TABLE payment_orders
  ADD COLUMN IF NOT EXISTS external_redirect_required boolean NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS payment_orders_niger_redirect_operators
  ON payment_orders(operator)
  WHERE country_code='NE' AND external_redirect_required=true;
CREATE TABLE IF NOT EXISTS payment_operator_blocks (
  country_code varchar(2) NOT NULL CHECK (country_code='NE'),
  operator varchar(120) NOT NULL,
  reason text NOT NULL CHECK (reason='external_redirect'),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (country_code,operator)
);
COMMIT;