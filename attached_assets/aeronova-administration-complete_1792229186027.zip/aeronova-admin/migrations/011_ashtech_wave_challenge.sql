BEGIN;

ALTER TABLE payment_orders
  ADD COLUMN IF NOT EXISTS challenge_wave_url text;

ALTER TABLE payment_webhook_events
  ADD COLUMN IF NOT EXISTS last_attempt_at timestamptz;

CREATE INDEX IF NOT EXISTS ashtech_webhook_reconciliation_idx
  ON payment_webhook_events(provider, last_attempt_at ASC NULLS FIRST, received_at ASC)
  WHERE provider = 'ashtechpay' AND processed_at IS NULL;

ALTER TABLE payment_orders
  DROP CONSTRAINT IF EXISTS payment_orders_challenge_mode_check,
  ADD CONSTRAINT payment_orders_challenge_mode_check
    CHECK (challenge_mode IS NULL OR challenge_mode IN ('sms', 'ussd', 'wave')),
  DROP CONSTRAINT IF EXISTS payment_orders_wave_challenge_check,
  ADD CONSTRAINT payment_orders_wave_challenge_check
    CHECK (challenge_mode IS DISTINCT FROM 'wave' OR challenge_wave_url IS NOT NULL);

COMMIT;