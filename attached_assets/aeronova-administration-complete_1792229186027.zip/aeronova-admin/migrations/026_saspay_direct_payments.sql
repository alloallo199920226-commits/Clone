CREATE TABLE IF NOT EXISTS saspay_payments (
  id bigserial PRIMARY KEY,
  user_id bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  deposit_id bigint NOT NULL UNIQUE REFERENCES deposits(id) ON DELETE CASCADE,
  reference varchar(191) NOT NULL UNIQUE,
  client_request_id varchar(80) NOT NULL,
  amount bigint NOT NULL CHECK(amount > 0),
  currency varchar(3) NOT NULL,
  country_code varchar(2) NOT NULL,
  country_id uuid NOT NULL,
  network_id uuid NOT NULL,
  operator varchar(120) NOT NULL,
  phone varchar(24) NOT NULL,
  request_payload jsonb NOT NULL,
  provider_tx_id uuid UNIQUE,
  state varchar(24) NOT NULL DEFAULT 'sending'
    CHECK(state IN ('sending','pending','succeeded','failed','manual_required')),
  redirect_required boolean NOT NULL DEFAULT false,
  lease_token uuid,
  lease_until timestamptz,
  first_sent_at timestamptz NOT NULL DEFAULT now(),
  last_checked_at timestamptz,
  last_error varchar(80),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id,client_request_id),
  CHECK((country_code='CM' AND currency='XAF') OR
        (country_code IN ('TG','BJ','NE','SN','CI','BF') AND currency='XOF'))
);
ALTER TABLE saspay_payments ADD COLUMN IF NOT EXISTS prepayment_otp_required boolean NOT NULL DEFAULT false;
ALTER TABLE saspay_payments ADD COLUMN IF NOT EXISTS prepayment_otp_sealed text;
-- Upgrade existing installations, retaining country/currency validation.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='saspay_payments'::regclass
      AND conname='saspay_payments_check' AND pg_get_constraintdef(oid) NOT LIKE '%''CI''%') THEN
    ALTER TABLE saspay_payments DROP CONSTRAINT saspay_payments_check;
    ALTER TABLE saspay_payments ADD CONSTRAINT saspay_payments_check
      CHECK((country_code='CM' AND currency='XAF') OR
        (country_code IN ('TG','BJ','NE','SN','CI','BF') AND currency='XOF'));
  END IF;
END $$;
CREATE INDEX IF NOT EXISTS saspay_pending_check_idx
  ON saspay_payments(last_checked_at ASC NULLS FIRST)
  WHERE state IN ('sending','pending','manual_required');

-- Provider capabilities are independent of customer/history deletions.
CREATE TABLE IF NOT EXISTS saspay_manual_networks (
  country_code varchar(2) NOT NULL,
  operator varchar(120) NOT NULL,
  reason varchar(80) NOT NULL DEFAULT 'external_checkout_required',
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(country_code,operator)
);
-- Import legacy exclusions once. Replaying history on every start would undo
-- an explicitly authorized operator reactivation even without a new redirect.
WITH backfill AS (
  INSERT INTO admin_settings(key,value)
  VALUES('saspay_manual_networks_history_backfill','{"applied":true}'::jsonb)
  ON CONFLICT(key) DO NOTHING
  RETURNING key
)
INSERT INTO saspay_manual_networks(country_code,operator)
  SELECT DISTINCT country_code,operator FROM saspay_payments
  WHERE redirect_required=true AND EXISTS(SELECT 1 FROM backfill)
  ON CONFLICT(country_code,operator) DO NOTHING;
