BEGIN;

CREATE TABLE IF NOT EXISTS payment_orders (
  id bigserial PRIMARY KEY,
  user_id bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  deposit_id bigint NOT NULL UNIQUE REFERENCES deposits(id) ON DELETE CASCADE,
  reference varchar(191) NOT NULL UNIQUE,
  client_request_id varchar(80) NOT NULL,
  provider varchar(40) NOT NULL DEFAULT 'ashtechpay',
  provider_tx_id varchar(160),
  amount bigint NOT NULL CHECK (amount > 0),
  currency varchar(8) NOT NULL,
  country_code varchar(8) NOT NULL,
  operator varchar(120),
  phone varchar(24),
  status varchar(32) NOT NULL DEFAULT 'created'
    CHECK (status IN ('created','initiating','pending','otp_required','verification_pending','succeeded','failed','requires_redirect')),
  provider_session_reference varchar(191),
  challenge_mode varchar(8) CHECK (challenge_mode IN ('sms','ussd')),
  challenge_ussd_code varchar(80),
  challenge_message varchar(240),
  initiation_attempted boolean NOT NULL DEFAULT false,
  initiation_started_at timestamptz,
  initiation_in_progress boolean NOT NULL DEFAULT false,
  otp_confirmation_in_progress boolean NOT NULL DEFAULT false,
  otp_confirmation_started_at timestamptz,
  webhook_seen boolean NOT NULL DEFAULT false,
  webhook_event_id varchar(160),
  lease_updated_at timestamptz,
  state_version bigint NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, client_request_id)
);

ALTER TABLE payment_orders
  ADD CONSTRAINT payment_orders_country_currency_check
  CHECK ((country_code = 'BJ' AND currency = 'XOF') OR
         (country_code = 'CM' AND currency = 'XAF'));

ALTER TABLE payment_orders
  ADD COLUMN IF NOT EXISTS otp_confirmation_started_at timestamptz,
  ADD COLUMN IF NOT EXISTS state_version bigint NOT NULL DEFAULT 0;

CREATE UNIQUE INDEX IF NOT EXISTS payment_orders_provider_tx_unique
  ON payment_orders(provider, provider_tx_id)
  WHERE provider_tx_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS payment_orders_status_lease_idx
  ON payment_orders(status, lease_updated_at);

COMMIT;