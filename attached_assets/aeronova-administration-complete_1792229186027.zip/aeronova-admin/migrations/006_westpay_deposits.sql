ALTER TABLE deposits
  ADD COLUMN IF NOT EXISTS payment_provider varchar(40),
  ADD COLUMN IF NOT EXISTS provider_tx_id varchar(160),
  ADD COLUMN IF NOT EXISTS provider_return_status varchar(40),
  ADD COLUMN IF NOT EXISTS provider_confirmed_at timestamptz;

CREATE UNIQUE INDEX IF NOT EXISTS deposits_provider_tx_unique
  ON deposits(payment_provider, provider_tx_id)
  WHERE provider_tx_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS payment_webhook_events (
  provider varchar(40) NOT NULL,
  event_id varchar(160) NOT NULL,
  event_type varchar(80) NOT NULL,
  payload jsonb NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz,
  PRIMARY KEY(provider, event_id)
);