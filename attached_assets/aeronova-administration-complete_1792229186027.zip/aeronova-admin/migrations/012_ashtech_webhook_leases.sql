BEGIN;

ALTER TABLE payment_webhook_events
  ADD COLUMN IF NOT EXISTS processing_token varchar(80),
  ADD COLUMN IF NOT EXISTS processing_until timestamptz;

CREATE INDEX IF NOT EXISTS ashtech_webhook_reconciliation_lease_idx
  ON payment_webhook_events(
    provider,
    (COALESCE(last_attempt_at, received_at)) ASC,
    received_at ASC,
    processing_until ASC
  )
  WHERE provider = 'ashtechpay' AND processed_at IS NULL;

COMMIT;