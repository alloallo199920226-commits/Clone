INSERT INTO payment_channels(operator_name,receiver_number,receiver_name,logo_color,logo_text,country,country_code,ussd_template,is_active,sort_order)
SELECT v.operator_name,v.receiver_number,v.receiver_name,v.logo_color,v.logo_text,v.country,v.country_code,v.ussd_template,true,v.sort_order
FROM (VALUES
  ('MTN Mobile Money (Démo)','00000001','DÉMO — NE PAS TRANSFÉRER','#ffd000','MTN','Bénin','+229','',10),
  ('Moov Money (Démo)','00000002','DÉMO — NE PAS TRANSFÉRER','#20a0df','MOOV','Bénin','+229','',20),
  ('Orange Money (Démo)','00000003','DÉMO — NE PAS TRANSFÉRER','#ff7900','OM','Burkina Faso','+226','',10),
  ('Moov Money (Démo)','00000004','DÉMO — NE PAS TRANSFÉRER','#20a0df','MOOV','Burkina Faso','+226','',20),
  ('TMoney (Démo)','00000005','DÉMO — NE PAS TRANSFÉRER','#e51b23','TM','Togo','+228','',10),
  ('Flooz (Démo)','00000006','DÉMO — NE PAS TRANSFÉRER','#20a0df','FLOOZ','Togo','+228','',20)
) AS v(operator_name,receiver_number,receiver_name,logo_color,logo_text,country,country_code,ussd_template,sort_order)
WHERE NOT EXISTS (
  SELECT 1 FROM payment_channels p
  WHERE p.operator_name=v.operator_name AND p.country=v.country
);