'use strict';
const { EventEmitter } = require('node:events');
const BANNED_MESSAGE = 'votre communauté est gelé';
const EXPIRED_COOKIE = 'coca_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0';

function createAccountSessionControl(pool) {
  const events = new EventEmitter();
  events.setMaxListeners(0);
  async function revoke(id, field) {
    if (!['is_banned', 'is_blocked'].includes(field)) throw new Error('Invalid account restriction');
    const client = await pool.connect();
    let result;
    try {
      await client.query('BEGIN');
      result = await client.query(`UPDATE users SET ${field}=true WHERE id=$1 RETURNING id`, [id]);
      if (result.rowCount) await client.query('DELETE FROM sessions WHERE user_id=$1', [id]);
      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally { client.release(); }
    // Notify only after the database has durably invalidated all devices.
    if (result.rowCount) events.emit(String(id), field === 'is_banned' ? 'banned' : 'blocked');
    return result;
  }
  function stream(req, res, tokenHash) {
    const id = req.user.id;
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();
    res.write(': session connected\n\n');
    let closed = false;
    let busy = false;
    const revokeClient = reason => {
      if (closed) return;
      res.write(`event: revoked\ndata: ${JSON.stringify({ reason })}\n\n`);
      res.end();
      cleanup();
    };
    const check = async () => {
      if (closed || busy) return;
      busy = true;
      try {
        // Also detect changes committed by another application instance.
        const { rows } = await pool.query(
          `SELECT u.is_banned,u.is_blocked,
             EXISTS(SELECT 1 FROM sessions s WHERE s.user_id=u.id AND s.token_hash=$2 AND s.expires_at>now()) AS active
           FROM users u WHERE u.id=$1`, [id, tokenHash]);
        if (closed) return;
        const user = rows[0];
        if (!user || !user.active || user.is_banned || user.is_blocked)
          revokeClient(user?.is_banned ? 'banned' : user?.is_blocked ? 'blocked' : 'expired');
        else res.write(': session active\n\n');
      } catch {
        // A temporary database/network failure is not a ban or logout.
        if (!closed) res.write(': check deferred\n\n');
      } finally { busy = false; }
    };
    const timer = setInterval(check, 5000);
    timer.unref?.();
    function cleanup() {
      if (closed) return;
      closed = true;
      clearInterval(timer);
      events.off(String(id), revokeClient);
    }
    events.on(String(id), revokeClient);
    res.on('close', cleanup);
    void check(); // Covers a ban committed between authentication and subscription.
  }
  return { revoke, stream };
}
module.exports = { BANNED_MESSAGE, EXPIRED_COOKIE, createAccountSessionControl };
