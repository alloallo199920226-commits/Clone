'use strict';

// Database time is the only clock used for financial eligibility. The existing
// (user_vip_id, income_date) key also preserves all previously paid instalments.
const CREDIT_DUE_INCOME_SQL = `
WITH selected AS MATERIALIZED (
  SELECT uv.id,uv.user_id,uv.purchased_at,uv.expires_at,vp.daily_income,vp.duration_days
  FROM user_vips uv JOIN vip_products vp ON vp.id=uv.product_id
  WHERE uv.status='active' AND uv.expires_at IS NOT NULL AND EXISTS (
    SELECT 1 FROM generate_series(1,LEAST(vp.duration_days,
      floor(extract(epoch FROM (LEAST(now(),uv.expires_at)-uv.purchased_at))/86400)::int)) period(n)
    WHERE NOT EXISTS (
      SELECT 1 FROM vip_income_accruals paid WHERE paid.user_vip_id=uv.id
        AND paid.income_date=((uv.purchased_at+period.n*interval '24 hours') AT TIME ZONE 'UTC')::date
    )
  )
  ORDER BY uv.id LIMIT $1 FOR UPDATE OF uv SKIP LOCKED
), inserted AS (
  INSERT INTO vip_income_accruals(user_vip_id,income_date,amount)
  SELECT s.id,((s.purchased_at+period.n*interval '24 hours') AT TIME ZONE 'UTC')::date,s.daily_income
  FROM selected s
  CROSS JOIN LATERAL generate_series(1,LEAST(s.duration_days,
    floor(extract(epoch FROM (LEAST(now(),s.expires_at)-s.purchased_at))/86400)::int)) period(n)
  ON CONFLICT (user_vip_id,income_date) DO NOTHING
  RETURNING user_vip_id,income_date,amount
), recorded AS (
  INSERT INTO transactions(user_id,type,amount,direction,reference,metadata)
  SELECT s.user_id,'vip_daily_income',i.amount,'credit',
    'VIPGAIN-'||i.user_vip_id::text||'-'||i.income_date::text,
    jsonb_build_object('userVipId',i.user_vip_id,'incomeDate',i.income_date,
      'dueAt',s.purchased_at+(i.income_date-
        (s.purchased_at AT TIME ZONE 'UTC')::date)*interval '24 hours')
  FROM inserted i JOIN selected s ON s.id=i.user_vip_id
  RETURNING amount
), totals AS (
  SELECT s.user_id,sum(i.amount)::bigint amount
  FROM inserted i JOIN selected s ON s.id=i.user_vip_id GROUP BY s.user_id
), credited AS (
  UPDATE accounts a SET balance=a.balance+t.amount,
    cumulative_earnings=a.cumulative_earnings+t.amount,updated_at=now()
  FROM totals t WHERE a.user_id=t.user_id RETURNING t.amount
), marked AS (
  UPDATE user_vips uv SET last_income_date=latest.income_date
  FROM (SELECT user_vip_id,max(income_date) income_date FROM inserted GROUP BY user_vip_id) latest
  WHERE uv.id=latest.user_vip_id RETURNING uv.id
)
SELECT (SELECT count(*)::int FROM selected) AS purchases,
  (SELECT count(*)::int FROM inserted) AS instalments,
  (SELECT count(*)::int FROM marked) AS marked,
  (SELECT count(*)::int FROM recorded) AS recorded,
  (SELECT coalesce(sum(amount),0)::text FROM inserted) AS due_amount,
  (SELECT coalesce(sum(amount),0)::text FROM credited) AS credited_amount`;

async function creditDueVipIncome({pool, batchSize = 100}) {
  if (!Number.isSafeInteger(batchSize) || batchSize < 1 || batchSize > 1000)
    throw new Error('Taille du lot de revenus invalide.');
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query("SET LOCAL TIME ZONE 'UTC'");
    await client.query("SET LOCAL statement_timeout = '20s'");
    // Multiple published instances, restarts and overlapping ticks cannot pay twice.
    const lock = await client.query("SELECT pg_try_advisory_xact_lock(731204,24) AS acquired");
    if (!lock.rows[0].acquired) {
      await client.query('COMMIT');
      return {busy:true,purchases:0,instalments:0};
    }
    const result = (await client.query(CREDIT_DUE_INCOME_SQL, [batchSize])).rows[0];
    if (result.due_amount !== result.credited_amount || result.instalments !== result.recorded)
      throw new Error('Crédit des revenus incomplet : transaction annulée.');
    await client.query('COMMIT');
    return {busy:false,purchases:result.purchases,instalments:result.instalments};
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

function createVipIncomeScheduler({pool, intervalMs = 30000, onError = () => {}}) {
  let started = false, timer = null, running = false;
  async function tick() {
    if (!started || running) return;
    running = true;
    let delay = intervalMs;
    try {
      const result = await creditDueVipIncome({pool});
      if (result.purchases === 100) delay = 1000; // Drain a backlog in bounded transactions.
    } catch (error) {
      onError(error);
    } finally {
      running = false;
      if (started) {
        timer = setTimeout(tick, delay);
        timer.unref?.();
      }
    }
  }
  return {
    start() { if (!started) {started = true;void tick();} },
    stop() {started = false;clearTimeout(timer);timer = null;}
  };
}

module.exports = {creditDueVipIncome,createVipIncomeScheduler};