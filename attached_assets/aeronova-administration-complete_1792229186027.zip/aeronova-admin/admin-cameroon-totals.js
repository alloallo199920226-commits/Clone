'use strict';

// Aggregate each ledger separately: joining deposits to withdrawals would
// multiply amounts for users with several transactions.
const CAMEROON_TOTALS_SQL = `SELECT
  (SELECT COALESCE(SUM(d.amount),0)
     FROM deposits d JOIN users u ON u.id=d.user_id
    WHERE d.status='completed'
      AND UPPER(BTRIM(u.country)) IN ('CAMEROUN','CAMEROON','CM','+237','237')) AS "totalDeposits",
  (SELECT COALESCE(SUM(w.amount),0)
     FROM withdrawals w JOIN users u ON u.id=w.user_id
    WHERE w.status='completed'
      AND UPPER(BTRIM(u.country)) IN ('CAMEROUN','CAMEROON','CM','+237','237')) AS "totalWithdrawals"`;

function registerCameroonTotals(app, { pool, adminAuth }) {
  app.get('/api/admin/cameroon-totals', adminAuth, async (req, res, next) => {
    try {
      if (req.adminScope !== 'general') {
        return res.status(403).json({ error: 'Ces totaux sont réservés à l’administration générale.' });
      }
      const { rows } = await pool.query(CAMEROON_TOTALS_SQL);
      const totalDeposits = Number(rows[0]?.totalDeposits);
      const totalWithdrawals = Number(rows[0]?.totalWithdrawals);
      if (!Number.isSafeInteger(totalDeposits) || totalDeposits < 0 ||
          !Number.isSafeInteger(totalWithdrawals) || totalWithdrawals < 0) {
        throw new Error('Totaux Cameroun invalides.');
      }
      res.json({ country: 'Cameroun', currency: 'XAF', totalDeposits, totalWithdrawals });
    } catch (error) { next(error); }
  });
}

module.exports = { registerCameroonTotals, CAMEROON_TOTALS_SQL };