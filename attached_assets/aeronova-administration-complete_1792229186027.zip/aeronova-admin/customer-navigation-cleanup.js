// Remove only primary navigation signatures. Page actions, filters, pagination
// and community reaction controls must remain available.
function stripPrimaryNavigation(html) {
  return html.replace(/<(nav|footer)\b([^>]*)>[\s\S]*?<\/\1\s*>/gi, (markup, tag, attrs) => {
    const attribute = name => attrs.match(new RegExp(`\\b${name}\\s*=\\s*["']([^"']*)["']`, 'i'))?.[1] || '';
    const classes = attribute('class').split(/\s+/);
    const primaryClasses = new Set([
      'bottom', 'bottom-nav', 'bottom-navigation', 'bottom-tabs', 'bottom-tab-bar',
      'mobile-nav', 'mobile-navbar', 'footer-nav', 'sprite-global-nav'
    ]);
    const primaryPurpose = /^(?:main-bottom-nav|tab-bar|bottom-tab-bar|main-navigation)$/i.test(attribute('data-purpose'));
    const primaryLabel = /^(?:navigation principale|main navigation)$/i.test(attribute('aria-label').trim());
    return classes.some(name => primaryClasses.has(name)) || primaryPurpose || primaryLabel ? '' : markup;
  });
}

module.exports = { stripPrimaryNavigation };