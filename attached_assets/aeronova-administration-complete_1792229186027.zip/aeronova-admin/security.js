const crypto = require('crypto');

const exactBody = (body, allowed) => {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return false;
  const accepted = new Set(allowed);
  return Object.keys(body).every(key => accepted.has(key));
};

const westpayOrderReference = event => String(
  event?.orderId ||
  event?.order_id ||
  event?.orderReference ||
  event?.order_reference ||
  event?.merchantReference ||
  event?.merchant_reference ||
  event?.reference ||
  ''
).trim();

const westpayEventMatches = ({ event, deposit, accountCountry, accountPhone, merchantSlug, normalizeCountry, normalizePhone }) => (
  Boolean(deposit) &&
  String(event?.merchantSlug || '') === String(merchantSlug || '') &&
  Number.isSafeInteger(Number(event?.amount)) &&
  Number(event.amount) === Number(deposit.amount) &&
  normalizeCountry(event?.country) === normalizeCountry(accountCountry) &&
  normalizePhone(event?.payer) === normalizePhone(accountPhone)
);

const createRateLimiter = ({ windowMs, max, key }) => {
  const buckets = new Map();
  return (req, res, next) => {
    const now = Date.now();
    const rawKey = String(key(req));
    const id = crypto.createHash('sha256').update(rawKey).digest('hex');
    let bucket = buckets.get(id);
    if (!bucket || bucket.resetAt <= now) bucket = { count: 0, resetAt: now + windowMs };
    bucket.count += 1;
    buckets.set(id, bucket);
    if (buckets.size > 10000) {
      for (const [bucketId, value] of buckets) if (value.resetAt <= now) buckets.delete(bucketId);
      while (buckets.size > 10000) buckets.delete(buckets.keys().next().value);
    }
    res.setHeader('RateLimit-Limit', String(max));
    res.setHeader('RateLimit-Remaining', String(Math.max(0, max - bucket.count)));
    res.setHeader('RateLimit-Reset', String(Math.ceil(bucket.resetAt / 1000)));
    if (bucket.count > max) {
      res.setHeader('Retry-After', String(Math.ceil((bucket.resetAt - now) / 1000)));
      return res.status(429).json({ error: 'Trop de tentatives. Réessayez plus tard.' });
    }
    next();
  };
};

const createDbRateLimiter = ({ pool, windowMs, max, key }) => async (req, res, next) => {
  try {
    const id = crypto.createHash('sha256').update(String(key(req))).digest('hex');
    const result = await pool.query(
      `INSERT INTO security_rate_limits(key_hash,attempt_count,reset_at)
       VALUES($1,1,now()+($2 * interval '1 millisecond'))
       ON CONFLICT(key_hash) DO UPDATE SET
         attempt_count=CASE WHEN security_rate_limits.reset_at<=now() THEN 1 ELSE security_rate_limits.attempt_count+1 END,
         reset_at=CASE WHEN security_rate_limits.reset_at<=now() THEN excluded.reset_at ELSE security_rate_limits.reset_at END
       RETURNING attempt_count,reset_at`,
      [id, windowMs]
    );
    const bucket = result.rows[0];
    const resetAt = new Date(bucket.reset_at).getTime();
    res.setHeader('RateLimit-Limit', String(max));
    res.setHeader('RateLimit-Remaining', String(Math.max(0, max - Number(bucket.attempt_count))));
    res.setHeader('RateLimit-Reset', String(Math.ceil(resetAt / 1000)));
    if (Number(bucket.attempt_count) > max) {
      res.setHeader('Retry-After', String(Math.max(1, Math.ceil((resetAt - Date.now()) / 1000))));
      return res.status(429).json({ error: 'Trop de tentatives. Réessayez plus tard.' });
    }
    next();
  } catch (error) {
    next(error);
  }
};

module.exports = { exactBody, westpayOrderReference, westpayEventMatches, createRateLimiter, createDbRateLimiter };