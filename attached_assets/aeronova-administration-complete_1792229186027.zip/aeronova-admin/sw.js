const CACHE = 'sprite-api-v177';
// Only public presentation assets belong here, never authenticated HTML or API data.
const CORE = [
  '/sprite-auth.css',
  '/sprite-assets/sprite-theme.css',
  '/sprite-assets/platform-product-theme.css',
  '/sprite-assets/aeronova-brand.css',
  '/sprite-assets/customer-navigation.css',
  '/sprite-assets/stripe-pay-brand.css?v=1',
  '/sprite-assets/stripe-pay-brand.js?v=2',
  '/sprite-assets/aeronova-wordmark.svg',
  '/quipe_profil_utilisateur/team-page.css',
  '/quipe_profil_utilisateur/platform-team-reference.css',
  '/quipe_profil_utilisateur/team-reference.css',
  '/accueil_produits_coca_cola/notification-popup.css'
];

const OFFLINE_HTML = `<!doctype html>
<html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#09264f"><title>Connexion interrompue — AERONOVA</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;min-height:100dvh;display:grid;place-items:center;padding:24px;background:linear-gradient(145deg,#edf6ff,#fff);color:#09264f;font-family:system-ui,sans-serif}
main{width:min(100%,430px);padding:32px 26px;background:white;border:1px solid #dce8f5;border-radius:24px;box-shadow:0 16px 48px #09264f12}
.brand{font-weight:800;letter-spacing:2px;color:#1268d8}h1{font-size:28px;line-height:1.2;margin-top:28px}p{line-height:1.6;color:#50647a}
button{width:100%;min-height:52px;margin-top:16px;border:0;border-radius:14px;background:#1268d8;color:white;font:700 16px system-ui;cursor:pointer}button:focus-visible{outline:3px solid #09264f;outline-offset:4px}
</style></head><body><main>
<div class="brand">AERONOVA</div><h1>Connexion interrompue</h1>
<p>Cette page nécessite une connexion Internet. Vérifiez votre réseau, puis réessayez.</p>
<p>La coupure ne signifie pas que vous êtes déconnecté de votre compte. Si un paiement était en cours, vérifiez son statut après le retour du réseau avant de créer une autre demande.</p>
<button id="retry" type="button">Réessayer</button>
<p id="network-status" role="status" aria-live="polite"></p>
</main><script>
document.getElementById("retry").addEventListener("click",function(){location.reload()});
window.addEventListener("online",function(){document.getElementById("network-status").textContent="Le réseau est de nouveau disponible. Vous pouvez réessayer."});
</script></body></html>`;

// If a stylesheet has never been cached, do not expose the underlying legacy UI.
// This response is never saved: refreshing online restores the real stylesheet.
const OFFLINE_STYLE = `
body>*{display:none!important;visibility:hidden!important;pointer-events:none!important}
html body::after{content:"AERONOVA\\A \\A Connexion interrompue\\A \\A Vérifiez votre réseau, puis rafraîchissez cette page. Si un paiement était en cours, vérifiez son statut avant de créer une autre demande.";white-space:pre-wrap;box-sizing:border-box;position:fixed!important;inset:0!important;width:100vw!important;height:100vh!important;height:100dvh!important;max-width:none!important;z-index:2147483647!important;display:grid!important;align-content:center!important;padding:32px!important;background:#edf6ff!important;color:#09264f!important;font:600 18px/1.65 system-ui,sans-serif!important;pointer-events:auto!important;visibility:visible!important;opacity:1!important;transform:none!important;filter:none!important;clip-path:none!important;border-radius:0!important}
`;

function offlineResponse(content, type) {
  return new Response(content, {
    status: 200,
    headers: { 'Content-Type': type + '; charset=utf-8', 'Cache-Control': 'no-store' }
  });
}

async function networkAsset(request, complete = false) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);
  try {
    const response = await fetch(request, { cache: 'no-store', signal: controller.signal });
    // A connection can fail after the headers: do not deliver half an HTML/CSS/JS file.
    // Returning the original response preserves redirect URLs and response headers.
    if (complete && response.ok && !response.redirected &&
        /text\/(?:html|css)|javascript/i.test(response.headers.get('content-type') || '')) {
      await response.clone().arrayBuffer();
    }
    return response;
  } finally {
    clearTimeout(timer);
  }
}

function cacheable(response) {
  return response.ok && !response.redirected &&
    !/text\/html/i.test(response.headers.get('content-type') || '');
}

async function saveAsset(cache, request, response) {
  if (cacheable(response)) {
    try {
      await cache.put(request, response.clone());
    } catch (error) {
      console.warn('Asset AERONOVA non conservé hors ligne.', error.name);
    }
  }
}

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    // A missing optional asset must not leave the obsolete worker controlling the site.
    await Promise.all(CORE.map(async url => {
      try {
        await saveAsset(cache, url, await networkAsset(url, true));
      } catch (error) {
        console.warn('Préchargement AERONOVA indisponible.', url, error.name);
      }
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil(caches.keys()
    .then(keys => Promise.all(keys.filter(key => key.startsWith('sprite-api-') && key !== CACHE)
      .map(key => caches.delete(key))))
    .then(() => self.clients.claim()));
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (url.origin !== location.origin) return;
  // No cache, no timeout wrapper, no retries for any financial/session API request.
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(fetch(request));
    return;
  }
  if (request.method !== 'GET' || request.destination === 'video' || request.headers.has('range')) return;
  // Approval controls must never execute a cached administration script.
  if (url.pathname.startsWith('/admin-ui/') ||
      (request.destination === 'script' && /\/(?:admin|cameroun)\.js$/.test(url.pathname))) {
    event.respondWith(fetch(request, { cache: 'no-store' }));
    return;
  }
  if (request.mode === 'navigate' || request.destination === 'document' || /\.html$/.test(url.pathname)) {
    event.respondWith(networkAsset(request, true)
      .catch(() => offlineResponse(OFFLINE_HTML, 'text/html')));
    return;
  }

  const operation = (async () => {
    const cache = await caches.open(CACHE);
    const style = request.destination === 'style' || /\.css$/.test(url.pathname);
    const cached = await cache.match(request, style ? { ignoreSearch: true } : undefined);
    const fresh = networkAsset(request, style || request.destination === 'script').then(async response => {
      if (style && !cacheable(response)) throw new Error('Stylesheet indisponible');
      await saveAsset(cache, request, response);
      return response;
    }).catch(() => cached || (style
      ? offlineResponse(OFFLINE_STYLE, 'text/css')
      : Response.error()));
    // Keep writes alive even when an image response is served immediately from cache.
    return { response: style || request.destination === 'script' ? await fresh : cached || await fresh, fresh };
  })();
  event.respondWith(operation.then(result => result.response));
  event.waitUntil(operation.then(result => result.fresh).then(() => undefined));
});
