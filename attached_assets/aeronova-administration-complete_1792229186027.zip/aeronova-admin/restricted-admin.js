'use strict';

const COOKIE = 'coca_restricted_admin';
const HIDDEN_FIELDS = new Set([
  'approvedDeposits', 'approvedWithdrawals', 'completed_deposits', 'completed_withdrawals',
  'totalDeposits', 'totalWithdrawals', 'total_deposits', 'total_withdrawals',
  'paymentChannels', 'payment_channels', 'channels', 'cameroonTotals'
]);

function redactRestrictedData(value) {
  if (!value || typeof value !== 'object' || value instanceof Date) return value;
  if (Array.isArray(value)) return value.map(redactRestrictedData);
  return Object.fromEntries(Object.entries(value)
    .filter(([key]) => !HIDDEN_FIELDS.has(key))
    .map(([key, item]) => [key, redactRestrictedData(item)]));
}

function restrictedRouteAllowed(pathname) {
  try { pathname = decodeURIComponent(pathname); } catch { return false; }
  return !/^\/api\/admin\/(?:payment-channels|cameroon-totals|logout)(?:\/|$)/i.test(pathname);
}

function restrictedConfigurationError({ privatePath, password, generalPath, cameroonPath, generalPassword, cameroonPassword }) {
  if (!privatePath) return 'RESTRICTED_ADMIN_PATH : l’adresse privée est manquante.';
  if (privatePath.length < 8) return 'RESTRICTED_ADMIN_PATH : le nom enregistré est trop court. Il faut au moins 8 caractères.';
  if (privatePath.length > 100) return 'RESTRICTED_ADMIN_PATH : le nom enregistré est trop long. La limite est de 100 caractères.';
  if (!/^[a-zA-Z0-9_-]+$/.test(privatePath))
    return 'RESTRICTED_ADMIN_PATH : le nom contient des caractères non autorisés. Utilisez uniquement des lettres sans accents, des chiffres, des tirets ou _. Aucun espace ni lien complet.';
  if ([generalPath, cameroonPath].includes(privatePath))
    return 'RESTRICTED_ADMIN_PATH : cette adresse est déjà utilisée par une autre administration. Choisissez un autre nom.';
  if (['admin-ui', 'api', 'checkout', 'administration'].includes(privatePath))
    return 'RESTRICTED_ADMIN_PATH : ce nom est réservé à une page du site. Choisissez un autre nom.';
  if (!password || password.length < 12) return 'RESTRICTED_ADMIN_PASSWORD : choisissez un mot de passe d’au moins 12 caractères.';
  if ([generalPassword, cameroonPassword].includes(password)) return 'RESTRICTED_ADMIN_PASSWORD : choisissez un mot de passe différent de ceux des autres administrations.';
  return '';
}

function createRestrictedAdminAuth({ pool, cookies, hashToken }) {
  return async function restrictedAdminAuth(req, res, next) {
    try {
      const token = cookies(req)[COOKIE];
      if (!token) return res.status(401).json({ error: 'Connexion à l’administration séparée requise.' });
      const session = await pool.query(
        "SELECT 1 FROM admin_sessions WHERE token_hash=$1 AND scope='restricted' AND expires_at>now()",
        [hashToken(token)]
      );
      if (!session.rowCount) return res.status(401).json({ error: 'Session administrateur expirée.' });
      if (!restrictedRouteAllowed(req.path)) return res.status(403).json({ error: 'Fonctionnalité indisponible dans cette administration.' });
      req.adminScope = 'restricted';
      const json = res.json;
      res.json = function restrictedJson(payload) {
        return json.call(this, redactRestrictedData(payload));
      };
      next();
    } catch (error) { next(error); }
  };
}

function registerRestrictedAdmin(app, {
  pool, cookies, hashToken, secureEqual, strictBody, loginRate, createAdminSession,
  adminAuth, requestIp, auditSecurity, privatePath, getPassword, getConfigurationError = () => ''
}) {
  app.post('/api/restricted-admin/login', loginRate, strictBody(['path', 'password']), async (req, res, next) => {
    try {
      const configurationError = getConfigurationError();
      if (configurationError) return res.status(503).json({ error: configurationError });
      const password = getPassword();
      if (!privatePath || !password || !secureEqual(req.body.path, privatePath)) {
        auditSecurity(req, 'restricted_admin_login_path_rejected');
        return res.status(404).json({ error: 'Administration indisponible.' });
      }
      const clientKey = hashToken(`restricted:${requestIp(req)}`);
      const attempt = (await pool.query('SELECT failures,locked_until FROM admin_login_attempts WHERE client_hash=$1', [clientKey])).rows[0];
      if (attempt?.locked_until && new Date(attempt.locked_until) > new Date()) {
        return res.status(429).json({ error: 'Trop de tentatives. Réessayez dans quelques minutes.' });
      }
      if (!secureEqual(req.body.password, password)) {
        await pool.query(
          `INSERT INTO admin_login_attempts(client_hash,failures,locked_until)
           VALUES($1,1,NULL)
           ON CONFLICT(client_hash) DO UPDATE SET
             failures=CASE WHEN admin_login_attempts.updated_at < now()-interval '30 minutes' THEN 1 ELSE admin_login_attempts.failures+1 END,
             locked_until=CASE
               WHEN (CASE WHEN admin_login_attempts.updated_at < now()-interval '30 minutes' THEN 1 ELSE admin_login_attempts.failures+1 END)>=5
               THEN now()+interval '15 minutes' ELSE NULL END,
             updated_at=now()`, [clientKey]
        );
        await new Promise(resolve => setTimeout(resolve, 650));
        auditSecurity(req, 'restricted_admin_login_failed');
        return res.status(401).json({ error: 'Mot de passe administrateur incorrect.' });
      }
      await pool.query('DELETE FROM admin_login_attempts WHERE client_hash=$1', [clientKey]);
      await createAdminSession(res, 'restricted');
      auditSecurity(req, 'restricted_admin_login_succeeded');
      res.json({ ok: true });
    } catch (error) { next(error); }
  });
  app.post('/api/restricted-admin/logout', adminAuth, async (req, res, next) => {
    try {
      await pool.query("DELETE FROM admin_sessions WHERE token_hash=$1 AND scope='restricted'", [hashToken(cookies(req)[COOKIE])]);
      res.setHeader('Set-Cookie', `${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`);
      res.json({ ok: true });
    } catch (error) { next(error); }
  });
}

function restrictedAdminHtml(html) {
  return html.replace('<body>', '<body data-admin-scope="restricted">')
    .replace('<title>Administration sécurisée</title>', '<title>Administration séparée</title>')
    .replace('<strong>Administration Sprite</strong>', '<strong>Administration séparée Sprite</strong>')
    .replace(/(\/admin-ui\/general\.js\?v=)\d+/, '$1restricted-157')
    .replace(/^\s*<button data-tab="channels">Canaux<\/button>\s*$/m, '')
    .replace(/^\s*<button\b[^>]*data-tab="cameroon"[^>]*>[\s\S]*?<\/button>\s*$/m, '');
}

module.exports = { COOKIE, redactRestrictedData, restrictedRouteAllowed, restrictedConfigurationError, createRestrictedAdminAuth, registerRestrictedAdmin, restrictedAdminHtml };