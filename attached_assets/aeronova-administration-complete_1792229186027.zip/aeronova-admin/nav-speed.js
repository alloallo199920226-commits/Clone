(() => {
  if (!('serviceWorker' in navigator)) return;
  navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(error => {
    console.warn('Cache hors ligne indisponible', error);
  });
})();

(() => {
  const style = document.createElement('style');
  style.textContent = `
    @media (max-width: 719px) {
      .bottom {
        left: 0 !important;
        right: 0 !important;
        bottom: 0 !important;
        width: 100% !important;
        max-width: 480px !important;
        margin-inline: auto !important;
        transform: none !important;
        border-radius: 28px 28px 0 0 !important;
        will-change: auto !important;
      }
    }
  `;
  document.head.appendChild(style);
})();