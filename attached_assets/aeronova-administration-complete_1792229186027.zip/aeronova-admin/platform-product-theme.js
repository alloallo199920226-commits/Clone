const stylesheet = '<link rel="stylesheet" href="/sprite-assets/platform-product-theme.css?v=12">';
const { withAeronovaBranding } = require('./site-branding');

// Apply the same appearance before first paint, without changing page content,
// authentication, financial values, form hooks, or customer navigation.
function withPlatformProductTheme(html) {
  return withAeronovaBranding(html)
    // These presentation-only sheets draw the former Sprite liquid/bottle artwork.
    // Keep the original documents, controls, scripts, and data-state classes intact.
    .replace(/<link\b[^>]*href=["'][^"']*\/?(?:profile-liquid|liquid-products|pointage-reference|pointage-checked|pointage-fidelity)\.css(?:\?[^"']*)?["'][^>]*>\s*/gi, '')
    .replace(/<html\b([^>]*)>/i, (_tag, attributes) => {
      const preserved = attributes.replace(/\sdata-platform-theme\s*=\s*["'][^"']*["']/gi, '');
      return `<html${preserved} data-platform-theme="silver">`;
    })
    .replace(/<link\b[^>]*href=["']\/sprite-assets\/(?:platform-product-theme|aeronova-brand)\.css(?:\?[^"']*)?["'][^>]*>\s*/gi, '')
    .replace(/<\/head>/i, `${stylesheet}<link rel="stylesheet" href="/sprite-assets/aeronova-brand.css?v=1"></head>`);
}

module.exports = { withPlatformProductTheme };
