// Owner-requested settings rollout. Only configuration changes; never account balances.
const POLICY_KEY = 'financial_policy_nigeria_october_2026';
const POLICY_PATCH = Object.freeze({
  signupBonus: 2000,
  dailyCheckInReward: 200,
  checkinBonus: 200,
  minimumDeposit: 3000,
  depositMin: 3000,
  withdrawalFeePercent: 10,
  maxWithdrawals: null
});

async function applyFinancialPolicy(pool, defaults) {
  // One statement makes the marker and settings atomic across concurrent starts.
  // Later administrator changes are preserved on every subsequent restart.
  return pool.query(
    `WITH rollout AS (
       INSERT INTO admin_settings(key,value)
       VALUES($1,'{"applied":true}'::jsonb)
       ON CONFLICT(key) DO NOTHING
       RETURNING key
     )
     INSERT INTO admin_settings(key,value)
     SELECT 'financial_config',$2::jsonb FROM rollout WHERE true
     ON CONFLICT(key) DO UPDATE
       SET value=admin_settings.value || $3::jsonb,updated_at=now()
     RETURNING value`,
    [POLICY_KEY, JSON.stringify({ ...defaults, ...POLICY_PATCH }), JSON.stringify(POLICY_PATCH)]
  );
}

async function applyDepositMinimumPolicy(pool, defaults) {
  // Apply only this requested setting once; preserve all other settings and history.
  const patch = { minimumDeposit: 3000, depositMin: 3000 };
  return pool.query(
    `WITH rollout AS (
       INSERT INTO admin_settings(key,value)
       VALUES($1,'{"applied":true}'::jsonb)
       ON CONFLICT(key) DO NOTHING
       RETURNING key
     )
     INSERT INTO admin_settings(key,value)
     SELECT 'financial_config',$2::jsonb FROM rollout WHERE true
     ON CONFLICT(key) DO UPDATE
       SET value=admin_settings.value || $3::jsonb,updated_at=now()
     RETURNING value`,
    ['deposit_minimum_3000_restored_october_14_2026_evening', JSON.stringify({ ...defaults, ...patch }), JSON.stringify(patch)]
  );
}

async function applyWithdrawalWindowPolicy(pool) {
  // Restore the requested schedule once, clearing prior forced opening or closure.
  // Explicit administrator overrides made afterward still survive restarts.
  return pool.query(
    `WITH rollout AS (
       INSERT INTO admin_settings(key,value)
       VALUES($1,'{"applied":true}'::jsonb)
       ON CONFLICT(key) DO NOTHING
       RETURNING key
     )
     INSERT INTO admin_settings(key,value)
     SELECT 'withdraw_override',$2::jsonb FROM rollout WHERE true
     ON CONFLICT(key) DO UPDATE
       SET value=admin_settings.value || $2::jsonb,updated_at=now()
     RETURNING value`,
    ['withdrawal_window_algeria_10_to_midnight_october_14_2026', JSON.stringify({ enabled: false, closed: false })]
  );
}

async function applyWithdrawalMinimumPolicy(pool, defaults) {
  // Apply this requested minimum once, without overwriting later admin adjustments.
  const patch = { minimumWithdrawal: 2000, withdrawalMin: 2000 };
  return pool.query(
    `WITH rollout AS (
       INSERT INTO admin_settings(key,value)
       VALUES($1,'{"applied":true}'::jsonb)
       ON CONFLICT(key) DO NOTHING
       RETURNING key
     )
     INSERT INTO admin_settings(key,value)
     SELECT 'financial_config',$2::jsonb FROM rollout WHERE true
     ON CONFLICT(key) DO UPDATE
       SET value=admin_settings.value || $3::jsonb,updated_at=now()
     RETURNING value`,
    ['withdrawal_minimum_2000_october_2026', JSON.stringify({ ...defaults, ...patch }), JSON.stringify(patch)]
  );
}

async function applySignupBonusPolicy(pool, defaults) {
  // Apply only the new signup reward once, not existing balances or past credits.
  const patch = { signupBonus: 2000 };
  return pool.query(
    `WITH rollout AS (
       INSERT INTO admin_settings(key,value)
       VALUES($1,'{"applied":true}'::jsonb)
       ON CONFLICT(key) DO NOTHING
       RETURNING key
     )
     INSERT INTO admin_settings(key,value)
     SELECT 'financial_config',$2::jsonb FROM rollout WHERE true
     ON CONFLICT(key) DO UPDATE
       SET value=admin_settings.value || $3::jsonb,updated_at=now()
     RETURNING value`,
    ['signup_bonus_2000_october_14_2026', JSON.stringify({ ...defaults, ...patch }), JSON.stringify(patch)]
  );
}

async function applyWithdrawalFrequencyPolicy(pool, defaults) {
  const patch = { maxWithdrawals: 2 };
  return pool.query(
    `WITH rollout AS (
       INSERT INTO admin_settings(key,value)
       VALUES($1,'{"applied":true}'::jsonb)
       ON CONFLICT(key) DO NOTHING RETURNING key
     )
     INSERT INTO admin_settings(key,value)
     SELECT 'financial_config',$2::jsonb FROM rollout WHERE true
     ON CONFLICT(key) DO UPDATE
       SET value=admin_settings.value || $3::jsonb,updated_at=now()
     RETURNING value`,
    ['withdrawal_frequency_two_daily_october_2026', JSON.stringify({...defaults,...patch}), JSON.stringify(patch)]
  );
}

async function applyReferralWithdrawalRatesPolicy(pool, defaults) {
  const patch = { referralCommissionRates: [30, 2, 1], withdrawalFeePercent: 15 };
  // DML-only rollout: update these two settings once, preserving all other
  // configuration, existing payments and subsequent administrator adjustments.
  return pool.query(
    `WITH rollout AS (
       INSERT INTO admin_settings(key,value)
       VALUES($1,'{"applied":true}'::jsonb)
       ON CONFLICT(key) DO NOTHING RETURNING key
     )
     INSERT INTO admin_settings(key,value)
     SELECT 'financial_config',$2::jsonb FROM rollout WHERE true
     ON CONFLICT(key) DO UPDATE
       SET value=admin_settings.value || $3::jsonb,updated_at=now()
     RETURNING value`,
    ['referral_30_2_1_withdrawal_fee_15_october_2026', JSON.stringify({...defaults,...patch}), JSON.stringify(patch)]
  );
}

module.exports = { POLICY_PATCH, applyFinancialPolicy, applyDepositMinimumPolicy, applyWithdrawalWindowPolicy, applyWithdrawalMinimumPolicy, applySignupBonusPolicy, applyWithdrawalFrequencyPolicy, applyReferralWithdrawalRatesPolicy };