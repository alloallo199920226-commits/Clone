const { stripPrimaryNavigation } = require('./customer-navigation-cleanup');
const { withSharedNotifications } = require('./customer-notifications');

const customerDirectories = new Set([
  'accueil_produits_coca_cola',
  'historique_des_depots',
  'historique_des_retraits',
  'historique_du_compte',
  'modal_confirmation_achat_vip1',
  'paiement_gopay',
  'produits_vip_investissement',
  'profil_utilisateur_le_mien',
  'quipe_profil_utilisateur',
  'recharge_paiement_gopay',
  'retrait_d_argent',
  'espace_social',
  'checkout',
  'pages'
]);

const destinations = [
  ['home', '/accueil_produits_coca_cola/code.html', 'Accueil', '<path d="m3 11 9-8 9 8v10h-6v-6H9v6H3z"/>'],
  ['products', '/produits_vip_investissement/code.html', 'Produits', '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>'],
  ['team', '/quipe_profil_utilisateur/code.html', 'Équipe', '<circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2"/><path d="M3 21v-3a6 6 0 0 1 12 0v3m1-7a5 5 0 0 1 5 5v2"/>'],
  ['profile', '/profil_utilisateur_le_mien/code.html', 'Profil', '<circle cx="12" cy="7" r="4"/><path d="M4 21a8 8 0 0 1 16 0z"/>']
];

function isCustomerPage(pathname) {
  if (pathname === '/checkout' || pathname === '/checkout/') return true;
  const parts = pathname.split('/').filter(Boolean);
  return parts.length === 2 && customerDirectories.has(parts[0]) && parts[1].endsWith('.html');
}

function activeDestination(pathname) {
  if (pathname.startsWith('/espace_social/')) return 'home';
  if (pathname.includes('produits_vip_') || pathname.includes('mes-produits') || pathname.includes('modal_confirmation_')) return 'products';
  if (pathname.includes('quipe_') || pathname.includes('historique-equipe')) return 'team';
  if (pathname.includes('profil_utilisateur') || pathname.includes('historique_du_compte') ||
      pathname.includes('solde.html') || pathname.includes('missions.html') ||
      pathname.includes('mot-de-passe.html')) return 'profile';
  return 'home';
}

function navigationMarkup(active) {
  if (active === 'support') {
    const supportItems = destinations.map(item => item[0] === 'team'
      ? ['support', '/pages/service-client.html', 'Service client', '<path d="M4 13v-2a8 8 0 0 1 16 0v2M4 13h3v6H5a2 2 0 0 1-2-2v-2a2 2 0 0 1 1-2Zm16 0h-3v6h2a2 2 0 0 0 2-2v-2a2 2 0 0 0-1-2ZM17 19a5 5 0 0 1-5 2"/>']
      : item);
    return `<nav class="bottom-nav" aria-label="Navigation principale">${supportItems.map(([key,href,label,icon]) =>
      `<a href="${href}"${key==='support'?' class="active" aria-current="page"':''}>${key==='products'
        ? '<img src="/sprite-assets/navigation-drone.webp" alt="" width="28" height="22">'
        : `<svg viewBox="0 0 24 24" aria-hidden="true">${icon}</svg>`}<span>${label}</span></a>`).join('')}</nav>`;
  }
  return `<nav class="sprite-global-nav" aria-label="Navigation principale">
    <svg class="sprite-global-nav__silhouette" viewBox="0 0 1000 180" preserveAspectRatio="none" aria-hidden="true">
      <defs>
        <linearGradient id="sprite-nav-glass" x1="0" y1="0" x2="0.15" y2="1">
          <stop offset="0" stop-color="#0d7550" stop-opacity=".98"/>
          <stop offset=".3" stop-color="#064a35" stop-opacity=".97"/>
          <stop offset="1" stop-color="#022e24" stop-opacity=".99"/>
        </linearGradient>
        <linearGradient id="sprite-nav-edge" x1="0" y1="0" x2="1" y2="0">
          <stop stop-color="#6aff9a" stop-opacity=".25"/>
          <stop offset=".48" stop-color="#d8ffd0" stop-opacity=".86"/>
          <stop offset="1" stop-color="#70ffad" stop-opacity=".38"/>
        </linearGradient>
        <radialGradient id="sprite-nav-well" cx="50%" cy="14%" r="70%">
          <stop stop-color="#67ff80" stop-opacity=".45"/>
          <stop offset=".48" stop-color="#0c8a51" stop-opacity=".25"/>
          <stop offset="1" stop-color="#052f25" stop-opacity="0"/>
        </radialGradient>
      </defs>
      <path class="sprite-global-nav__glass" d="M78 18 C153 5 260 5 347 12 C401 16 420 23 439 55 C453 80 472 99 500 101 C528 99 547 80 561 55 C580 23 599 16 653 12 C740 5 847 5 922 18 C969 26 994 49 997 82 C1000 123 974 153 929 160 C813 177 187 177 71 160 C26 153 0 123 3 82 C6 49 31 26 78 18 Z"/>
      <path class="sprite-global-nav__rim" d="M78 18 C153 5 260 5 347 12 C401 16 420 23 439 55 C453 80 472 99 500 101 C528 99 547 80 561 55 C580 23 599 16 653 12 C740 5 847 5 922 18 C969 26 994 49 997 82 C1000 123 974 153 929 160 C813 177 187 177 71 160 C26 153 0 123 3 82 C6 49 31 26 78 18 Z"/>
      <ellipse class="sprite-global-nav__well" cx="500" cy="93" rx="92" ry="74"/>
    </svg>
    <span class="sprite-global-nav__reflection" aria-hidden="true"></span>
    <span class="sprite-global-nav__dock" aria-hidden="true"></span>
    <img class="sprite-global-nav__bottle" src="/sprite-assets/sprite-bottle_2.png" alt="" aria-hidden="true">
    ${destinations.map(([key, href, label, icon]) => `<a class="sprite-global-nav__item${active === key ? ' is-active' : ''}" href="${href}"${active === key ? ' aria-current="page"' : ''}>
      ${key === 'products' ? '<img class="sprite-global-nav__drone" src="/sprite-assets/navigation-drone.webp" alt="" aria-hidden="true" width="32" height="26">' : `<svg viewBox="0 0 24 24" fill="currentColor" stroke="none" stroke-width="1.8" aria-hidden="true">${icon}</svg>`}
      <span>${label}</span>
    </a>`).join('')}
  </nav>`;
}

function withCustomerNavigation(html, pathname) {
  if (!isCustomerPage(pathname)) return html;
  if (pathname === '/pages/service-client.html' && html.includes('id="support-reference-page"')) {
    return withSharedNotifications(stripPrimaryNavigation(html)
      .replace('</body>', `${navigationMarkup('support')}</body>`));
  }
  // The old footers vary from page to page. Remove them before sending HTML,
  // so a slow connection never displays two navigation bars at once.
  return withSharedNotifications(stripPrimaryNavigation(html)
    .replace('</head>', html.includes('src="/vip-product-images.js"') ? '</head>' : '<script src="/vip-product-images.js"></script></head>')
    .replace(/<link\b[^>]*href=["']\/sprite-assets\/customer-navigation\.css(?:\?[^"']*)?["'][^>]*>/gi, '')
    .replace('</head>', '<link rel="stylesheet" href="/sprite-assets/customer-navigation.css?v=154"></head>')
    .replace('</body>', `${navigationMarkup(activeDestination(pathname))}</body>`));
}

module.exports = { withCustomerNavigation, isCustomerPage, activeDestination };