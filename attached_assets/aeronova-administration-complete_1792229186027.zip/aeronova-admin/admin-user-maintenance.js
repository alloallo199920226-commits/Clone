'use strict';
const crypto = require('node:crypto');
const WEEK = 7 * 24 * 60 * 60 * 1000;
const error = (message, status = 400) => Object.assign(new Error(message), { status });
const digest = ids => crypto.createHash('sha256').update(ids.map(String).join(',')).digest('hex');

function signPreview(payload, secret) {
  if (!secret) throw error('Configuration sécurisée indisponible.', 503);
  const data = Buffer.from(JSON.stringify(payload)).toString('base64url');
  return `${data}.${crypto.createHmac('sha256', secret).update(data).digest('base64url')}`;
}
function verifyPreview(token, secret, now = Date.now()) {
  if (!secret || typeof token !== 'string' || token.length > 2000) throw error('Confirmation invalide.');
  const [data, signature, extra] = token.split('.');
  if (!data || !signature || extra) throw error('Confirmation invalide.');
  const expected = crypto.createHmac('sha256', secret).update(data).digest();
  const actual = Buffer.from(signature, 'base64url');
  if (actual.length !== expected.length || !crypto.timingSafeEqual(actual, expected)) throw error('Confirmation invalide.');
  let payload;
  try { payload = JSON.parse(Buffer.from(data, 'base64url').toString()); } catch { throw error('Confirmation invalide.'); }
  if (!Number.isSafeInteger(payload.count) || payload.count < 0 || !/^[a-f0-9]{64}$/.test(payload.digest) ||
      !Number.isFinite(payload.expires) || payload.expires <= now ||
      !Number.isFinite(Date.parse(payload.cutoff)) || Date.parse(payload.cutoff) > now - WEEK) {
    throw error('Confirmation expirée ou invalide. Recalculez les comptes concernés.', 409);
  }
  return payload;
}
async function snapshot(queryable, cutoff) {
  const users = await queryable.query('SELECT id FROM users WHERE created_at<$1 ORDER BY id', [cutoff]);
  const ids = users.rows.map(row => String(row.id));
  const result = await queryable.query(`SELECT
    (SELECT COALESCE(sum(balance),0)::text FROM accounts WHERE user_id=ANY($1::bigint[])) AS "balanceTotal",
    (SELECT count(*)::int FROM deposits WHERE user_id=ANY($1::bigint[])) AS "depositCount",
    (SELECT count(*)::int FROM withdrawals WHERE user_id=ANY($1::bigint[])) AS "withdrawalCount",
    (SELECT count(*)::int FROM user_vips WHERE user_id=ANY($1::bigint[])) AS "vipCount"`, [ids]);
  return { ids, count: ids.length, digest: digest(ids), cutoff, ...result.rows[0] };
}
function registerUserMaintenance(app, { pool, adminAuth, strictBody, rate, secureEqual, getPassword, getSecret }) {
  app.get('/api/admin/users-purge-preview', adminAuth, async (_req, res, next) => {
    try {
      const cutoff = new Date(Date.now() - WEEK).toISOString();
      const result = await snapshot(pool, cutoff);
      const confirmationToken = signPreview({ cutoff, count: result.count, digest: result.digest, expires: Date.now() + 10 * 60 * 1000 }, getSecret());
      const { ids, digest: ignored, ...summary } = result;
      res.json({ ...summary, confirmationToken });
    } catch (reason) { next(reason); }
  });
  app.post('/api/admin/users-purge', adminAuth, rate,
    strictBody(['confirmationToken', 'confirmation', 'password', 'requestId']), async (req, res, next) => {
      let client;
      try {
        if (!getPassword(req) || !secureEqual(req.body.password, getPassword(req))) throw error('Authentification administrateur requise.', 401);
        if (req.body.confirmation !== 'SUPPRIMER') throw error('Saisissez SUPPRIMER pour confirmer.');
        if (!/^[a-zA-Z0-9_-]{16,120}$/.test(String(req.body.requestId || ''))) throw error('Identifiant de demande invalide.');
        const preview = verifyPreview(req.body.confirmationToken, getSecret());
        client = await pool.connect();
        await client.query('BEGIN');
        await client.query("SET LOCAL lock_timeout='5s'");
        await client.query("SET LOCAL statement_timeout='30s'");
        await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [req.body.requestId]);
        const prior = await client.query("SELECT payload FROM admin_operations WHERE request_id=$1 AND operation_type='purge_old_users'", [req.body.requestId]);
        if (prior.rowCount) { await client.query('COMMIT'); return res.json(prior.rows[0].payload); }
        // Freeze membership and referral rewrites while the preview is checked.
        await client.query('LOCK TABLE users IN SHARE ROW EXCLUSIVE MODE');
        const current = await snapshot(client, preview.cutoff);
        if (current.count !== preview.count || current.digest !== preview.digest) throw error('Les comptes concernés ont changé. Recalculez la prévisualisation.', 409);
        const ids = current.ids;
        // Explicitly release non-cascading financial and referral references.
        await client.query('UPDATE users SET referred_by=NULL WHERE referred_by=ANY($1::bigint[])', [ids]);
        await client.query(`DELETE FROM referral_commissions WHERE beneficiary_id=ANY($1::bigint[]) OR source_user_id=ANY($1::bigint[])
          OR deposit_id IN (SELECT id FROM deposits WHERE user_id=ANY($1::bigint[]))`, [ids]);
        await client.query(`DELETE FROM payment_webhook_events WHERE deposit_id IN (SELECT id FROM deposits WHERE user_id=ANY($1::bigint[]))
          OR (provider='ashtechpay' AND payload->>'merchantReference' IN (SELECT reference FROM payment_orders WHERE user_id=ANY($1::bigint[])))`, [ids]);
        const deleted = await client.query('DELETE FROM users WHERE id=ANY($1::bigint[]) RETURNING id', [ids]);
        if (deleted.rowCount !== current.count) throw error('Suppression incomplète : aucune modification conservée.', 409);
        const payload = { ok: true, deletedUsers: deleted.rowCount, cutoff: preview.cutoff,
          deletedDeposits: current.depositCount, deletedWithdrawals: current.withdrawalCount, deletedVips: current.vipCount };
        // No deleted account owns the receipt, so retries remain idempotent.
        await client.query("INSERT INTO admin_operations(request_id,operation_type,user_id,payload) VALUES($1,'purge_old_users',NULL,$2)", [req.body.requestId, JSON.stringify(payload)]);
        await client.query('COMMIT');
        res.json(payload);
      } catch (reason) {
        if (client) await client.query('ROLLBACK').catch(() => {});
        next(reason);
      } finally { client?.release(); }
    });
}
module.exports = { registerUserMaintenance, signPreview, verifyPreview, snapshot };