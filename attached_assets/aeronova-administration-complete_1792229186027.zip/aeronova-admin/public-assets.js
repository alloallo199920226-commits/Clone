'use strict';
const path = require('node:path');
const directories = new Set([
  'accueil_produits_coca_cola', 'checkout', 'connexion', 'espace_social',
  'historique_des_depots', 'historique_des_retraits', 'historique_du_compte',
  'inscription_s_lection_pays', 'modal_confirmation_achat_vip1', 'pages',
  'paiement_gopay', 'produits_vip_investissement', 'profil_utilisateur_le_mien',
  'quipe_profil_utilisateur', 'recharge_paiement_gopay', 'retrait_d_argent', 'sprite-assets'
]);
const rootFiles = new Set([
  'index.html', 'app.css', 'app.js', 'sprite-auth.css', 'nav-speed.js',
  'network-runtime.js', 'vip-product-images.js', 'sw.js', 'favicon.svg', 'favicon.ico'
]);
const webExtensions = new Set(['.html', '.css', '.js', '.svg', '.png', '.jpg', '.jpeg', '.webp', '.gif', '.ico', '.woff', '.woff2', '.ttf', '.mp4', '.webm', '.mp3', '.ogg']);
const mediaExtensions = new Set(['.svg', '.png', '.jpg', '.jpeg', '.webp', '.gif', '.woff', '.woff2', '.ttf', '.mp4', '.webm', '.mp3', '.ogg']);
function isPublicAsset(rawPath) {
  let decoded;
  try { decoded = decodeURIComponent(rawPath); } catch { return false; }
  if (decoded.includes('\\') || decoded.includes('\0')) return false;
  const parts = decoded.split('/').filter(Boolean);
  if (parts.some(part => part.startsWith('.') || part === '..')) return false;
  if (parts.length === 1) return rootFiles.has(parts[0]);
  const extension = path.extname(parts.at(-1)).toLowerCase();
  if (parts[0] === 'attached_assets') return mediaExtensions.has(extension);
  return directories.has(parts[0]) && webExtensions.has(extension);
}
module.exports = { isPublicAsset };