(() => {
  if (window.__cocaNavigationInitialized) return;
  window.__cocaNavigationInitialized = true;
  const base = location.pathname.split('/').slice(0, -2).join('/') + '/';
  const pages = {
    login: 'connexion/code.html',
    home: 'accueil_produits_coca_cola/code.html',
    products: 'produits_vip_investissement/code.html',
    team: 'quipe_profil_utilisateur/code.html',
    profile: 'profil_utilisateur_le_mien/code.html',
    recharge: 'recharge_paiement_gopay/code.html',
    withdraw: 'retrait_d_argent/code.html',
    history: 'historique_des_retraits/code.html',
    purchase: 'modal_confirmation_achat_vip1/code.html'
  };
  const go = (key) => { location.href = base + pages[key]; };
  const current = location.pathname;
  document.documentElement.classList.add('app-responsive');
  const oldNavSelectors = [
    '[data-purpose="main-bottom-nav"]',
    '[data-purpose="tab-bar"]',
    '[data-purpose="bottom-tab-bar"]'
  ];
  document.querySelectorAll(oldNavSelectors.join(',')).forEach(nav => nav.remove());
  if (current.includes('accueil_produits')) {
    document.querySelectorAll('nav.fixed.bottom-0').forEach(nav => nav.remove());
  }

  document.documentElement.classList.remove('app-has-footer-nav');
  document.querySelectorAll('.app-quick-nav').forEach(nav => nav.remove());

  const message = sessionStorage.getItem('appMessage');
  if (message) {
    sessionStorage.removeItem('appMessage');
    const toast = document.createElement('div');
    toast.className = 'app-toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3300);
  }
  const notifyAndGo = (message, key) => {
    sessionStorage.setItem('appMessage', message);
    go(key);
  };
  const showError = (message) => {
    document.querySelector('.app-toast')?.remove();
    const toast = document.createElement('div');
    toast.className = 'app-toast app-toast-error';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3300);
  };

  const registration = document.getElementById('registration-form');
  if (registration && !registration.hasAttribute('data-custom-registration')) {
    registration.addEventListener('submit', (event) => {
      event.preventDefault();
      notifyAndGo('Compte créé avec succès. Bienvenue !', 'home');
    });
  }
  const login = document.getElementById('login-form');
  if (login) login.addEventListener('submit', (event) => {
    event.preventDefault();
    sessionStorage.setItem('isAuthenticated', 'true');
    notifyAndGo('Connexion réussie. Bienvenue !', 'home');
  });
  document.getElementById('logout-button')?.addEventListener('click', (event) => {
    event.preventDefault();
    sessionStorage.clear();
    localStorage.removeItem('rememberedSession');
    location.replace(base + pages.login);
  });

  if (current.includes('accueil_produits') || current.includes('profil_utilisateur') || current.includes('quipe_')) {
    document.addEventListener('click', (event) => {
      const target = event.target.closest('button, a');
      if (!target || target.closest('a[href]')) return;
      const text = target.textContent.trim().toLowerCase();
      if (text.includes('recharg')) { event.preventDefault(); go('recharge'); }
      else if (text.includes('retir')) { event.preventDefault(); go('withdraw'); }
      else if (text.includes('historique')) { event.preventDefault(); go('history'); }
    });
  }

  if (current.includes('produits_vip')) {
    document.querySelectorAll('[data-purpose="product-card"]').forEach(card => {
      card.querySelector('button')?.addEventListener('click', () => {
        const name = card.querySelector('h2')?.textContent.trim() || 'VIP1';
        const lines = [...card.querySelectorAll('.details span')].map(node => node.textContent.trim());
        const valueAfter = (label, fallback) => {
          const line = lines.find(text => text.includes(label));
          return line?.match(/FCFA\s[\d,]+/)?.[0] || fallback;
        };
        const product = {
          name,
          price: valueAfter('Prix', 'FCFA 3,000'),
          daily: valueAfter('Revenu quotidien', 'FCFA 430'),
          total: valueAfter('Revenu total', 'FCFA 38,700')
        };
        sessionStorage.setItem('selectedProduct', JSON.stringify(product));
        go('purchase');
      });
    });
  }

  if (current.includes('modal_confirmation')) {
    const product = JSON.parse(sessionStorage.getItem('selectedProduct') || '{"name":"VIP1","price":"FCFA 3,000","daily":"FCFA 430","total":"FCFA 38,700"}');
    document.getElementById('modal-vip-title').textContent = product.name;
    const textNodes = [...document.querySelectorAll('div')];
    const price = textNodes.find(node => node.children.length === 0 && node.textContent.trim() === 'FCFA 3,000');
    if (price) price.textContent = product.price;
    const daily = textNodes.find(node => node.textContent.trim().startsWith('Revenu quotidien :'));
    if (daily) daily.textContent = `Revenu quotidien : ${product.daily}`;
    const total = textNodes.find(node => node.textContent.trim().startsWith('Revenu total :'));
    if (total) total.textContent = `Revenu total : ${product.total}`;
    document.querySelector('[data-purpose="btn-cancel"]')?.addEventListener('click', () => go('products'));
  }

  if (current.includes('retrait_d_argent')) {
    document.getElementById('confirm-button')?.addEventListener('click', () => {
      const amount = Number(document.getElementById('withdraw-amount')?.value);
      if (!Number.isFinite(amount) || amount < 2000) {
        showError('Le montant minimum de retrait est de 2 000 FCFA.');
        return;
      }
      if (amount > 2000) {
        showError('Le montant dépasse votre solde disponible.');
        return;
      }
      const withdrawal = {
        amount,
        received: amount * 0.90,
        reference: `T${Date.now()}`,
        date: new Date().toLocaleString('fr-FR')
      };
      localStorage.setItem('lastWithdrawal', JSON.stringify(withdrawal));
      notifyAndGo(`Demande de retrait de ${amount.toLocaleString('fr-FR')} FCFA enregistrée.`, 'history');
    });
    document.querySelector('[aria-label="Historique"]')?.addEventListener('click', () => go('history'));
  }

  if (current.includes('historique_des_retraits')) {
    try {
      const withdrawal = JSON.parse(localStorage.getItem('lastWithdrawal'));
      if (withdrawal?.amount) {
        const list = document.querySelector('[data-purpose="orders-list"]');
        const card = document.createElement('article');
        card.className = 'card-outline bg-white px-3.5 pt-2.5 pb-2 text-[15px] font-normal';
        card.innerHTML = `
          <div class="flex justify-between items-center pb-2">
            <span class="font-bold text-gray-900">Ordre de retrait</span>
            <span class="font-bold text-gray-900">FCFA ${withdrawal.amount.toLocaleString('fr-FR')}</span>
          </div>
          <div class="dotted-divider"></div>
          <div class="flex justify-between items-center py-2.5"><span>Réf. commande</span><span>${withdrawal.reference}</span></div>
          <div class="solid-divider"></div>
          <div class="flex justify-between items-center py-2.5"><span>Montant reçu</span><span>FCFA ${withdrawal.received.toLocaleString('fr-FR')}</span></div>
          <div class="solid-divider"></div>
          <div class="flex justify-between items-center py-2.5"><span>État</span><span class="text-[#eab308]">Paiement en cours</span></div>
          <div class="solid-divider"></div>
          <div class="flex justify-between items-center pt-2.5 pb-1"><span>Temps</span><span>${withdrawal.date}</span></div>`;
        list?.prepend(card);
      }
    } catch (_) {
      localStorage.removeItem('lastWithdrawal');
    }
  }

  document.querySelectorAll('[aria-label*="Retour"], [aria-label*="Back"], #nav-back-btn')
    .forEach(button => button.addEventListener('click', () => {
      if (history.length > 1) history.back(); else go('home');
    }));
})();

(() => {
  if (window.__cocaHydrationInitialized) return;
  window.__cocaHydrationInitialized = true;
  const api = async (url, options = {}) => {
    const response = await fetch(url, {
      credentials: 'same-origin',
      ...options,
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Une erreur est survenue.');
    return data;
  };
  const formatMoney = value => `FCFA ${Number(value || 0).toLocaleString('fr-FR')}`;
  const toast = (message, error = false) => {
    document.querySelector('.api-toast')?.remove();
    const node = document.createElement('div');
    node.className = `app-toast api-toast${error ? ' app-toast-error' : ''}`;
    node.textContent = message;
    document.body.appendChild(node);
    setTimeout(() => node.remove(), 4000);
  };
  const home = '../accueil_produits_coca_cola/code.html';
  const login = '../connexion/code.html';
  const isAuthPage = location.pathname.includes('/connexion/') || location.pathname.includes('inscription_') || location.pathname === '/register';

  document.addEventListener('submit', async event => {
    const form = event.target;
    if (form.id !== 'login-form' && form.id !== 'registration-form') return;
    event.preventDefault();
    event.stopImmediatePropagation();
    const submit = form.querySelector('[type="submit"]');
    if (submit?.disabled) return;
    if (form.id === 'registration-form' && !form.querySelector('[name="country"]')?.value) {
      form.querySelector('#country-error')?.classList.add('show');
      return toast('Veuillez sélectionner votre pays.', true);
    }
    if (form.id === 'login-form' && !form.querySelector('[name="dialCode"]')?.value) {
      form.querySelector('#login-country-error')?.classList.add('show');
      return toast('Veuillez sélectionner votre pays.', true);
    }
    if (!form.checkValidity()) return form.reportValidity();
    submit && (submit.disabled = true);
    try {
      if (form.id === 'registration-form') {
        const password = form.querySelector('#password').value;
        if (password !== form.querySelector('#confirm-password').value) throw new Error('Les mots de passe ne correspondent pas.');
        const result = await api('/api/auth/register', {
          method: 'POST',
          body: JSON.stringify({
            country: form.querySelector('[name="country"]').value,
            phone: `${form.querySelector('[name="dialCode"]')?.value || ''}${form.querySelector('[name="phone"]').value}`,
            password,
            referralCode: form.querySelector('[name="referral_code"]').value
          })
        });
        sessionStorage.setItem('appMessage', `Compte créé. Bonus de ${formatMoney(result.bonus)} crédité.`);
        location.href = home;
      } else {
        await api('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({
            phone: `${form.querySelector('[name="dialCode"]')?.value || ''}${form.querySelector('[name="phone"]').value}`,
            localPhone: form.querySelector('[name="phone"]').value,
            password: form.querySelector('[name="password"]').value,
            remember: Boolean(form.querySelector('[type="checkbox"]')?.checked)
          })
        });
        sessionStorage.setItem('appMessage', 'Connexion réussie.');
        location.href = home;
      }
    } catch (error) {
      toast(error.message, true);
      submit && (submit.disabled = false);
    }
  }, true);

  document.addEventListener('click', async event => {
    const confirmPurchase = event.target.closest('[data-purpose="btn-confirm"]');
    const deposit = event.target.closest('#confirm');
    const logout = event.target.closest('#logout-button');
    if (logout) {
      event.preventDefault(); event.stopImmediatePropagation();
      try { await api('/api/auth/logout', { method: 'POST' }); } catch {}
      location.replace(login);
      return;
    }
    if (confirmPurchase && location.pathname.includes('modal_confirmation')) {
      event.preventDefault(); event.stopImmediatePropagation();
      const product = JSON.parse(sessionStorage.getItem('selectedProduct') || '{"name":"VIP1"}');
      confirmPurchase.disabled = true;
      try {
        await api('/api/vips/purchase', { method: 'POST', body: JSON.stringify({ code: product.name }) });
        sessionStorage.removeItem('selectedProduct');
        sessionStorage.setItem('appMessage', `Achat ${product.name} confirmé.`);
        location.href = '../pages/mes-produits.html';
      } catch (error) { toast(error.message, true); confirmPurchase.disabled = false; }
      return;
    }
    if (deposit && location.pathname.includes('recharge_') && !location.pathname.includes('recharge_paiement_gopay')) {
      event.preventDefault(); event.stopImmediatePropagation();
      const amount = Number(document.querySelector('#value')?.value);
      deposit.disabled = true;
      try {
        const result = await api('/api/deposits', { method: 'POST', body: JSON.stringify({ amount }) });
        toast(`${result.message} Référence : ${result.reference}`);
      } catch (error) { toast(error.message, true); } finally { deposit.disabled = false; }
      return;
    }
    if (deposit && location.pathname.includes('retrait_')) {
      event.preventDefault(); event.stopImmediatePropagation();
      const amount = Number(document.querySelector('#amount')?.value);
      const status = document.querySelector('#status');
      deposit.dataset.state = 'loading';
      deposit.setAttribute('aria-busy', 'true');
      if (status) status.textContent = '';
      deposit.disabled = true;
      try {
        const result = await api('/api/withdrawals', {
          method: 'POST',
          body: JSON.stringify({ amount, walletId: Number(document.querySelector('#walletTitle')?.dataset.walletId) || null })
        });
        deposit.dataset.state = 'success';
        if (status) status.textContent = 'Retrait enregistré.';
        sessionStorage.setItem('appMessage', `Retrait ${result.reference} enregistré.`);
        location.href = '../historique_des_retraits/code.html';
      } catch (error) {
        deposit.dataset.state = 'error';
        if (status) status.textContent = error.message;
        toast(error.message, true);
        deposit.disabled = false;
      } finally {
        deposit.removeAttribute('aria-busy');
      }
    }
  }, true);

  async function hydrate() {
    const config = await api('/api/config/public');
    const rates = config.referralCommissionRates;
    document.querySelectorAll('[data-config="daily-checkin-reward"]').forEach(node => {
      node.innerHTML = `Récompense de connexion quotidienne de <b>${Number(config.dailyCheckInReward).toLocaleString('fr-FR')} FCFA.</b>`;
    });
    document.querySelectorAll('[data-config="signup-bonus"]').forEach(node => {
      node.innerHTML = `Inscrivez-vous maintenant et recevez <b>${Number(config.signupBonus).toLocaleString('fr-FR')} FCFA !</b>`;
    });
    document.querySelectorAll('[data-config="referral-rates"]').forEach(node => {
      node.innerHTML = `Recevez <b>${rates.join(' %, ')} %</b> sur le premier dépôt validé de vos filleuls.`;
    });
    document.querySelectorAll('[data-config="deposit-rule"]').forEach(node => {
      const image = node.querySelector('img')?.outerHTML || '';
      node.innerHTML = `${image}Dépôt minimum : ${Number(config.minimumDeposit).toLocaleString('fr-FR')} FCFA. Confirmation requise avant crédit.`;
    });
    document.querySelectorAll('[data-config="withdrawal-rule"]').forEach(node => {
      const dailyLimit = config.maxWithdrawals === null ? 'Sans limite quotidienne' : `${Number(config.maxWithdrawals)} retraits par jour`;
      node.innerHTML = `Retrait minimum de <b>${Number(config.minimumWithdrawal).toLocaleString('fr-FR')} FCFA</b>, avec un VIP actif. Ouvert chaque jour de 10 h 00 (inclus) à 00 h 00 (minuit, exclus), heure de l’Algérie (Africa/Algiers). Maximum : <b>${dailyLimit}</b>. Aucun nouveau retrait tant qu’un retrait est en attente. Frais : <b>${config.withdrawalFeePercent} %</b>.`;
    });
    document.querySelectorAll('[data-config="withdrawal-limit"]').forEach(node => {
      node.textContent = config.maxWithdrawals === null ? 'Aucune limite quotidienne de retraits.' : `Maximum : ${Number(config.maxWithdrawals)} retraits par jour.`;
    });
    document.querySelectorAll('[data-config="withdrawal-minimum"]').forEach(node => {
      node.textContent = `Le montant minimum de retrait est de ${Number(config.minimumWithdrawal).toLocaleString('fr-FR')} FCFA.`;
    });
    document.querySelectorAll('[data-config="withdrawal-fee"]').forEach(node => {
      node.textContent = `${Number(config.withdrawalFeePercent).toFixed(2)}%`;
    });
    document.querySelectorAll('[data-config="withdrawal-fee-label"]').forEach(node => {
      node.textContent = `Frais de retrait : ${config.withdrawalFeePercent} %.`;
    });
    const withdrawalInput = document.querySelector('#amount');
    if (withdrawalInput && location.pathname.includes('retrait_')) {
      withdrawalInput.min = String(config.minimumWithdrawal);
      withdrawalInput.addEventListener('input', () => {
        const amount = Math.max(0, Number(withdrawalInput.value) || 0);
        const net = amount - Math.floor(amount * Number(config.withdrawalFeePercent) / 100);
        const received = document.querySelector('#received');
        if (received) received.textContent = `FCFA ${net.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      });
      if (withdrawalInput.value) withdrawalInput.dispatchEvent(new Event('input', { bubbles: true }));
    }
    if (isAuthPage) return;
    try {
      const me = await api('/api/me');
      const strongs = [...document.querySelectorAll('strong')];
      const balanceLabels = [...document.querySelectorAll('small,span')].filter(n => n.textContent.trim() === 'Solde du compte');
      balanceLabels.forEach(label => {
        const container = label.closest('.bal,.balance');
        const value = container?.querySelector('strong');
        if (value) {
          const balance = me.account?.balance;
          value.textContent = location.pathname.includes('profil_utilisateur_le_mien')
            ? balance != null && Number.isFinite(Number(balance))
              ? `FCFA ${Number(balance).toLocaleString('en-US')}`
              : 'FCFA —'
            : formatMoney(balance);
        }
      });
      const revenueLabels = [...document.querySelectorAll('small,span')].filter(n => /Revenu cumulé/i.test(n.textContent));
      revenueLabels.forEach(label => {
        const container = label.closest('.bal,.balance');
        const value = container?.querySelector('strong');
        if (value) {
          const earnings = me.account?.cumulative_earnings;
          value.textContent = location.pathname.includes('profil_utilisateur_le_mien')
            ? earnings != null && Number.isFinite(Number(earnings))
              ? `FCFA ${Number(earnings).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
              : 'FCFA —'
            : formatMoney(earnings);
        }
      });
      if (location.pathname.includes('quipe_')) {
        const referrals = await api('/api/referrals');
        const link = `${location.origin}/register?ref=${referrals.referralCode}`;
        const codeNode = document.querySelector('#invite-code');
        const linkNode = document.querySelector('#invite-link');
        if (codeNode) codeNode.textContent = referrals.referralCode;
        if (linkNode) linkNode.textContent = link;
        document.querySelectorAll('.copy').forEach((button, index) => { button.dataset.copy = index ? link : referrals.referralCode; button.disabled = false; });
        const teamValue = document.querySelector('.stats .stat:first-child strong');
        if (teamValue) teamValue.textContent = referrals.directReferrals;
        const commissionValue = strongs.find(n => n.textContent.includes('FCFA 0.00'));
        if (commissionValue) commissionValue.textContent = formatMoney(referrals.totalCommission);
        document.querySelectorAll('.level').forEach((card, index) => {
          const level = referrals.levels[index];
          const values = card.querySelectorAll('.columns strong');
          if (!level || values.length < 3) return;
          values[0].textContent = `${level.rate}%`;
          values[1].textContent = level.memberCount;
          values[2].textContent = formatMoney(level.commission);
        });
      }
      if (location.pathname.includes('/pages/historique-equipe.html') && !window.teamHistoryOwnsRendering) {
        const referrals = await api('/api/referrals');
        window.backendReferralLevels = referrals.levels;
        const renderBackendLevel = levelNumber => {
          const level = referrals.levels.find(item => item.level === levelNumber);
          const members = level?.members || [];
          const memberCount = document.querySelector('#memberCount');
          const depositTotal = document.querySelector('#depositTotal');
          const list = document.querySelector('#members');
          if (memberCount) memberCount.textContent = level?.memberCount || 0;
          if (depositTotal) depositTotal.textContent = formatMoney(level?.completedDeposits || 0);
          if (list) list.innerHTML = members.length ? members.map(member => `
            <div class="member"><span class="member-logo"><img src="assets/account-logo.png" alt=""></span>
            <span><p>Compte : <b>${member.account}</b></p><small>Date : ${new Date(member.joinedAt).toLocaleString('fr-FR')}</small></span>
            <strong class="money">${formatMoney(member.completedDeposits)}</strong></div>`).join('') :
            '<div class="empty">Aucune activité réelle pour ce niveau.</div>';
        };
        renderBackendLevel(1);
        document.querySelectorAll('.tab').forEach(button => {
          button.addEventListener('click', () => renderBackendLevel(Number(button.dataset.level)));
        });
      }
      if (location.pathname.includes('/pages/mes-produits.html') && !window.mesProduitsOwnsRendering) {
        const data = await api('/api/vips/mine');
        const images = { VIP1: 'vip1.webp', VIP2: 'vip2.webp', VIP3: 'vip3.webp' };
        const list = document.querySelector('#list');
        const active = data.purchases.filter(p => p.status === 'active' && new Date(p.expires_at) > new Date());
        document.querySelector('#count').textContent = `${active.length} produit${active.length > 1 ? 's' : ''} actif${active.length > 1 ? 's' : ''}`;
        list.innerHTML = data.purchases.length ? data.purchases.map(p => `
          <article class="product"><img class="photo" style="object-fit:contain" src="${window.vipProductImages.imageFor(p)}" alt="${p.name}">
          <div><h2>${p.name}</h2><span class="status">${p.status === 'active' ? 'Actif' : 'Expiré'}</span>
          <div class="details"><span>Prix : <b>${formatMoney(p.price)}</b></span>
          <span>Revenu quotidien : <b>${formatMoney(p.daily_income)}</b></span>
          <span>Expire le ${new Date(p.expires_at).toLocaleDateString('fr-FR')}</span>
          <span>Acheté le ${new Date(p.purchased_at).toLocaleDateString('fr-FR')}</span></div></div></article>`).join('') :
          '<section class="empty"><h2>Aucun produit acheté</h2><p>Vos produits VIP apparaîtront ici.</p><a href="../produits_vip_investissement/code.html">Découvrir les produits</a></section>';
      }
      if (location.pathname.includes('/pages/missions.html') && !window.missionsOwnsRendering) {
        const data = await api('/api/missions');
        const root = document.querySelector('#missions');
        root.innerHTML = data.missions.length ? data.missions.map((m, index) => {
          const goal = Number(m.target_value), current = Number(m.current), pct = Math.min(100, Math.round(current / goal * 100));
          return `<article class="mission"><span class="badge">Lv${index + 1}</span><p>${m.title} : <b>${formatMoney(m.reward)}</b></p>
            <div class="numbers"><div><strong>${current}</strong><span>Actuel</span></div><div><strong>${goal}</strong><span>Objectif</span></div><div><strong>${current}/${goal}</strong><span>Progression</span></div></div>
            <div class="progress"><i style="width:${pct}%"></i><span>${m.claimed ? 'Réclamée' : m.completed ? 'Touchez pour réclamer' : 'En cours'}</span></div>
            ${m.completed && !m.claimed ? `<button class="api-claim" data-mission="${m.id}" style="width:100%;margin-top:8px;border:0;border-radius:18px;padding:8px;color:#fff;background:#e50914">Réclamer ${formatMoney(m.reward)}</button>` : ''}</article>`;
        }).join('') : '<section class="empty">Aucune mission disponible actuellement.</section>';
      }
      if (location.pathname.includes('historique_des_retraits') && !window.withdrawalHistoryOwnsRendering) {
        const data = await api('/api/withdrawals');
        const list = document.querySelector('#list');
        list.innerHTML = data.withdrawals.length ? data.withdrawals.map(w => `
          <article class="withdrawal"><header class="card-head"><span class="wallet">▣</span><h2>Ordre de retrait</h2><strong class="amount">${formatMoney(w.amount)}</strong></header>
          <div class="rows"><div class="row"><span>▣</span><span class="label">Réf. commande</span><span class="value">${w.reference}</span></div>
          <div class="row"><span>◈</span><span class="label">Montant reçu</span><span class="value">${formatMoney(w.net_amount)}</span></div>
          <div class="row"><span>◷</span><span class="label">État</span><span class="badge ${w.status}">${w.status === 'pending' ? 'Paiement en cours' : w.status}</span></div>
          <div class="row"><span>◷</span><span class="label">Temps</span><span class="value">${new Date(w.created_at).toLocaleString('fr-FR')}</span></div></div></article>`).join('') :
          '<div class="empty">Aucun retrait enregistré.</div>';
      }
    } catch (error) {
      if (error.message.includes('Authentification') || error.message.includes('Session')) location.replace(login);
      else toast(error.message, true);
    }
  }
  const ref = new URLSearchParams(location.search).get('ref');
  const refInput = document.querySelector('[name="referral_code"]');
  if (ref && refInput) refInput.value = ref;
  document.addEventListener('click', async event => {
    const claim = event.target.closest('.api-claim');
    if (!claim) return;
    claim.disabled = true;
    try {
      const result = await api(`/api/missions/${claim.dataset.mission}/claim`, { method: 'POST' });
      toast(`Récompense de ${formatMoney(result.reward)} créditée.`);
      setTimeout(() => location.reload(), 700);
    } catch (error) { toast(error.message, true); claim.disabled = false; }
  });
  hydrate();
})();(() => {
  if (window.__cocaNavigationInitialized) return;
  window.__cocaNavigationInitialized = true;
  const base = location.pathname.split('/').slice(0, -2).join('/') + '/';
  const pages = {
    login: 'connexion/code.html',
    home: 'accueil_produits_coca_cola/code.html',
    products: 'produits_vip_investissement/code.html',
    team: 'quipe_profil_utilisateur/code.html',
    profile: 'profil_utilisateur_le_mien/code.html',
    recharge: 'recharge_paiement_gopay/code.html',
    withdraw: 'retrait_d_argent/code.html',
    history: 'historique_des_retraits/code.html',
    purchase: 'modal_confirmation_achat_vip1/code.html'
  };
  const go = (key) => { location.href = base + pages[key]; };
  const current = location.pathname;
  document.documentElement.classList.add('app-responsive');
  const oldNavSelectors = [
    '[data-purpose="main-bottom-nav"]',
    '[data-purpose="tab-bar"]',
    '[data-purpose="bottom-tab-bar"]'
  ];
  document.querySelectorAll(oldNavSelectors.join(',')).forEach(nav => nav.remove());
  if (current.includes('accueil_produits')) {
    document.querySelectorAll('nav.fixed.bottom-0').forEach(nav => nav.remove());
  }

  document.documentElement.classList.remove('app-has-footer-nav');
  document.querySelectorAll('.app-quick-nav').forEach(nav => nav.remove());

  const message = sessionStorage.getItem('appMessage');
  if (message) {
    sessionStorage.removeItem('appMessage');
    const toast = document.createElement('div');
    toast.className = 'app-toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3300);
  }
  const notifyAndGo = (message, key) => {
    sessionStorage.setItem('appMessage', message);
    go(key);
  };
  const showError = (message) => {
    document.querySelector('.app-toast')?.remove();
    const toast = document.createElement('div');
    toast.className = 'app-toast app-toast-error';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3300);
  };

  const registration = document.getElementById('registration-form');
  if (registration && !registration.hasAttribute('data-custom-registration')) {
    registration.addEventListener('submit', (event) => {
      event.preventDefault();
      notifyAndGo('Compte créé avec succès. Bienvenue !', 'home');
    });
  }
  const login = document.getElementById('login-form');
  if (login) login.addEventListener('submit', (event) => {
    event.preventDefault();
    sessionStorage.setItem('isAuthenticated', 'true');
    notifyAndGo('Connexion réussie. Bienvenue !', 'home');
  });
  document.getElementById('logout-button')?.addEventListener('click', (event) => {
    event.preventDefault();
    sessionStorage.clear();
    localStorage.removeItem('rememberedSession');
    location.replace(base + pages.login);
  });

  if (current.includes('accueil_produits') || current.includes('profil_utilisateur') || current.includes('quipe_')) {
    document.addEventListener('click', (event) => {
      const target = event.target.closest('button, a');
      if (!target || target.closest('a[href]')) return;
      const text = target.textContent.trim().toLowerCase();
      if (text.includes('recharg')) { event.preventDefault(); go('recharge'); }
      else if (text.includes('retir')) { event.preventDefault(); go('withdraw'); }
      else if (text.includes('historique')) { event.preventDefault(); go('history'); }
    });
  }

  if (current.includes('produits_vip')) {
    document.querySelectorAll('[data-purpose="product-card"]').forEach(card => {
      card.querySelector('button')?.addEventListener('click', () => {
        const name = card.querySelector('h2')?.textContent.trim() || 'VIP1';
        const lines = [...card.querySelectorAll('.details span')].map(node => node.textContent.trim());
        const valueAfter = (label, fallback) => {
          const line = lines.find(text => text.includes(label));
          return line?.match(/FCFA\s[\d,]+/)?.[0] || fallback;
        };
        const product = {
          name,
          price: valueAfter('Prix', 'FCFA 3,000'),
          daily: valueAfter('Revenu quotidien', 'FCFA 430'),
          total: valueAfter('Revenu total', 'FCFA 38,700')
        };
        sessionStorage.setItem('selectedProduct', JSON.stringify(product));
        go('purchase');
      });
    });
  }

  if (current.includes('modal_confirmation')) {
    const product = JSON.parse(sessionStorage.getItem('selectedProduct') || '{"name":"VIP1","price":"FCFA 3,000","daily":"FCFA 430","total":"FCFA 38,700"}');
    document.getElementById('modal-vip-title').textContent = product.name;
    const textNodes = [...document.querySelectorAll('div')];
    const price = textNodes.find(node => node.children.length === 0 && node.textContent.trim() === 'FCFA 3,000');
    if (price) price.textContent = product.price;
    const daily = textNodes.find(node => node.textContent.trim().startsWith('Revenu quotidien :'));
    if (daily) daily.textContent = `Revenu quotidien : ${product.daily}`;
    const total = textNodes.find(node => node.textContent.trim().startsWith('Revenu total :'));
    if (total) total.textContent = `Revenu total : ${product.total}`;
    document.querySelector('[data-purpose="btn-cancel"]')?.addEventListener('click', () => go('products'));
  }

  if (current.includes('retrait_d_argent')) {
    document.getElementById('confirm-button')?.addEventListener('click', () => {
      const amount = Number(document.getElementById('withdraw-amount')?.value);
      if (!Number.isFinite(amount) || amount < 2000) {
        showError('Le montant minimum de retrait est de 2 000 FCFA.');
        return;
      }
      if (amount > 2000) {
        showError('Le montant dépasse votre solde disponible.');
        return;
      }
      const withdrawal = {
        amount,
        received: amount * 0.90,
        reference: `T${Date.now()}`,
        date: new Date().toLocaleString('fr-FR')
      };
      localStorage.setItem('lastWithdrawal', JSON.stringify(withdrawal));
      notifyAndGo(`Demande de retrait de ${amount.toLocaleString('fr-FR')} FCFA enregistrée.`, 'history');
    });
    document.querySelector('[aria-label="Historique"]')?.addEventListener('click', () => go('history'));
  }

  if (current.includes('historique_des_retraits')) {
    try {
      const withdrawal = JSON.parse(localStorage.getItem('lastWithdrawal'));
      if (withdrawal?.amount) {
        const list = document.querySelector('[data-purpose="orders-list"]');
        const card = document.createElement('article');
        card.className = 'card-outline bg-white px-3.5 pt-2.5 pb-2 text-[15px] font-normal';
        card.innerHTML = `
          <div class="flex justify-between items-center pb-2">
            <span class="font-bold text-gray-900">Ordre de retrait</span>
            <span class="font-bold text-gray-900">FCFA ${withdrawal.amount.toLocaleString('fr-FR')}</span>
          </div>
          <div class="dotted-divider"></div>
          <div class="flex justify-between items-center py-2.5"><span>Réf. commande</span><span>${withdrawal.reference}</span></div>
          <div class="solid-divider"></div>
          <div class="flex justify-between items-center py-2.5"><span>Montant reçu</span><span>FCFA ${withdrawal.received.toLocaleString('fr-FR')}</span></div>
          <div class="solid-divider"></div>
          <div class="flex justify-between items-center py-2.5"><span>État</span><span class="text-[#eab308]">Paiement en cours</span></div>
          <div class="solid-divider"></div>
          <div class="flex justify-between items-center pt-2.5 pb-1"><span>Temps</span><span>${withdrawal.date}</span></div>`;
        list?.prepend(card);
      }
    } catch (_) {
      localStorage.removeItem('lastWithdrawal');
    }
  }

  document.querySelectorAll('[aria-label*="Retour"], [aria-label*="Back"], #nav-back-btn')
    .forEach(button => button.addEventListener('click', () => {
      if (history.length > 1) history.back(); else go('home');
    }));
})();

(() => {
  if (window.__cocaHydrationInitialized) return;
  window.__cocaHydrationInitialized = true;
  const api = async (url, options = {}) => {
    const response = await fetch(url, {
      credentials: 'same-origin',
      ...options,
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Une erreur est survenue.');
    return data;
  };
  const formatMoney = value => `FCFA ${Number(value || 0).toLocaleString('fr-FR')}`;
  const toast = (message, error = false) => {
    document.querySelector('.api-toast')?.remove();
    const node = document.createElement('div');
    node.className = `app-toast api-toast${error ? ' app-toast-error' : ''}`;
    node.textContent = message;
    document.body.appendChild(node);
    setTimeout(() => node.remove(), 4000);
  };
  const home = '../accueil_produits_coca_cola/code.html';
  const login = '../connexion/code.html';
  const isAuthPage = location.pathname.includes('/connexion/') || location.pathname.includes('inscription_') || location.pathname === '/register';

  document.addEventListener('submit', async event => {
    const form = event.target;
    if (form.id !== 'login-form' && form.id !== 'registration-form') return;
    event.preventDefault();
    event.stopImmediatePropagation();
    const submit = form.querySelector('[type="submit"]');
    if (submit?.disabled) return;
    if (!form.checkValidity()) return form.reportValidity();
    submit && (submit.disabled = true);
    try {
      if (form.id === 'registration-form') {
        const password = form.querySelector('#password').value;
        if (password !== form.querySelector('#confirm-password').value) throw new Error('Les mots de passe ne correspondent pas.');
        const result = await api('/api/auth/register', {
          method: 'POST',
          body: JSON.stringify({
            country: form.querySelector('[name="country"]').value,
            phone: `${form.querySelector('[name="dialCode"]')?.value || ''}${form.querySelector('[name="phone"]').value}`,
            password,
            referralCode: form.querySelector('[name="referral_code"]').value
          })
        });
        sessionStorage.setItem('appMessage', `Compte créé. Bonus de ${formatMoney(result.bonus)} crédité.`);
        location.href = home;
      } else {
        await api('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({
            phone: `${form.querySelector('[name="dialCode"]')?.value || ''}${form.querySelector('[name="phone"]').value}`,
            localPhone: form.querySelector('[name="phone"]').value,
            password: form.querySelector('[name="password"]').value,
            remember: Boolean(form.querySelector('[type="checkbox"]')?.checked)
          })
        });
        sessionStorage.setItem('appMessage', 'Connexion réussie.');
        location.href = home;
      }
    } catch (error) {
      toast(error.message, true);
      submit && (submit.disabled = false);
    }
  }, true);

  document.addEventListener('click', async event => {
    const confirmPurchase = event.target.closest('[data-purpose="btn-confirm"]');
    const deposit = event.target.closest('#confirm');
    const logout = event.target.closest('#logout-button');
    if (logout) {
      event.preventDefault(); event.stopImmediatePropagation();
      try { await api('/api/auth/logout', { method: 'POST' }); } catch {}
      location.replace(login);
      return;
    }
    if (confirmPurchase && location.pathname.includes('modal_confirmation')) {
      event.preventDefault(); event.stopImmediatePropagation();
      const product = JSON.parse(sessionStorage.getItem('selectedProduct') || '{"name":"VIP1"}');
      confirmPurchase.disabled = true;
      try {
        await api('/api/vips/purchase', { method: 'POST', body: JSON.stringify({ code: product.name }) });
        sessionStorage.removeItem('selectedProduct');
        sessionStorage.setItem('appMessage', `Achat ${product.name} confirmé.`);
        location.href = '../pages/mes-produits.html';
      } catch (error) { toast(error.message, true); confirmPurchase.disabled = false; }
      return;
    }
    if (deposit && location.pathname.includes('recharge_') && !location.pathname.includes('recharge_paiement_gopay')) {
      event.preventDefault(); event.stopImmediatePropagation();
      const amount = Number(document.querySelector('#value')?.value);
      deposit.disabled = true;
      try {
        const result = await api('/api/deposits', { method: 'POST', body: JSON.stringify({ amount }) });
        toast(`${result.message} Référence : ${result.reference}`);
      } catch (error) { toast(error.message, true); } finally { deposit.disabled = false; }
      return;
    }
    if (deposit && location.pathname.includes('retrait_')) {
      event.preventDefault(); event.stopImmediatePropagation();
      const amount = Number(document.querySelector('#amount')?.value);
      deposit.disabled = true;
      try {
        const result = await api('/api/withdrawals', {
          method: 'POST',
          body: JSON.stringify({ amount, walletId: Number(document.querySelector('#walletTitle')?.dataset.walletId) || null })
        });
        sessionStorage.setItem('appMessage', `Retrait ${result.reference} enregistré.`);
        location.href = '../historique_des_retraits/code.html';
      } catch (error) { toast(error.message, true); deposit.disabled = false; }
    }
  }, true);

  async function hydrate() {
    const config = await api('/api/config/public');
    const rates = config.referralCommissionRates;
    document.querySelectorAll('[data-config="daily-checkin-reward"]').forEach(node => {
      node.innerHTML = `Récompense de connexion quotidienne de <b>${Number(config.dailyCheckInReward).toLocaleString('fr-FR')} FCFA.</b>`;
    });
    document.querySelectorAll('[data-config="signup-bonus"]').forEach(node => {
      node.innerHTML = `Inscrivez-vous maintenant et recevez <b>${Number(config.signupBonus).toLocaleString('fr-FR')} FCFA !</b>`;
    });
    document.querySelectorAll('[data-config="referral-rates"]').forEach(node => {
      node.innerHTML = `Recevez <b>${rates.join(' %, ')} %</b> sur le premier dépôt validé de vos filleuls.`;
    });
    document.querySelectorAll('[data-config="deposit-rule"]').forEach(node => {
      const image = node.querySelector('img')?.outerHTML || '';
      node.innerHTML = `${image}Dépôt minimum : ${Number(config.minimumDeposit).toLocaleString('fr-FR')} FCFA. Confirmation requise avant crédit.`;
    });
    document.querySelectorAll('[data-config="withdrawal-rule"]').forEach(node => {
      const dailyLimit = config.maxWithdrawals === null ? 'Sans limite quotidienne' : `${Number(config.maxWithdrawals)} retraits par jour`;
      node.innerHTML = `Retrait minimum de <b>${Number(config.minimumWithdrawal).toLocaleString('fr-FR')} FCFA</b>, avec un VIP actif. Ouvert chaque jour de 10 h 00 (inclus) à 00 h 00 (minuit, exclus), heure de l’Algérie (Africa/Algiers). Maximum : <b>${dailyLimit}</b>. Aucun nouveau retrait tant qu’un retrait est en attente. Frais : <b>${config.withdrawalFeePercent} %</b>.`;
    });
    document.querySelectorAll('[data-config="withdrawal-limit"]').forEach(node => {
      node.textContent = config.maxWithdrawals === null ? 'Aucune limite quotidienne de retraits.' : `Maximum : ${Number(config.maxWithdrawals)} retraits par jour.`;
    });
    document.querySelectorAll('[data-config="withdrawal-minimum"]').forEach(node => {
      node.textContent = `Le montant minimum de retrait est de ${Number(config.minimumWithdrawal).toLocaleString('fr-FR')} FCFA.`;
    });
    document.querySelectorAll('[data-config="withdrawal-fee"]').forEach(node => {
      node.textContent = `${Number(config.withdrawalFeePercent).toFixed(2)}%`;
    });
    document.querySelectorAll('[data-config="withdrawal-fee-label"]').forEach(node => {
      node.textContent = `Frais de retrait : ${config.withdrawalFeePercent} %.`;
    });
    const withdrawalInput = document.querySelector('#amount');
    if (withdrawalInput && location.pathname.includes('retrait_')) {
      withdrawalInput.min = String(config.minimumWithdrawal);
      withdrawalInput.addEventListener('input', () => {
        const amount = Math.max(0, Number(withdrawalInput.value) || 0);
        const net = amount - Math.floor(amount * Number(config.withdrawalFeePercent) / 100);
        const received = document.querySelector('#received');
        if (received) received.textContent = formatMoney(net);
      });
    }
    if (isAuthPage) return;
    try {
      const me = await api('/api/me');
      const strongs = [...document.querySelectorAll('strong')];
      const balanceLabels = [...document.querySelectorAll('small,span')].filter(n => n.textContent.trim() === 'Solde du compte');
      balanceLabels.forEach(label => {
        const container = label.closest('.bal,.balance');
        const value = container?.querySelector('strong');
        if (value) value.textContent = formatMoney(me.account.balance);
      });
      const revenueLabels = [...document.querySelectorAll('small,span')].filter(n => /Revenu cumulé/i.test(n.textContent));
      revenueLabels.forEach(label => {
        const container = label.closest('.bal,.balance');
        const value = container?.querySelector('strong');
        if (value) value.textContent = formatMoney(me.account.cumulative_earnings);
      });
      if (location.pathname.includes('quipe_')) {
        const referrals = await api('/api/referrals');
        const link = `${location.origin}/register?ref=${referrals.referralCode}`;
        const codeNode = document.querySelector('#invite-code');
        const linkNode = document.querySelector('#invite-link');
        if (codeNode) codeNode.textContent = referrals.referralCode;
        if (linkNode) linkNode.textContent = link;
        document.querySelectorAll('.copy').forEach((button, index) => { button.dataset.copy = index ? link : referrals.referralCode; button.disabled = false; });
        const teamValue = document.querySelector('.stats .stat:first-child strong');
        if (teamValue) teamValue.textContent = referrals.directReferrals;
        const commissionValue = strongs.find(n => n.textContent.includes('FCFA 0.00'));
        if (commissionValue) commissionValue.textContent = formatMoney(referrals.totalCommission);
        document.querySelectorAll('.level').forEach((card, index) => {
          const level = referrals.levels[index];
          const values = card.querySelectorAll('.columns strong');
          if (!level || values.length < 3) return;
          values[0].textContent = `${level.rate}%`;
          values[1].textContent = level.memberCount;
          values[2].textContent = formatMoney(level.commission);
        });
      }
      if (location.pathname.includes('/pages/historique-equipe.html') && !window.teamHistoryOwnsRendering) {
        const referrals = await api('/api/referrals');
        window.backendReferralLevels = referrals.levels;
        const renderBackendLevel = levelNumber => {
          const level = referrals.levels.find(item => item.level === levelNumber);
          const members = level?.members || [];
          const memberCount = document.querySelector('#memberCount');
          const depositTotal = document.querySelector('#depositTotal');
          const list = document.querySelector('#members');
          if (memberCount) memberCount.textContent = level?.memberCount || 0;
          if (depositTotal) depositTotal.textContent = formatMoney(level?.completedDeposits || 0);
          if (list) list.innerHTML = members.length ? members.map(member => `
            <div class="member"><span class="member-logo"><img src="assets/account-logo.png" alt=""></span>
            <span><p>Compte : <b>${member.account}</b></p><small>Date : ${new Date(member.joinedAt).toLocaleString('fr-FR')}</small></span>
            <strong class="money">${formatMoney(member.completedDeposits)}</strong></div>`).join('') :
            '<div class="empty">Aucune activité réelle pour ce niveau.</div>';
        };
        renderBackendLevel(1);
        document.querySelectorAll('.tab').forEach(button => {
          button.addEventListener('click', () => renderBackendLevel(Number(button.dataset.level)));
        });
      }
      if (location.pathname.includes('/pages/mes-produits.html') && !window.mesProduitsOwnsRendering) {
        const data = await api('/api/vips/mine');
        const images = { VIP1: 'vip1.webp', VIP2: 'vip2.webp', VIP3: 'vip3.webp' };
        const list = document.querySelector('#list');
        const active = data.purchases.filter(p => p.status === 'active' && new Date(p.expires_at) > new Date());
        document.querySelector('#count').textContent = `${active.length} produit${active.length > 1 ? 's' : ''} actif${active.length > 1 ? 's' : ''}`;
        list.innerHTML = data.purchases.length ? data.purchases.map(p => `
          <article class="product"><img class="photo" style="object-fit:contain" src="${window.vipProductImages.imageFor(p)}" alt="${p.name}">
          <div><h2>${p.name}</h2><span class="status">${p.status === 'active' ? 'Actif' : 'Expiré'}</span>
          <div class="details"><span>Prix : <b>${formatMoney(p.price)}</b></span>
          <span>Revenu quotidien : <b>${formatMoney(p.daily_income)}</b></span>
          <span>Expire le ${new Date(p.expires_at).toLocaleDateString('fr-FR')}</span>
          <span>Acheté le ${new Date(p.purchased_at).toLocaleDateString('fr-FR')}</span></div></div></article>`).join('') :
          '<section class="empty"><h2>Aucun produit acheté</h2><p>Vos produits VIP apparaîtront ici.</p><a href="../produits_vip_investissement/code.html">Découvrir les produits</a></section>';
      }
      if (location.pathname.includes('/pages/missions.html') && !window.missionsOwnsRendering) {
        const data = await api('/api/missions');
        const root = document.querySelector('#missions');
        root.innerHTML = data.missions.length ? data.missions.map((m, index) => {
          const goal = Number(m.target_value), current = Number(m.current), pct = Math.min(100, Math.round(current / goal * 100));
          return `<article class="mission"><span class="badge">Lv${index + 1}</span><p>${m.title} : <b>${formatMoney(m.reward)}</b></p>
            <div class="numbers"><div><strong>${current}</strong><span>Actuel</span></div><div><strong>${goal}</strong><span>Objectif</span></div><div><strong>${current}/${goal}</strong><span>Progression</span></div></div>
            <div class="progress"><i style="width:${pct}%"></i><span>${m.claimed ? 'Réclamée' : m.completed ? 'Touchez pour réclamer' : 'En cours'}</span></div>
            ${m.completed && !m.claimed ? `<button class="api-claim" data-mission="${m.id}" style="width:100%;margin-top:8px;border:0;border-radius:18px;padding:8px;color:#fff;background:#e50914">Réclamer ${formatMoney(m.reward)}</button>` : ''}</article>`;
        }).join('') : '<section class="empty">Aucune mission disponible actuellement.</section>';
      }
      if (location.pathname.includes('historique_des_retraits') && !window.withdrawalHistoryOwnsRendering) {
        const data = await api('/api/withdrawals');
        const list = document.querySelector('#list');
        list.innerHTML = data.withdrawals.length ? data.withdrawals.map(w => `
          <article class="withdrawal"><header class="card-head"><span class="wallet">▣</span><h2>Ordre de retrait</h2><strong class="amount">${formatMoney(w.amount)}</strong></header>
          <div class="rows"><div class="row"><span>▣</span><span class="label">Réf. commande</span><span class="value">${w.reference}</span></div>
          <div class="row"><span>◈</span><span class="label">Montant reçu</span><span class="value">${formatMoney(w.net_amount)}</span></div>
          <div class="row"><span>◷</span><span class="label">État</span><span class="badge ${w.status}">${w.status === 'pending' ? 'Paiement en cours' : w.status}</span></div>
          <div class="row"><span>◷</span><span class="label">Temps</span><span class="value">${new Date(w.created_at).toLocaleString('fr-FR')}</span></div></div></article>`).join('') :
          '<div class="empty">Aucun retrait enregistré.</div>';
      }
    } catch (error) {
      if (error.message.includes('Authentification') || error.message.includes('Session')) location.replace(login);
      else toast(error.message, true);
    }
  }
  const ref = new URLSearchParams(location.search).get('ref');
  const refInput = document.querySelector('[name="referral_code"]');
  if (ref && refInput) refInput.value = ref;
  document.addEventListener('click', async event => {
    const claim = event.target.closest('.api-claim');
    if (!claim) return;
    claim.disabled = true;
    try {
      const result = await api(`/api/missions/${claim.dataset.mission}/claim`, { method: 'POST' });
      toast(`Récompense de ${formatMoney(result.reward)} créditée.`);
      setTimeout(() => location.reload(), 700);
    } catch (error) { toast(error.message, true); claim.disabled = false; }
  });
  hydrate();
})();(() => {
  if (window.__cocaNavigationInitialized) return;
  window.__cocaNavigationInitialized = true;
  const base = location.pathname.split('/').slice(0, -2).join('/') + '/';
  const pages = {
    login: 'connexion/code.html',
    home: 'accueil_produits_coca_cola/code.html',
    products: 'produits_vip_investissement/code.html',
    team: 'quipe_profil_utilisateur/code.html',
    profile: 'profil_utilisateur_le_mien/code.html',
    recharge: 'recharge_paiement_gopay/code.html',
    withdraw: 'retrait_d_argent/code.html',
    history: 'historique_des_retraits/code.html',
    purchase: 'modal_confirmation_achat_vip1/code.html'
  };
  const go = (key) => { location.href = base + pages[key]; };
  const current = location.pathname;
  document.documentElement.classList.add('app-responsive');
  const oldNavSelectors = [
    '[data-purpose="main-bottom-nav"]',
    '[data-purpose="tab-bar"]',
    '[data-purpose="bottom-tab-bar"]'
  ];
  document.querySelectorAll(oldNavSelectors.join(',')).forEach(nav => nav.remove());
  if (current.includes('accueil_produits')) {
    document.querySelectorAll('nav.fixed.bottom-0').forEach(nav => nav.remove());
  }

  document.documentElement.classList.remove('app-has-footer-nav');
  document.querySelectorAll('.app-quick-nav').forEach(nav => nav.remove());

  const message = sessionStorage.getItem('appMessage');
  if (message) {
    sessionStorage.removeItem('appMessage');
    const toast = document.createElement('div');
    toast.className = 'app-toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3300);
  }
  const notifyAndGo = (message, key) => {
    sessionStorage.setItem('appMessage', message);
    go(key);
  };
  const showError = (message) => {
    document.querySelector('.app-toast')?.remove();
    const toast = document.createElement('div');
    toast.className = 'app-toast app-toast-error';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3300);
  };

  const registration = document.getElementById('registration-form');
  if (registration && !registration.hasAttribute('data-custom-registration')) {
    registration.addEventListener('submit', (event) => {
      event.preventDefault();
      notifyAndGo('Compte créé avec succès. Bienvenue !', 'home');
    });
  }
  const login = document.getElementById('login-form');
  if (login) login.addEventListener('submit', (event) => {
    event.preventDefault();
    sessionStorage.setItem('isAuthenticated', 'true');
    notifyAndGo('Connexion réussie. Bienvenue !', 'home');
  });
  document.getElementById('logout-button')?.addEventListener('click', (event) => {
    event.preventDefault();
    sessionStorage.clear();
    localStorage.removeItem('rememberedSession');
    location.replace(base + pages.login);
  });

  if (current.includes('accueil_produits') || current.includes('profil_utilisateur') || current.includes('quipe_')) {
    document.addEventListener('click', (event) => {
      const target = event.target.closest('button, a');
      if (!target || target.closest('a[href]')) return;
      const text = target.textContent.trim().toLowerCase();
      if (text.includes('recharg')) { event.preventDefault(); go('recharge'); }
      else if (text.includes('retir')) { event.preventDefault(); go('withdraw'); }
      else if (text.includes('historique')) { event.preventDefault(); go('history'); }
    });
  }

  if (current.includes('produits_vip')) {
    document.querySelectorAll('[data-purpose="product-card"]').forEach(card => {
      card.querySelector('button')?.addEventListener('click', () => {
        const name = card.querySelector('h2')?.textContent.trim() || 'VIP1';
        const lines = [...card.querySelectorAll('.details span')].map(node => node.textContent.trim());
        const valueAfter = (label, fallback) => {
          const line = lines.find(text => text.includes(label));
          return line?.match(/FCFA\s[\d,]+/)?.[0] || fallback;
        };
        const product = {
          name,
          price: valueAfter('Prix', 'FCFA 3,000'),
          daily: valueAfter('Revenu quotidien', 'FCFA 430'),
          total: valueAfter('Revenu total', 'FCFA 38,700')
        };
        sessionStorage.setItem('selectedProduct', JSON.stringify(product));
        go('purchase');
      });
    });
  }

  if (current.includes('modal_confirmation')) {
    const product = JSON.parse(sessionStorage.getItem('selectedProduct') || '{"name":"VIP1","price":"FCFA 3,000","daily":"FCFA 430","total":"FCFA 38,700"}');
    document.getElementById('modal-vip-title').textContent = product.name;
    const textNodes = [...document.querySelectorAll('div')];
    const price = textNodes.find(node => node.children.length === 0 && node.textContent.trim() === 'FCFA 3,000');
    if (price) price.textContent = product.price;
    const daily = textNodes.find(node => node.textContent.trim().startsWith('Revenu quotidien :'));
    if (daily) daily.textContent = `Revenu quotidien : ${product.daily}`;
    const total = textNodes.find(node => node.textContent.trim().startsWith('Revenu total :'));
    if (total) total.textContent = `Revenu total : ${product.total}`;
    document.querySelector('[data-purpose="btn-cancel"]')?.addEventListener('click', () => go('products'));
  }

  if (current.includes('retrait_d_argent')) {
    document.getElementById('confirm-button')?.addEventListener('click', () => {
      const amount = Number(document.getElementById('withdraw-amount')?.value);
      if (!Number.isFinite(amount) || amount < 2000) {
        showError('Le montant minimum de retrait est de 2 000 FCFA.');
        return;
      }
      if (amount > 2000) {
        showError('Le montant dépasse votre solde disponible.');
        return;
      }
      const withdrawal = {
        amount,
        received: amount * 0.90,
        reference: `T${Date.now()}`,
        date: new Date().toLocaleString('fr-FR')
      };
      localStorage.setItem('lastWithdrawal', JSON.stringify(withdrawal));
      notifyAndGo(`Demande de retrait de ${amount.toLocaleString('fr-FR')} FCFA enregistrée.`, 'history');
    });
    document.querySelector('[aria-label="Historique"]')?.addEventListener('click', () => go('history'));
  }

  if (current.includes('historique_des_retraits')) {
    try {
      const withdrawal = JSON.parse(localStorage.getItem('lastWithdrawal'));
      if (withdrawal?.amount) {
        const list = document.querySelector('[data-purpose="orders-list"]');
        const card = document.createElement('article');
        card.className = 'card-outline bg-white px-3.5 pt-2.5 pb-2 text-[15px] font-normal';
        card.innerHTML = `
          <div class="flex justify-between items-center pb-2">
            <span class="font-bold text-gray-900">Ordre de retrait</span>
            <span class="font-bold text-gray-900">FCFA ${withdrawal.amount.toLocaleString('fr-FR')}</span>
          </div>
          <div class="dotted-divider"></div>
          <div class="flex justify-between items-center py-2.5"><span>Réf. commande</span><span>${withdrawal.reference}</span></div>
          <div class="solid-divider"></div>
          <div class="flex justify-between items-center py-2.5"><span>Montant reçu</span><span>FCFA ${withdrawal.received.toLocaleString('fr-FR')}</span></div>
          <div class="solid-divider"></div>
          <div class="flex justify-between items-center py-2.5"><span>État</span><span class="text-[#eab308]">Paiement en cours</span></div>
          <div class="solid-divider"></div>
          <div class="flex justify-between items-center pt-2.5 pb-1"><span>Temps</span><span>${withdrawal.date}</span></div>`;
        list?.prepend(card);
      }
    } catch (_) {
      localStorage.removeItem('lastWithdrawal');
    }
  }

  document.querySelectorAll('[aria-label*="Retour"], [aria-label*="Back"], #nav-back-btn')
    .forEach(button => button.addEventListener('click', () => {
      if (history.length > 1) history.back(); else go('home');
    }));
})();

(() => {
  if (window.__cocaHydrationInitialized) return;
  window.__cocaHydrationInitialized = true;
  const api = async (url, options = {}) => {
    const response = await fetch(url, {
      credentials: 'same-origin',
      ...options,
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Une erreur est survenue.');
    return data;
  };
  const formatMoney = value => `FCFA ${Number(value || 0).toLocaleString('fr-FR')}`;
  const toast = (message, error = false) => {
    document.querySelector('.api-toast')?.remove();
    const node = document.createElement('div');
    node.className = `app-toast api-toast${error ? ' app-toast-error' : ''}`;
    node.textContent = message;
    document.body.appendChild(node);
    setTimeout(() => node.remove(), 4000);
  };
  const home = '../accueil_produits_coca_cola/code.html';
  const login = '../connexion/code.html';
  const isAuthPage = location.pathname.includes('/connexion/') || location.pathname.includes('inscription_') || location.pathname === '/register';

  document.addEventListener('submit', async event => {
    const form = event.target;
    if (form.id !== 'login-form' && form.id !== 'registration-form') return;
    event.preventDefault();
    event.stopImmediatePropagation();
    const submit = form.querySelector('[type="submit"]');
    if (submit?.disabled) return;
    if (!form.checkValidity()) return form.reportValidity();
    submit && (submit.disabled = true);
    try {
      if (form.id === 'registration-form') {
        const password = form.querySelector('#password').value;
        if (password !== form.querySelector('#confirm-password').value) throw new Error('Les mots de passe ne correspondent pas.');
        const result = await api('/api/auth/register', {
          method: 'POST',
          body: JSON.stringify({
            country: form.querySelector('[name="country"]').value,
            phone: `${form.querySelector('[name="dialCode"]')?.value || ''}${form.querySelector('[name="phone"]').value}`,
            password,
            referralCode: form.querySelector('[name="referral_code"]').value
          })
        });
        sessionStorage.setItem('appMessage', `Compte créé. Bonus de ${formatMoney(result.bonus)} crédité.`);
        location.href = home;
      } else {
        await api('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({
            phone: `${form.querySelector('[name="dialCode"]')?.value || ''}${form.querySelector('[name="phone"]').value}`,
            localPhone: form.querySelector('[name="phone"]').value,
            password: form.querySelector('[name="password"]').value,
            remember: Boolean(form.querySelector('[type="checkbox"]')?.checked)
          })
        });
        sessionStorage.setItem('appMessage', 'Connexion réussie.');
        location.href = home;
      }
    } catch (error) {
      toast(error.message, true);
      submit && (submit.disabled = false);
    }
  }, true);

  document.addEventListener('click', async event => {
    const confirmPurchase = event.target.closest('[data-purpose="btn-confirm"]');
    const deposit = event.target.closest('#confirm');
    const logout = event.target.closest('#logout-button');
    if (logout) {
      event.preventDefault(); event.stopImmediatePropagation();
      try { await api('/api/auth/logout', { method: 'POST' }); } catch {}
      location.replace(login);
      return;
    }
    if (confirmPurchase && location.pathname.includes('modal_confirmation')) {
      event.preventDefault(); event.stopImmediatePropagation();
      const product = JSON.parse(sessionStorage.getItem('selectedProduct') || '{"name":"VIP1"}');
      confirmPurchase.disabled = true;
      try {
        await api('/api/vips/purchase', { method: 'POST', body: JSON.stringify({ code: product.name }) });
        sessionStorage.removeItem('selectedProduct');
        sessionStorage.setItem('appMessage', `Achat ${product.name} confirmé.`);
        location.href = '../pages/mes-produits.html';
      } catch (error) { toast(error.message, true); confirmPurchase.disabled = false; }
      return;
    }
    if (deposit && location.pathname.includes('recharge_') && !location.pathname.includes('recharge_paiement_gopay')) {
      event.preventDefault(); event.stopImmediatePropagation();
      const amount = Number(document.querySelector('#value')?.value);
      deposit.disabled = true;
      try {
        const result = await api('/api/deposits', { method: 'POST', body: JSON.stringify({ amount }) });
        toast(`${result.message} Référence : ${result.reference}`);
      } catch (error) { toast(error.message, true); } finally { deposit.disabled = false; }
      return;
    }
    if (deposit && location.pathname.includes('retrait_')) {
      event.preventDefault(); event.stopImmediatePropagation();
      const amount = Number(document.querySelector('#amount')?.value);
      deposit.disabled = true;
      try {
        const result = await api('/api/withdrawals', {
          method: 'POST',
          body: JSON.stringify({ amount, walletId: Number(document.querySelector('#walletTitle')?.dataset.walletId) || null })
        });
        sessionStorage.setItem('appMessage', `Retrait ${result.reference} enregistré.`);
        location.href = '../historique_des_retraits/code.html';
      } catch (error) { toast(error.message, true); deposit.disabled = false; }
    }
  }, true);

  async function hydrate() {
    const config = await api('/api/config/public');
    const rates = config.referralCommissionRates;
    document.querySelectorAll('[data-config="daily-checkin-reward"]').forEach(node => {
      node.innerHTML = `Récompense de connexion quotidienne de <b>${Number(config.dailyCheckInReward).toLocaleString('fr-FR')} FCFA.</b>`;
    });
    document.querySelectorAll('[data-config="signup-bonus"]').forEach(node => {
      node.innerHTML = `Inscrivez-vous maintenant et recevez <b>${Number(config.signupBonus).toLocaleString('fr-FR')} FCFA !</b>`;
    });
    document.querySelectorAll('[data-config="referral-rates"]').forEach(node => {
      node.innerHTML = `Recevez <b>${rates.join(' %, ')} %</b> sur le premier dépôt validé de vos filleuls.`;
    });
    document.querySelectorAll('[data-config="deposit-rule"]').forEach(node => {
      const image = node.querySelector('img')?.outerHTML || '';
      node.innerHTML = `${image}Dépôt minimum : ${Number(config.minimumDeposit).toLocaleString('fr-FR')} FCFA. Confirmation requise avant crédit.`;
    });
    document.querySelectorAll('[data-config="withdrawal-rule"]').forEach(node => {
      const dailyLimit = config.maxWithdrawals === null ? 'Sans limite quotidienne' : `${Number(config.maxWithdrawals)} retraits par jour`;
      node.innerHTML = `Retrait minimum de <b>${Number(config.minimumWithdrawal).toLocaleString('fr-FR')} FCFA</b>, avec un VIP actif. Ouvert chaque jour de 10 h 00 (inclus) à 00 h 00 (minuit, exclus), heure de l’Algérie (Africa/Algiers). Maximum : <b>${dailyLimit}</b>. Aucun nouveau retrait tant qu’un retrait est en attente. Frais : <b>${config.withdrawalFeePercent} %</b>.`;
    });
    document.querySelectorAll('[data-config="withdrawal-limit"]').forEach(node => {
      node.textContent = config.maxWithdrawals === null ? 'Aucune limite quotidienne de retraits.' : `Maximum : ${Number(config.maxWithdrawals)} retraits par jour.`;
    });
    document.querySelectorAll('[data-config="withdrawal-minimum"]').forEach(node => {
      node.textContent = `Le montant minimum de retrait est de ${Number(config.minimumWithdrawal).toLocaleString('fr-FR')} FCFA.`;
    });
    document.querySelectorAll('[data-config="withdrawal-fee"]').forEach(node => {
      node.textContent = `${Number(config.withdrawalFeePercent).toFixed(2)}%`;
    });
    document.querySelectorAll('[data-config="withdrawal-fee-label"]').forEach(node => {
      node.textContent = `Frais de retrait : ${config.withdrawalFeePercent} %.`;
    });
    const withdrawalInput = document.querySelector('#amount');
    if (withdrawalInput && location.pathname.includes('retrait_')) {
      withdrawalInput.min = String(config.minimumWithdrawal);
      withdrawalInput.addEventListener('input', () => {
        const amount = Math.max(0, Number(withdrawalInput.value) || 0);
        const net = amount - Math.floor(amount * Number(config.withdrawalFeePercent) / 100);
        const received = document.querySelector('#received');
        if (received) received.textContent = formatMoney(net);
      });
    }
    if (isAuthPage) return;
    try {
      const me = await api('/api/me');
      const strongs = [...document.querySelectorAll('strong')];
      const balanceLabels = [...document.querySelectorAll('small,span')].filter(n => n.textContent.trim() === 'Solde du compte');
      balanceLabels.forEach(label => {
        const container = label.closest('.bal,.balance');
        const value = container?.querySelector('strong');
        if (value) value.textContent = formatMoney(me.account.balance);
      });
      const revenueLabels = [...document.querySelectorAll('small,span')].filter(n => /Revenu cumulé/i.test(n.textContent));
      revenueLabels.forEach(label => {
        const container = label.closest('.bal,.balance');
        const value = container?.querySelector('strong');
        if (value) value.textContent = formatMoney(me.account.cumulative_earnings);
      });
      if (location.pathname.includes('quipe_')) {
        const referrals = await api('/api/referrals');
        const link = `${location.origin}/register?ref=${referrals.referralCode}`;
        const codeNode = document.querySelector('#invite-code');
        const linkNode = document.querySelector('#invite-link');
        if (codeNode) codeNode.textContent = referrals.referralCode;
        if (linkNode) linkNode.textContent = link;
        document.querySelectorAll('.copy').forEach((button, index) => { button.dataset.copy = index ? link : referrals.referralCode; button.disabled = false; });
        const teamValue = document.querySelector('.stats .stat:first-child strong');
        if (teamValue) teamValue.textContent = referrals.directReferrals;
        const commissionValue = strongs.find(n => n.textContent.includes('FCFA 0.00'));
        if (commissionValue) commissionValue.textContent = formatMoney(referrals.totalCommission);
        document.querySelectorAll('.level').forEach((card, index) => {
          const level = referrals.levels[index];
          const values = card.querySelectorAll('.columns strong');
          if (!level || values.length < 3) return;
          values[0].textContent = `${level.rate}%`;
          values[1].textContent = level.memberCount;
          values[2].textContent = formatMoney(level.commission);
        });
      }
      if (location.pathname.includes('/pages/historique-equipe.html') && !window.teamHistoryOwnsRendering) {
        const referrals = await api('/api/referrals');
        window.backendReferralLevels = referrals.levels;
        const renderBackendLevel = levelNumber => {
          const level = referrals.levels.find(item => item.level === levelNumber);
          const members = level?.members || [];
          const memberCount = document.querySelector('#memberCount');
          const depositTotal = document.querySelector('#depositTotal');
          const list = document.querySelector('#members');
          if (memberCount) memberCount.textContent = level?.memberCount || 0;
          if (depositTotal) depositTotal.textContent = formatMoney(level?.completedDeposits || 0);
          if (list) list.innerHTML = members.length ? members.map(member => `
            <div class="member"><span class="member-logo"><img src="assets/account-logo.png" alt=""></span>
            <span><p>Compte : <b>${member.account}</b></p><small>Date : ${new Date(member.joinedAt).toLocaleString('fr-FR')}</small></span>
            <strong class="money">${formatMoney(member.completedDeposits)}</strong></div>`).join('') :
            '<div class="empty">Aucune activité réelle pour ce niveau.</div>';
        };
        renderBackendLevel(1);
        document.querySelectorAll('.tab').forEach(button => {
          button.addEventListener('click', () => renderBackendLevel(Number(button.dataset.level)));
        });
      }
      if (location.pathname.includes('/pages/mes-produits.html') && !window.mesProduitsOwnsRendering) {
        const data = await api('/api/vips/mine');
        const images = { VIP1: 'vip1.webp', VIP2: 'vip2.webp', VIP3: 'vip3.webp' };
        const list = document.querySelector('#list');
        const active = data.purchases.filter(p => p.status === 'active' && new Date(p.expires_at) > new Date());
        document.querySelector('#count').textContent = `${active.length} produit${active.length > 1 ? 's' : ''} actif${active.length > 1 ? 's' : ''}`;
        list.innerHTML = data.purchases.length ? data.purchases.map(p => `
          <article class="product"><img class="photo" style="object-fit:contain" src="${window.vipProductImages.imageFor(p)}" alt="${p.name}">
          <div><h2>${p.name}</h2><span class="status">${p.status === 'active' ? 'Actif' : 'Expiré'}</span>
          <div class="details"><span>Prix : <b>${formatMoney(p.price)}</b></span>
          <span>Revenu quotidien : <b>${formatMoney(p.daily_income)}</b></span>
          <span>Expire le ${new Date(p.expires_at).toLocaleDateString('fr-FR')}</span>
          <span>Acheté le ${new Date(p.purchased_at).toLocaleDateString('fr-FR')}</span></div></div></article>`).join('') :
          '<section class="empty"><h2>Aucun produit acheté</h2><p>Vos produits VIP apparaîtront ici.</p><a href="../produits_vip_investissement/code.html">Découvrir les produits</a></section>';
      }
      if (location.pathname.includes('/pages/missions.html') && !window.missionsOwnsRendering) {
        const data = await api('/api/missions');
        const root = document.querySelector('#missions');
        root.innerHTML = data.missions.length ? data.missions.map((m, index) => {
          const goal = Number(m.target_value), current = Number(m.current), pct = Math.min(100, Math.round(current / goal * 100));
          return `<article class="mission"><span class="badge">Lv${index + 1}</span><p>${m.title} : <b>${formatMoney(m.reward)}</b></p>
            <div class="numbers"><div><strong>${current}</strong><span>Actuel</span></div><div><strong>${goal}</strong><span>Objectif</span></div><div><strong>${current}/${goal}</strong><span>Progression</span></div></div>
            <div class="progress"><i style="width:${pct}%"></i><span>${m.claimed ? 'Réclamée' : m.completed ? 'Touchez pour réclamer' : 'En cours'}</span></div>
            ${m.completed && !m.claimed ? `<button class="api-claim" data-mission="${m.id}" style="width:100%;margin-top:8px;border:0;border-radius:18px;padding:8px;color:#fff;background:#e50914">Réclamer ${formatMoney(m.reward)}</button>` : ''}</article>`;
        }).join('') : '<section class="empty">Aucune mission disponible actuellement.</section>';
      }
      if (location.pathname.includes('historique_des_retraits') && !window.withdrawalHistoryOwnsRendering) {
        const data = await api('/api/withdrawals');
        const list = document.querySelector('#list');
        list.innerHTML = data.withdrawals.length ? data.withdrawals.map(w => `
          <article class="withdrawal"><header class="card-head"><span class="wallet">▣</span><h2>Ordre de retrait</h2><strong class="amount">${formatMoney(w.amount)}</strong></header>
          <div class="rows"><div class="row"><span>▣</span><span class="label">Réf. commande</span><span class="value">${w.reference}</span></div>
          <div class="row"><span>◈</span><span class="label">Montant reçu</span><span class="value">${formatMoney(w.net_amount)}</span></div>
          <div class="row"><span>◷</span><span class="label">État</span><span class="badge ${w.status}">${w.status === 'pending' ? 'Paiement en cours' : w.status}</span></div>
          <div class="row"><span>◷</span><span class="label">Temps</span><span class="value">${new Date(w.created_at).toLocaleString('fr-FR')}</span></div></div></article>`).join('') :
          '<div class="empty">Aucun retrait enregistré.</div>';
      }
    } catch (error) {
      if (error.message.includes('Authentification') || error.message.includes('Session')) location.replace(login);
      else toast(error.message, true);
    }
  }
  const ref = new URLSearchParams(location.search).get('ref');
  const refInput = document.querySelector('[name="referral_code"]');
  if (ref && refInput) refInput.value = ref;
  document.addEventListener('click', async event => {
    const claim = event.target.closest('.api-claim');
    if (!claim) return;
    claim.disabled = true;
    try {
      const result = await api(`/api/missions/${claim.dataset.mission}/claim`, { method: 'POST' });
      toast(`Récompense de ${formatMoney(result.reward)} créditée.`);
      setTimeout(() => location.reload(), 700);
    } catch (error) { toast(error.message, true); claim.disabled = false; }
  });
  hydrate();
})();(() => {
  if (window.__cocaNavigationInitialized) return;
  window.__cocaNavigationInitialized = true;
  const base = location.pathname.split('/').slice(0, -2).join('/') + '/';
  const pages = {
    login: 'connexion/code.html',
    home: 'accueil_produits_coca_cola/code.html',
    products: 'produits_vip_investissement/code.html',
    team: 'quipe_profil_utilisateur/code.html',
    profile: 'profil_utilisateur_le_mien/code.html',
    recharge: 'recharge_paiement_gopay/code.html',
    withdraw: 'retrait_d_argent/code.html',
    history: 'historique_des_retraits/code.html',
    purchase: 'modal_confirmation_achat_vip1/code.html'
  };
  const go = (key) => { location.href = base + pages[key]; };
  const current = location.pathname;
  document.documentElement.classList.add('app-responsive');
  const oldNavSelectors = [
    '[data-purpose="main-bottom-nav"]',
    '[data-purpose="tab-bar"]',
    '[data-purpose="bottom-tab-bar"]'
  ];
  document.querySelectorAll(oldNavSelectors.join(',')).forEach(nav => nav.remove());
  if (current.includes('accueil_produits')) {
    document.querySelectorAll('nav.fixed.bottom-0').forEach(nav => nav.remove());
  }

  document.documentElement.classList.remove('app-has-footer-nav');
  document.querySelectorAll('.app-quick-nav').forEach(nav => nav.remove());

  const message = sessionStorage.getItem('appMessage');
  if (message) {
    sessionStorage.removeItem('appMessage');
    const toast = document.createElement('div');
    toast.className = 'app-toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3300);
  }
  const notifyAndGo = (message, key) => {
    sessionStorage.setItem('appMessage', message);
    go(key);
  };
  const showError = (message) => {
    document.querySelector('.app-toast')?.remove();
    const toast = document.createElement('div');
    toast.className = 'app-toast app-toast-error';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3300);
  };

  const registration = document.getElementById('registration-form');
  if (registration && !registration.hasAttribute('data-custom-registration')) {
    registration.addEventListener('submit', (event) => {
      event.preventDefault();
      notifyAndGo('Compte créé avec succès. Bienvenue !', 'home');
    });
  }
  const login = document.getElementById('login-form');
  if (login) login.addEventListener('submit', (event) => {
    event.preventDefault();
    sessionStorage.setItem('isAuthenticated', 'true');
    notifyAndGo('Connexion réussie. Bienvenue !', 'home');
  });
  document.getElementById('logout-button')?.addEventListener('click', (event) => {
    event.preventDefault();
    sessionStorage.clear();
    localStorage.removeItem('rememberedSession');
    location.replace(base + pages.login);
  });

  if (current.includes('accueil_produits') || current.includes('profil_utilisateur') || current.includes('quipe_')) {
    document.addEventListener('click', (event) => {
      const target = event.target.closest('button, a');
      if (!target || target.closest('a[href]')) return;
      const text = target.textContent.trim().toLowerCase();
      if (text.includes('recharg')) { event.preventDefault(); go('recharge'); }
      else if (text.includes('retir')) { event.preventDefault(); go('withdraw'); }
      else if (text.includes('historique')) { event.preventDefault(); go('history'); }
    });
  }

  if (current.includes('produits_vip')) {
    document.querySelectorAll('[data-purpose="product-card"]').forEach(card => {
      card.querySelector('button')?.addEventListener('click', () => {
        const name = card.querySelector('h2')?.textContent.trim() || 'VIP1';
        const lines = [...card.querySelectorAll('.details span')].map(node => node.textContent.trim());
        const valueAfter = (label, fallback) => {
          const line = lines.find(text => text.includes(label));
          return line?.match(/FCFA\s[\d,]+/)?.[0] || fallback;
        };
        const product = {
          name,
          price: valueAfter('Prix', 'FCFA 3,000'),
          daily: valueAfter('Revenu quotidien', 'FCFA 430'),
          total: valueAfter('Revenu total', 'FCFA 38,700')
        };
        sessionStorage.setItem('selectedProduct', JSON.stringify(product));
        go('purchase');
      });
    });
  }

  if (current.includes('modal_confirmation')) {
    const product = JSON.parse(sessionStorage.getItem('selectedProduct') || '{"name":"VIP1","price":"FCFA 3,000","daily":"FCFA 430","total":"FCFA 38,700"}');
    document.getElementById('modal-vip-title').textContent = product.name;
    const textNodes = [...document.querySelectorAll('div')];
    const price = textNodes.find(node => node.children.length === 0 && node.textContent.trim() === 'FCFA 3,000');
    if (price) price.textContent = product.price;
    const daily = textNodes.find(node => node.textContent.trim().startsWith('Revenu quotidien :'));
    if (daily) daily.textContent = `Revenu quotidien : ${product.daily}`;
    const total = textNodes.find(node => node.textContent.trim().startsWith('Revenu total :'));
    if (total) total.textContent = `Revenu total : ${product.total}`;
    document.querySelector('[data-purpose="btn-cancel"]')?.addEventListener('click', () => go('products'));
  }

  if (current.includes('retrait_d_argent')) {
    document.getElementById('confirm-button')?.addEventListener('click', () => {
      const amount = Number(document.getElementById('withdraw-amount')?.value);
      if (!Number.isFinite(amount) || amount < 2000) {
        showError('Le montant minimum de retrait est de 2 000 FCFA.');
        return;
      }
      if (amount > 2000) {
        showError('Le montant dépasse votre solde disponible.');
        return;
      }
      const withdrawal = {
        amount,
        received: amount * 0.90,
        reference: `T${Date.now()}`,
        date: new Date().toLocaleString('fr-FR')
      };
      localStorage.setItem('lastWithdrawal', JSON.stringify(withdrawal));
      notifyAndGo(`Demande de retrait de ${amount.toLocaleString('fr-FR')} FCFA enregistrée.`, 'history');
    });
    document.querySelector('[aria-label="Historique"]')?.addEventListener('click', () => go('history'));
  }

  if (current.includes('historique_des_retraits')) {
    try {
      const withdrawal = JSON.parse(localStorage.getItem('lastWithdrawal'));
      if (withdrawal?.amount) {
        const list = document.querySelector('[data-purpose="orders-list"]');
        const card = document.createElement('article');
        card.className = 'card-outline bg-white px-3.5 pt-2.5 pb-2 text-[15px] font-normal';
        card.innerHTML = `
          <div class="flex justify-between items-center pb-2">
            <span class="font-bold text-gray-900">Ordre de retrait</span>
            <span class="font-bold text-gray-900">FCFA ${withdrawal.amount.toLocaleString('fr-FR')}</span>
          </div>
          <div class="dotted-divider"></div>
          <div class="flex justify-between items-center py-2.5"><span>Réf. commande</span><span>${withdrawal.reference}</span></div>
          <div class="solid-divider"></div>
          <div class="flex justify-between items-center py-2.5"><span>Montant reçu</span><span>FCFA ${withdrawal.received.toLocaleString('fr-FR')}</span></div>
          <div class="solid-divider"></div>
          <div class="flex justify-between items-center py-2.5"><span>État</span><span class="text-[#eab308]">Paiement en cours</span></div>
          <div class="solid-divider"></div>
          <div class="flex justify-between items-center pt-2.5 pb-1"><span>Temps</span><span>${withdrawal.date}</span></div>`;
        list?.prepend(card);
      }
    } catch (_) {
      localStorage.removeItem('lastWithdrawal');
    }
  }

  document.querySelectorAll('[aria-label*="Retour"], [aria-label*="Back"], #nav-back-btn')
    .forEach(button => button.addEventListener('click', () => {
      if (history.length > 1) history.back(); else go('home');
    }));
})();

(() => {
  if (window.__cocaHydrationInitialized) return;
  window.__cocaHydrationInitialized = true;
  const api = async (url, options = {}) => {
    const response = await fetch(url, {
      credentials: 'same-origin',
      ...options,
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Une erreur est survenue.');
    return data;
  };
  const formatMoney = value => `FCFA ${Number(value || 0).toLocaleString('fr-FR')}`;
  const toast = (message, error = false) => {
    document.querySelector('.api-toast')?.remove();
    const node = document.createElement('div');
    node.className = `app-toast api-toast${error ? ' app-toast-error' : ''}`;
    node.textContent = message;
    document.body.appendChild(node);
    setTimeout(() => node.remove(), 4000);
  };
  const home = '../accueil_produits_coca_cola/code.html';
  const login = '../connexion/code.html';
  const isAuthPage = location.pathname.includes('/connexion/') || location.pathname.includes('inscription_') || location.pathname === '/register';

  document.addEventListener('submit', async event => {
    const form = event.target;
    if (form.id !== 'login-form' && form.id !== 'registration-form') return;
    event.preventDefault();
    event.stopImmediatePropagation();
    const submit = form.querySelector('[type="submit"]');
    if (submit?.disabled) return;
    if (!form.checkValidity()) return form.reportValidity();
    submit && (submit.disabled = true);
    try {
      if (form.id === 'registration-form') {
        const password = form.querySelector('#password').value;
        if (password !== form.querySelector('#confirm-password').value) throw new Error('Les mots de passe ne correspondent pas.');
        const result = await api('/api/auth/register', {
          method: 'POST',
          body: JSON.stringify({
            country: form.querySelector('[name="country"]').value,
            phone: `${form.querySelector('[name="dialCode"]')?.value || ''}${form.querySelector('[name="phone"]').value}`,
            password,
            referralCode: form.querySelector('[name="referral_code"]').value
          })
        });
        sessionStorage.setItem('appMessage', `Compte créé. Bonus de ${formatMoney(result.bonus)} crédité.`);
        location.href = home;
      } else {
        await api('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({
            phone: `${form.querySelector('[name="dialCode"]')?.value || ''}${form.querySelector('[name="phone"]').value}`,
            localPhone: form.querySelector('[name="phone"]').value,
            password: form.querySelector('[name="password"]').value,
            remember: Boolean(form.querySelector('[type="checkbox"]')?.checked)
          })
        });
        sessionStorage.setItem('appMessage', 'Connexion réussie.');
        location.href = home;
      }
    } catch (error) {
      toast(error.message, true);
      submit && (submit.disabled = false);
    }
  }, true);

  document.addEventListener('click', async event => {
    const confirmPurchase = event.target.closest('[data-purpose="btn-confirm"]');
    const deposit = event.target.closest('#confirm');
    const logout = event.target.closest('#logout-button');
    if (logout) {
      event.preventDefault(); event.stopImmediatePropagation();
      try { await api('/api/auth/logout', { method: 'POST' }); } catch {}
      location.replace(login);
      return;
    }
    if (confirmPurchase && location.pathname.includes('modal_confirmation')) {
      event.preventDefault(); event.stopImmediatePropagation();
      const product = JSON.parse(sessionStorage.getItem('selectedProduct') || '{"name":"VIP1"}');
      confirmPurchase.disabled = true;
      try {
        await api('/api/vips/purchase', { method: 'POST', body: JSON.stringify({ code: product.name }) });
        sessionStorage.removeItem('selectedProduct');
        sessionStorage.setItem('appMessage', `Achat ${product.name} confirmé.`);
        location.href = '../pages/mes-produits.html';
      } catch (error) { toast(error.message, true); confirmPurchase.disabled = false; }
      return;
    }
    if (deposit && location.pathname.includes('recharge_') && !location.pathname.includes('recharge_paiement_gopay')) {
      event.preventDefault(); event.stopImmediatePropagation();
      const amount = Number(document.querySelector('#value')?.value);
      deposit.disabled = true;
      try {
        const result = await api('/api/deposits', { method: 'POST', body: JSON.stringify({ amount }) });
        toast(`${result.message} Référence : ${result.reference}`);
      } catch (error) { toast(error.message, true); } finally { deposit.disabled = false; }
      return;
    }
    if (deposit && location.pathname.includes('retrait_')) {
      event.preventDefault(); event.stopImmediatePropagation();
      const amount = Number(document.querySelector('#amount')?.value);
      deposit.disabled = true;
      try {
        const result = await api('/api/withdrawals', {
          method: 'POST',
          body: JSON.stringify({ amount, walletId: Number(document.querySelector('#walletTitle')?.dataset.walletId) || null })
        });
        sessionStorage.setItem('appMessage', `Retrait ${result.reference} enregistré.`);
        location.href = '../historique_des_retraits/code.html';
      } catch (error) { toast(error.message, true); deposit.disabled = false; }
    }
  }, true);

  async function hydrate() {
    const config = await api('/api/config/public');
    const rates = config.referralCommissionRates;
    document.querySelectorAll('[data-config="daily-checkin-reward"]').forEach(node => {
      node.innerHTML = `Récompense de connexion quotidienne de <b>${Number(config.dailyCheckInReward).toLocaleString('fr-FR')} FCFA.</b>`;
    });
    document.querySelectorAll('[data-config="signup-bonus"]').forEach(node => {
      node.innerHTML = `Inscrivez-vous maintenant et recevez <b>${Number(config.signupBonus).toLocaleString('fr-FR')} FCFA !</b>`;
    });
    document.querySelectorAll('[data-config="referral-rates"]').forEach(node => {
      node.innerHTML = `Recevez <b>${rates.join(' %, ')} %</b> sur le premier dépôt validé de vos filleuls.`;
    });
    document.querySelectorAll('[data-config="deposit-rule"]').forEach(node => {
      const image = node.querySelector('img')?.outerHTML || '';
      node.innerHTML = `${image}Dépôt minimum : ${Number(config.minimumDeposit).toLocaleString('fr-FR')} FCFA. Confirmation requise avant crédit.`;
    });
    document.querySelectorAll('[data-config="withdrawal-rule"]').forEach(node => {
      const dailyLimit = config.maxWithdrawals === null ? 'Sans limite quotidienne' : `${Number(config.maxWithdrawals)} retraits par jour`;
      node.innerHTML = `Retrait minimum de <b>${Number(config.minimumWithdrawal).toLocaleString('fr-FR')} FCFA</b>, avec un VIP actif. Ouvert chaque jour de 10 h 00 (inclus) à 00 h 00 (minuit, exclus), heure de l’Algérie (Africa/Algiers). Maximum : <b>${dailyLimit}</b>. Aucun nouveau retrait tant qu’un retrait est en attente. Frais : <b>${config.withdrawalFeePercent} %</b>.`;
    });
    document.querySelectorAll('[data-config="withdrawal-limit"]').forEach(node => {
      node.textContent = config.maxWithdrawals === null ? 'Aucune limite quotidienne de retraits.' : `Maximum : ${Number(config.maxWithdrawals)} retraits par jour.`;
    });
    document.querySelectorAll('[data-config="withdrawal-minimum"]').forEach(node => {
      node.textContent = `Le montant minimum de retrait est de ${Number(config.minimumWithdrawal).toLocaleString('fr-FR')} FCFA.`;
    });
    document.querySelectorAll('[data-config="withdrawal-fee"]').forEach(node => {
      node.textContent = `${Number(config.withdrawalFeePercent).toFixed(2)}%`;
    });
    document.querySelectorAll('[data-config="withdrawal-fee-label"]').forEach(node => {
      node.textContent = `Frais de retrait : ${config.withdrawalFeePercent} %.`;
    });
    const withdrawalInput = document.querySelector('#amount');
    if (withdrawalInput && location.pathname.includes('retrait_')) {
      withdrawalInput.min = String(config.minimumWithdrawal);
      withdrawalInput.addEventListener('input', () => {
        const amount = Math.max(0, Number(withdrawalInput.value) || 0);
        const net = amount - Math.floor(amount * Number(config.withdrawalFeePercent) / 100);
        const received = document.querySelector('#received');
        if (received) received.textContent = formatMoney(net);
      });
    }
    if (isAuthPage) return;
    try {
      const me = await api('/api/me');
      const strongs = [...document.querySelectorAll('strong')];
      const balanceLabels = [...document.querySelectorAll('small,span')].filter(n => n.textContent.trim() === 'Solde du compte');
      balanceLabels.forEach(label => {
        const container = label.closest('.bal,.balance');
        const value = container?.querySelector('strong');
        if (value) value.textContent = formatMoney(me.account.balance);
      });
      const revenueLabels = [...document.querySelectorAll('small,span')].filter(n => /Revenu cumulé/i.test(n.textContent));
      revenueLabels.forEach(label => {
        const container = label.closest('.bal,.balance');
        const value = container?.querySelector('strong');
        if (value) value.textContent = formatMoney(me.account.cumulative_earnings);
      });
      if (location.pathname.includes('quipe_')) {
        const referrals = await api('/api/referrals');
        const link = `${location.origin}/register?ref=${referrals.referralCode}`;
        const codeNode = document.querySelector('#invite-code');
        const linkNode = document.querySelector('#invite-link');
        if (codeNode) codeNode.textContent = referrals.referralCode;
        if (linkNode) linkNode.textContent = link;
        document.querySelectorAll('.copy').forEach((button, index) => { button.dataset.copy = index ? link : referrals.referralCode; button.disabled = false; });
        const teamValue = document.querySelector('.stats .stat:first-child strong');
        if (teamValue) teamValue.textContent = referrals.directReferrals;
        const commissionValue = strongs.find(n => n.textContent.includes('FCFA 0.00'));
        if (commissionValue) commissionValue.textContent = formatMoney(referrals.totalCommission);
        document.querySelectorAll('.level').forEach((card, index) => {
          const level = referrals.levels[index];
          const values = card.querySelectorAll('.columns strong');
          if (!level || values.length < 3) return;
          values[0].textContent = `${level.rate}%`;
          values[1].textContent = level.memberCount;
          values[2].textContent = formatMoney(level.commission);
        });
      }
      if (location.pathname.includes('/pages/historique-equipe.html') && !window.teamHistoryOwnsRendering) {
        const referrals = await api('/api/referrals');
        window.backendReferralLevels = referrals.levels;
        const renderBackendLevel = levelNumber => {
          const level = referrals.levels.find(item => item.level === levelNumber);
          const members = level?.members || [];
          const memberCount = document.querySelector('#memberCount');
          const depositTotal = document.querySelector('#depositTotal');
          const list = document.querySelector('#members');
          if (memberCount) memberCount.textContent = level?.memberCount || 0;
          if (depositTotal) depositTotal.textContent = formatMoney(level?.completedDeposits || 0);
          if (list) list.innerHTML = members.length ? members.map(member => `
            <div class="member"><span class="member-logo"><img src="assets/account-logo.png" alt=""></span>
            <span><p>Compte : <b>${member.account}</b></p><small>Date : ${new Date(member.joinedAt).toLocaleString('fr-FR')}</small></span>
            <strong class="money">${formatMoney(member.completedDeposits)}</strong></div>`).join('') :
            '<div class="empty">Aucune activité réelle pour ce niveau.</div>';
        };
        renderBackendLevel(1);
        document.querySelectorAll('.tab').forEach(button => {
          button.addEventListener('click', () => renderBackendLevel(Number(button.dataset.level)));
        });
      }
      if (location.pathname.includes('/pages/mes-produits.html') && !window.mesProduitsOwnsRendering) {
        const data = await api('/api/vips/mine');
        const images = { VIP1: 'vip1.webp', VIP2: 'vip2.webp', VIP3: 'vip3.webp' };
        const list = document.querySelector('#list');
        const active = data.purchases.filter(p => p.status === 'active' && new Date(p.expires_at) > new Date());
        document.querySelector('#count').textContent = `${active.length} produit${active.length > 1 ? 's' : ''} actif${active.length > 1 ? 's' : ''}`;
        list.innerHTML = data.purchases.length ? data.purchases.map(p => `
          <article class="product"><img class="photo" style="object-fit:contain" src="${window.vipProductImages.imageFor(p)}" alt="${p.name}">
          <div><h2>${p.name}</h2><span class="status">${p.status === 'active' ? 'Actif' : 'Expiré'}</span>
          <div class="details"><span>Prix : <b>${formatMoney(p.price)}</b></span>
          <span>Revenu quotidien : <b>${formatMoney(p.daily_income)}</b></span>
          <span>Expire le ${new Date(p.expires_at).toLocaleDateString('fr-FR')}</span>
          <span>Acheté le ${new Date(p.purchased_at).toLocaleDateString('fr-FR')}</span></div></div></article>`).join('') :
          '<section class="empty"><h2>Aucun produit acheté</h2><p>Vos produits VIP apparaîtront ici.</p><a href="../produits_vip_investissement/code.html">Découvrir les produits</a></section>';
      }
      if (location.pathname.includes('/pages/missions.html') && !window.missionsOwnsRendering) {
        const data = await api('/api/missions');
        const root = document.querySelector('#missions');
        root.innerHTML = data.missions.length ? data.missions.map((m, index) => {
          const goal = Number(m.target_value), current = Number(m.current), pct = Math.min(100, Math.round(current / goal * 100));
          return `<article class="mission"><span class="badge">Lv${index + 1}</span><p>${m.title} : <b>${formatMoney(m.reward)}</b></p>
            <div class="numbers"><div><strong>${current}</strong><span>Actuel</span></div><div><strong>${goal}</strong><span>Objectif</span></div><div><strong>${current}/${goal}</strong><span>Progression</span></div></div>
            <div class="progress"><i style="width:${pct}%"></i><span>${m.claimed ? 'Réclamée' : m.completed ? 'Touchez pour réclamer' : 'En cours'}</span></div>
            ${m.completed && !m.claimed ? `<button class="api-claim" data-mission="${m.id}" style="width:100%;margin-top:8px;border:0;border-radius:18px;padding:8px;color:#fff;background:#e50914">Réclamer ${formatMoney(m.reward)}</button>` : ''}</article>`;
        }).join('') : '<section class="empty">Aucune mission disponible actuellement.</section>';
      }
      if (location.pathname.includes('historique_des_retraits') && !window.withdrawalHistoryOwnsRendering) {
        const data = await api('/api/withdrawals');
        const list = document.querySelector('#list');
        list.innerHTML = data.withdrawals.length ? data.withdrawals.map(w => `
          <article class="withdrawal"><header class="card-head"><span class="wallet">▣</span><h2>Ordre de retrait</h2><strong class="amount">${formatMoney(w.amount)}</strong></header>
          <div class="rows"><div class="row"><span>▣</span><span class="label">Réf. commande</span><span class="value">${w.reference}</span></div>
          <div class="row"><span>◈</span><span class="label">Montant reçu</span><span class="value">${formatMoney(w.net_amount)}</span></div>
          <div class="row"><span>◷</span><span class="label">État</span><span class="badge ${w.status}">${w.status === 'pending' ? 'Paiement en cours' : w.status}</span></div>
          <div class="row"><span>◷</span><span class="label">Temps</span><span class="value">${new Date(w.created_at).toLocaleString('fr-FR')}</span></div></div></article>`).join('') :
          '<div class="empty">Aucun retrait enregistré.</div>';
      }
    } catch (error) {
      if (error.message.includes('Authentification') || error.message.includes('Session')) location.replace(login);
      else toast(error.message, true);
    }
  }
  const ref = new URLSearchParams(location.search).get('ref');
  const refInput = document.querySelector('[name="referral_code"]');
  if (ref && refInput) refInput.value = ref;
  document.addEventListener('click', async event => {
    const claim = event.target.closest('.api-claim');
    if (!claim) return;
    claim.disabled = true;
    try {
      const result = await api(`/api/missions/${claim.dataset.mission}/claim`, { method: 'POST' });
      toast(`Récompense de ${formatMoney(result.reward)} créditée.`);
      setTimeout(() => location.reload(), 700);
    } catch (error) { toast(error.message, true); claim.disabled = false; }
  });
  hydrate();
})();