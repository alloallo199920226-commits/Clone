(function (root) {
  'use strict';
  const labels = [
    'Sprite Original', 'Sprite Zero Sugar', 'Sprite Chill Cherry Lime',
    'Sprite Tropical Mix', 'Sprite Winter Spiced Cranberry',
    'Sprite Chill Mango Citrus', 'Sprite + Tea Zero Sugar',
    'Sprite Chill Mint Zero Sugar', 'Sprite Winter Spiced Cranberry Zero Sugar',
    'Sprite Zero Sugar — édition allemande'
  ];
  const publishedCodes = [
    'VIP1789392665165', 'VIP1789393479124', 'VIP1789393524542', 'VIP1789393590823',
    'VIP1789393650016', 'VIP1789393758310', 'VIP1789393802579', 'VIP1789393855784'
  ];
  const assignments = Object.fromEntries(publishedCodes.map((code, index) => [code, index]));
  labels.forEach((_, index) => { assignments[`VIP${index + 1}`] = index; });
  const variants = labels.map((label, index) => Object.freeze({
    label, src: `/produits_vip_investissement/assets/sprite-real/sprite-${index + 1}.webp`
  }));
  function variant(product, index = 0) {
    const assigned = assignments[String(product?.code || '').toUpperCase()];
    const rank = assigned ?? (Number.isSafeInteger(index) && index >= 0 ? index % variants.length : 0);
    return variants[rank];
  }
  function imageFor(product, index = 0) {
    const custom = String(product?.image_class || '').trim();
    if (/^https?:\/\//i.test(custom) || (custom.startsWith('/') && !custom.startsWith('//'))) return custom;
    if (/^[\w.-]+\.(?:png|jpe?g|webp)$/i.test(custom)) return `/attached_assets/${custom}`;
    return variant(product, index).src;
  }
  const api = Object.freeze({ variants: Object.freeze(variants), variant, imageFor });
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.vipProductImages = api;
})(typeof window === 'object' ? window : globalThis);