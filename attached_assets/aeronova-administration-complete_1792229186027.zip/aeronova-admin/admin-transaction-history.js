'use strict';

function parameters(query = {}) {
  const type = query.type || 'all', status = query.status || 'all', assistance = query.assistance || 'all';
  const limit = Number(query.limit || 50), search = String(query.search || '').trim();
  if (!['all', 'deposit', 'withdrawal'].includes(type) || !['all', 'pending', 'approved', 'rejected'].includes(status) ||
      !['all', 'normal', 'admin'].includes(assistance) || !Number.isInteger(limit) || limit < 1 || limit > 100 || search.length > 100)
    throw Object.assign(new Error('Filtres invalides.'), { status: 400 });
  let cursor = null;
  if (query.cursor) {
    try {
      if (typeof query.cursor !== 'string' || query.cursor.length > 500) throw Error();
      cursor = JSON.parse(Buffer.from(query.cursor, 'base64url').toString());
      if (!Number.isFinite(Date.parse(cursor.date)) || !/^\d{1,19}$/.test(String(cursor.id)) || BigInt(cursor.id)>9223372036854775807n || !['deposit', 'withdrawal'].includes(cursor.type)) throw Error();
    } catch { throw Object.assign(new Error('Page invalide.'), { status: 400 }); }
  }
  return { type, status, assistance, limit, search, cursor };
}
function historySql(cameroon) {
  const country = cameroon ? "WHERE upper(trim(u.country)) IN ('CAMEROUN','CM','+237','237')" : '';
  return `WITH ledger AS (
    SELECT d.id,d.user_id AS "userId",u.phone AS "userPhone",u.country AS "countryCode",d.amount,d.status,d.reference,
      d.created_at AS "createdAt",d.amount AS "netAmount",0 AS fee,COALESCE(d.payer_number,u.phone) AS "payerNumber",
      d.receiver_number AS destination,COALESCE(d.operator_name,'Compte principal') AS "operatorName",
      COALESCE(d.payment_provider,'manual') AS "paymentProvider",false AS "adminAssisted",'deposit'::text AS type,
      d.receiver_name AS "receiverName",NULL::text AS "walletHolderName",NULL::bigint AS "walletId",
      d.provider_confirmed_at AS "providerConfirmedAt",d.provider_tx_id AS "providerTxId",
      false AS "hasAdminCredit",false AS "hasAdminVipGrant"
      FROM deposits d JOIN users u ON u.id=d.user_id ${country}
    UNION ALL
    SELECT w.id,w.user_id,u.phone,COALESCE(NULLIF(w.wallet_country,''),u.country),w.amount,w.status,w.reference,w.created_at,
      w.net_amount,w.fee,COALESCE(w.wallet_account_number,w.destination),w.destination,w.wallet_operator,'manual',
      (EXISTS(SELECT 1 FROM transactions t WHERE t.user_id=w.user_id AND t.type='admin_credit')
        OR EXISTS(SELECT 1 FROM admin_operations ao WHERE ao.user_id=w.user_id AND ao.operation_type='grant_vip')),
      'withdrawal'::text,NULL::text,w.wallet_holder_name,w.wallet_id,NULL::timestamptz,NULL::text,
      EXISTS(SELECT 1 FROM transactions t WHERE t.user_id=w.user_id AND t.type='admin_credit'),
      EXISTS(SELECT 1 FROM admin_operations ao WHERE ao.user_id=w.user_id AND ao.operation_type='grant_vip')
      FROM withdrawals w JOIN users u ON u.id=w.user_id ${country}
    ), filtered AS (SELECT * FROM ledger WHERE
      ($1='all' OR type=$1) AND
      ($2='all' OR ($2='pending' AND status IN ('pending','pending_review','pending_verification'))
        OR ($2='approved' AND status IN ('approved','completed')) OR ($2='rejected' AND status='rejected')) AND
      ($3='all' OR ($3='admin' AND type='withdrawal' AND "adminAssisted") OR ($3='normal' AND NOT "adminAssisted")) AND
      ($4='' OR strpos(lower(concat_ws(' ',id::text,"userId"::text,"userPhone","payerNumber",destination,reference,"operatorName")),lower($4))>0)
    )`;
}
function registerTransactionHistory(app, { pool, adminAuth, cameroonAdminAuth, internationalPhone }) {
  for (const cameroon of [false, true]) {
    app.get(cameroon ? '/api/cameroon-admin/transaction-history' : '/api/admin/transaction-history',
      cameroon ? cameroonAdminAuth : adminAuth, async (req, res, next) => {
        try {
          const p = parameters(req.query), common = [p.type, p.status, p.assistance, p.search], sql = historySql(cameroon);
          const [total, page] = await Promise.all([
            pool.query(`${sql} SELECT count(*)::text AS total FROM filtered`, common),
            pool.query(`${sql} SELECT filtered.*,
              to_char("createdAt" AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS "cursorCreatedAt",
              (SELECT count(*)::int FROM users r WHERE r.referred_by=filtered."userId") AS "referralCount",
              (SELECT COALESCE(sum(rc.amount),0)::text FROM referral_commissions rc WHERE rc.beneficiary_id=filtered."userId") AS "referralCommissionAmount"
              FROM filtered WHERE ($5::timestamptz IS NULL OR ("createdAt",id,type)<($5::timestamptz,$6::bigint,$7::text))
              ORDER BY "createdAt" DESC,id DESC,type DESC LIMIT $8`, [...common, p.cursor?.date || null, p.cursor?.id || null, p.cursor?.type || null, p.limit + 1])
          ]);
          const rows = page.rows.slice(0, p.limit), last = rows.at(-1);
          const nextCursor = page.rows.length > p.limit && last
            ? Buffer.from(JSON.stringify({ date: last.cursorCreatedAt || new Date(last.createdAt).toISOString(), id: String(last.id), type: last.type })).toString('base64url') : null;
          res.json({ total: total.rows[0].total, transactions: rows.map(row => ({ ...row,
            registrationNumber: internationalPhone(row.userPhone, row.countryCode) })), nextCursor });
        } catch (reason) { next(reason); }
      });
  }
}
module.exports = { registerTransactionHistory, parameters, historySql };