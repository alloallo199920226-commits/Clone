const VALID_DAYS = new Set(['7', '30', '90']);

// Read only. A zero is an aggregate of no recorded VIP credits, not a forecast.
const INCOME_SERIES_SQL = `
  WITH calendar AS (
    SELECT generate_series(
      (now() AT TIME ZONE 'Africa/Lagos')::date - ($2::int - 1),
      (now() AT TIME ZONE 'Africa/Lagos')::date,
      interval '1 day'
    )::date AS day
  ), credits AS (
    SELECT (created_at AT TIME ZONE 'Africa/Lagos')::date AS day, SUM(amount) AS amount
    FROM transactions
    WHERE user_id = $1 AND type = 'vip_daily_income' AND direction = 'credit'
      AND created_at >= (
        ((now() AT TIME ZONE 'Africa/Lagos')::date - ($2::int - 1))::timestamp
        AT TIME ZONE 'Africa/Lagos'
      )
      AND created_at < (
        ((now() AT TIME ZONE 'Africa/Lagos')::date + 1)::timestamp
        AT TIME ZONE 'Africa/Lagos'
      )
    GROUP BY 1
  )
  SELECT calendar.day::text AS date, COALESCE(credits.amount, 0) AS amount
  FROM calendar LEFT JOIN credits USING (day) ORDER BY calendar.day`;

function registerVipIncomeSeries({ app, auth, pool }) {
  app.get('/api/vips/income-series', auth, async (req, res, next) => {
    const days = req.query.days === undefined ? '7' : req.query.days;
    if (!VALID_DAYS.has(days)) {
      return res.status(400).json({ error: 'Choisissez une période de 7, 30 ou 90 jours.' });
    }
    try {
      const result = await pool.query(INCOME_SERIES_SQL, [req.user.id, Number(days)]);
      const points = result.rows.map(row => {
        const amount = Number(row.amount);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(row.date) || row.amount == null || !Number.isFinite(amount) || amount < 0) {
          throw new Error('Données de revenus VIP invalides.');
        }
        return { date: row.date, amount };
      });
      if (points.length !== Number(days)) throw new Error('Période de revenus VIP incomplète.');
      res.setHeader('Cache-Control', 'private, no-store');
      res.json({
        days: Number(days), timeZone: 'Africa/Lagos', points,
        total: points.reduce((sum, point) => sum + point.amount, 0)
      });
    } catch (error) { next(error); }
  });
}

module.exports = { registerVipIncomeSeries, INCOME_SERIES_SQL };
