'use strict';

const crypto = require('node:crypto');
const { SaspayProvider, saspayCountry, payerPhone, directPolicyAllows, verifiedIdentity, uuid } = require('./saspay-provider');
const { otpProtection } = require('./saspay-otp');
const WINDOW_MS = 8 * 60 * 1000;
const manualUrl = amount => `/paiement_gopay/code.html?amount=${encodeURIComponent(amount)}`;
const fail = (message, status = 400) => Object.assign(new Error(message), { status });
const manualOnlyError = () => Object.assign(
  fail('Cet opérateur utilise le paiement manuel, sans page de paiement externe.', 409),
  { manualRequired: true }
);
function dto(row) {
  const confirmationDeadline = new Date(row.first_sent_at).getTime() + WINDOW_MS;
  return {
    reference: row.reference, amount: Number(row.amount), currency: row.currency,
    status: row.state, credited: row.state === 'succeeded',
    failureReason: row.state === 'failed' && row.last_error === 'saspay_customer_required'
      ? 'customer_information_required' : null,
    canStartNewPayment: row.state === 'failed' && !row.provider_tx_id,
    operator: row.operator, phone: row.phone,
    confirmationDeadline, confirmationExpired: Date.now() >= confirmationDeadline,
    manualRequired: row.state === 'manual_required',
    manualUrl: row.state === 'manual_required' ? manualUrl(row.amount) : null,
    prepaymentOtpRequired: row.prepayment_otp_required === true
  };
}
function validCustomer(value) {
  // New checkouts supply only the verified payer phone. Retain validation of
  // optional contact data from older clients, never invent personal details.
  if (value === undefined) return true;
  return value !== null && typeof value === 'object' && !Array.isArray(value) &&
    Object.keys(value).every(k => ['email', 'first_name', 'last_name', 'phone'].includes(k)) &&
    (value.email === undefined || (typeof value.email === 'string' &&
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.email) && value.email.length <= 254)) &&
    ['first_name', 'last_name'].every(k => value[k] === undefined ||
      (typeof value[k] === 'string' && value[k].trim().length > 0 &&
       value[k].length <= 80 && !/[\u0000-\u001f]/.test(value[k])));
}
function withinTier(method, amount) {
  return method.tiers.some(t => Number.isFinite(Number(t.min_amount)) &&
    amount >= Number(t.min_amount) && (t.max_amount === null || amount <= Number(t.max_amount)));
}
function registerSaspayRoutes(app, {
  pool, auth, strictBody, financialRate, financialConfig, completeProviderDeposit,
  automaticPaymentsEnabled = async () => false,
  provider = new SaspayProvider(), otpVault = otpProtection()
}) {
  async function load(reference, userId) {
    return (await pool.query(
      `SELECT * FROM saspay_payments WHERE reference=$1 ${userId ? 'AND user_id=$2' : ''}`,
      userId ? [reference, userId] : [reference]
    )).rows[0];
  }
  async function requiresManual(country, operator, db = pool) {
    return (await db.query(
      'SELECT 1 FROM saspay_manual_networks WHERE country_code=$1 AND operator=$2',
      [country, operator]
    )).rowCount > 0;
  }
  async function claim(id) {
    const token = crypto.randomUUID();
    const row = (await pool.query(
      `UPDATE saspay_payments SET lease_token=$2,lease_until=now()+interval '60 seconds',
         last_checked_at=now()
       WHERE id=$1 AND state IN ('sending','pending','manual_required')
         AND (lease_until IS NULL OR lease_until<now()) RETURNING *`, [id, token]
    )).rows[0];
    return row;
  }
  async function release(row, code = null) {
    await pool.query(
      `UPDATE saspay_payments SET lease_token=NULL,lease_until=NULL,last_error=COALESCE($3,last_error)
       WHERE id=$1 AND lease_token=$2`, [row.id, row.lease_token, code]
    );
  }
  async function initiate(row) {
    if (!await automaticPaymentsEnabled()) return;
    const otp = row.prepayment_otp_required
      ? otpVault.open(row.prepayment_otp_sealed, row.reference) : undefined;
    const result = await provider.create(row, { otp });
    if (!uuid(result?.id)) throw fail('Réponse Saspay incertaine. Ne relancez pas une nouvelle demande.', 502);
    const redirect = typeof result.checkout_url === 'string' && result.checkout_url.trim() !== '';
    // Persist identity even when external checkout is required. Never return its URL.
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const current = (await client.query('SELECT * FROM saspay_payments WHERE id=$1 FOR UPDATE', [row.id])).rows[0];
      if (current.lease_token !== row.lease_token || new Date(current.lease_until).getTime() <= Date.now()) {
        await client.query('ROLLBACK');
        return;
      }
      await client.query(
        `UPDATE saspay_payments SET provider_tx_id=$2,state=$3,redirect_required=$4,
           prepayment_otp_sealed=NULL,updated_at=now()
         WHERE id=$1`, [row.id, result.id, redirect ? 'manual_required' : 'pending', redirect]
      );
      if (redirect) await client.query(
        `INSERT INTO saspay_manual_networks(country_code,operator) VALUES($1,$2)
         ON CONFLICT(country_code,operator) DO NOTHING`, [row.country_code, row.operator]
      );
      await client.query(`UPDATE deposits SET provider_tx_id=$2,provider_return_status=$3 WHERE id=$1`,
        [row.deposit_id, result.id, redirect ? 'external_checkout_blocked' : 'PENDING']);
      await client.query('COMMIT');
    } catch (error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
  }
  async function reconcile(id) {
    const row = await claim(id);
    if (!row) return;
    try {
      // Never resend an indeterminate charge indefinitely: the provider may
      // eventually expire its idempotency cache. A known ID remains
      // verifiable even after the customer-facing deadline.
      if (!row.provider_tx_id && Date.now() - new Date(row.first_sent_at).getTime() >= WINDOW_MS) return;
      if (!row.provider_tx_id) {
        // A policy change must not initiate or resend a now-manual collection.
        // Known provider IDs above remain eligible for authoritative verification.
        if (!directPolicyAllows(row.country_code, row.operator)) return;
        if (row.prepayment_otp_required && !row.prepayment_otp_sealed) return;
        await initiate(row);
        return;
      }
      const result = await provider.verify(String(row.provider_tx_id));
      if (!verifiedIdentity(result, row)) throw fail('Identité du paiement incohérente.', 502);
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const current = (await client.query('SELECT * FROM saspay_payments WHERE id=$1 FOR UPDATE', [row.id])).rows[0];
        if (current.lease_token !== row.lease_token || new Date(current.lease_until).getTime() <= Date.now() ||
            !['pending','manual_required'].includes(current.state)) {
          await client.query('ROLLBACK');
          return;
        }
        if (result.status === 'SUCCESS') {
          const deposit = (await client.query('SELECT * FROM deposits WHERE id=$1 FOR UPDATE', [row.deposit_id])).rows[0];
          if (deposit?.payment_provider !== 'saspay' || deposit.provider_tx_id !== String(result.id) ||
              Number(deposit.amount) !== Number(row.amount) || deposit.user_id !== row.user_id) {
            throw fail('Dépôt incohérent.', 502);
          }
          if (deposit.status !== 'completed') {
            if (!['pending','pending_review'].includes(deposit.status)) throw fail('Dépôt non créditable.', 409);
            const credited = await completeProviderDeposit(client, deposit, { txId: result.id, confirmedBy: 'saspay_verified_api' });
            if (!credited) throw fail('Confirmation financière différée.', 409);
          }
          await client.query(`UPDATE saspay_payments SET state='succeeded',updated_at=now() WHERE id=$1`, [row.id]);
          await client.query(`UPDATE deposits SET provider_return_status='SUCCESS' WHERE id=$1`, [row.deposit_id]);
        } else if (['FAILED','CANCELLED'].includes(result.status)) {
          await client.query(`UPDATE saspay_payments SET state='failed',updated_at=now() WHERE id=$1`, [row.id]);
          await client.query(`UPDATE deposits SET status='rejected',provider_return_status=$2 WHERE id=$1 AND status IN ('pending','pending_review')`,
            [row.deposit_id, result.status]);
        }
        await client.query('COMMIT');
      } catch (error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
      await release(row);
    } catch (error) {
      // An ambiguous initiation stays bound to the original idempotency key.
      // Only explicit validation/authentication rejection proves no payment was created.
      if (!row.provider_tx_id && [400,401,403,422].includes(error.providerStatus)) {
        await pool.query(
          `UPDATE saspay_payments SET state='failed',prepayment_otp_sealed=NULL,updated_at=now()
           WHERE id=$1 AND lease_token=$2 AND lease_until>now()`, [row.id, row.lease_token]
        );
        await pool.query(`UPDATE deposits SET status='rejected' WHERE id=$1 AND status='pending'
          AND EXISTS(SELECT 1 FROM saspay_payments WHERE deposit_id=$1 AND state='failed')`, [row.deposit_id]);
      }
      await release(row, /^[a-z_]{1,80}$/.test(error.code || '') ? error.code : 'verification_pending');
      throw error;
    } finally {
      // Only this lease's owner can release it, even following a late result.
      await release(row);
    }
  }
  app.get('/api/saspay/options', auth, async (req, res, next) => {
    try {
      const country = saspayCountry(req.user.country);
      const config = await financialConfig();
      const base = { country, minimumDeposit: Number(config.minimumDeposit), payerPhone: req.user.phone,
        manualUrl: manualUrl(Number(config.minimumDeposit)), methods: [] };
      if (!await automaticPaymentsEnabled()) {
        return res.json({ ...base, manualOnly: true, reason: 'Les dépôts automatiques Saspay sont en réserve. Utilisez les canaux manuels disponibles.' });
      }
      if (!country || ['BJ', 'CI', 'BF', 'CM', 'NE', 'TG'].includes(country.code)) return res.json({ ...base, manualOnly: true });
      try {
        const blocked = new Set((await pool.query(
          'SELECT operator FROM saspay_manual_networks WHERE country_code=$1', [country.code]
        )).rows.map(row => row.operator));
        const methods = (await provider.catalog()).filter(m => m.country === country.code)
          .map(method => ({ ...method, manual: method.manual ||
            !directPolicyAllows(country.code, method.id) || blocked.has(method.id) }));
        res.json({ ...base, methods: [...methods.map(m => ({
          id: m.id, name: m.name, manual: m.manual, tiers: m.tiers,
          otpRequired: m.otpRequired === true, otpInstructions: m.otpInstructions || ''
        })), { id: 'manual', name: 'Autre opérateur — canaux manuels disponibles', manual: true }],
          manualOnly: !methods.some(m => !m.manual) });
      } catch {
        res.json({ ...base, manualOnly: true, reason: 'Saspay est indisponible. Le paiement manuel reste accessible.' });
      }
    } catch (error) { next(error); }
  });
  app.post('/api/saspay/payments', auth, financialRate,
    strictBody(['amount','clientRequestId','operator','phone','customer','otp']), async (req, res, next) => {
      try {
        const country = saspayCountry(req.user.country);
        if (!country) throw fail('Ce pays utilise le paiement manuel.', 403);
        const amount = Number(req.body.amount);
        const clientId = String(req.body.clientRequestId || '');
        const phone = payerPhone(country.code, req.body.phone);
        const config = await financialConfig();
        if (!Number.isSafeInteger(amount) || amount < config.minimumDeposit || amount > 100000000) throw fail('Montant du dépôt invalide.');
        if (!/^[A-Za-z0-9_-]{12,80}$/.test(clientId) || !phone || !validCustomer(req.body.customer)) throw fail('Vérifiez les informations de la demande et le numéro Mobile Money.');
        const existing = (await pool.query('SELECT * FROM saspay_payments WHERE user_id=$1 AND client_request_id=$2',
          [req.user.id, clientId])).rows[0];
        const customer = { phone };
        for (const key of ['email', 'first_name', 'last_name']) {
          if (req.body.customer?.[key] !== undefined) customer[key] = req.body.customer[key].trim();
        }
        if (existing) {
          if (existing.prepayment_otp_sealed &&
              String(req.body.otp || '').trim() !== otpVault.open(existing.prepayment_otp_sealed, existing.reference)) {
            throw fail('Reprenez cette demande avec le même code de paiement, sans en créer une nouvelle.', 409);
          }
          // PostgreSQL jsonb reorders keys: compare fields, not JSON serialization.
          if (Number(existing.amount) !== amount || existing.operator !== req.body.operator || existing.phone !== phone ||
              Object.keys(customer).some(k => existing.request_payload.customer[k] !== customer[k])) {
            throw fail('Cette demande existe déjà avec des informations différentes.', 409);
          }
          try { await reconcile(existing.id); } catch { /* Existing uncertain payment remains verifiable. */ }
          return res.json(dto(await load(existing.reference, req.user.id)));
        }
        if (!await automaticPaymentsEnabled() ||
            !directPolicyAllows(country.code, req.body.operator) ||
            await requiresManual(country.code, req.body.operator)) throw manualOnlyError();
        const method = (await provider.catalog()).find(m => m.country === country.code && m.id === req.body.operator);
        if (!method || method.manual) throw manualOnlyError();
        if (!['email','first_name','last_name'].every(key => typeof customer[key] === 'string' && customer[key].trim())) {
          throw fail('Saspay exige votre prénom, votre nom et une adresse e-mail valide pour le paiement automatique.');
        }
        const otp = String(req.body.otp || '').trim();
        if (method.otpRequired && !/^\d{4,12}$/.test(otp)) {
          throw fail('Saisissez le code de paiement à usage unique obtenu via USSD, pas votre code PIN.');
        }
        if (!withinTier(method, amount)) throw fail('Ce montant n’est pas accepté par cet opérateur.');
        const client = await pool.connect();
        let row;
        try {
          await client.query('BEGIN');
          // Serialize intention creation per account; never wait on the provider while holding a connection.
          await client.query('SELECT id FROM users WHERE id=$1 FOR UPDATE', [req.user.id]);
          row = (await client.query('SELECT * FROM saspay_payments WHERE user_id=$1 AND client_request_id=$2', [req.user.id, clientId])).rows[0];
          if (row) {
            if (row.prepayment_otp_sealed && otp !== otpVault.open(row.prepayment_otp_sealed, row.reference)) {
              throw fail('Le code de cette demande ne peut pas être remplacé.', 409);
            }
            if (Number(row.amount) !== amount || row.operator !== method.id || row.phone !== phone ||
                Object.keys(customer).some(k => row.request_payload.customer[k] !== customer[k])) throw fail('Demande incompatible.', 409);
          } else {
            // Recheck after taking the account lock, before creating any new intention.
            if (!await automaticPaymentsEnabled(client) ||
                !directPolicyAllows(country.code, method.id) ||
                await requiresManual(country.code, method.id, client)) throw manualOnlyError();
            if ((await client.query('SELECT 1 FROM deposits WHERE user_id=$1 AND client_request_id=$2',
              [req.user.id, clientId])).rowCount) {
              throw fail('Cet identifiant appartient déjà à un dépôt. Reprenez ce dépôt ; pour une opération distincte, créez un autre dépôt.', 409);
            }
            const reference = `SAS-${crypto.randomUUID()}`;
            const sealedOtp = method.otpRequired ? otpVault.seal(otp, reference) : null;
            const deposit = (await client.query(
              `INSERT INTO deposits(user_id,amount,status,reference,payment_provider,payer_number,operator_name,client_request_id)
               VALUES($1,$2,'pending',$3,'saspay',$4,$5,$6) RETURNING id`,
              [req.user.id, amount, reference, phone, method.name, clientId]
            )).rows[0];
            // Preserve the merchant's documented ADD_ON pricing; show its estimate before confirmation.
            const payload = { amount: `${amount}.00`, currency: country.currency, country: country.code,
              network: method.id, customer, description: 'Recharge du compte AERONOVA',
              fee_charge_mode: 'ADD_ON', metadata: { reference } };
            row = (await client.query(
              `INSERT INTO saspay_payments(user_id,deposit_id,reference,client_request_id,amount,currency,
                 country_code,country_id,network_id,operator,phone,request_payload,
                 prepayment_otp_required,prepayment_otp_sealed)
               VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING *`,
              [req.user.id, deposit.id, reference, clientId, amount, country.currency, country.code,
                method.countryId, method.networkId, method.id, phone, JSON.stringify(payload),
                method.otpRequired === true, sealedOtp]
            )).rows[0];
          }
          await client.query('COMMIT');
        } catch (error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
        try { await reconcile(row.id); } catch { /* Do not classify a timeout as a failure. */ }
        res.status(201).json(dto(await load(row.reference, req.user.id)));
    } catch (error) {
      if (error.manualRequired) return res.status(409).json({
        error: error.message, manualRequired: true, manualUrl: manualUrl(Number(req.body.amount))
      });
      next(error);
    }
  });
  app.get('/api/saspay/payments/:reference/status', auth, financialRate, async (req, res, next) => {
    try {
      const row = await load(req.params.reference, req.user.id);
      if (!row) throw fail('Paiement introuvable.', 404);
      try { await reconcile(row.id); } catch { /* Reconciliation continues independently. */ }
      res.json(dto(await load(row.reference, req.user.id)));
    } catch (error) { next(error); }
  });
  app.post('/api/saspay/payments/:reference/otp', auth, financialRate, strictBody(['otp']), async (req, res, next) => {
    try {
      const row = await load(req.params.reference, req.user.id);
      if (!row) throw fail('Paiement introuvable.', 404);
      if (row.prepayment_otp_required || row.state !== 'pending' || !row.provider_tx_id ||
          Date.now() >= new Date(row.first_sent_at).getTime() + WINDOW_MS) throw fail('Confirmation OTP indisponible.', 409);
      const otp = String(req.body.otp || '');
      if (!/^[A-Za-z0-9]{4,12}$/.test(otp)) throw fail('Code OTP invalide.');
      await provider.confirmOtp(String(row.provider_tx_id), otp);
      try { await reconcile(row.id); } catch { /* A successful OTP is not itself financial proof. */ }
      res.json(dto(await load(row.reference, req.user.id)));
    } catch (error) { next(error); }
  });
  app.get('/api/saspay/intents/:clientRequestId/status', auth, financialRate, async (req, res, next) => {
    try {
      if (!uuid(req.params.clientRequestId)) throw fail('Demande introuvable.', 404);
      const row = (await pool.query(`SELECT * FROM saspay_payments WHERE user_id=$1 AND client_request_id=$2`,
        [req.user.id, req.params.clientRequestId])).rows[0];
      if (!row) throw fail('Demande introuvable.', 404);
      try { await reconcile(row.id); } catch { /* Preserve the original intention on uncertain verification. */ }
      res.json(dto(await load(row.reference, req.user.id)));
    } catch (error) { next(error); }
  });
  // Signed webhook is optional: persistent server polling also works without it.
  app.post('/api/saspay/webhook', async (req, res, next) => {
    try {
      const secret = process.env.SASPAY_WEBHOOK_SECRET;
      if (!secret) return res.status(503).json({ error: 'Webhook non configuré ; vérification API active.' });
      const timestamp = String(req.get('x-webhook-timestamp') || '');
      const signature = String(req.get('x-webhook-signature') || '');
      if (!/^\d{10}$/.test(timestamp) || Math.abs(Date.now() / 1000 - Number(timestamp)) > 300 ||
          !/^[0-9a-f]{64}$/.test(signature) || !Buffer.isBuffer(req.rawBody)) return res.sendStatus(401);
      const expected = crypto.createHmac('sha256', secret).update(timestamp + '.').update(req.rawBody).digest();
      if (!crypto.timingSafeEqual(Buffer.from(signature, 'hex'), expected)) return res.sendStatus(401);
      // Payload status/amount never credits funds; it only schedules authoritative API verification.
      const id = req.body?.data?.id;
      if (uuid(id)) await pool.query('UPDATE saspay_payments SET last_checked_at=NULL WHERE provider_tx_id=$1', [id]);
      res.sendStatus(200);
    } catch (error) { next(error); }
  });
  let timer = null, busy = false;
  async function tick() {
    if (busy) return;
    busy = true;
    try {
      await pool.query(`UPDATE saspay_payments SET prepayment_otp_sealed=NULL
        WHERE prepayment_otp_sealed IS NOT NULL AND
          (first_sent_at<=now()-interval '8 minutes' OR provider_tx_id IS NOT NULL OR state IN ('succeeded','failed'))`);
      const rows = (await pool.query(
        `SELECT id FROM saspay_payments WHERE state IN ('sending','pending','manual_required')
          AND (provider_tx_id IS NOT NULL OR first_sent_at>now()-interval '8 minutes')
         AND (lease_until IS NULL OR lease_until<now())
         ORDER BY last_checked_at ASC NULLS FIRST,id LIMIT 20`
      )).rows;
      for (const row of rows) { try { await reconcile(row.id); } catch { /* Retry same identity on next tick. */ } }
    } catch { console.error('Vérification Saspay différée.'); } finally { busy = false; }
  }
  return {
    start() { if (!timer) { timer = setInterval(tick, 30000); timer.unref(); void tick(); } },
    stop() { clearInterval(timer); timer = null; },
    tick, reconcile
  };
}
module.exports = { registerSaspayRoutes, dto, validCustomer, withinTier };
