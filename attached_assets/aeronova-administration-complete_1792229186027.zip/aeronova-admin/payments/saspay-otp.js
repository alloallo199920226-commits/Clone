'use strict';
const crypto = require('crypto');

// Keep a prepayment code recoverable for the bounded idempotent retry window,
// never in cleartext, payment payloads, logs, URLs or browser storage.
function otpProtection(secret = () => process.env.SESSION_SECRET) {
  function key() {
    const value = secret();
    if (!value || value.length < 16) throw Object.assign(
      Error('La protection du code de paiement est indisponible.'), { status: 503 }
    );
    return crypto.createHash('sha256').update('saspay-prepayment-otp-v1:').update(value).digest();
  }
  return {
    seal(code, reference) {
      const iv = crypto.randomBytes(12);
      const cipher = crypto.createCipheriv('aes-256-gcm', key(), iv);
      cipher.setAAD(Buffer.from(reference));
      const data = Buffer.concat([cipher.update(code, 'utf8'), cipher.final()]);
      return [iv, cipher.getAuthTag(), data].map(b => b.toString('base64')).join('.');
    },
    open(sealed, reference) {
      try {
        const [iv, tag, data] = sealed.split('.').map(s => Buffer.from(s, 'base64'));
        const decipher = crypto.createDecipheriv('aes-256-gcm', key(), iv);
        decipher.setAAD(Buffer.from(reference));
        decipher.setAuthTag(tag);
        return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
      } catch {
        throw Object.assign(Error('Le code protégé ne peut pas être repris. Ne créez pas un second paiement.'),
          { status: 503, code: 'prepayment_otp_unavailable' });
      }
    }
  };
}
module.exports = { otpProtection };
