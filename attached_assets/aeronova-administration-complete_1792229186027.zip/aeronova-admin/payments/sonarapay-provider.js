'use strict';

const { saspayCountry: countryFor, payerPhone } = require('./saspay-provider');
const { diagnostic } = require('./sonarapay-diagnostics');
const BASE = 'https://www.sonarapay.com';
const identifier = value => typeof value === 'string' && /^[A-Za-z0-9._-]{3,191}$/.test(value);
function directAllowed(country, operator) {
  if (country !== 'SN') return false;
  return !/^wave_/.test(operator);
}
function externalPage(body) {
  if (!body || typeof body !== 'object') return false;
  return Object.entries(body).some(([key, value]) =>
    (/(?:redirect|checkout|payment_?url|pay_?url)/i.test(key) && typeof value === 'string' && value.trim()) ||
    (value && typeof value === 'object' && externalPage(value)));
}
function providerError(status, uncertain = false) {
  return Object.assign(new Error(uncertain
    ? 'La réponse SonaraPay est incertaine. Vérifiez le statut sans créer un autre paiement.'
    : 'SonaraPay est indisponible pour cette demande. Aucun lien externe ne sera ouvert.'), {
    status: 502, providerStatus: status, uncertain
  });
}
class SonaraProvider {
  constructor({ fetchImpl = global.fetch, key = () => process.env.SONARAPAY_SDK_KEY } = {}) {
    this.fetchImpl = fetchImpl;
    this.key = key;
  }
  configured() { return Boolean(this.key()); }
  async request(path, body) {
    if (!this.configured()) throw providerError(503);
    let response, data;
    try {
      response = await this.fetchImpl(BASE + path, {
        // Leave time to persist the provider identity before checkout's 45s deadline.
        method: body ? 'POST' : 'GET', redirect: 'manual', signal: AbortSignal.timeout(body ? 35000 : 20000),
        headers: { Authorization: `Bearer ${this.key()}`, ...(body ? { 'Content-Type': 'application/json' } : {}) },
        ...(body ? { body: JSON.stringify(body) } : {})
      });
      // Never follow an HTTP redirect or expose the response body in errors.
      if (response.status >= 300 && response.status < 400) {
        throw Object.assign(providerError(response.status, Boolean(body)), {
          diagnostic: diagnostic(response.status, null, 'La redirection HTTP du fournisseur a été bloquée. Aucun lien externe ne sera ouvert.')
        });
      }
      data = await response.json();
    } catch (error) {
      if (error.providerStatus) throw error;
      throw Object.assign(providerError(response?.status || 504, Boolean(body)), {
        diagnostic: diagnostic(response?.status || null, null, response
          ? 'La réponse SonaraPay n’est pas un document JSON exploitable.'
          : 'Aucune réponse exploitable n’a été reçue de SonaraPay. La demande doit rester à vérifier.')
      });
    }
    if (!response.ok) {
      const error=providerError(response.status, Boolean(body) && response.status >= 500);
      error.diagnostic=diagnostic(response.status,data);
      // Keep a returned financial identity even on a non-2xx response.
      if(body && data && typeof data==='object')error.paymentResponse=data;
      throw error;
    }
    if (!data || typeof data !== 'object' || Array.isArray(data) && body) throw providerError(502, Boolean(body));
    return data;
  }
  async catalog() {
    // Documented public endpoint; avoid sharing merchant credentials with it.
    let response;
    try {
      response = await this.fetchImpl(BASE + '/api/countries', { redirect: 'manual', signal: AbortSignal.timeout(15000) });
      if (!response.ok) throw providerError(response.status);
      const countries = await response.json();
      if (!Array.isArray(countries)) throw providerError(502);
      return countries;
    } catch (error) {
      if (error.providerStatus) throw error;
      throw providerError(502);
    }
  }
  // Merchant-generated SDK keys use the endpoint shown beside that key in
  // "Webhooks & Code". Never fall back to another collection endpoint.
  create(payload) { return this.request('/api/v1/payments/initiate', payload); }
  verify(reference) {
    if (!identifier(reference)) throw providerError(400);
    return this.request(`/api/v1/payments/${encodeURIComponent(reference)}/status`);
  }
}
function verifiedStatus(body, row) {
  return body?.notFound !== true && body?.reference === row.provider_reference &&
    Number(body.amount) === Number(row.amount) && body.currency === row.currency &&
    payerPhone(row.country_code, body.customerPhone) === row.phone &&
    body.paymentMethod === row.operator_name &&
    body.description === row.request_payload.description && !externalPage(body);
}
function verifiedProof(body, row) {
  return body?.reference === row.provider_reference && body.transactionId === row.provider_tx_id &&
    Number(body.amount) === Number(row.amount) && body.currency === row.currency &&
    body.operatorId === row.operator && payerPhone(row.country_code, body.customerPhone) === row.phone &&
    (body.countryCode === undefined || body.countryCode === row.country_code);
}
module.exports = { SonaraProvider, countryFor, payerPhone, directAllowed, externalPage, identifier, verifiedStatus, verifiedProof };
