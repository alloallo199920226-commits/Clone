'use strict';

// Only bounded diagnostic text is retained, never the response body, headers,
// payer payload or credentials. Rendering also uses textContent, not HTML.
function safeText(value) {
  if (typeof value !== 'string') return null;
  return value.slice(0, 4000)
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .replace(/\bBearer\s+\S+/gi, 'Bearer [masqué]')
    .replace(/\b(?:https?|postgres(?:ql)?):\/\/\S+/gi, '[adresse masquée]')
    .replace(/\b(?:sdk_|sp_(?:live|test)_sk_|whsec_|sk_(?:live|test)_)[A-Za-z0-9._=-]+/gi, '[masqué]')
    .replace(/\b(password|secret|token|api[_ -]?key|pin|otp|signature)\s*[:=]\s*["']?[^"',;\s]+/gi, '$1: [masqué]')
    .replace(/[A-Za-z0-9.+_-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, '[e-mail masqué]')
    .replace(/\+?\d[\d ().-]{7,}\d/g, '[numéro masqué]')
    .replace(/\b\d{6,}\b/g, '[masqué]')
    .replace(/\b[A-Za-z0-9_-]{24,}\b/g, '[masqué]')
    .replace(/\s+/g, ' ').trim().slice(0, 400) || null;
}

function diagnostic(httpStatus, body, fallback) {
  const status = Number.isInteger(httpStatus) && httpStatus >= 100 && httpStatus <= 599 ? httpStatus : null;
  const rawCode = body?.code ?? body?.errorCode ?? body?.error?.code;
  const code = typeof rawCode === 'string' && /^[A-Za-z][A-Za-z0-9_]{1,48}$/.test(rawCode) &&
    safeText(rawCode) === rawCode ? rawCode : null;
  const texts = [body?.message, typeof body?.error === 'string' ? body.error : body?.error?.message];
  // Validation field names are allowlisted; unrelated account data is ignored.
  for (const field of ['amount','currency','countryCode','operatorId','customerPhone','customerName','otp','description']) {
    const values = body?.errors?.[field];
    for (const value of Array.isArray(values) ? values.slice(0, 3) : [values]) {
      if (typeof value === 'string') texts.push(`${field} : ${value}`);
    }
  }
  const message = status >= 500
    ? 'SonaraPay a signalé une erreur serveur. La demande doit rester à vérifier.'
    : safeText([...new Set(texts.filter(value => typeof value === 'string'))].join(' '));
  return {
    httpStatus: status,
    code,
    message: message || safeText(fallback) || 'SonaraPay n’a pas communiqué de motif détaillé.'
  };
}

function publicDiagnostic(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  return diagnostic(value.httpStatus, {code: value.code, message: value.message});
}

function compactDiagnostic(value) {
  const clean = publicDiagnostic(value);
  if (!clean) return null;
  const compact = {h: clean.httpStatus, c: clean.code, m: clean.message};
  // Older published schemas have only an 80-character last_error column.
  // Preserve a useful, masked excerpt there rather than risking payment IDs.
  while (JSON.stringify(compact).length > 80 && compact.m.length) compact.m = compact.m.slice(0, -1);
  return JSON.stringify(compact);
}

function storedDiagnostic(row) {
  const full = publicDiagnostic(row.last_diagnostic);
  if (full) return full;
  try {
    const compact = JSON.parse(row.last_error);
    if (!compact || !Object.hasOwn(compact, 'h') || typeof compact.m !== 'string') return null;
    return publicDiagnostic({httpStatus: compact.h, code: compact.c, message: compact.m});
  } catch { return null; }
}

module.exports = { diagnostic, publicDiagnostic, safeText, compactDiagnostic, storedDiagnostic };
