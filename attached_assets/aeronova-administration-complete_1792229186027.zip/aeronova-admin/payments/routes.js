'use strict';

const crypto = require('node:crypto');
const {
  AshtechPaymentProvider,
  REAL_TEST_WARNING,
  REDIRECT_MESSAGE,
  identityMatches,
  webhookMapsToOrder,
  validWaveUrl
} = require('./ashtech-provider');
const { PAYMENT_COUNTRIES, countryForOrder, normalizePaymentPhone, paymentCountry } = require('./countries');
const { confirmationWindow } = require('./confirmation-window');

const PRODUCT = { name: 'Recharge du portefeuille' };
const MAX_DEPOSIT = 100_000_000;
const INITIATION_LEASE_MS = 30_000;
const RECONCILIATION_LEASE_MS = 2 * 60_000;
const GENERIC_UNAVAILABLE = 'Le paiement Mobile Money est temporairement indisponible.';
const CI_WAVE_MANUAL_URL = '/paiement_gopay/code.html?manual=wave';
const TG_TOGOCEL_MANUAL_URL = '/paiement_gopay/code.html?manual=togocel';
const CM_MANUAL_URL = '/paiement_gopay/code.html';
const NIGER_REDIRECT_BLOCKED = 'Cet opérateur exige une validation externe et a été retiré des paiements automatiques du Niger. Aucun lien externe ne sera ouvert. Cette demande reste en vérification : ne recommencez pas tant que son statut n’est pas résolu.';
const WAVE_OPERATOR_NAMES = new Set(['WAVE', 'WAVE MONEY']);
const TOGO_MANUAL_OPERATOR_NAMES = new Set(['TOGOCEL', 'TMONEY', 'MIXXBYYAS', 'MOOV', 'MOOVMONEY', 'FLOOZ', 'FLOOZMONEY', 'FLOOZMOOV']);
const TOGO_FLOOZ_CATALOG_NAMES = new Set(['MOOV', 'MOOVMONEY', 'FLOOZ', 'FLOOZMONEY', 'FLOOZMOOV']);
const normalizedOperator = value => typeof value === 'string'
  ? value.trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleUpperCase('en').replace(/[^A-Z0-9]/g, '')
  : '';
const isTogoManualOperator = value => TOGO_MANUAL_OPERATOR_NAMES.has(normalizedOperator(value));
const isTogoFloozOperator = value => TOGO_FLOOZ_CATALOG_NAMES.has(normalizedOperator(value));
const NIGER_RECHARGE_OPERATOR_NAMES = new Set([
  'AIRTEL', 'AIRTELMONEY', 'MOOV', 'MOOVMONEY', 'MOOVAFRICA', 'MOOVAFRICAMONEY'
]);
const isNigerRechargeOperator = value => NIGER_RECHARGE_OPERATOR_NAMES.has(normalizedOperator(value));
const isDemoPaymentChannel = channel => /\(démo\)/i.test(String(channel?.operatorName || '')) ||
  /0000000[56]/.test(String(channel?.receiverNumber || '')) ||
  /démo|demo|ne pas transférer/i.test(String(channel?.receiverName || ''));
const isTogoManualChannel = channel => Boolean(channel &&
  channel.isActive === true &&
  paymentCountry(channel.country)?.code === 'TG' &&
  String(channel.countryCode || '').trim() === PAYMENT_COUNTRIES.TG.dialCode &&
  isTogoManualOperator(channel.operatorName) &&
  typeof channel.receiverNumber === 'string' &&
  normalizePaymentPhone('TG', channel.receiverNumber) !== null &&
  !isDemoPaymentChannel(channel));
const normalizeCountry = value => paymentCountry(value)?.name || String(value || '').trim();
const ownerCountryIsBenin = country => paymentCountry(country)?.code === 'BJ';
const countryForAccount = (value, paymentCountryName) => paymentCountry(paymentCountryName(value));
const orderMatchesAccount = (order, userCountry, paymentCountryName) => {
  const accountCountry = countryForAccount(userCountry, paymentCountryName);
  const orderCountry = countryForOrder(order?.country_code, order?.currency);
  return Boolean(accountCountry && orderCountry && accountCountry.code === orderCountry.code);
};
const validatePaymentPhone = (value, countryCode = 'BJ') => normalizePaymentPhone(countryCode, value);
const validateBeninPhone = value => validatePaymentPhone(value, 'BJ');
const isCoteDIvoireWaveOperator = value =>
  typeof value === 'string' && WAVE_OPERATOR_NAMES.has(value.trim().toLocaleUpperCase('en'));
const isCoteDIvoireWaveChannel = channel => Boolean(channel &&
  channel.isActive === true &&
  paymentCountry(channel.country)?.code === 'CI' &&
  String(channel.countryCode || '').trim() === PAYMENT_COUNTRIES.CI.dialCode &&
  isCoteDIvoireWaveOperator(channel.operatorName) &&
  typeof channel.receiverNumber === 'string' && channel.receiverNumber.trim());

function amountWithinLimits(value, minimum) {
  return Number.isSafeInteger(value) && value >= Math.max(200, Number(minimum) || 200) && value <= MAX_DEPOSIT;
}

function paymentDto(row, { testMode = false, now = Date.now() } = {}) {
  const status = row.status;
  const country = countryForOrder(row.country_code, row.currency);
  const externalRedirectBlocked = country?.code === 'NE' &&
    (row.external_redirect_required === true || row.challenge_mode === 'wave' || status === 'requires_redirect');
  const waveUrl = !externalRedirectBlocked && row.challenge_mode === 'wave' && validWaveUrl(row.challenge_wave_url)
    ? row.challenge_wave_url : null;
  const challenge = !externalRedirectBlocked && row.challenge_mode && (row.challenge_mode !== 'wave' || waveUrl) ? {
    mode: row.challenge_mode,
    ...(row.challenge_mode === 'ussd' && row.challenge_ussd_code ? { ussdCode: row.challenge_ussd_code } : {}),
    ...(row.challenge_mode === 'wave' ? { url: waveUrl } : {}),
    ...(row.challenge_message ? { message: row.challenge_message } : {})
  } : null;
  const messages = {
    created: 'Votre commande est prête. Sélectionnez votre opérateur et confirmez le numéro.',
    initiating: 'La demande de paiement est en cours de transmission.',
    pending: row.challenge_message || 'Confirmez la demande Mobile Money sur votre téléphone.',
    otp_required: row.challenge_message || 'Saisissez le code reçu pour confirmer le paiement.',
    verification_pending: row.challenge_message || 'Le paiement est en cours de vérification. Aucun montant n’a encore été crédité.',
    succeeded: 'Paiement confirmé. Votre portefeuille a été crédité.',
    failed: row.challenge_message || 'Le paiement n’a pas abouti. Pour recommencer, créez explicitement une nouvelle commande.',
    requires_redirect: REDIRECT_MESSAGE
  };
  return {
    reference: row.reference,
    orderId: String(row.id),
    amount: Number(row.amount),
    currency: row.currency,
    country: country ? {
      code: country.code,
      name: country.name,
      currency: country.currency,
      dialCode: country.dialCode
    } : null,
    product: PRODUCT,
    status,
    ...confirmationWindow(row, now),
    operator: row.operator || null,
    phone: row.phone || null,
    challenge,
    ...(country?.code === 'NE' ? {
      externalRedirectBlocked,
      operatorRestricted: Boolean(row.operator && !isNigerRechargeOperator(row.operator))
    } : {}),
    confirmationInProgress: row.otp_confirmation_in_progress === true,
    ...(status === 'created' ? {
      manualRedirectAllowed: !row.initiation_attempted && !row.initiation_in_progress &&
        !row.provider_tx_id && !row.provider_session_reference &&
        !row.otp_confirmation_in_progress && !row.challenge_mode
    } : {}),
    message: externalRedirectBlocked && !['succeeded','failed'].includes(status)
      ? NIGER_REDIRECT_BLOCKED : messages[status] || messages.verification_pending,
    credited: status === 'succeeded',
    testMode,
    realTestWarning: testMode ? REAL_TEST_WARNING : null
  };
}

function positiveMatchForProvider(transaction, order) {
  return identityMatches(transaction, {
    ...order,
    amount: Number(order.amount),
    currency: order.currency
  });
}

function canFulfillPayment(transaction, order) {
  return Boolean(transaction?.simulated !== true && transaction?.status === 'success' &&
    identityMatches(transaction, order));
}

function publicProviderError(error) {
  const status = Number(error?.status) || null;
  const code = typeof error?.code === 'string' ? error.code : null;
  if (status === 401) return {
    status: 502,
    errorCode: 'invalid_api_key',
    message: 'La clé API AshTech Pay est absente ou invalide. Vérifiez ASHTECH_API_KEY côté serveur.'
  };
  if (status === 403 || code === 'api_not_enabled') return {
    status: 502,
    errorCode: code === 'api_not_enabled' ? 'api_not_enabled' : 'direct_api_access_denied',
    message: 'L’accès Direct API AshTech Pay n’est pas activé ou le compte n’est pas vérifié. Contactez AshTech Pay.'
  };
  if (status === 400) return {
    status: 400,
    errorCode: code || 'invalid_payment_request',
    message: 'AshTech Pay a refusé les données de paiement. Vérifiez le montant, le pays, l’opérateur et le numéro.'
  };
  if (status === 409 || code === 'duplicate_reference' || code === 'otp_confirmation_in_progress') return {
    status: 409,
    errorCode: code === 'otp_confirmation_in_progress' ? code : 'duplicate_reference',
    message: code === 'otp_confirmation_in_progress'
      ? 'Une confirmation OTP est déjà en cours. Attendez son résultat avant de réessayer.'
      : 'Cette référence est déjà utilisée. Créez une nouvelle commande avant de recommencer.'
  };
  if (status === 429) return {
    status: 429,
    errorCode: 'rate_limited',
    retryAfterMs: Number(error?.retryAfterMs) || 1000,
    message: 'Trop de vérifications auprès d’AshTech Pay. Attendez le délai indiqué avant de réessayer.'
  };
  return {
    status: 503,
    errorCode: 'provider_unavailable',
    uncertain: true,
    message: 'Le résultat du paiement est incertain. Ne relancez pas la demande. Ne renvoyez pas le code OTP ; attendez la vérification du statut.'
  };
}

function registerPaymentRoutes(app, {
  pool,
  auth,
  strictBody,
  financialRate = (_req, _res, next) => next(),
  financialConfig,
  reference,
  completeProviderDeposit,
  paymentCountryName,
  provider = new AshtechPaymentProvider(),
  scheduler,
  automaticDepositsEnabled = false
}) {
  if (!app || !pool || typeof pool.query !== 'function' || typeof pool.connect !== 'function' ||
      typeof auth !== 'function' || typeof strictBody !== 'function' ||
      typeof financialConfig !== 'function' || typeof reference !== 'function' ||
      typeof completeProviderDeposit !== 'function' || typeof paymentCountryName !== 'function' ||
      typeof financialRate !== 'function') {
    throw new TypeError('registerPaymentRoutes requires the application payment dependencies');
  }

  const realTestModeActive = () => typeof provider.realTestModeActive === 'function' &&
    provider.realTestModeActive() === true;
  const collectionReady = () => typeof provider.collectionReady === 'function'
    ? provider.collectionReady() === true
    : Boolean(provider.configured());

  const blockedNigerOperators = async () => new Set((await pool.query(
    `SELECT DISTINCT operator FROM payment_orders
      WHERE country_code='NE' AND operator IS NOT NULL
        AND (external_redirect_required=true OR challenge_mode='wave' OR status='requires_redirect')
      UNION SELECT operator FROM payment_operator_blocks WHERE country_code='NE'`
  )).rows.map(row => row.operator));

  const options = async userCountry => {
    const accountCountry = userCountry === undefined ? null : countryForAccount(userCountry, paymentCountryName);
    const testMode = realTestModeActive();
    const result = {
      available: false,
      reason: 'Le paiement Mobile Money est temporairement indisponible.',
      country: accountCountry ? {
        code: accountCountry.code,
        name: accountCountry.name,
        currency: accountCountry.currency,
        dialCode: accountCountry.dialCode
      } : null,
      methods: [],
      manualWaveAvailable: false,
      manualWaveUrl: null,
      manualAvailable: false,
      manualUrl: null,
      minimumDeposit: 200,
      payerPhone: '',
      testMode,
      realTestWarning: testMode ? REAL_TEST_WARNING : null
    };
    let manualWaveMethod = null;
    try {
      const config = await financialConfig();
      result.minimumDeposit = Math.max(200, Number(config.minimumDeposit) || 200);
      if (!automaticDepositsEnabled) {
        result.manualOnly = true;
        result.manualAvailable = true;
        result.manualUrl = CM_MANUAL_URL;
        result.reason = 'Tous les nouveaux dépôts utilisent le paiement manuel, avec validation administrative.';
        return result;
      }
      if (!accountCountry) {
        result.reason = 'Le paiement Mobile Money automatique est réservé aux comptes du Bénin, de Côte d’Ivoire et du Niger. Le Cameroun et le Togo utilisent le paiement manuel.';
        return result;
      }
      if (accountCountry.code === 'CM') {
        result.manualOnly = true;
        result.manualUrl = CM_MANUAL_URL;
        result.reason = 'Les dépôts au Cameroun utilisent le paiement manuel, avec validation administrative.';
        return result;
      }
      let manualWaveChannel = null;
      let manualTogocelChannel = null;
      if (accountCountry.code === 'CI' || accountCountry.code === 'TG') {
        const channels = (await pool.query(
          `SELECT id,operator_name AS "operatorName",receiver_number AS "receiverNumber",
                  receiver_name AS "receiverName",country,country_code AS "countryCode",is_active AS "isActive"
             FROM payment_channels
            WHERE is_active=true AND country_code=$1`,
          [accountCountry.dialCode]
        )).rows;
        if (accountCountry.code === 'CI') manualWaveChannel = channels.find(isCoteDIvoireWaveChannel) || null;
        if (accountCountry.code === 'TG') manualTogocelChannel = channels.find(isTogoManualChannel) || null;
        if (manualWaveChannel) {
          result.manualWaveAvailable = true;
          result.manualWaveUrl = CI_WAVE_MANUAL_URL;
          result.manualAvailable = true;
          result.manualUrl = CI_WAVE_MANUAL_URL;
          manualWaveMethod = {
            id: manualWaveChannel.operatorName,
            name: manualWaveChannel.operatorName,
            manual: true,
            manualUrl: CI_WAVE_MANUAL_URL,
            manualWaveUrl: CI_WAVE_MANUAL_URL
          };
        }
        if (manualTogocelChannel) {
          result.manualAvailable = true;
          result.manualUrl = TG_TOGOCEL_MANUAL_URL;
          result.methods.push(...channels.filter(isTogoManualChannel).map(channel => ({
            id: channel.operatorName,
            name: isTogoFloozOperator(channel.operatorName) ? 'Flooz (Moov) — paiement manuel' : `${channel.operatorName} — paiement manuel`,
            manual: true,
            manualUrl: TG_TOGOCEL_MANUAL_URL
          })));
        }
      }
      if (accountCountry.code === 'TG') {
        result.reason = result.manualAvailable
          ? 'Au Togo, Flooz (Moov) et Togocel sont actuellement en paiement manuel, avec validation administrative.'
          : 'Aucun canal Flooz (Moov) ou Togocel manuel actif n’est configuré pour le Togo.';
        return result;
      }
      if (!collectionReady()) {
        if (manualWaveMethod) result.methods.push(manualWaveMethod);
        return result;
      }
      const catalog = await provider.getCatalog(accountCountry.code);
      if (catalog.code !== accountCountry.code || catalog.currency !== accountCountry.currency) {
        if (manualWaveMethod) result.methods.push(manualWaveMethod);
        return result;
      }
      const blockedOperators = accountCountry.code === 'NE' ? await blockedNigerOperators() : new Set();
      const automaticOperators = catalog.operators.filter(id => !blockedOperators.has(id) &&
        (accountCountry.code !== 'NE' || isNigerRechargeOperator(id)));
      if (accountCountry.code === 'NE' && automaticOperators.length === 0) {
        result.reason = 'Seuls Airtel et Moov sont autorisés au Niger. Aucun de ces opérateurs n’est actuellement disponible sans redirection externe.';
        return result;
      }
      result.available = true;
      delete result.reason;
      result.methods = [...result.methods, ...automaticOperators
        .filter(id => accountCountry.code !== 'CI' || manualWaveChannel || !isCoteDIvoireWaveOperator(id))
        .map(id => ({
          id,
          name: id,
          ...(manualWaveChannel && isCoteDIvoireWaveOperator(id)
            ? { manual: true, manualWaveUrl: CI_WAVE_MANUAL_URL }
            : {})
        }))];
      if (manualWaveMethod && !result.methods.some(method => isCoteDIvoireWaveOperator(method.id))) {
        result.methods.push(manualWaveMethod);
      }
      return result;
    } catch (error) {
      const safeError = publicProviderError(error);
      result.reason = accountCountry?.code === 'TG'
        ? 'Le paiement automatique Flooz (Moov) au Togo n’est pas disponible dans le catalogue actif du prestataire.'
        : safeError.message;
      result.errorCode = safeError.errorCode;
      if (manualWaveMethod && !result.methods.some(method => isCoteDIvoireWaveOperator(method.id))) {
        result.methods.push(manualWaveMethod);
      }
      if (safeError.retryAfterMs) {
        result.retryAfterSeconds = Math.max(1, Math.ceil(safeError.retryAfterMs / 1000));
      }
      return result;
    }
  };

  const getOwnedOrder = async (referenceValue, userId) => (await pool.query(
    `SELECT o.*, d.status AS deposit_status, d.amount AS deposit_amount,
            d.user_id AS deposit_user_id,d.payment_provider AS deposit_payment_provider,
            d.provider_tx_id AS deposit_provider_tx_id,
            u.phone AS user_phone, u.country AS user_country
       FROM payment_orders o
       JOIN deposits d ON d.id=o.deposit_id
       JOIN users u ON u.id=o.user_id
      WHERE o.reference=$1 AND o.user_id=$2 AND o.provider='ashtechpay'`,
    [referenceValue, userId]
  )).rows[0];

  const respondWithOrder = (res, row, code = 200) =>
    res.status(code).json(paymentDto(row, { testMode: realTestModeActive() }));

  async function lockReconciliationClaim(client, workerClaim) {
    if (!workerClaim) return true;
    if (workerClaim.eventId) {
      const event = (await client.query(
        `SELECT event_id FROM payment_webhook_events
          WHERE provider='ashtechpay' AND event_id=$1 AND processing_token=$2
            AND processing_until>now() AND processed_at IS NULL
          FOR UPDATE`,
        [workerClaim.eventId, workerClaim.processingToken]
      )).rows[0];
      if (!event) return false;
    }
    if (!workerClaim.orderId) return true;
    const order = (await client.query(
      `SELECT id FROM payment_orders
        WHERE id=$1 AND verification_processing_token=$2
          AND verification_processing_until>now()
        FOR UPDATE`,
      [workerClaim.orderId, workerClaim.processingToken]
    )).rows[0];
    return Boolean(order);
  }

  const updateStatus = async (orderId, status, extra = {}, expectedVersion = null, workerClaim = null) => {
    const values = [orderId, status, extra.transactionId || null, extra.sessionReference || null,
      extra.challengeMode || null, extra.ussdCode || null, extra.challengeMessage || null,
      extra.waveUrl || null, expectedVersion, extra.clearChallenge === true, Boolean(workerClaim?.orderId)];
    const sql =
      `UPDATE payment_orders SET status=$2,
         provider_tx_id=COALESCE(provider_tx_id,$3),
         provider_session_reference=COALESCE(provider_session_reference,$4),
         challenge_mode=CASE WHEN $10 THEN NULL ELSE COALESCE($5,challenge_mode) END,
         challenge_ussd_code=CASE WHEN $10 THEN NULL ELSE COALESCE($6,challenge_ussd_code) END,
         challenge_wave_url=CASE WHEN $10 THEN NULL ELSE COALESCE($8,challenge_wave_url) END,
         challenge_message=CASE WHEN $10 THEN $7 ELSE COALESCE($7,challenge_message) END,
         initiation_in_progress=false, otp_confirmation_in_progress=false,
         otp_confirmation_started_at=NULL,state_version=state_version+1,
         verification_processing_token=CASE WHEN $11 THEN NULL ELSE verification_processing_token END,
         verification_processing_until=CASE WHEN $11 THEN NULL ELSE verification_processing_until END,
         lease_updated_at=now(), updated_at=now()
       WHERE id=$1 AND status NOT IN ('succeeded','failed','requires_redirect')
           AND ($9::bigint IS NULL OR state_version=$9)`;
    if (!workerClaim) return pool.query(sql, values);

    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      if (!await lockReconciliationClaim(client, workerClaim)) {
        await client.query('ROLLBACK');
        return { rowCount: 0, rows: [] };
      }
      const locked = (await client.query(
        `SELECT id,status,state_version FROM payment_orders WHERE id=$1 FOR UPDATE`,
        [orderId]
      )).rows[0];
      if (!locked || Number(locked.state_version) !== Number(expectedVersion) ||
          ['succeeded', 'failed', 'requires_redirect'].includes(locked.status)) {
        await client.query('ROLLBACK');
        return { rowCount: 0, rows: [] };
      }
      const changed = await client.query(sql, values);
      if (!changed.rowCount) {
        await client.query('ROLLBACK');
        return changed;
      }
      await client.query('COMMIT');
      return changed;
    } catch (error) {
      try { await client.query('ROLLBACK'); } catch { /* transaction may already be closed */ }
      throw error;
    } finally {
      client.release();
    }
  };

  async function projectTerminalState(orderId, status, expectedVersion, message, workerClaim = null) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      if (!await lockReconciliationClaim(client, workerClaim)) {
        await client.query('ROLLBACK');
        return false;
      }
      const locked = (await client.query(
        `SELECT o.*,d.status AS deposit_status
           FROM payment_orders o JOIN deposits d ON d.id=o.deposit_id
          WHERE o.id=$1 FOR UPDATE OF o,d`,
        [orderId]
      )).rows[0];
      if (!locked || Number(locked.state_version) !== Number(expectedVersion) ||
          ['succeeded', 'failed', 'requires_redirect'].includes(locked.status)) {
        await client.query('ROLLBACK');
        return false;
      }
      const rejected = await client.query(
        `UPDATE deposits SET status='rejected',provider_return_status=$2
          WHERE id=$1 AND status='pending' AND payment_provider='ashtechpay' RETURNING id`,
        [locked.deposit_id, status]
      );
      if (!rejected.rowCount) {
        await client.query('ROLLBACK');
        return false;
      }
      const changed = await client.query(
        `UPDATE payment_orders SET status=$2,challenge_mode=NULL,challenge_ussd_code=NULL,
                challenge_wave_url=NULL,
                challenge_message=$3,initiation_in_progress=false,
                otp_confirmation_in_progress=false,otp_confirmation_started_at=NULL,
                verification_processing_token=NULL,verification_processing_until=NULL,
                state_version=state_version+1,lease_updated_at=now(),updated_at=now()
          WHERE id=$1 AND state_version=$4 AND status NOT IN ('succeeded','failed','requires_redirect')`,
        [orderId, status, message || null, expectedVersion]
      );
      if (!changed.rowCount) {
        await client.query('ROLLBACK');
        return false;
      }
      await client.query('COMMIT');
      return true;
    } catch (error) {
      try { await client.query('ROLLBACK'); } catch { /* transaction may already be closed */ }
      throw error;
    } finally {
      client.release();
    }
  }

  async function fulfill(order, verifiedTransaction, workerClaim = null) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      if (!await lockReconciliationClaim(client, workerClaim)) {
        await client.query('ROLLBACK');
        return false;
      }
      const locked = (await client.query(
        `SELECT o.*,d.status AS deposit_status,d.amount AS deposit_amount,d.user_id AS deposit_user_id,
                d.payment_provider AS deposit_payment_provider,d.provider_tx_id AS deposit_provider_tx_id,
                u.phone AS user_phone,u.country AS user_country
           FROM payment_orders o JOIN deposits d ON d.id=o.deposit_id
           JOIN users u ON u.id=o.user_id
          WHERE o.id=$1 FOR UPDATE OF o,d`,
        [order.id]
      )).rows[0];
      if (!locked) throw Object.assign(new Error('Payment order disappeared'), { status: 404 });
      if (locked.status === 'succeeded') {
        const consistent = locked.deposit_status === 'completed' &&
          locked.deposit_payment_provider === 'ashtechpay' &&
          locked.deposit_provider_tx_id === verifiedTransaction.transactionId;
        await client.query('COMMIT');
        return consistent;
      }
      if (['failed', 'requires_redirect'].includes(locked.status)) {
        await client.query('ROLLBACK');
        return false;
      }
      if (Number(locked.state_version) !== Number(order.state_version)) {
        await client.query('ROLLBACK');
        return false;
      }
      if (!positiveMatchForProvider(verifiedTransaction, locked) ||
          !canFulfillPayment(verifiedTransaction, locked) ||
          Number(locked.deposit_amount) !== Number(locked.amount) ||
          Number(locked.deposit_user_id) !== Number(locked.user_id) ||
          (locked.deposit_provider_tx_id &&
            String(locked.deposit_provider_tx_id) !== verifiedTransaction.transactionId) ||
          !orderMatchesAccount(locked, locked.user_country, paymentCountryName) ||
          !['pending', 'pending_review'].includes(locked.deposit_status) ||
          locked.deposit_payment_provider !== 'ashtechpay') {
        await client.query('ROLLBACK');
        return false;
      }
      const deposit = (await client.query(
        `UPDATE deposits SET payment_provider='ashtechpay',provider_tx_id=$2,
                provider_return_status='success',provider_confirmed_at=now()
          WHERE id=$1 AND status IN ('pending','pending_review')
            AND payment_provider='ashtechpay'
            AND (provider_tx_id IS NULL OR provider_tx_id=$2) RETURNING *`,
        [locked.deposit_id, verifiedTransaction.transactionId]
      )).rows[0];
      if (!deposit) {
        await client.query('ROLLBACK');
        return false;
      }
      await client.query('SELECT id FROM users WHERE id=$1 FOR UPDATE', [locked.user_id]);
      const completed = await completeProviderDeposit(client, deposit, {
        confirmedBy: 'ashtechpay_verified_api',
        txId: verifiedTransaction.transactionId
      });
      if (completed !== true) {
        await client.query('ROLLBACK');
        return false;
      }
      const projectedDeposit = (await client.query(
        `SELECT status,payment_provider,provider_tx_id FROM deposits WHERE id=$1`,
        [locked.deposit_id]
      )).rows[0];
      if (!projectedDeposit || projectedDeposit.status !== 'completed' ||
          projectedDeposit.payment_provider !== 'ashtechpay' ||
          projectedDeposit.provider_tx_id !== verifiedTransaction.transactionId) {
        await client.query('ROLLBACK');
        return false;
      }
      const projectedOrder = await client.query(
        `UPDATE payment_orders SET status='succeeded',provider_tx_id=$2,
           initiation_in_progress=false,otp_confirmation_in_progress=false,
            otp_confirmation_started_at=NULL,verification_processing_token=NULL,
            verification_processing_until=NULL,state_version=state_version+1,updated_at=now()
         WHERE id=$1 AND state_version=$3 AND status NOT IN ('succeeded','failed','requires_redirect')`,
        [locked.id, verifiedTransaction.transactionId, locked.state_version]
      );
      if (!projectedOrder.rowCount) {
        await client.query('ROLLBACK');
        return false;
      }
      await client.query('COMMIT');
      return true;
    } catch (error) {
      try { await client.query('ROLLBACK'); } catch { /* transaction may already be closed */ }
      throw error;
    } finally {
      client.release();
    }
  }

  async function verifyForOrder(order, { fromWebhook = false, workerClaim = null } = {}) {
    if (!order.provider_tx_id) return { kind: 'pending' };
    let transaction;
    try {
      transaction = await provider.verifyPayment(order.provider_tx_id);
    } catch (error) {
      return { kind: 'unavailable', error };
    }
    if (transaction?.simulated === true) {
      await updateStatus(order.id, 'verification_pending', {
        challengeMessage: 'Réponse de simulation/sandbox détectée. Elle ne constitue pas un paiement et ne sera jamais créditée.'
      }, order.state_version, workerClaim);
      return { kind: 'simulated', transaction };
    }
    if (!identityMatches(transaction, order)) {
      await updateStatus(order.id, 'verification_pending', {}, order.state_version, workerClaim);
      return { kind: 'mismatch' };
    }
    if (transaction.status === 'success') {
      const credited = await fulfill(order, transaction, workerClaim);
      return { kind: credited ? 'succeeded' : 'verification_pending', transaction };
    }
    if (transaction.status === 'failed') {
      await projectTerminalState(
        order.id, 'failed', order.state_version,
        'Le paiement n’a pas abouti. Pour recommencer, créez explicitement une nouvelle commande.',
        workerClaim
      );
      return { kind: 'failed', transaction };
    }
    if (transaction.status === 'pending') {
      if (order.status !== 'otp_required') {
        await updateStatus(order.id, 'pending', {
          challengeMessage: order.challenge_message || null
        }, order.state_version, workerClaim);
      }
      return { kind: 'pending', transaction };
    }
    await updateStatus(order.id, 'verification_pending', {}, order.state_version, workerClaim);
    return { kind: 'verification_pending', transaction, fromWebhook };
  }

  app.get('/api/payments/options', auth, async (req, res, next) => {
    try {
      const available = await options(req.user?.country);
      const payerPhone = req.user?.phone ? (() => {
        const accountCountry = countryForAccount(req.user.country, paymentCountryName);
        if (!accountCountry) return '';
        const normalized = validatePaymentPhone(
          String(req.user.phone).replace(new RegExp(`^\\${accountCountry.dialCode}`), ''),
          accountCountry.code
        );
        return normalized || '';
      })() : '';
      res.json({ ...available, payerPhone });
    } catch (error) { next(error); }
  });

  app.post('/api/payments/orders', auth, financialRate, strictBody(['amount', 'clientRequestId']), async (req, res, next) => {
    try {
      if (!automaticDepositsEnabled) return res.status(409).json({
        error: 'Les nouveaux dépôts doivent utiliser le paiement manuel.',
        errorCode: 'manual_payment_required',
        manualUrl: CM_MANUAL_URL
      });
      const accountCountry = countryForAccount(req.user.country, paymentCountryName);
      if (!accountCountry) return res.status(400).json({ error: 'Le paiement Mobile Money automatique est réservé aux comptes du Bénin, de Côte d’Ivoire et du Niger.' });
      if (accountCountry.code === 'CM') return res.status(409).json({
        error: 'Les dépôts au Cameroun doivent utiliser le paiement manuel.',
        errorCode: 'cameroon_manual_required',
        manualUrl: CM_MANUAL_URL
      });
      if (accountCountry.code === 'TG') return res.status(409).json({
        error: 'Flooz (Moov) et Togocel sont actuellement en paiement manuel au Togo.',
        errorCode: 'togo_manual_required',
        manualUrl: TG_TOGOCEL_MANUAL_URL
      });
      const config = await financialConfig();
      const amount = req.body?.amount;
      const clientRequestId = String(req.body?.clientRequestId || '').trim();
      if (!amountWithinLimits(amount, config.minimumDeposit)) {
        return res.status(400).json({ error: `Le dépôt minimum est de ${Math.max(200, Number(config.minimumDeposit) || 200)} FCFA et le montant maximal est de ${MAX_DEPOSIT} FCFA.` });
      }
      if (!/^[a-zA-Z0-9_-]{12,80}$/.test(clientRequestId)) {
        return res.status(400).json({ error: 'Requête de paiement invalide.' });
      }
      const client = await pool.connect();
      let created;
      try {
        await client.query('BEGIN');
        const existing = (await client.query(
          `SELECT * FROM payment_orders WHERE user_id=$1 AND client_request_id=$2 FOR UPDATE`,
          [req.user.id, clientRequestId]
        )).rows[0];
        if (existing) {
          if (Number(existing.amount) !== amount || !orderMatchesAccount(existing, req.user.country, paymentCountryName)) {
            await client.query('ROLLBACK');
            return res.status(409).json({ error: 'Cette requête de paiement existe déjà avec un autre montant ou pays.' });
          }
          await client.query('COMMIT');
          return respondWithOrder(res, existing);
        }
        if (!collectionReady()) {
          await client.query('ROLLBACK');
          return res.status(503).json({ error: GENERIC_UNAVAILABLE });
        }
        const orderReference = reference('DEP');
        const deposit = (await client.query(
          `INSERT INTO deposits(user_id,amount,status,reference,payment_provider,client_request_id)
           VALUES($1,$2,'pending',$3,'ashtechpay',$4) RETURNING id`,
          [req.user.id, amount, orderReference, clientRequestId]
        )).rows[0];
        created = (await client.query(
          `INSERT INTO payment_orders(user_id,deposit_id,reference,client_request_id,amount,currency,country_code)
           VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
          [req.user.id, deposit.id, orderReference, clientRequestId, amount, accountCountry.currency, accountCountry.code]
        )).rows[0];
        await client.query('COMMIT');
      } catch (error) {
        try { await client.query('ROLLBACK'); } catch { /* transaction may already be closed */ }
        if (error.code === '23514' && error.constraint === 'payment_orders_country_currency_check') {
          return res.status(503).json({
            error: `La configuration des paiements Mobile Money pour ${accountCountry.name} est incomplète sur cette version publiée du site. Aucune demande n’a été envoyée à l’opérateur pour cette tentative; ne payez pas davantage. Contactez le support avant de réessayer.`,
            errorCode: 'payment_country_not_enabled'
          });
        }
        if (error.code === '23505') {
          const existing = (await pool.query(
            `SELECT * FROM payment_orders WHERE user_id=$1 AND client_request_id=$2`,
            [req.user.id, clientRequestId]
          )).rows[0];
          if (existing && Number(existing.amount) === amount &&
              orderMatchesAccount(existing, req.user.country, paymentCountryName)) return respondWithOrder(res, existing);
          if (existing) return res.status(409).json({ error: 'Cette requête de paiement existe déjà avec un autre montant ou pays.' });
        }
        throw error;
      } finally { client.release(); }
      return respondWithOrder(res, created, 201);
    } catch (error) { next(error); }
  });

  app.post('/api/payments/create', auth, financialRate, strictBody(['reference', 'operator', 'phone', 'otp']), async (req, res, next) => {
    try {
      const referenceValue = String(req.body?.reference || '').trim();
      const operator = String(req.body?.operator || '').trim();
      const otp = req.body?.otp;
      if (!referenceValue || referenceValue.length > 191 || !operator || operator.length > 120 ||
          (otp !== undefined && (typeof otp !== 'string' || !/^\d{4,10}$/.test(otp)))) {
        return res.status(400).json({ error: 'Informations de paiement invalides.' });
      }
      let order = await getOwnedOrder(referenceValue, req.user.id);
      if (!order) return res.status(404).json({ error: 'Commande de paiement introuvable.' });
      if (!orderMatchesAccount(order, order.user_country, paymentCountryName) ||
          !orderMatchesAccount(order, req.user.country, paymentCountryName)) {
        return res.status(404).json({ error: 'Commande de paiement introuvable.' });
      }
      if (!automaticDepositsEnabled) {
        // Do not re-initiate an already sent or uncertain payment. Its status,
        // reconciliation and signed webhook remain available independently.
        if (order.status !== 'created' || order.provider_tx_id || order.provider_session_reference ||
            order.initiation_attempted || order.initiation_in_progress || order.otp_confirmation_in_progress ||
            order.challenge_mode) return respondWithOrder(res, order);
        return res.status(409).json({
          ...paymentDto(order, { testMode: realTestModeActive() }),
          error: 'Les dépôts sont manuels. Aucune nouvelle collecte automatique n’a été envoyée.',
          errorCode: 'manual_payment_required',
          manualUrl: `${CM_MANUAL_URL}?amount=${encodeURIComponent(Number(order.amount))}`
        });
      }
      const phone = validatePaymentPhone(req.body?.phone, order.country_code);
      if (!phone) {
        return res.status(400).json({ error: 'Informations de paiement invalides.' });
      }
      if (order.operator && (order.operator !== operator || order.phone !== phone)) {
        return res.status(409).json({ error: 'L’opérateur et le numéro sont verrouillés pour cette commande.' });
      }
      const orderCountry = countryForOrder(order.country_code, order.currency);
      if (orderCountry?.code === 'CM' && order.status === 'created') {
        if (order.provider_tx_id || order.provider_session_reference || order.initiation_in_progress ||
            order.otp_confirmation_in_progress || order.challenge_mode) return respondWithOrder(res, order);
        return res.status(409).json({
          ...paymentDto(order, { testMode: realTestModeActive() }),
          error: 'Les dépôts au Cameroun doivent utiliser le paiement manuel. Aucune nouvelle collecte n’a été envoyée.',
          errorCode: 'cameroon_manual_required',
          manualUrl: `${CM_MANUAL_URL}?amount=${encodeURIComponent(Number(order.amount))}`
        });
      }
      if (orderCountry?.code === 'CI' && isCoteDIvoireWaveOperator(operator)) {
        if (order.provider_tx_id) return respondWithOrder(res, order);
        if (order.status === 'created' || (order.status === 'otp_required' && otp !== undefined)) {
          const config = await financialConfig();
          const manualAmount = Number(order.amount);
          const manualUrl = amountWithinLimits(manualAmount, config.minimumDeposit)
            ? `/paiement_gopay/code.html?amount=${encodeURIComponent(manualAmount)}&manual=wave`
            : null;
          return res.status(409).json({
            error: 'Wave en Côte d’Ivoire doit être réglé par le canal manuel. Aucune collecte automatique n’a été envoyée.',
            errorCode: 'wave_manual_required',
            ...(manualUrl ? { manualUrl } : {})
          });
        }
      }
      if (orderCountry?.code === 'TG') {
        // Previously sent payments keep their identity and remain verifiable.
        if (!order.initiation_attempted && !order.provider_tx_id && order.status === 'created') {
          return res.status(409).json({
            error: 'Flooz (Moov) et Togocel sont en paiement manuel au Togo. Aucune collecte automatique n’a été envoyée.',
            errorCode: 'togo_manual_required',
            ...(amountWithinLimits(Number(order.amount), (await financialConfig()).minimumDeposit)
              ? { manualUrl: `/paiement_gopay/code.html?amount=${encodeURIComponent(Number(order.amount))}&manual=togocel` }
              : {})
          });
        }
      }
      if (order.status !== 'created' && !(order.status === 'otp_required' && otp !== undefined)) {
        return respondWithOrder(res, order, order.status === 'initiating' ? 202 : 200);
      }
      if (otp !== undefined && order.status !== 'otp_required') {
        return res.status(409).json({ error: 'Aucune session OTP active pour cette commande.' });
      }
      if (order.status === 'otp_required' && otp === undefined) return respondWithOrder(res, order);
      if (order.country_code === 'NE' && !isNigerRechargeOperator(operator)) {
        return res.status(403).json({
          ...paymentDto(order, { testMode: realTestModeActive() }),
          error: 'Seuls Airtel et Moov sont autorisés pour les recharges au Niger. Aucune nouvelle demande n’a été envoyée.',
          errorCode: 'niger_operator_not_allowed'
        });
      }
      if (confirmationWindow(order).confirmationExpired) {
        return res.status(409).json({
          ...paymentDto(order, { testMode: realTestModeActive() }),
          error: 'Le délai de confirmation de 8 minutes est dépassé. Aucun code ni nouvelle collecte ne sera envoyé. La vérification du paiement existant continue.',
          errorCode: 'confirmation_window_expired'
        });
      }
      if (!collectionReady()) return res.status(503).json({ error: GENERIC_UNAVAILABLE });
      if (order.country_code === 'NE' && (await blockedNigerOperators()).has(operator)) {
        return res.status(409).json({
          error: 'Cet opérateur a été retiré car il exige une validation externe. Aucune nouvelle demande n’a été envoyée.',
          errorCode: 'niger_operator_requires_redirect'
        });
      }
      let catalog;
      try { catalog = await provider.getCatalog(order.country_code); } catch (error) {
        const safeError = publicProviderError(error);
        if (safeError.retryAfterMs) {
          const retryAfterSeconds = Math.max(1, Math.ceil(safeError.retryAfterMs / 1000));
          res.set?.('Retry-After', String(retryAfterSeconds));
          res.setHeader?.('Retry-After', String(retryAfterSeconds));
          return res.status(429).json({
            error: safeError.message,
            errorCode: safeError.errorCode,
            retryAfterSeconds
          });
        }
        return res.status(safeError.status).json({
          error: safeError.message,
          errorCode: safeError.errorCode
        });
      }
      if (catalog.code !== order.country_code || catalog.currency !== order.currency ||
          !catalog.operators.includes(operator) ||
          (order.country_code === 'TG' && !isTogoFloozOperator(operator))) {
        return res.status(400).json({ error: 'Cet opérateur n’est pas disponible dans le catalogue de paiement.' });
      }
      const client = await pool.connect();
      let claim;
      try {
        await client.query('BEGIN');
        const locked = (await client.query(
          `SELECT o.*,u.country AS user_country FROM payment_orders o JOIN users u ON u.id=o.user_id
            WHERE o.id=$1 AND o.user_id=$2 FOR UPDATE OF o,u`,
          [order.id, req.user.id]
        )).rows[0];
        if (!locked) throw Object.assign(new Error('Commande introuvable'), { status: 404 });
        if (!orderMatchesAccount(locked, locked.user_country, paymentCountryName) ||
            !orderMatchesAccount(locked, req.user.country, paymentCountryName)) {
          await client.query('ROLLBACK');
          return res.status(404).json({ error: 'Commande de paiement introuvable.' });
        }
        if (locked.operator && (locked.operator !== operator || locked.phone !== phone)) {
          await client.query('ROLLBACK');
          return res.status(409).json({ error: 'L’opérateur et le numéro sont verrouillés pour cette commande.' });
        }
        if (otp !== undefined) {
          if (confirmationWindow(locked).confirmationExpired) {
            await client.query('ROLLBACK');
            return res.status(409).json({
              ...paymentDto(locked, { testMode: realTestModeActive() }),
              error: 'Le délai de confirmation de 8 minutes est dépassé. Aucun code ne sera envoyé.',
              errorCode: 'confirmation_window_expired'
            });
          }
          if (locked.status !== 'otp_required' || !locked.provider_session_reference) {
            await client.query('ROLLBACK');
            return res.status(409).json({ error: 'La session OTP de cette commande n’est plus active.' });
          }
          if (locked.otp_confirmation_in_progress) {
            await client.query('ROLLBACK');
            const current = await getOwnedOrder(referenceValue, req.user.id);
            if (!current) return res.status(404).json({ error: 'Commande de paiement introuvable.' });
            return res.status(409).json({
              ...paymentDto(current, { testMode: realTestModeActive() }),
              error: 'Une confirmation OTP est déjà en cours.',
              errorCode: 'otp_confirmation_in_progress'
            });
          }
          const changed = await client.query(
            `UPDATE payment_orders SET operator=$2,phone=$3,otp_confirmation_in_progress=true,
                    otp_confirmation_started_at=now(),state_version=state_version+1,
                    lease_updated_at=now(),updated_at=now() WHERE id=$1 AND status='otp_required'
                    AND otp_confirmation_in_progress=false RETURNING *`,
            [locked.id, operator, phone]
          );
          claim = changed.rows[0];
        } else {
          if (locked.status !== 'created' || locked.initiation_attempted) {
            await client.query('ROLLBACK');
            const current = await getOwnedOrder(referenceValue, req.user.id);
            return respondWithOrder(res, current || order, 202);
          }
          const changed = await client.query(
            `UPDATE payment_orders SET operator=$2,phone=$3,status='initiating',
                    initiation_attempted=true,initiation_in_progress=true,
                    initiation_started_at=now(),otp_confirmation_started_at=NULL,
                    state_version=state_version+1,lease_updated_at=now(),updated_at=now()
              WHERE id=$1 AND status='created' AND initiation_attempted=false RETURNING *`,
            [locked.id, operator, phone]
          );
          claim = changed.rows[0];
        }
        if (!claim) {
          await client.query('ROLLBACK');
          const current = await getOwnedOrder(referenceValue, req.user.id);
          return respondWithOrder(res, current || order, 202);
        }
        await client.query('COMMIT');
      } catch (error) {
        try { await client.query('ROLLBACK'); } catch { /* transaction may already be closed */ }
        throw error;
      } finally { client.release(); }

      let result;
      try {
        result = await provider.createPayment({
          amount: Number(claim.amount),
          currency: claim.currency,
          countryCode: claim.country_code,
          operator,
          phone,
          reference: otp !== undefined ? claim.provider_session_reference : claim.reference,
          ...(otp !== undefined ? { otp } : {})
        });
      } catch (error) {
        const safeError = publicProviderError(error);
        if (otp !== undefined && safeError.errorCode === 'otp_confirmation_in_progress') {
          const current = await getOwnedOrder(referenceValue, req.user.id);
          const sameConfirmationLease = current?.status === 'otp_required' &&
            current.otp_confirmation_in_progress === true &&
            current.provider_session_reference === claim.provider_session_reference &&
            Number(current.state_version) === Number(claim.state_version);
          if (sameConfirmationLease) {
            return res.status(409).json({
              ...paymentDto(current, { testMode: realTestModeActive() }),
              error: safeError.message,
              errorCode: safeError.errorCode
            });
          }
          if (!current) return res.status(404).json({ error: 'Commande de paiement introuvable.' });
          return respondWithOrder(
            res,
            current,
            ['pending', 'otp_required', 'verification_pending'].includes(current.status) ? 202 : 200
          );
        }
        await updateStatus(
          claim.id, 'verification_pending',
          { challengeMessage: safeError.message, clearChallenge: true },
          claim.state_version
        );
        order = await getOwnedOrder(referenceValue, req.user.id);
        if (safeError.retryAfterMs) {
          const retryAfterSeconds = Math.max(1, Math.ceil(safeError.retryAfterMs / 1000));
          res.set?.('Retry-After', String(retryAfterSeconds));
          res.setHeader?.('Retry-After', String(retryAfterSeconds));
        }
        return res.status(safeError.status).json({
          ...paymentDto(order, { testMode: realTestModeActive() }),
          error: safeError.message,
          errorCode: safeError.errorCode,
          ...(safeError.retryAfterMs
            ? { retryAfterSeconds: Math.max(1, Math.ceil(safeError.retryAfterMs / 1000)) }
            : {})
        });
      }

      if (result.kind === 'otp_required') {
        if (!result.sessionReference || result.sessionReference.length > 191) {
          await updateStatus(
            claim.id, 'verification_pending', { transactionId: result.transactionId }, claim.state_version
          );
        } else {
          const mode = result.ussdCode ? 'ussd' : 'sms';
          const ussdCode = mode === 'ussd' && /^[#*0-9A-Da-d+]{1,80}$/.test(result.ussdCode) ? result.ussdCode : null;
          const challengeMode = mode === 'ussd' && ussdCode ? 'ussd' : 'sms';
          const challengeMessage = challengeMode === 'ussd'
            ? 'Composez le code USSD, puis saisissez le code reçu pour confirmer le paiement.'
            : 'Saisissez le code reçu par SMS pour confirmer le paiement.';
          await pool.query(
            `UPDATE payment_orders SET status='otp_required',
                    provider_session_reference=COALESCE(provider_session_reference,$2),
                    provider_tx_id=COALESCE(provider_tx_id,$3),challenge_mode=$4,
                    challenge_ussd_code=$5,challenge_message=$6,
                    initiation_in_progress=false,otp_confirmation_in_progress=false,
                    otp_confirmation_started_at=NULL,state_version=state_version+1,updated_at=now()
              WHERE id=$1 AND state_version=$7 AND status NOT IN ('succeeded','failed','requires_redirect')`,
            [claim.id, result.sessionReference, result.transactionId || null, challengeMode,
              challengeMode === 'ussd' ? ussdCode : null, challengeMessage, claim.state_version]
          );
        }
      } else if (result.kind === 'invalid_otp') {
        const invalidOtp = await pool.query(
          `UPDATE payment_orders SET status='otp_required',otp_confirmation_in_progress=false,
                  initiation_in_progress=false,otp_confirmation_started_at=NULL,
                  state_version=state_version+1,updated_at=now()
            WHERE id=$1 AND status='otp_required' AND otp_confirmation_in_progress=true
              AND state_version=$2 RETURNING id`,
          [claim.id, claim.state_version]
        );
        order = await getOwnedOrder(referenceValue, req.user.id);
        if (!order) return res.status(404).json({ error: 'Commande de paiement introuvable.' });
        if (!invalidOtp.rowCount) {
          return respondWithOrder(
            res, order,
            ['pending', 'otp_required', 'verification_pending'].includes(order.status) ? 202 : 200
          );
        }
        return res.status(400).json({
          ...paymentDto(order, { testMode: realTestModeActive() }),
          error: 'Le code OTP est invalide. Vérifiez-le et saisissez à nouveau le code reçu.',
          errorCode: 'invalid_otp'
        });
      } else if (result.kind === 'otp_expired') {
        const expired = await projectTerminalState(
          claim.id, 'failed', claim.state_version,
          'La session OTP a expiré. Créez une nouvelle commande pour recommencer.'
        );
        order = await getOwnedOrder(referenceValue, req.user.id);
        if (!order) return res.status(404).json({ error: 'Commande de paiement introuvable.' });
        if (!expired) {
          return respondWithOrder(
            res, order,
            ['pending', 'otp_required', 'verification_pending'].includes(order.status) ? 202 : 200
          );
        }
        return res.status(400).json({
          ...paymentDto(order, { testMode: realTestModeActive() }),
          error: 'La session OTP a expiré. Créez une nouvelle commande pour recommencer.',
          errorCode: 'otp_expired'
        });
      } else if (claim.country_code === 'NE' && ['requires_redirect', 'wave'].includes(result.kind)) {
        await pool.query(
          `INSERT INTO payment_operator_blocks(country_code,operator,reason)
            VALUES('NE',$1,'external_redirect') ON CONFLICT(country_code,operator) DO NOTHING`,
          [operator]
        );
        await pool.query(
          `UPDATE payment_orders SET external_redirect_required=true
            WHERE id=$1 AND country_code='NE' AND operator=$2`,
          [claim.id, operator]
        );
        // Removing an operator must not lose the identity of a sent payment.
        // Continue status reconciliation without opening a link or re-collecting.
        await updateStatus(claim.id, 'verification_pending', {
          transactionId: result.transactionId,
          sessionReference: result.sessionReference,
          clearChallenge: true,
          challengeMessage: NIGER_REDIRECT_BLOCKED
        }, claim.state_version);
      } else if (result.kind === 'requires_redirect') {
        await projectTerminalState(
          claim.id, 'requires_redirect', claim.state_version, REDIRECT_MESSAGE
        );
      } else if (result.kind === 'wave') {
        if (validWaveUrl(result.waveUrl)) {
          await updateStatus(claim.id, 'pending', {
            transactionId: result.transactionId,
            sessionReference: result.sessionReference,
            challengeMode: 'wave',
            waveUrl: result.waveUrl,
            challengeMessage: 'Ouvrez Wave pour confirmer le paiement, puis attendez sa vérification.'
          }, claim.state_version);
        } else {
          await updateStatus(claim.id, 'verification_pending', {
            transactionId: result.transactionId,
            sessionReference: result.sessionReference,
            challengeMessage: 'La réponse Wave ne contient pas d’URL de confirmation HTTPS vérifiable. Le paiement reste en attente de vérification.'
          }, claim.state_version);
        }
      } else if (result.kind === 'pending') {
        await updateStatus(claim.id, 'pending', {
          transactionId: result.transactionId,
          sessionReference: result.sessionReference,
          challengeMessage: otp !== undefined
            ? 'Confirmation incertaine. Ne renvoyez pas le code. Attendez la notification ou contactez le support si le statut ne se résout pas.'
            : null
        }, claim.state_version);
      } else {
        await updateStatus(claim.id, 'verification_pending', {
          transactionId: result.transactionId,
          sessionReference: result.sessionReference,
          challengeMessage: result.simulated
            ? 'Réponse de simulation/sandbox détectée. Elle ne constitue pas un paiement et ne sera jamais créditée.'
            : otp !== undefined
            ? 'Confirmation incertaine. Ne renvoyez pas le code. Attendez la notification ou contactez le support si le statut ne se résout pas.'
            : null
        }, claim.state_version);
      }
      order = await getOwnedOrder(referenceValue, req.user.id);
      return respondWithOrder(res, order, ['pending', 'otp_required', 'verification_pending', 'requires_redirect'].includes(order.status) ? 202 : 200);
    } catch (error) { next(error); }
  });

  app.get('/api/payments/:reference/status', auth, async (req, res, next) => {
    try {
      let order = await getOwnedOrder(req.params.reference, req.user.id);
      if (!order) return res.status(404).json({ error: 'Commande de paiement introuvable.' });
      if (!orderMatchesAccount(order, order.user_country, paymentCountryName) ||
          !orderMatchesAccount(order, req.user.country, paymentCountryName)) {
        return res.status(404).json({ error: 'Commande de paiement introuvable.' });
      }
      if (order.status === 'initiating' && order.initiation_started_at &&
          Date.now() - new Date(order.initiation_started_at).getTime() > INITIATION_LEASE_MS) {
        await updateStatus(order.id, 'verification_pending', {}, order.state_version);
        order = await getOwnedOrder(req.params.reference, req.user.id);
        if (!order || !orderMatchesAccount(order, req.user.country, paymentCountryName)) {
          return res.status(404).json({ error: 'Commande de paiement introuvable.' });
        }
      } else if (order.status === 'otp_required' && order.otp_confirmation_in_progress &&
          order.otp_confirmation_started_at &&
          Date.now() - new Date(order.otp_confirmation_started_at).getTime() > INITIATION_LEASE_MS) {
        await updateStatus(
          order.id, 'verification_pending',
          { challengeMessage: 'Une confirmation OTP reste incertaine. Ne renvoyez pas le code. Attendez la notification ou contactez le support si le statut ne se résout pas.' },
          order.state_version
        );
        order = await getOwnedOrder(req.params.reference, req.user.id);
      }
      if (order.status === 'succeeded' || order.status === 'failed' || order.status === 'requires_redirect') {
        return respondWithOrder(res, order);
      }
      if (order.provider_tx_id) {
        const verified = await verifyForOrder(order);
        if (verified.kind === 'unavailable') {
          const apiError = verified.error;
          if (apiError?.status === 429) {
            const retryAfter = Math.max(1, Math.ceil((apiError.retryAfterMs || 1000) / 1000));
            res.set?.('Retry-After', String(retryAfter));
            res.setHeader?.('Retry-After', String(retryAfter));
            return res.status(429).json({
              ...paymentDto(order, { testMode: realTestModeActive() }),
              error: 'AshTech Pay a limité les vérifications. Attendez le délai indiqué avant de consulter à nouveau.',
              errorCode: 'rate_limited',
              retryAfterSeconds: retryAfter
            });
          }
          const safeError = publicProviderError(apiError);
          return res.status(safeError.status === 503 ? 503 : 502).json({
            ...paymentDto(order, { testMode: realTestModeActive() }),
            error: safeError.message,
            errorCode: safeError.errorCode || 'provider_unavailable'
          });
        }
        order = await getOwnedOrder(req.params.reference, req.user.id);
      }
      return respondWithOrder(res, order);
    } catch (error) { next(error); }
  });

  async function releaseWebhookClaim(row, message, matchStatus = 'retryable') {
    return pool.query(
      `UPDATE payment_webhook_events SET match_status=$3,last_error=$4,
              processing_token=NULL,processing_until=NULL
        WHERE provider='ashtechpay' AND event_id=$1 AND processing_token=$2
          AND processed_at IS NULL`,
      [row.event_id, row.processing_token, matchStatus, message]
    );
  }

  async function markWebhookProcessed(row, depositId) {
    return pool.query(
      `UPDATE payment_webhook_events SET processed_at=COALESCE(processed_at,now()),
              match_status='matched',deposit_id=$3,last_error=NULL,
              processing_token=NULL,processing_until=NULL
        WHERE provider='ashtechpay' AND event_id=$1 AND processing_token=$2
          AND processed_at IS NULL`,
      [row.event_id, row.processing_token, depositId]
    );
  }

  async function releaseOrderVerificationClaim(workerClaim) {
    if (!workerClaim?.orderId) return { rowCount: 0, rows: [] };
    return pool.query(
      `UPDATE payment_orders SET verification_processing_token=NULL,
              verification_processing_until=NULL
        WHERE id=$1 AND verification_processing_token=$2`,
      [workerClaim.orderId, workerClaim.processingToken]
    );
  }

  async function reconcileStoredWebhook(row) {
    const payload = row.payload && typeof row.payload === 'object'
      ? row.payload
      : JSON.parse(String(row.payload || '{}'));
    const tx = {
      transactionId: payload.transactionId,
      merchantReference: payload.merchantReference,
      amount: payload.amount,
      grossAmountProvided: payload.grossAmountProvided === true,
      currency: payload.currency,
      operator: payload.operator,
      countryCode: payload.countryCode,
      phone: payload.phone,
      status: payload.status
    };
    const candidates = (await pool.query(
      `SELECT o.*,d.status AS deposit_status,d.amount AS deposit_amount,d.user_id AS deposit_user_id,
              d.payment_provider AS deposit_payment_provider,d.provider_tx_id AS deposit_provider_tx_id,
              u.phone AS user_phone,u.country AS user_country
         FROM payment_orders o JOIN deposits d ON d.id=o.deposit_id
         JOIN users u ON u.id=o.user_id
        WHERE o.provider='ashtechpay'
          AND (o.provider_tx_id=$1 OR o.reference=$2 OR o.provider_session_reference=$2)`,
      [tx.transactionId, tx.merchantReference]
    )).rows;
    if (candidates.length !== 1 || !webhookMapsToOrder(tx, candidates[0])) {
      await releaseWebhookClaim(row, 'Aucune commande unique ne correspond encore à l’événement signé.');
      return false;
    }

    const order = candidates[0];
    const client = await pool.connect();
    let terminalDepositId = null;
    try {
      await client.query('BEGIN');
      if (!await lockReconciliationClaim(client, {
        eventId: row.event_id, processingToken: row.processing_token
      })) {
        await client.query('ROLLBACK');
        return false;
      }
      const locked = (await client.query(
        `SELECT o.*,d.status AS deposit_status,d.payment_provider AS deposit_payment_provider,
                d.provider_tx_id AS deposit_provider_tx_id
           FROM payment_orders o JOIN deposits d ON d.id=o.deposit_id
          WHERE o.id=$1 FOR UPDATE OF o,d`,
        [order.id]
      )).rows[0];
      if (!locked || !webhookMapsToOrder(tx, locked)) {
        await client.query('ROLLBACK');
        await releaseWebhookClaim(row, 'L’identité financière de la commande ne correspond pas.');
        return false;
      }
      if (locked.status === 'succeeded' &&
          locked.deposit_status === 'completed' &&
          locked.deposit_payment_provider === 'ashtechpay' &&
          locked.deposit_provider_tx_id === tx.transactionId &&
          tx.status === 'success') {
        terminalDepositId = locked.deposit_id;
      } else if (locked.status === 'failed' &&
          locked.deposit_status === 'rejected' &&
          locked.deposit_provider_tx_id === tx.transactionId &&
          tx.status === 'failed') {
        terminalDepositId = locked.deposit_id;
      } else {
        const claimed = await client.query(
        `UPDATE payment_orders SET webhook_seen=true,webhook_event_id=COALESCE(webhook_event_id,$2),
                provider_tx_id=COALESCE(provider_tx_id,$3),
                status=CASE WHEN status IN ('created','initiating','otp_required') THEN 'verification_pending' ELSE status END,
                challenge_mode=CASE WHEN status='otp_required' THEN NULL ELSE challenge_mode END,
                challenge_ussd_code=CASE WHEN status='otp_required' THEN NULL ELSE challenge_ussd_code END,
                challenge_wave_url=CASE WHEN status='otp_required' THEN NULL ELSE challenge_wave_url END,
                challenge_message=CASE WHEN status='otp_required' THEN $4 ELSE challenge_message END,
                initiation_in_progress=false,otp_confirmation_in_progress=false,
                otp_confirmation_started_at=NULL,verification_processing_token=$5,
                verification_processing_until=now()+($6::double precision*interval '1 millisecond'),
                verification_last_attempt_at=now(),state_version=state_version+1,updated_at=now()
          WHERE id=$1 AND (verification_processing_until IS NULL OR verification_processing_until<=now())
            AND status NOT IN ('succeeded','failed','requires_redirect') RETURNING id`,
          [order.id, row.event_id, tx.transactionId,
            'Une confirmation OTP reste incertaine. Ne renvoyez pas le code. Attendez la vérification du statut.',
            row.processing_token, RECONCILIATION_LEASE_MS]
        );
        if (!claimed.rowCount) {
          await client.query('ROLLBACK');
          await releaseWebhookClaim(row, 'Une vérification de cette commande est déjà en cours.');
          return false;
        }
      }
      await client.query('COMMIT');
      if (terminalDepositId) return (await markWebhookProcessed(row, terminalDepositId)).rowCount === 1;
    } catch (error) {
      try { await client.query('ROLLBACK'); } catch { /* transaction may already be closed */ }
      throw error;
    } finally {
      client.release();
    }

    const workerClaim = {
      eventId: row.event_id, processingToken: row.processing_token,
      orderId: order.id
    };
    try {
      const refreshed = await getOwnedOrder(order.reference, order.user_id);
      if (!refreshed) throw new Error('Stored webhook order is unavailable');
      const verified = await verifyForOrder(refreshed, { fromWebhook: true, workerClaim });
      if (verified.kind === 'unavailable') throw verified.error || new Error('Provider status unavailable');
      const finalOrder = await getOwnedOrder(order.reference, order.user_id);
      if (!finalOrder) throw new Error('Stored webhook order is unavailable');
      const resolvedSuccess = finalOrder.status === 'succeeded' &&
        finalOrder.deposit_status === 'completed' &&
        finalOrder.deposit_payment_provider === 'ashtechpay' &&
        finalOrder.deposit_provider_tx_id === tx.transactionId;
      const resolvedFailure = finalOrder.status === 'failed' && finalOrder.deposit_status === 'rejected';
      if (!resolvedSuccess && !resolvedFailure) {
        await releaseWebhookClaim(row, 'La vérification serveur du statut final reste en attente.');
        return false;
      }
      const processed = await markWebhookProcessed(row, finalOrder.deposit_id);
      return processed.rowCount === 1;
    } finally {
      try { await releaseOrderVerificationClaim(workerClaim); } catch { /* Expiring claim remains recoverable. */ }
    }
  }

  async function reconcileKnownOrder(row) {
    const workerClaim = {
      orderId: row.id,
      processingToken: row.verification_processing_token
    };
    try {
      const order = await getOwnedOrder(row.reference, row.user_id);
      if (!order || !order.provider_tx_id ||
          !orderMatchesAccount(order, order.user_country, paymentCountryName)) return false;
      const verified = await verifyForOrder(order, { workerClaim });
      if (!['succeeded', 'failed'].includes(verified.kind)) return false;
      const finalOrder = await getOwnedOrder(row.reference, row.user_id);
      return verified.kind === 'succeeded'
        ? finalOrder?.status === 'succeeded' &&
          finalOrder.deposit_status === 'completed' &&
          finalOrder.deposit_payment_provider === 'ashtechpay' &&
          finalOrder.deposit_provider_tx_id === verified.transaction?.transactionId
        : finalOrder?.status === 'failed' && finalOrder.deposit_status === 'rejected';
    } finally {
      try { await releaseOrderVerificationClaim(workerClaim); } catch { /* Expiring claim remains recoverable. */ }
    }
  }

  async function runOrderReconciliation() {
    const processingToken = crypto.randomUUID();
    const pending = (await pool.query(
      `WITH eligible AS (
         SELECT o.id FROM payment_orders o JOIN deposits d ON d.id=o.deposit_id
          WHERE o.provider='ashtechpay' AND o.provider_tx_id IS NOT NULL
            AND o.status IN ('created','initiating','pending','otp_required','verification_pending')
            AND o.webhook_seen=false
            AND d.status IN ('pending','pending_review')
            AND d.payment_provider='ashtechpay'
            AND (o.verification_processing_until IS NULL OR o.verification_processing_until<=now())
          ORDER BY COALESCE(o.verification_last_attempt_at,o.created_at) ASC,o.created_at ASC
          LIMIT 20 FOR UPDATE OF o SKIP LOCKED
       )
       UPDATE payment_orders AS queued
          SET verification_last_attempt_at=now(),verification_processing_token=$1,
              verification_processing_until=now()+($2::double precision*interval '1 millisecond')
         FROM eligible
        WHERE queued.id=eligible.id
       RETURNING queued.id,queued.reference,queued.user_id,queued.verification_processing_token`,
      [processingToken, RECONCILIATION_LEASE_MS]
    )).rows;
    let resolved = 0;
    for (let offset = 0; offset < pending.length; offset += 5) {
      const batch = pending.slice(offset, offset + 5);
      const results = await Promise.all(batch.map(async row => {
        try {
          return await reconcileKnownOrder(row);
        } catch {
          try {
            await releaseOrderVerificationClaim({
              orderId: row.id,
              processingToken: row.verification_processing_token
            });
          } catch { /* Unfinished order remains retryable after lease expiry. */ }
          return false;
        }
      }));
      resolved += results.filter(Boolean).length;
    }
    return { resolved, attempted: pending.length };
  }

  let reconciliationRunning = false;
  async function runWebhookReconciliation() {
    if (reconciliationRunning) return { skipped: true, processed: 0 };
    reconciliationRunning = true;
    try {
      const processingToken = crypto.randomUUID();
      const pending = (await pool.query(
        `WITH eligible AS (
           SELECT provider,event_id FROM payment_webhook_events
            WHERE provider='ashtechpay' AND processed_at IS NULL
              AND (processing_until IS NULL OR processing_until <= now())
            ORDER BY COALESCE(last_attempt_at,received_at) ASC,received_at ASC
            LIMIT 20 FOR UPDATE SKIP LOCKED
         )
         UPDATE payment_webhook_events AS queued
            SET last_attempt_at=now(),processing_token=$1,
                processing_until=now()+($2::double precision*interval '1 millisecond')
           FROM eligible
          WHERE queued.provider=eligible.provider AND queued.event_id=eligible.event_id
         RETURNING queued.event_id,queued.payload,queued.processing_token`,
        [processingToken, RECONCILIATION_LEASE_MS]
      )).rows;
      let processed = 0;
      for (const row of pending) {
        try {
          if (await reconcileStoredWebhook(row)) processed += 1;
        } catch {
          try {
            await releaseWebhookClaim(row, 'La réconciliation serveur doit être réessayée.');
          } catch { /* Durable event remains unprocessed for the next pass. */ }
        }
      }
      const orderResult = await runOrderReconciliation();
      return {
        skipped: false,
        processed,
        pending: pending.length,
        ordersResolved: orderResult.resolved,
        ordersAttempted: orderResult.attempted
      };
    } finally {
      reconciliationRunning = false;
    }
  }

  const reconciliationScheduler = scheduler || {
    setInterval: (callback, milliseconds) => setInterval(callback, milliseconds),
    clearInterval: timer => clearInterval(timer)
  };
  let reconciliationTimer = null;
  const webhookReconciliation = {
    runOnce: runWebhookReconciliation,
    startReconciliationWorker: intervalMs => webhookReconciliation.start(intervalMs),
    start(intervalMs = 30_000) {
      if (reconciliationTimer) return reconciliationTimer;
      if (!reconciliationScheduler || typeof reconciliationScheduler.setInterval !== 'function') {
        throw new TypeError('Webhook reconciliation scheduler must provide setInterval');
      }
      reconciliationTimer = reconciliationScheduler.setInterval(() => {
        runWebhookReconciliation().catch(() => { /* Unprocessed rows retry on the next pass. */ });
      }, Math.max(1000, Number(intervalMs) || 30_000));
      reconciliationTimer?.unref?.();
      Promise.resolve().then(() => runWebhookReconciliation())
        .catch(() => { /* Durable unprocessed rows retry on the next pass. */ });
      return reconciliationTimer;
    },
    stop() {
      if (reconciliationTimer && typeof reconciliationScheduler.clearInterval === 'function') {
        reconciliationScheduler.clearInterval(reconciliationTimer);
      }
      reconciliationTimer = null;
    }
  };

  app.post('/api/payments/webhook', async (req, res) => {
    if (!provider.configured() || !Buffer.isBuffer(req.rawBody)) {
      return res.status(503).json({ error: 'Vérification du webhook indisponible.' });
    }
    let event;
    try { event = await provider.handleWebhook({ headers: req.headers, rawBody: req.rawBody }); } catch {
      return res.status(400).json({ error: 'Webhook invalide.' });
    }
    if (!event?.valid) {
      const code = event?.reason === 'missing_configuration' ? 503 : 400;
      return res.status(code).json({ error: code === 503 ? 'Vérification du webhook indisponible.' : 'Webhook invalide.' });
    }
    if (!['payment.completed', 'payment.failed'].includes(event.eventType)) return res.status(200).json({ ok: true });
    const tx = event.transaction;
    if (!tx?.transactionId || !tx.merchantReference) return res.status(400).json({ error: 'Identité du paiement incomplète.' });
    if (tx.simulated) return res.status(200).json({ ok: true, simulated: true, credited: false });

    const sanitized = JSON.stringify({
      transactionId: tx.transactionId,
      merchantReference: tx.merchantReference,
      amount: tx.amount,
      grossAmountProvided: tx.grossAmountProvided === true,
      currency: tx.currency,
      operator: tx.operator,
      countryCode: tx.countryCode,
      phone: tx.phone,
      status: tx.status,
      eventType: event.eventType
    });
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const inserted = await client.query(
        `INSERT INTO payment_webhook_events(provider,event_id,event_type,payload,match_status)
         VALUES('ashtechpay',$1,$2,$3::jsonb,'queued') ON CONFLICT(provider,event_id) DO NOTHING`,
        [event.eventId, event.eventType, sanitized]
      );
      if (!inserted.rowCount) {
        const logged = (await client.query(
          `SELECT payload FROM payment_webhook_events WHERE provider='ashtechpay' AND event_id=$1 FOR UPDATE`,
          [event.eventId]
        )).rows[0];
        const prior = logged?.payload;
        if (!prior || prior.transactionId !== tx.transactionId ||
            prior.merchantReference !== tx.merchantReference ||
            prior.amount !== tx.amount ||
            prior.grossAmountProvided !== (tx.grossAmountProvided === true) ||
            prior.currency !== tx.currency ||
            prior.operator !== tx.operator ||
            prior.countryCode !== tx.countryCode ||
            prior.phone !== tx.phone ||
            prior.status !== tx.status || prior.eventType !== event.eventType) {
          await client.query('ROLLBACK');
          return res.status(400).json({ error: 'Événement webhook déjà utilisé.' });
        }
      }
      await client.query('COMMIT');
    } catch {
      try { await client.query('ROLLBACK'); } catch { /* transaction may already be closed */ }
      return res.status(503).json({ error: 'Événement de paiement temporairement indisponible.' });
    } finally { client.release(); }

    return res.status(200).json({ ok: true, queued: true });
  });

  return webhookReconciliation;
}

module.exports = {
  isNigerRechargeOperator,
  MAX_DEPOSIT,
  amountWithinLimits,
  canFulfillPayment,
  isCoteDIvoireWaveChannel,
  isCoteDIvoireWaveOperator,
  isDemoPaymentChannel,
  isTogoFloozOperator,
  isTogoManualChannel,
  isTogoManualOperator,
  INITIATION_LEASE_MS,
  normalizeCountry,
  ownerCountryIsBenin,
  orderMatchesAccount,
  paymentDto,
  publicProviderError,
  positiveMatchForProvider,
  registerPaymentRoutes,
  validateBeninPhone,
  validatePaymentPhone
};