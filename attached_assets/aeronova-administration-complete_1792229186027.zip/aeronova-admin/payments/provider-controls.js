'use strict';

const SETTINGS_KEY = 'payment_provider_controls';

function createProviderControls(pool, { sonaraConfigured = () => false } = {}) {
  async function read(db = pool) {
    const result = await db.query('SELECT value FROM admin_settings WHERE key=$1', [SETTINGS_KEY]);
    const value = result.rows[0]?.value || {};
    const saspayEnabled = value.saspayEnabled === true;
    return {
      // Reserve mode is the default, including the first publish.
      saspayEnabled,
      sonarapayConfigured: Boolean(sonaraConfigured()),
      sonarapayAutomaticEnabled: !saspayEnabled && value.sonarapayEnabled !== false && Boolean(sonaraConfigured())
    };
  }
  async function setSaspay(enabled) {
    await pool.query(
      `INSERT INTO admin_settings(key,value) VALUES($1,$2::jsonb)
       ON CONFLICT(key) DO UPDATE SET value=admin_settings.value || EXCLUDED.value,updated_at=now()`,
      [SETTINGS_KEY, JSON.stringify({ saspayEnabled: enabled, ...(enabled ? { sonarapayEnabled: false } : {}) })]
    );
    return read();
  }
  async function setSonara(enabled) {
    await pool.query(
      `INSERT INTO admin_settings(key,value) VALUES($1,$2::jsonb)
       ON CONFLICT(key) DO UPDATE SET value=admin_settings.value || EXCLUDED.value,updated_at=now()`,
      [SETTINGS_KEY,JSON.stringify({sonarapayEnabled:enabled,...(enabled?{saspayEnabled:false}:{})})]
    );
    return read();
  }
  return { read, setSaspay, setSonara, saspayEnabled: async db => (await read(db)).saspayEnabled,
    sonaraEnabled: async db => (await read(db)).sonarapayAutomaticEnabled };
}

function registerProviderControls(app, { controls, adminAuth, strictBody }) {
  app.get('/api/admin/payment-provider-controls', adminAuth, async (_req, res, next) => {
    try { res.json(await controls.read()); } catch (error) { next(error); }
  });
  app.patch('/api/admin/payment-provider-controls', adminAuth, strictBody(['saspayEnabled','sonarapayEnabled']), async (req, res, next) => {
    try {
      const fields=Object.keys(req.body||{});
      if(fields.length===1 && fields[0]==='sonarapayEnabled' && typeof req.body.sonarapayEnabled==='boolean') {
        if(req.body.sonarapayEnabled && !(await controls.read()).sonarapayConfigured) {
          return res.status(409).json({error:'Enregistrez la clé SDK et le secret webhook SonaraPay avant son activation.'});
        }
        return res.json(await controls.setSonara(req.body.sonarapayEnabled));
      }
      if (fields.length!==1 || typeof req.body?.saspayEnabled !== 'boolean') {
        return res.status(400).json({ error: 'Choisissez activer ou mettre en réserve Saspay.' });
      }
      res.json(await controls.setSaspay(req.body.saspayEnabled));
    } catch (error) { next(error); }
  });
}

module.exports = { createProviderControls, registerProviderControls };
