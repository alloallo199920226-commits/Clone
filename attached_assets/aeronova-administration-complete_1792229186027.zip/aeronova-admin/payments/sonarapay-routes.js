'use strict';

const crypto = require('node:crypto');
const { SonaraProvider, countryFor, payerPhone, directAllowed, externalPage, identifier, verifiedStatus, verifiedProof } = require('./sonarapay-provider');
const { diagnostic, publicDiagnostic, compactDiagnostic, storedDiagnostic } = require('./sonarapay-diagnostics');
const WINDOW_MS = 8 * 60 * 1000;
const fail = (message, status = 400) => Object.assign(new Error(message), { status });
const manualUrl = amount => `/paiement_gopay/code.html?amount=${encodeURIComponent(amount)}`;
const manualError = () => Object.assign(fail('Cet opérateur utilise le paiement manuel, sans page externe.', 409), { manualRequired: true });
function dto(row) {
  const confirmationDeadline = new Date(row.first_sent_at).getTime() + WINDOW_MS;
  return {
    reference: row.reference, amount: Number(row.amount), currency: row.currency,
    status: row.state, credited: row.state === 'succeeded', operator: row.operator, phone: row.phone,
    confirmationDeadline, confirmationExpired: Date.now() >= confirmationDeadline,
    manualRequired: row.state === 'manual_required',
    manualUrl: row.state === 'manual_required' ? manualUrl(row.amount) : null,
    canStartNewPayment: row.state === 'failed',
    verificationUnavailable: row.last_error === 'status_verification_unavailable',
    awaitingSignedWebhook: row.last_error === 'awaiting_signed_webhook',
    providerDiagnostic: row.last_error === 'awaiting_signed_webhook' ? null : storedDiagnostic(row),
    // The external SDK OTP continuation is not documented. Never use the
    // public checkout's confirm-ussd/operatorReference endpoint as an OTP API.
    prepaymentOtpRequired: true
  };
}
function registerSonaraRoutes(app, {
  pool, auth, strictBody, financialRate, financialConfig, completeProviderDeposit,
  automaticPaymentsEnabled = async () => false, provider = new SonaraProvider()
}) {
  const load = async (reference, userId) => (await pool.query(
    'SELECT * FROM sonarapay_payments WHERE reference=$1 AND user_id=$2', [reference, userId]
  )).rows[0];
  async function manualNetwork(country, operator, db = pool) {
    return (await db.query('SELECT 1 FROM sonarapay_manual_networks WHERE country_code=$1 AND operator=$2', [country, operator])).rowCount > 0;
  }
  async function recordResponse(row, result, state, reason = null, details = null) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const current = (await client.query('SELECT * FROM sonarapay_payments WHERE id=$1 FOR UPDATE', [row.id])).rows[0];
      if (current.state !== 'sending') { await client.query('ROLLBACK'); return; }
      const hasDiagnosticColumn = Object.hasOwn(current, 'last_diagnostic');
      const values = [row.id, identifier(result?.reference) ? result.reference : null,
        identifier(result?.transactionId) ? result.transactionId : null, state,
        !hasDiagnosticColumn && details ? compactDiagnostic(details) : reason];
      if (hasDiagnosticColumn) values.push(details ? JSON.stringify(publicDiagnostic(details)) : null);
      // Diagnostic schema lag must never lose an acknowledged financial ID.
      await client.query(`UPDATE sonarapay_payments SET provider_reference=$2,provider_tx_id=$3,state=$4,last_error=$5${hasDiagnosticColumn ? ',last_diagnostic=$6' : ''},updated_at=now() WHERE id=$1`, values);
      await client.query('UPDATE deposits SET provider_tx_id=$2,status=$3 WHERE id=$1',
        [row.deposit_id, identifier(result?.transactionId) ? result.transactionId : null, state === 'failed' ? 'rejected' : state === 'pending_review' ? 'pending_review' : 'pending']);
      if (state === 'manual_required') {
        await client.query(`INSERT INTO sonarapay_manual_networks(country_code,operator,reason) VALUES($1,$2,$3) ON CONFLICT DO NOTHING`,
          [row.country_code, row.operator, reason]);
      }
      await client.query('COMMIT');
    } catch (error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
  }
  async function sendOnce(row) {
    if (!await automaticPaymentsEnabled()) {
      await recordResponse(row, null, 'failed', 'provider_reserved_before_send'); return;
    }
    // A persisted sending intention is NEVER resent, even after a timeout,
    // restart or missing response. The SDK has no documented idempotency TTL.
    try {
      const result = await provider.create(row.request_payload);
      const hasIdentity = identifier(result?.reference) && identifier(result?.transactionId);
      if (hasIdentity && (externalPage(result) || result.requiresOtp === true)) {
        await recordResponse(row, result, 'manual_required', externalPage(result) ? 'external_checkout_required' : 'otp_continuation_unverified');
      } else if (hasIdentity && Number(result.amount) === Number(row.amount) && result.currency === row.currency) {
        await recordResponse(row, result, 'pending');
      } else {
        await recordResponse(row, result, 'pending_review', 'initiation_identity_uncertain');
      }
    } catch (error) {
      const details = publicDiagnostic(error.diagnostic) || diagnostic(error.providerStatus, null);
      console.warn('Diagnostic SonaraPay', {reference: row.reference, ...details});
      if (identifier(error.paymentResponse?.reference) || identifier(error.paymentResponse?.transactionId)) {
        await recordResponse(row,error.paymentResponse,'pending_review','initiation_response_uncertain',details);return;
      }
      const rejected = !error.uncertain && [400,401,403,404,405,422].includes(error.providerStatus);
      await recordResponse(row, null, rejected ? 'failed' : 'pending_review', rejected ? 'provider_rejected_before_payment' : 'initiation_response_uncertain',details);
    }
  }
  async function reconcile(id) {
    const token = crypto.randomUUID();
    const row = (await pool.query(`UPDATE sonarapay_payments SET lease_token=$2,lease_until=now()+interval '60 seconds',last_checked_at=now()
      WHERE id=$1 AND provider_reference IS NOT NULL AND provider_tx_id IS NOT NULL AND state<>'succeeded'
      AND (lease_until IS NULL OR lease_until<now()) RETURNING *`, [id,token])).rows[0];
    if (!row) return;
    try {
      const status = await provider.verify(row.provider_reference);
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const current = (await client.query('SELECT * FROM sonarapay_payments WHERE id=$1 FOR UPDATE', [id])).rows[0];
        if (current.lease_token !== token || new Date(current.lease_until).getTime() <= Date.now()) {
          await client.query('ROLLBACK'); return;
        }
        const events = (await client.query(`SELECT event_id,payload FROM payment_webhook_events
          WHERE provider='sonarapay' AND (payload->>'reference'=$1 OR payload->>'transactionId'=$2)
          ORDER BY received_at,event_id FOR UPDATE`, [current.provider_reference,current.provider_tx_id])).rows;
        const contradictory = events.some(event => !verifiedProof(event.payload,current));
        if (!verifiedStatus(status,current) || contradictory) {
          await client.query(`UPDATE sonarapay_payments SET state='pending_review',last_error='verification_identity_uncertain',updated_at=now() WHERE id=$1`,[id]);
          await client.query(`UPDATE deposits SET status='pending_review' WHERE id=$1 AND status<>'completed'`,[current.deposit_id]);
        } else if (status.status === 'successful' && events.some(event =>
          verifiedProof(event.payload,current) && event.payload.event === 'payment.successful' && event.payload.status === 'successful')) {
          const deposit = (await client.query('SELECT * FROM deposits WHERE id=$1 FOR UPDATE',[current.deposit_id])).rows[0];
          if (deposit?.payment_provider !== 'sonarapay' || deposit.reference !== current.reference ||
              String(deposit.provider_tx_id) !== current.provider_tx_id || Number(deposit.amount) !== Number(current.amount) ||
              String(deposit.user_id) !== String(current.user_id)) throw fail('Dépôt incohérent.',502);
          if (deposit.status !== 'completed') {
            const credited = await completeProviderDeposit(client,deposit,{txId:current.provider_tx_id,confirmedBy:'sonarapay_signed_and_verified_api'});
            if (!credited) throw fail('Crédit indisponible.',502);
          }
          await client.query(`UPDATE sonarapay_payments SET state='succeeded',last_error=NULL,updated_at=now() WHERE id=$1`,[id]);
          await client.query(`UPDATE payment_webhook_events SET processed_at=now(),match_status='matched',deposit_id=$1
            WHERE provider='sonarapay' AND event_id=ANY($2::varchar[])`,[current.deposit_id,events.map(event=>event.event_id)]);
        } else if (status.status === 'failed' && events.some(event =>
          verifiedProof(event.payload,current) && event.payload.status === 'failed')) {
          await client.query(`UPDATE sonarapay_payments SET state='failed',last_error='provider_confirmed_failure',updated_at=now() WHERE id=$1`,[id]);
          await client.query(`UPDATE deposits SET status='rejected' WHERE id=$1 AND status<>'completed'`,[current.deposit_id]);
        } else if (status.status === 'successful' && ['pending','pending_review'].includes(current.state)) {
          // The API identity is now verified, but the signed notification is
          // still missing. Clear the stale review state without crediting.
          await client.query(`UPDATE sonarapay_payments SET state='pending',last_error='awaiting_signed_webhook',updated_at=now() WHERE id=$1`,[id]);
          await client.query(`UPDATE deposits SET status='pending' WHERE id=$1 AND status<>'completed'`,[current.deposit_id]);
        }
        await client.query('COMMIT');
      } catch(error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
    } catch(error) {
      await pool.query(`UPDATE sonarapay_payments SET last_error='status_verification_unavailable'
        WHERE id=$1 AND lease_token=$2 AND state<>'succeeded'`,[id,token]);
      throw error;
    } finally {
      await pool.query(`UPDATE sonarapay_payments SET lease_token=NULL,lease_until=NULL WHERE id=$1 AND lease_token=$2`,[id,token]);
    }
  }
  app.get('/api/sonarapay/options',auth,async(req,res,next)=>{
    try {
      const country=countryFor(req.user.country),config=await financialConfig();
      const base={country,minimumDeposit:Number(config.minimumDeposit),payerPhone:req.user.phone,manualUrl:manualUrl(config.minimumDeposit),
        requiresCustomer:false,provider:'sonarapay',methods:[]};
      if (!country || !await automaticPaymentsEnabled() || ['BJ','CI','BF','CM','NE','TG'].includes(country.code)) return res.json({...base,manualOnly:true});
      try {
        const catalog=(await provider.catalog()).find(entry=>entry.code===country.code);
        if (!catalog || catalog.currency!==country.currency || !Array.isArray(catalog.operators)) throw fail('Catalogue incompatible.',502);
        const blocked=new Set((await pool.query('SELECT operator FROM sonarapay_manual_networks WHERE country_code=$1',[country.code])).rows.map(entry=>entry.operator));
        const methods=catalog.operators.filter(method=>identifier(method.id)&&typeof method.name==='string'&&method.name.length<=160)
          .map(method=>({id:method.id,name:method.name,manual:!directAllowed(country.code,method.id)||blocked.has(method.id),
            otpRequired:false}));
        return res.json({...base,methods:[...methods,{id:'manual',name:'Autre opérateur — paiement manuel',manual:true}],manualOnly:!methods.some(method=>!method.manual)});
      } catch { return res.json({...base,manualOnly:true,reason:'SonaraPay est indisponible. Les canaux manuels restent accessibles.'}); }
    } catch(error) { next(error); }
  });
  app.post('/api/sonarapay/payments',auth,financialRate,strictBody(['amount','clientRequestId','operator','phone']),async(req,res,next)=>{
    try {
      const country=countryFor(req.user.country),amount=Number(req.body.amount),clientId=String(req.body.clientRequestId||'');
      const phone=country&&payerPhone(country.code,req.body.phone),config=await financialConfig();
      if (!country||!phone||!Number.isSafeInteger(amount)||amount<config.minimumDeposit||amount>100000000||
          !/^[A-Za-z0-9_-]{12,80}$/.test(clientId)) throw fail('Vérifiez le montant et le numéro Mobile Money.');
      const existing=(await pool.query('SELECT * FROM sonarapay_payments WHERE user_id=$1 AND client_request_id=$2',[req.user.id,clientId])).rows[0];
      if (existing) {
        if (Number(existing.amount)!==amount||existing.operator!==req.body.operator||existing.phone!==phone) throw fail('Cette demande existe avec des informations différentes.',409);
        try { await reconcile(existing.id); } catch {}
        return res.json(dto(await load(existing.reference,req.user.id)));
      }
      if (!await automaticPaymentsEnabled()||!directAllowed(country.code,req.body.operator)||await manualNetwork(country.code,req.body.operator)) throw manualError();
      const catalog=(await provider.catalog()).find(entry=>entry.code===country.code&&entry.currency===country.currency);
      const method=catalog?.operators?.find(entry=>entry.id===req.body.operator&&typeof entry.name==='string'&&entry.name.length<=160);
      if (!method) throw manualError();
      const client=await pool.connect();
      let row,created=false;
      try {
        await client.query('BEGIN');
        await client.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[req.user.id]);
        row=(await client.query('SELECT * FROM sonarapay_payments WHERE user_id=$1 AND client_request_id=$2',[req.user.id,clientId])).rows[0];
        if (row) {
          if (Number(row.amount)!==amount||row.operator!==method.id||row.phone!==phone) throw fail('Demande incompatible.',409);
        } else {
          if (!await automaticPaymentsEnabled(client)||await manualNetwork(country.code,method.id,client)) throw manualError();
          // Distinct intentions may coexist. Never reset, cancel or resend an
          // older collection; the same key cannot become a different payment,
          // including across providers.
          if ((await client.query('SELECT 1 FROM deposits WHERE user_id=$1 AND client_request_id=$2',
            [req.user.id,clientId])).rowCount) {
            throw fail('Cet identifiant appartient déjà à un dépôt. Reprenez ce dépôt ; pour une opération distincte, créez un autre dépôt.',409);
          }
          const reference=`SON-${crypto.randomUUID()}`;
          const payload={amount,currency:country.currency,countryCode:country.code,operatorId:method.id,customerPhone:phone,description:`Recharge ${reference}`};
          const deposit=(await client.query(`INSERT INTO deposits(user_id,amount,status,reference,payment_provider,payer_number,operator_name,client_request_id)
            VALUES($1,$2,'pending',$3,'sonarapay',$4,$5,$6) RETURNING id`,[req.user.id,amount,reference,phone,method.name,clientId])).rows[0];
          row=(await client.query(`INSERT INTO sonarapay_payments(user_id,deposit_id,reference,client_request_id,amount,currency,country_code,operator,operator_name,phone,request_payload)
            VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
          [req.user.id,deposit.id,reference,clientId,amount,country.currency,country.code,method.id,method.name,phone,JSON.stringify(payload)])).rows[0];
          created=true;
        }
        await client.query('COMMIT');
      } catch(error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
      if (created) await sendOnce(row);
      try { await reconcile(row.id); } catch {}
      res.status(created?201:200).json(dto(await load(row.reference,req.user.id)));
    } catch(error) {
      if(error.manualRequired)return res.status(409).json({error:error.message,manualRequired:true,manualUrl:manualUrl(Number(req.body.amount))});
      next(error);
    }
  });
  app.get('/api/sonarapay/payments/:reference/status',auth,financialRate,async(req,res,next)=>{
    try {
      const row=await load(req.params.reference,req.user.id);
      if(!row)throw fail('Paiement introuvable.',404);
      try { await reconcile(row.id); } catch {}
      res.json(dto(await load(row.reference,req.user.id)));
    }catch(error){next(error);}
  });
  app.get('/api/sonarapay/intents/:clientRequestId/status',auth,financialRate,async(req,res,next)=>{
    try{
      const row=(await pool.query('SELECT * FROM sonarapay_payments WHERE user_id=$1 AND client_request_id=$2',[req.user.id,req.params.clientRequestId])).rows[0];
      if(!row)throw fail('Demande introuvable.',404);
      try{await reconcile(row.id);}catch{}
      res.json(dto(await load(row.reference,req.user.id)));
    }catch(error){next(error);}
  });
  let timer=null,running=false;
  async function drain(){
    if(running)return;running=true;
    try{
      const rows=(await pool.query(`SELECT id FROM sonarapay_payments WHERE provider_reference IS NOT NULL AND state<>'succeeded'
        ORDER BY last_checked_at ASC NULLS FIRST,id LIMIT 20`)).rows;
      for(const row of rows){try{await reconcile(row.id);}catch{}}
    }catch{}finally{running=false;}
  }
  return { reconcile,drain,start(){if(!timer){timer=setInterval(drain,15000);timer.unref();void drain();}},stop(){clearInterval(timer);timer=null;} };
}
module.exports={registerSonaraRoutes,dto};
