'use strict';

const crypto = require('node:crypto');
const WEBHOOK_PATH = '/api/payments/sonarapay/webhook';

// SonaraPay's published Node example signs JSON.stringify(req.body), not
// the original HTTP bytes. Keep this separate from Ashtech/Saspay signatures.
function verifySonaraSignature(payload, signature, secret) {
  if (!secret || typeof signature !== 'string' || !/^[a-f0-9]{64}$/i.test(signature)) return false;
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return false;
  const expected = crypto.createHmac('sha256', secret).update(JSON.stringify(payload)).digest();
  return crypto.timingSafeEqual(expected, Buffer.from(signature, 'hex'));
}

function registerSonaraWebhook(app, {
  pool,
  secret = () => process.env.SONARAPAY_WEBHOOK_SECRET,
  automaticCredits = async () => false,
  onRejected = () => {},
  onError = () => {}
}) {
  // Configuration readiness, not proof of a real successful payment.
  app.get(WEBHOOK_PATH, async (_req, res) => {
    try {
      const configured = Boolean(secret());
      res.status(configured ? 200 : 503).json({
        provider: 'sonarapay', configured, method: 'POST',
        automaticCredits: configured && await automaticCredits()
      });
    } catch {
      res.status(503).json({provider:'sonarapay',configured:false,automaticCredits:false});
    }
  });

  app.post(WEBHOOK_PATH, async (req, res) => {
    const signingSecret = secret();
    if (!signingSecret) return res.status(503).json({ error: 'Secret webhook SonaraPay non configuré.' });
    if (!req.is('application/json')) return res.status(415).json({ error: 'Un message JSON est requis.' });
    if (!verifySonaraSignature(req.body, req.get('x-sonara-signature'), signingSecret)) {
      // Only a fixed reason: never log the signature, secret or payer data.
      onRejected(req.get('x-sonara-signature') ? 'invalid_signature' : 'missing_signature');
      return res.status(401).json({ error: 'Signature SonaraPay invalide.' });
    }

    const serialized = JSON.stringify(req.body);
    // Hash the complete signed proof, not just its transaction ID: retain
    // contradictory notifications and deduplicate exact retries atomically.
    const eventId = crypto.createHash('sha256').update(serialized).digest('hex');
    const eventType = typeof req.body.event === 'string' && /^[a-zA-Z0-9_.:-]{1,80}$/.test(req.body.event)
      ? req.body.event : 'unknown';
    try {
      const stored = await pool.query(
        `INSERT INTO payment_webhook_events(provider,event_id,event_type,payload,match_status)
         VALUES('sonarapay',$1,$2,$3::jsonb,'received')
         ON CONFLICT(provider,event_id) DO NOTHING RETURNING event_id`,
        [eventId, eventType, serialized]
      );
      // Acknowledge only after durable storage. No balances, deposits or other
      // providers are modified; connecting SonaraPay payment orders is separate.
      return res.status(200).json({
        received: true,
        verified: true,
        duplicate: stored.rowCount === 0,
        credited: false
      });
    } catch (error) {
      onError(error);
      return res.status(503).json({ error: 'Réception SonaraPay différée. Réessayez ultérieurement.' });
    }
  });
}

module.exports = { WEBHOOK_PATH, verifySonaraSignature, registerSonaraWebhook };
