'use strict';

const BASE = 'https://api.saspay.me/api/v1/';
const COUNTRIES = Object.freeze({
  TG: { code: 'TG', name: 'Togo', dialCode: '+228', currency: 'XOF', aliases: ['togo'] },
  BJ: { code: 'BJ', name: 'Bénin', dialCode: '+229', currency: 'XOF', aliases: ['benin'] },
  CM: { code: 'CM', name: 'Cameroun', dialCode: '+237', currency: 'XAF', aliases: ['cameroun', 'cameroon'] },
  NE: { code: 'NE', name: 'Niger', dialCode: '+227', currency: 'XOF', aliases: ['niger'] },
  SN: { code: 'SN', name: 'Sénégal', dialCode: '+221', currency: 'XOF', aliases: ['senegal'] },
  CI: { code: 'CI', name: 'Côte d’Ivoire', dialCode: '+225', currency: 'XOF', aliases: ["cote d'ivoire", 'cote d’ivoire', 'cote divoire', 'ivory coast'] },
  BF: { code: 'BF', name: 'Burkina Faso', dialCode: '+226', currency: 'XOF', aliases: ['burkina faso', 'burkina'] }
});
const normalize = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLowerCase();
function saspayCountry(value) {
  const v = normalize(value);
  return Object.values(COUNTRIES).find(c => [c.code.toLowerCase(), c.dialCode, c.dialCode.slice(1), ...c.aliases].includes(v)) || null;
}
function payerPhone(country, value) {
  const c = COUNTRIES[country];
  if (!c || !/^[+\d\s()-]+$/.test(String(value || ''))) return null;
  let digits = String(value).replace(/\D/g, '');
  if (digits.startsWith('00')) digits = digits.slice(2);
  const prefix = c.dialCode.slice(1);
  if (digits.startsWith(prefix) && digits.length > 10) digits = digits.slice(prefix.length);
  const valid = country === 'BJ' ? /^01\d{8}$/.test(digits)
    : country === 'CI' ? /^0[157]\d{8}$/.test(digits)
    : country === 'CM' ? /^6\d{8}$/.test(digits)
      : country === 'SN' ? /^\d{9}$/.test(digits) : /^\d{8}$/.test(digits);
  return valid ? c.dialCode + digits : null;
}
// The official Softpay documentation explicitly describes hosted checkout for
// these brands. Country policies can impose stricter manual-only handling;
// routes still block every returned checkout URL.
function hostedNetwork(code) {
  return /^(?:wave|orange|djamo)(?:[_\s-]|$)|^(?:card|crypto)$/i.test(String(code || '').trim());
}
function directPolicyAllows(country, operator) {
  if (['BJ', 'CI', 'BF', 'CM', 'NE', 'TG'].includes(country)) return false;
  return true;
}
const uuid = value => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(value || ''));
function verifiedIdentity(payment, order) {
  return uuid(order.provider_tx_id) && payment?.id === order.provider_tx_id &&
    payment.transaction_type === 'PAIEMENT' && payment.flow_direction === 'INBOUND' &&
    payment.currency === order.currency && Number(payment.requested_amount) === Number(order.amount) &&
    payment.country === order.country_id && payment.network === order.network_id;
}
function providerError(status, code) {
  const error = new Error(status === 401 || status === 403
    ? 'L’accès Saspay est indisponible. Utilisez le paiement manuel.'
    : 'Saspay ne répond pas correctement. Vérifiez le statut avant de recommencer.');
  error.status = status === 401 || status === 403 ? 503 : 502;
  error.code = code || 'saspay_unavailable';
  error.providerStatus = status;
  return error;
}
class SaspayProvider {
  constructor({ fetchImpl = global.fetch, key = () => process.env.SASPAY_API_KEY } = {}) {
    this.fetchImpl = fetchImpl;
    this.key = key;
    this.cached = null;
    this.catalogPromise = null;
  }
  configured() { return Boolean(this.key()); }
  async request(route, { method = 'GET', body, idempotencyKey } = {}) {
    if (!this.configured()) throw providerError(401, 'saspay_not_configured');
    const url = new URL(route, BASE);
    if (url.origin !== new URL(BASE).origin || !url.pathname.startsWith('/api/v1/')) throw providerError(502);
    let response;
    try {
      response = await this.fetchImpl(url, {
        method, redirect: 'error', signal: AbortSignal.timeout(18000),
        headers: {
          Authorization: `Bearer ${this.key()}`, Accept: 'application/json',
          ...(body ? { 'Content-Type': 'application/json' } : {}),
          ...(idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {})
        },
        ...(body ? { body: JSON.stringify(body) } : {})
      });
    } catch { throw providerError(0, 'saspay_response_uncertain'); }
    let data;
    try { data = await response.json(); } catch { throw providerError(response.status); }
    if (!response.ok) {
      // Never expose gateway errors, payer details, credentials or raw responses.
      const missingContact = method === 'POST' && route === 'payments/softpay/' &&
        [400, 422].includes(response.status) &&
        ['email', 'first_name', 'last_name'].some(field =>
          !body?.customer?.[field] &&
          Object.hasOwn(data?.error?.customer || {}, field));
      if (missingContact) throw providerError(response.status, 'saspay_customer_required');
      const code = /^[a-z_]{1,64}$/.test(data?.code || '') ? data.code : 'saspay_unavailable';
      throw providerError(response.status, code);
    }
    return data?.data ?? data;
  }
  async catalog() {
    if (this.cached && this.cached.expires > Date.now()) return this.cached.data;
    if (this.catalogPromise) return this.catalogPromise;
    this.catalogPromise = (async () => {
      const [countries, rates] = await Promise.all([this.request('countries/'), this.request('pricing/my-rates/')]);
      if (!Array.isArray(countries) || !Array.isArray(rates)) throw providerError(502);
      const networks = [];
      let route = 'networks/?page_size=100';
      for (let page = 0; route && page < 20; page++) {
        const result = await this.request(route);
        if (!Array.isArray(result.results)) throw providerError(502);
        networks.push(...result.results);
        route = result.next;
      }
      if (route) throw providerError(502);
      const data = rates.filter(r => COUNTRIES[r.country_code] && r.payin?.available === true).flatMap(rate => {
        const country = countries.find(c => c.iso_code === rate.country_code);
        const network = networks.find(n => n.code === rate.network_code && n.country === country?.id && n.is_active === true);
        if (!country || !network || !uuid(country.id) || !uuid(network.id) ||
            rate.currency !== COUNTRIES[rate.country_code].currency) return [];
        // Niger's standing policy only allows Airtel/Moov.
        if (rate.country_code === 'NE' && !['airtel_ne', 'moov_ne'].includes(rate.network_code)) return [];
        const orangeDirect = rate.country_code === 'CM' && rate.network_code === 'orange_cm';
        return [{
          id: rate.network_code, name: rate.network_name || network.name,
          country: rate.country_code, countryId: country.id, networkId: network.id,
          manual: !directPolicyAllows(rate.country_code, rate.network_code) ||
            (!orangeDirect && (hostedNetwork(rate.network_code) || hostedNetwork(rate.network_name || network.name))) ||
            rate.payin.otp_required === true,
          otpRequired: rate.payin.otp_required === true,
          otpInstructions: String(rate.payin.otp_instructions || '').slice(0, 500),
          tiers: Array.isArray(rate.payin.tiers) ? rate.payin.tiers : []
        }];
      });
      this.cached = { data, expires: Date.now() + 60000 };
      return data;
    })();
    try { return await this.catalogPromise; } finally { this.catalogPromise = null; }
  }
  create(order, { otp } = {}) {
    return this.request('payments/softpay/', {
      method: 'POST', idempotencyKey: order.reference,
      body: { ...order.request_payload, ...(otp ? { otp } : {}) }
    });
  }
  verify(id) {
    if (!uuid(id)) throw providerError(502);
    return this.request(`payments/${id}/verify/`);
  }
  confirmOtp(id, otp) {
    if (!uuid(id)) throw providerError(502);
    return this.request(`payments/${id}/confirm-otp/`, { method: 'POST', body: { otp } });
  }
}
module.exports = { SaspayProvider, saspayCountry, payerPhone, hostedNetwork, directPolicyAllows, verifiedIdentity, uuid };
