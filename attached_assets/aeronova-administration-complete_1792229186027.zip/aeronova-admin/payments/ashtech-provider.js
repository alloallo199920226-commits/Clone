'use strict';

const crypto = require('node:crypto');
const { PaymentProvider } = require('./payment-provider');
const { PAYMENT_COUNTRIES, normalizePaymentPhone, paymentCountry } = require('./countries');

const API_BASE = 'https://www.ashtechpay.com/v1';
const BENIN_OPERATORS = new Set(['Moov Money', 'MTN Money', 'Celtiis Money', 'Coris Money']);
const REDIRECT_MESSAGE = 'Le prestataire nécessite actuellement une redirection pour ce moyen de paiement. Une expérience 100 % sans redirection nécessite une API de paiement direct/embedded compatible.';
const REQUEST_TIMEOUT_MS = 10_000;
const CATALOG_TTL_MS = 5 * 60 * 1000;
const WEBHOOK_TOLERANCE_SECONDS = 5 * 60;
const MAX_RETRY_AFTER_MS = 5 * 60 * 1000;
const REAL_TEST_WARNING = 'ESSAI RÉEL — débit Mobile Money possible. Sans confirmation sécurisée, votre dépôt reste en attente et aucun solde n’est crédité.';

class AshtechApiError extends Error {
  constructor({ status = null, code = null, retryAfterMs = null, uncertain = false } = {}) {
    const namedCode = typeof code === 'string' && /^[a-z0-9_]{1,80}$/i.test(code) ? code.toLowerCase() : null;
    super(namedCode || (status === 429 ? 'rate_limited' : 'provider_unavailable'));
    this.name = 'AshtechApiError';
    this.status = status;
    this.code = namedCode;
    this.retryAfterMs = retryAfterMs;
    this.uncertain = uncertain;
  }
}

function firstValue(objects, names) {
  for (const object of objects) {
    if (!object || typeof object !== 'object') continue;
    for (const name of names) {
      if (object[name] !== undefined && object[name] !== null && object[name] !== '') return object[name];
    }
  }
  return undefined;
}

function payloadObjects(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return [];
  return [payload.data, payload.transaction, payload.payment, payload, payload.data?.transaction]
    .filter(value => value && typeof value === 'object' && !Array.isArray(value));
}

function finiteAmount(value) {
  if (typeof value === 'string' && !/^\d+(?:\.0+)?$/.test(value.trim())) return null;
  const amount = Number(value);
  return Number.isSafeInteger(amount) && amount > 0 ? amount : null;
}

function valuesFor(objects, names) {
  return objects.flatMap(object => names
    .filter(name => Object.prototype.hasOwnProperty.call(object, name))
    .map(name => object[name]));
}

function sameNonemptyStrings(values, normalize = value => value) {
  if (!values.length || values.some(value => typeof value !== 'string' || !value.trim())) return false;
  return new Set(values.map(normalize)).size === 1;
}

function providerPhoneIdentity(value) {
  if (typeof value !== 'string' || !/^\+?\d+$/.test(value)) return null;
  const internationalDigits = value.startsWith('+') ? value.slice(1) : value;
  const country = Object.values(PAYMENT_COUNTRIES).find(config =>
    internationalDigits.startsWith(config.dialCode.slice(1)));
  if (!country) return null;
  const phone = `+${internationalDigits}`;
  return normalizePaymentPhone(country.code, phone) === phone ? { country, phone } : null;
}

function strictPhoneCountry(value) {
  return providerPhoneIdentity(value)?.country || null;
}

function positiveFlag(value) {
  return value === true || value === 1 ||
    (typeof value === 'string' && ['true', '1'].includes(value.trim().toLowerCase()));
}

function normalizeTransaction(payload, { webhook = false, requireMerchantReference = false } = {}) {
  const objects = payloadObjects(payload);
  const transactionIdNames = ['transaction_id', 'transactionId', 'tx_id', 'txid', 'id'];
  const transactionIdValues = valuesFor(objects, transactionIdNames);
  const transactionIds = transactionIdValues.map(value =>
    typeof value === 'string' || typeof value === 'number' ? String(value) : null);
  const transactionIdIdentityValid = transactionIds.length > 0 &&
    transactionIds.every(Boolean) && new Set(transactionIds).size === 1;
  const transactionId = firstValue(objects, transactionIdNames);
  const merchantReferenceValues = valuesFor(objects, ['merchant_reference', 'merchantReference']);
  const merchantReferenceProvided = merchantReferenceValues.length > 0;
  const explicitMerchantReference = firstValue(objects, ['merchant_reference', 'merchantReference']);
  const fallbackMerchantReference = firstValue(objects, ['reference', 'ref']);
  const merchantReference = explicitMerchantReference || (requireMerchantReference ? undefined : fallbackMerchantReference);
  const gross = webhook ? firstValue(objects, ['total_amount']) : undefined;
  const amountValues = valuesFor(objects, webhook ? ['total_amount'] : ['amount']);
  const amount = finiteAmount(webhook ? gross : firstValue(objects, ['amount']));
  const currency = firstValue(objects, ['currency']);
  const status = firstValue(objects, ['status']);
  const statusValues = valuesFor(objects, ['status']);
  const statusIdentityValid = sameNonemptyStrings(statusValues, value => value.toLowerCase());
  const operator = firstValue(objects, ['operator', 'operator_name', 'operatorName']);
  const countryValues = valuesFor(objects, ['country_code', 'countryCode', 'country']);
  const countryCodeProvided = countryValues.length > 0;
  const countryConfigs = countryValues.map(value => typeof value === 'string' ? paymentCountry(value) : null);
  const countryIdentityValid = countryConfigs.every(Boolean) &&
    new Set(countryConfigs.map(country => country.code)).size <= 1;
  const countryCode = countryIdentityValid && countryConfigs.length
    ? countryConfigs[0].code
    : typeof countryValues[0] === 'string' ? countryValues[0].trim().toUpperCase() : null;
  const phoneValues = valuesFor(objects, ['phone', 'payer_phone', 'payerPhone']);
  const phoneIdentities = phoneValues.map(providerPhoneIdentity);
  const phoneIdentityValid = phoneIdentities.length > 0 && phoneIdentities.every(Boolean) &&
    new Set(phoneIdentities.map(identity => identity.phone)).size === 1 &&
    new Set(phoneIdentities.map(identity => identity.country.code)).size === 1;
  const phone = phoneIdentityValid ? phoneIdentities[0].phone : firstValue(objects, ['phone', 'payer_phone', 'payerPhone']);
  const currencyValues = valuesFor(objects, ['currency']);
  const currencyIdentityValid = sameNonemptyStrings(currencyValues, value => value.toUpperCase());
  const operatorValues = valuesFor(objects, ['operator', 'operator_name', 'operatorName']);
  const operatorIdentityValid = sameNonemptyStrings(operatorValues);
  const merchantReferenceIdentityValid = merchantReferenceProvided &&
    sameNonemptyStrings(merchantReferenceValues);
  const amountIdentityValid = amountValues.length > 0 && amountValues.every(value =>
    finiteAmount(value) !== null && finiteAmount(value) === amount);
  const flow = firstValue(objects, ['flow']);
  const ussdCode = firstValue(objects, ['ussd_code', 'ussdCode']);
  const error = firstValue(objects, ['error', 'code']);
  const simulated = objects.some(object =>
    ['sandbox', 'simulation', 'simulated', 'is_sandbox', 'is_simulated', 'test_mode']
      .some(key => positiveFlag(object[key])) ||
    ['environment', 'mode'].some(key =>
      typeof object[key] === 'string' && ['sandbox', 'simulation', 'test'].includes(object[key].trim().toLowerCase()))
  );
  const normalizedCountryCode = typeof countryCode === 'string'
    ? paymentCountry(countryCode)?.code || countryCode.trim().toUpperCase()
    : null;
  return {
    transactionId: typeof transactionId === 'string' || typeof transactionId === 'number' ? String(transactionId) : null,
    transactionIdIdentityValid,
    merchantReference: typeof merchantReference === 'string' ? merchantReference : null,
    merchantReferenceProvided,
    merchantReferenceRequired: requireMerchantReference,
    merchantReferenceIdentityValid,
    amount,
    amountIdentityValid,
    grossAmountProvided: webhook && gross !== undefined,
    currency: typeof currency === 'string' ? currency.toUpperCase() : null,
    currencyIdentityValid,
    status: typeof status === 'string' ? status.toLowerCase() : null,
    statusIdentityValid,
    operator: typeof operator === 'string' ? operator : null,
    operatorIdentityValid,
    countryCode: normalizedCountryCode,
    countryCodeProvided,
    countryIdentityValid,
    phone: typeof phone === 'string' || typeof phone === 'number' ? String(phone) : null,
    phoneIdentityValid,
    flow: typeof flow === 'string' ? flow.toLowerCase() : null,
    ussdCode: typeof ussdCode === 'string' ? ussdCode : null,
    error: typeof error === 'string' ? error.toLowerCase() : null,
    simulated
  };
}

function isVerifiedSuccess(transaction, order) {
  if (!transaction || transaction.status !== 'success') return false;
  return identityMatches(transaction, order);
}

function digits(value) {
  return String(value || '').replace(/\D/g, '');
}

function identityMatches(transaction, order) {
  if (!transaction || !order) return false;
  const orderCountry = paymentCountry(order.country_code);
  const expectedCountry = orderCountry && orderCountry.currency === String(order.currency).toUpperCase()
    ? orderCountry : null;
  const transactionPhoneCountry = strictPhoneCountry(transaction.phone);
  const transactionCountry = transaction.countryCodeProvided === false
    ? transactionPhoneCountry
    : paymentCountry(transaction.countryCode);
  const orderPhoneCountry = strictPhoneCountry(order.phone);
  const refs = new Set([order.reference, order.provider_session_reference].filter(Boolean).map(String));
  if (transaction.simulated === true ||
      !transaction.transactionId || !transaction.merchantReference ||
      transaction.transactionIdIdentityValid === false ||
      transaction.statusIdentityValid === false ||
      (transaction.merchantReferenceRequired === true &&
        (!transaction.merchantReferenceProvided || transaction.merchantReferenceIdentityValid !== true)) ||
      transaction.amountIdentityValid === false ||
      transaction.currencyIdentityValid === false ||
      transaction.operatorIdentityValid === false ||
      transaction.countryIdentityValid === false ||
      transaction.phoneIdentityValid === false ||
      !refs.has(transaction.merchantReference) ||
      !Number.isSafeInteger(transaction.amount) || transaction.amount !== Number(order.amount) ||
      transaction.currency !== String(order.currency).toUpperCase() ||
      !expectedCountry || !transactionCountry ||
      transactionCountry.code !== expectedCountry.code ||
      transactionCountry.currency !== transaction.currency ||
      !transactionPhoneCountry || transactionPhoneCountry.code !== expectedCountry.code ||
      !orderPhoneCountry || orderPhoneCountry.code !== expectedCountry.code ||
      transaction.phone !== order.phone ||
      !transaction.operator || !order.operator || transaction.operator !== order.operator) return false;
  if (order.provider_tx_id && String(order.provider_tx_id) !== transaction.transactionId) return false;
  if (transaction.countryCodeProvided !== false && transactionCountry.code !== transaction.countryCode) return false;
  return true;
}

function webhookMapsToOrder(transaction, order) {
  if (!transaction || !order || !transaction.transactionId || !transaction.merchantReference) return false;
  const refs = new Set([order.reference, order.provider_session_reference].filter(Boolean).map(String));
  if (!refs.has(transaction.merchantReference)) return false;
  if (order.provider_tx_id && String(order.provider_tx_id) !== transaction.transactionId) return false;
  if (transaction.grossAmountProvided &&
      (!Number.isSafeInteger(transaction.amount) || transaction.amount !== Number(order.amount))) return false;
  if (transaction.currency && transaction.currency !== String(order.currency).toUpperCase()) return false;
  if (transaction.operator && transaction.operator !== order.operator) return false;
  if (transaction.countryCode && transaction.countryCode !== order.country_code) return false;
  if (transaction.phone && digits(transaction.phone) !== digits(order.phone)) return false;
  return true;
}

function safeWebhookSecret(secret) {
  return typeof secret === 'string' && secret.trim() ? secret : null;
}

function validNotifyUrl(url) {
  if (typeof url !== 'string') return false;
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'https:' && Boolean(parsed.hostname) && !parsed.username && !parsed.password;
  } catch { return false; }
}

function validWaveUrl(value) {
  if (typeof value !== 'string' || !value.trim() || /[\u0000-\u001f\u007f]/.test(value) ||
      /%(?:0[0-9a-f]|1[0-9a-f]|7f)/i.test(value)) return false;
  try {
    const parsed = new URL(value);
    const hostname = parsed.hostname.toLowerCase().replace(/\.$/, '');
    if (parsed.protocol !== 'https:' || !hostname || !parsed.host ||
        parsed.username || parsed.password || (parsed.port && parsed.port !== '443') ||
        !hostname.includes('.') || hostname === 'localhost' ||
        hostname.endsWith('.localhost') || hostname.endsWith('.local') ||
        hostname.endsWith('.internal') || hostname.endsWith('.test') ||
        /^\d+(?:\.\d+){0,3}$/.test(hostname) || hostname.startsWith('[')) return false;
    return true;
  } catch { return false; }
}

function retryAfterMilliseconds(value, now = Date.now()) {
  if (typeof value !== 'string' || !value.trim()) return 1000;
  const seconds = Number(value);
  if (Number.isFinite(seconds) && seconds >= 0) {
    return Math.min(MAX_RETRY_AFTER_MS, Math.max(1000, seconds * 1000));
  }
  const date = Date.parse(value);
  if (!Number.isFinite(date)) return 1000;
  return Math.min(MAX_RETRY_AFTER_MS, Math.max(1000, date - now));
}

function verifyWebhookSignature({ headers, rawBody, secret, now = Date.now() }) {
  const webhookSecret = safeWebhookSecret(secret);
  if (!webhookSecret || !Buffer.isBuffer(rawBody)) return { valid: false, reason: 'missing_configuration' };
  const eventId = headers?.['x-ashtech-event-id'];
  const timestamp = headers?.['x-ashtech-timestamp'];
  const signature = headers?.['x-ashtech-signature'];
  if (typeof eventId !== 'string' || !eventId.trim() || eventId.length > 160 ||
      typeof timestamp !== 'string' || !/^\d{1,13}$/.test(timestamp) ||
      typeof signature !== 'string') return { valid: false, reason: 'invalid_headers' };
  const timestampSeconds = Number(timestamp);
  if (!Number.isSafeInteger(timestampSeconds) ||
      Math.abs(Math.floor(now / 1000) - timestampSeconds) > WEBHOOK_TOLERANCE_SECONDS) {
    return { valid: false, reason: 'stale_timestamp' };
  }
  const match = /^sha256=([0-9a-f]{64})$/i.exec(signature);
  if (!match) return { valid: false, reason: 'invalid_signature' };
  const expected = crypto.createHmac('sha256', webhookSecret)
    .update(timestamp)
    .update('.')
    .update(rawBody)
    .digest();
  const supplied = Buffer.from(match[1], 'hex');
  const valid = supplied.length === expected.length && crypto.timingSafeEqual(supplied, expected);
  return {
    valid,
    reason: valid ? null : 'invalid_signature',
    eventId,
    timestamp
  };
}

function signedWebhook({ body, eventId, timestamp, secret }) {
  const rawBody = Buffer.isBuffer(body) ? body : Buffer.from(body);
  const signature = crypto.createHmac('sha256', secret).update(String(timestamp)).update('.').update(rawBody).digest('hex');
  return { rawBody, headers: {
    'x-ashtech-event-id': eventId,
    'x-ashtech-timestamp': String(timestamp),
    'x-ashtech-signature': `sha256=${signature}`
  } };
}

class AshtechPaymentProvider extends PaymentProvider {
  constructor({ apiKey = process.env.ASHTECH_API_KEY, webhookSecret = process.env.ASHTECH_WEBHOOK_SECRET,
    notifyUrl = process.env.ASHTECH_NOTIFY_URL,
    realTestMode = process.env.ASHTECH_REAL_TEST_MODE === 'true',
    fetchImpl = globalThis.fetch, now = () => Date.now() } = {}) {
    super();
    this.apiKey = apiKey;
    this.webhookSecret = webhookSecret;
    this.notifyUrl = notifyUrl;
    this.realTestModeEnabled = realTestMode === true;
    this.fetchImpl = fetchImpl;
    this.now = now;
    this.catalogCache = null;
    this.catalogFetchedAt = 0;
    this.backoffUntil = 0;
  }

  configured() {
    return Boolean(typeof this.apiKey === 'string' && this.apiKey.trim() &&
      safeWebhookSecret(this.webhookSecret) &&
      validNotifyUrl(this.notifyUrl));
  }

  realTestModeActive() {
    return this.realTestModeEnabled && !this.configured() &&
      typeof this.apiKey === 'string' && Boolean(this.apiKey.trim()) &&
      validNotifyUrl(this.notifyUrl);
  }

  collectionReady() {
    return this.configured() || this.realTestModeActive();
  }

  async request(url, { method = 'GET', body } = {}) {
    if (typeof this.apiKey !== 'string' || !this.apiKey.trim()) throw new Error('Payment provider is not configured');
    if (typeof this.fetchImpl !== 'function') throw new Error('Payment provider transport is unavailable');
    if (this.now() < this.backoffUntil) {
      throw new AshtechApiError({
        status: 429,
        retryAfterMs: this.backoffUntil - this.now()
      });
    }
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
      let response;
      try {
        response = await this.fetchImpl(url, {
          method,
          headers: {
            Authorization: `Bearer ${this.apiKey}`,
            ...(body ? { 'Content-Type': 'application/json' } : {})
          },
          ...(body ? { body: JSON.stringify(body) } : {}),
          signal: controller.signal
        });
      } catch {
        throw new AshtechApiError({ uncertain: method === 'POST' });
      }
      let payload = null;
      try { payload = await response.json(); } catch { /* handled as an untrusted/empty response */ }
      if (response.status === 429) {
        const retryAfterMs = retryAfterMilliseconds(
          response.headers?.get?.('retry-after') || null,
          this.now()
        );
        this.backoffUntil = Math.max(this.backoffUntil, this.now() + retryAfterMs);
        throw new AshtechApiError({ status: 429, retryAfterMs });
      }
      if ((response.status < 200 || response.status >= 300) &&
          !(response.status === 400 && url.endsWith('/collect'))) {
        const errorCode = firstValue(payloadObjects(payload), ['error']);
        throw new AshtechApiError({
          status: response.status,
          code: typeof errorCode === 'string' ? errorCode : null,
          uncertain: method === 'POST' && response.status >= 500
        });
      }
      return { httpStatus: response.status, payload };
    } finally {
      clearTimeout(timeout);
    }
  }

  async getCatalog(countryCode = 'BJ', { force = false } = {}) {
    if (countryCode && typeof countryCode === 'object') {
      force = Boolean(countryCode.force);
      countryCode = 'BJ';
    }
    if (!this.apiKey) throw new Error('Payment provider is not configured');
    const expected = paymentCountry(countryCode);
    if (!expected) throw new Error('Payment catalogue unavailable');
    if (force || !this.catalogCache || this.now() - this.catalogFetchedAt >= CATALOG_TTL_MS) {
      const { httpStatus, payload } = await this.request(`${API_BASE}/countries`);
      if (httpStatus < 200 || httpStatus >= 300) throw new Error('Payment catalogue unavailable');
      const countries = Array.isArray(payload) ? payload : payload?.countries;
      if (!Array.isArray(countries)) throw new Error('Payment catalogue unavailable');
      const catalog = {};
      for (const config of Object.values(PAYMENT_COUNTRIES)) {
        const metadata = countries.find(country => country?.code === config.code);
        if (!metadata || paymentCountry(metadata.name)?.code !== config.code ||
            metadata.currency !== config.currency ||
            !Array.isArray(metadata.operators)) continue;
        const unavailableOperators = new Set(
          Array.isArray(metadata.unavailable_operators)
            ? metadata.unavailable_operators.filter(operator =>
              typeof operator === 'string').map(operator => operator.trim())
            : []
        );
        const operators = metadata.operators.filter(operator =>
          typeof operator === 'string' && operator.trim().length > 0 &&
          !unavailableOperators.has(operator.trim()));
        if (operators.length) {
          catalog[config.code] = {
            code: config.code, name: config.name, currency: config.currency, operators
          };
        }
      }
      this.catalogCache = catalog;
      this.catalogFetchedAt = this.now();
    }
    const result = this.catalogCache[expected.code];
    if (!result) throw new Error('Payment catalogue unavailable');
    return result;
  }

  async createPayment({ amount, currency, countryCode, operator, phone, reference, otp }) {
    const body = {
      amount, currency, country_code: countryCode, operator, phone, reference, notify_url: this.notifyUrl
    };
    if (otp !== undefined) body.otp = otp;
    const response = await this.request(`${API_BASE}/collect`, { method: 'POST', body });
    const transaction = normalizeTransaction(response.payload);
    const objects = payloadObjects(response.payload);
    if (transaction.simulated) {
      return { kind: 'verification_pending', transactionId: null, sessionReference: null, simulated: true };
    }
    // The catalogue does not publish per-operator flow guarantees. Never expose
    // an external validation link for Niger, including new redirect variants.
    if (countryCode === 'NE' && (
      ['wave', 'redirect', 'checkout', 'hosted_checkout'].includes(transaction.flow) ||
      objects.some(object => object.requires_redirect === true) ||
      ['wave_url', 'checkout_url', 'redirect_url', 'payment_url'].some(key =>
        objects.some(object => typeof object[key] === 'string' && object[key].trim()))
    )) {
      return {
        kind: 'requires_redirect',
        transactionId: transaction.transactionId,
        sessionReference: transaction.merchantReference
      };
    }
    if (response.httpStatus === 400 && transaction.error === 'otp_required' && transaction.merchantReference) {
      return {
        kind: 'otp_required',
        sessionReference: transaction.merchantReference,
        ussdCode: transaction.ussdCode
      };
    }
    if (response.httpStatus === 400 && transaction.error === 'invalid_otp') return { kind: 'invalid_otp' };
    if (response.httpStatus === 400 && transaction.error === 'otp_expired') return { kind: 'otp_expired' };
    if (response.httpStatus === 400) {
      throw new AshtechApiError({ status: 400, code: transaction.error || null });
    }
    if (response.httpStatus === 202 && transaction.status === 'pending') {
      const waveUrl = transaction.flow === 'wave' ? firstValue(objects, ['wave_url']) : undefined;
      if (transaction.flow === 'wave') {
        return {
          kind: 'wave',
          transactionId: transaction.transactionId,
          sessionReference: transaction.merchantReference,
          waveUrl: validWaveUrl(waveUrl) ? waveUrl : null
        };
      }
      return {
        kind: 'pending',
        transactionId: transaction.transactionId,
        sessionReference: transaction.merchantReference
      };
    }
    if (transaction.status === 'success') {
      return { kind: 'verification_pending', transactionId: transaction.transactionId, sessionReference: transaction.merchantReference };
    }
    return { kind: 'verification_pending', transactionId: transaction.transactionId, sessionReference: transaction.merchantReference };
  }

  async getPaymentStatus(transactionId) {
    const { httpStatus, payload } = await this.request(`${API_BASE}/transaction/${encodeURIComponent(transactionId)}`);
    const transaction = normalizeTransaction(payload, { requireMerchantReference: true });
    if (!['pending', 'success', 'failed'].includes(transaction.status) || transaction.simulated) {
      throw new AshtechApiError({ status: httpStatus });
    }
    return transaction;
  }

  async verifyPayment(transactionId) {
    return this.getPaymentStatus(transactionId);
  }

  async handleWebhook({ headers, rawBody }) {
    const signature = verifyWebhookSignature({
      headers, rawBody, secret: this.webhookSecret, now: this.now()
    });
    if (!signature.valid) return { valid: false, reason: signature.reason };
    let payload;
    try { payload = JSON.parse(rawBody.toString('utf8')); } catch {
      return { valid: false, reason: 'invalid_json' };
    }
    const objects = payloadObjects(payload);
    const type = firstValue(objects, ['event', 'event_type', 'eventType']) ||
      firstValue(objects, ['type']);
    const normalized = normalizeTransaction(payload, { webhook: true });
    if (typeof type !== 'string') return { valid: false, reason: 'invalid_event' };
    return {
      valid: true,
      eventId: signature.eventId,
      eventType: type.toLowerCase(),
      transaction: normalized
    };
  }
}

module.exports = {
  AshtechPaymentProvider,
  API_BASE,
  BENIN_OPERATORS,
  CATALOG_TTL_MS,
  REDIRECT_MESSAGE,
  REQUEST_TIMEOUT_MS,
  WEBHOOK_TOLERANCE_SECONDS,
  REAL_TEST_WARNING,
  AshtechApiError,
  identityMatches,
  isVerifiedSuccess,
  normalizeTransaction,
  retryAfterMilliseconds,
  signedWebhook,
  validNotifyUrl,
  validWaveUrl,
  webhookMapsToOrder,
  verifyWebhookSignature
};