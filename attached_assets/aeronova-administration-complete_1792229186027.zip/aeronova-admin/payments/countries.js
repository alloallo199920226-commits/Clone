'use strict';

const PAYMENT_COUNTRIES = Object.freeze({
  BJ: Object.freeze({
    code: 'BJ',
    name: 'Bénin',
    currency: 'XOF',
    dialCode: '+229',
    aliases: ['Bénin', 'Benin']
  }),
  CM: Object.freeze({
    code: 'CM',
    name: 'Cameroun',
    currency: 'XAF',
    dialCode: '+237',
    aliases: ['Cameroun', 'Cameroon']
  }),
  CI: Object.freeze({
    code: 'CI',
    name: "Côte d'Ivoire",
    currency: 'XOF',
    dialCode: '+225',
    aliases: ["Côte d'Ivoire", "Cote d'Ivoire", 'Côte d’Ivoire', 'Cote d’Ivoire', 'Ivory Coast']
  }),
  TG: Object.freeze({
    code: 'TG',
    name: 'Togo',
    currency: 'XOF',
    dialCode: '+228',
    aliases: ['Togo', 'Republic of Togo']
  }),
  NE: Object.freeze({
    code: 'NE',
    name: 'Niger',
    currency: 'XOF',
    dialCode: '+227',
    aliases: ['Niger', 'Republic of Niger', 'République du Niger']
  })
});

function normalizeCountryName(value) {
  return String(value || '').trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('fr');
}

function paymentCountry(value) {
  const normalized = normalizeCountryName(value);
  for (const country of Object.values(PAYMENT_COUNTRIES)) {
    if (normalized === country.code.toLocaleLowerCase('fr') ||
        country.aliases.some(alias => normalized === normalizeCountryName(alias))) return country;
  }
  return null;
}

function countryForOrder(code, currency) {
  const country = paymentCountry(code);
  return country && country.currency === String(currency || '').toUpperCase() ? country : null;
}

function normalizePaymentPhone(countryCode, value) {
  const country = paymentCountry(countryCode);
  if (!country) return null;
  const input = String(value || '').trim();
  let national;
  const prefix = country.dialCode;
  if (input.startsWith('+')) {
    const match = new RegExp(`^\\${prefix}(\\d+)$`).exec(input);
    if (!match) return null;
    national = match[1];
  } else if (/^00/.test(input)) {
    const match = new RegExp(`^00${prefix.slice(1)}(\\d+)$`).exec(input);
    national = match ? match[1] : input;
  } else {
    national = input;
  }
  const valid = country.code === 'BJ'
    ? /^\d{8}(?:\d{2})?$/.test(national)
    : country.code === 'CM'
    ? /^6\d{8}$/.test(national)
    : country.code === 'TG' || country.code === 'NE'
    ? /^\d{8}$/.test(national)
    : /^0\d{9}$/.test(national);
  return valid ? `${prefix}${national}` : null;
}

module.exports = { PAYMENT_COUNTRIES, countryForOrder, normalizePaymentPhone, paymentCountry };