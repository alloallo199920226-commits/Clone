'use strict';

const CONFIRMATION_WINDOW_MS = 8 * 60 * 1000;

function confirmationWindow(order, now = Date.now()) {
  const empty = { confirmationExpiresAt: null, confirmationRemainingMs: null, confirmationExpired: false };
  if (['succeeded', 'failed', 'requires_redirect'].includes(order.status)) return empty;
  if (order.status === 'created' && !order.initiation_attempted) return empty;
  const start = order.initiation_started_at || (order.initiation_attempted ? order.created_at : null);
  if (!start) return empty;
  const startedAt = new Date(start).getTime();
  if (!Number.isFinite(startedAt)) return empty;
  const expiresAt = startedAt + CONFIRMATION_WINDOW_MS;
  return {
    confirmationExpiresAt: new Date(expiresAt).toISOString(),
    confirmationRemainingMs: Math.max(0, Math.min(CONFIRMATION_WINDOW_MS, expiresAt - now)),
    confirmationExpired: now >= expiresAt
  };
}

module.exports = { CONFIRMATION_WINDOW_MS, confirmationWindow };