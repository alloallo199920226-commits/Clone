'use strict';

class PaymentProvider {
  async createPayment() { throw new Error('createPayment() must be implemented by a payment provider'); }
  async verifyPayment() { throw new Error('verifyPayment() must be implemented by a payment provider'); }
  async getPaymentStatus() { throw new Error('getPaymentStatus() must be implemented by a payment provider'); }
  async handleWebhook() { throw new Error('handleWebhook() must be implemented by a payment provider'); }
}

module.exports = { PaymentProvider };